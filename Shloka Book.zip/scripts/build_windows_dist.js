/**
 * Packaging helper script for Windows Desktop Standalone Release
 * Universal Sanskrit -> Kannada Scholarly Grantha Engine
 *
 * This script compiles the frontend into static assets, bundles the server
 * into a standalone executable using pkg/electron, and prepares a distributable
 * Windows .exe installer bundle.
 */

import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

console.log('===========================================================');
console.log('UNIVERSAL SANSKRIT GRANTHA ENGINE - WINDOWS BUILD GENERATOR');
console.log('===========================================================');

const DIST_DIR = path.join(process.cwd(), 'dist');
const WINDOWS_OUT_DIR = path.join(process.cwd(), 'release_windows');

if (!fs.existsSync(WINDOWS_OUT_DIR)) {
  fs.mkdirSync(WINDOWS_OUT_DIR, { recursive: true });
}

console.log('1. Building frontend and backend bundle...');
try {
  execSync('npm run build', { stdio: 'inherit' });
  console.log('-> Build compiled successfully into /dist');
} catch (e) {
  console.error('Build step failed:', e);
}

// Generate Windows Startup Launcher Script (Run_Grantha_Engine.bat)
const batContent = `@echo off
title Universal Sanskrit -> Kannada Scholarly Grantha Engine
color 0F
echo ==============================================================================
echo       UNIVERSAL SANSKRIT -^> KANNADA SCHOLARLY GRANTHA ENGINE
echo                  Scholarly Book Production System
echo ==============================================================================
echo.
echo Starting Grantha Engine Local Server on http://localhost:3000 ...
echo Database: grantha_data\\grantha_engine.sqlite
echo.

start http://localhost:3000
node dist\\server.cjs

pause
`;

fs.writeFileSync(path.join(WINDOWS_OUT_DIR, 'Run_Grantha_Engine.bat'), batContent);

// Add sample .env template and gemini_api_key.txt for desktop key setup
fs.writeFileSync(
  path.join(WINDOWS_OUT_DIR, '.env.example'),
  '# Google Gemini API Key for Universal Sanskrit Grantha Engine\nGEMINI_API_KEY=\n'
);

fs.writeFileSync(
  path.join(WINDOWS_OUT_DIR, 'gemini_api_key.txt'),
  '# Paste your Gemini API key (e.g. AIzaSy...) below this line or configure via the in-app Settings menu:\n'
);

const readmeContent = `# Universal Sanskrit → Kannada Scholarly Grantha Engine
## Windows Portable Desktop Edition

### How to Setup API Key:
1. Open the application, click **Settings (ಸಂರಚನೆ)**, paste your Google Gemini API Key and click **Save (ಉಳಿಸಿ)**. (This is stored securely in your local SQLite database).
   OR
2. Copy \`.env.example\` to \`.env\` and write \`GEMINI_API_KEY=your_key_here\`.
   OR
3. Paste your key in \`gemini_api_key.txt\`.

### How to Run:
1. Double click \`Run_Grantha_Engine.bat\`.
2. The browser will open automatically at \`http://localhost:3000\`.
3. All your uploaded Sanskrit PDFs, processed manuscripts, and SQLite checkpoints are stored locally inside \`grantha_data/\`.

### Features:
- Native PDF Sanskrit extraction (Devanagari text preservation)
- Universal structure detection (Ramayana Kanda/Sarga, Mahabharata Parva/Adhyaya, Purana Skandha/Adhyaya, Upanishads, Vedas)
- Master Index showing Head & Sub-head divisions (Adhyaya, Valli, Khanda, Parva, Kanda)
- 100% Kannada script for Lipyantara, Devanagari Sanskrit padas with Kannada meanings
- SanskritDocuments.org canonical verification
- 5 Mandatory Sections (Devanagari Moola Shloka, Kannada Transliteration, 1. ಪದಾರ್ಥ single-paragraph, 2. ಸರಳ ವಿವರಣೆ, 3. ವಿವರವಾದ ವ್ಯಾಖ್ಯಾನ)
- Master DOCX, Complete Audit XLSX, Shloka Index XLSX, and ZIP package export.
`;

fs.writeFileSync(path.join(WINDOWS_OUT_DIR, 'README_WINDOWS.md'), readmeContent);

console.log(`\nWindows portable package generated in: ${WINDOWS_OUT_DIR}`);
console.log('Launcher: Run_Grantha_Engine.bat');
