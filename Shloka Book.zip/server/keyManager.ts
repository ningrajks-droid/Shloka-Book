import fs from 'fs';
import path from 'path';
import { getSettings } from './db';

export interface KeyState {
  key: string;
  name: string;
  errorCount: number;
  rateLimitedUntil: number; // timestamp in ms
  lastUsed: number;         // timestamp in ms
  inFlight: number;         // active concurrent requests
  totalRequests: number;
  totalSuccesses: number;
  isExhausted: boolean;
}

export interface KeyPoolStatus {
  total: number;
  active: number;
  rateLimited: number;
  inFlight: number;
  hasAnyKey: boolean;
  keys: Array<{
    name: string;
    status: 'ACTIVE' | 'RATE_LIMITED' | 'COOLDOWN' | 'EXHAUSTED';
    inFlight: number;
    cooldownRemainingSec: number;
    successRate: string;
  }>;
}

export class KeyManager {
  private keys: Map<string, KeyState> = new Map();
  private currentIndex: number = 0;
  private readonly defaultCooldownMs = 15000; // 15 seconds default cooldown for 429

  constructor(initialKeys: string[] = []) {
    initialKeys.forEach((k, idx) => this.registerKey(k, idx + 1));
  }

  private registerKey(key: string, index?: number): KeyState {
    const trimmed = key.trim();
    if (!this.keys.has(trimmed)) {
      const idx = index ?? (this.keys.size + 1);
      const state: KeyState = {
        key: trimmed,
        name: `Key #${idx} (...${trimmed.slice(-4)})`,
        errorCount: 0,
        rateLimitedUntil: 0,
        lastUsed: 0,
        inFlight: 0,
        totalRequests: 0,
        totalSuccesses: 0,
        isExhausted: false,
      };
      this.keys.set(trimmed, state);
      return state;
    }
    return this.keys.get(trimmed)!;
  }

  /**
   * Discover and collect all configured API keys from environment variables,
   * local config files, and SQLite database settings.
   */
  public async getAllConfiguredKeys(): Promise<string[]> {
    const candidateKeys = new Set<string>();

    // 1. Check standard and numbered environment variables (e.g. GEMINI_API_KEY_1..5)
    const envVars = [
      process.env.GEMINI_API_KEY,
      process.env.GEMINI_API_KEYS,
      process.env.GOOGLE_API_KEY,
      process.env.API_KEY,
      process.env.GEMINI_KEY,
      process.env.GEMINI_API_KEY_1,
      process.env.GEMINI_API_KEY_2,
      process.env.GEMINI_API_KEY_3,
      process.env.GEMINI_API_KEY_4,
      process.env.GEMINI_API_KEY_5,
      process.env.GEMINI_API_KEY_6,
      process.env.GEMINI_API_KEY_7,
      process.env.GEMINI_API_KEY_8,
      process.env.GEMINI_API_KEY_9,
      process.env.GEMINI_API_KEY_10,
    ];

    for (const [k, v] of Object.entries(process.env)) {
      if (v && /^(GEMINI|GOOGLE_API|API_KEY)/i.test(k)) {
        envVars.push(v);
      }
    }

    for (const envVal of envVars) {
      if (envVal) {
        const split = envVal
          .split(/[\n,;\s]+/)
          .map((s) => s.trim().replace(/^["']|["']$/g, ''))
          .filter((s) => s.length > 5);
        for (const k of split) candidateKeys.add(k);
      }
    }

    // 2. Check local environment and persistent key files
    const envPaths = [
      path.join(process.cwd(), '.env'),
      path.join(process.cwd(), 'grantha_data', '.env'),
      path.join(process.cwd(), 'gemini_api_key.txt'),
      path.join(process.cwd(), 'gemini_api_keys.txt'),
      path.join(process.cwd(), 'api_keys.txt'),
      path.join(process.cwd(), 'grantha_data', 'gemini_key.txt'),
      path.join(process.cwd(), 'grantha_data', 'gemini_api_keys.txt'),
    ];

    for (const p of envPaths) {
      try {
        if (fs.existsSync(p)) {
          const content = fs.readFileSync(p, 'utf-8');
          const lines = content.split('\n');
          for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed || trimmed.startsWith('#')) continue;
            if (trimmed.includes('=')) {
              const [kName, ...rest] = trimmed.split('=');
              const val = rest.join('=').trim().replace(/^["']|["']$/g, '');
              if (
                /GEMINI|GOOGLE|API_KEY/i.test(kName) &&
                val.length > 5 &&
                !val.includes('YOUR_') &&
                !val.includes('your_api_key')
              ) {
                const subKeys = val
                  .split(/[\n,;\s]+/)
                  .map((s) => s.trim().replace(/^["']|["']$/g, ''))
                  .filter((s) => s.length > 5);
                for (const sk of subKeys) candidateKeys.add(sk);
              }
            } else if (trimmed.startsWith('AIzaSy') || trimmed.length >= 25) {
              const subKeys = trimmed
                .split(/[\n,;\s]+/)
                .map((s) => s.trim().replace(/^["']|["']$/g, ''))
                .filter((s) => s.length > 5);
              for (const sk of subKeys) candidateKeys.add(sk);
            }
          }
        }
      } catch {
        // Safe ignore for file read issues
      }
    }

    // 3. Check SQLite database persistent settings
    try {
      const settings = await getSettings();
      if (settings.apiKeys && Array.isArray(settings.apiKeys)) {
        for (const k of settings.apiKeys) {
          if (k && typeof k === 'string') {
            const subKeys = k
              .split(/[\n,;\s]+/)
              .map((s) => s.trim().replace(/^["']|["']$/g, ''))
              .filter((s) => s.length > 5);
            for (const sk of subKeys) candidateKeys.add(sk);
          }
        }
      }
    } catch {
      // Safe ignore
    }

    return Array.from(candidateKeys).filter((k) => k.length > 5);
  }

  /**
   * Sync active internal keys with configured sources.
   */
  private async syncKeys(): Promise<string[]> {
    const configured = await this.getAllConfiguredKeys();
    if (configured.length === 0) {
      if (process.env.GEMINI_API_KEY) {
        configured.push(process.env.GEMINI_API_KEY);
      }
    }

    // Add new keys
    configured.forEach((k, idx) => this.registerKey(k, idx + 1));

    // Cleanup removed keys
    for (const registeredKey of Array.from(this.keys.keys())) {
      if (!configured.includes(registeredKey)) {
        this.keys.delete(registeredKey);
      }
    }

    return configured;
  }

  /**
   * Check if any valid API key is configured anywhere in the project.
   */
  public async hasAnyConfiguredKey(): Promise<boolean> {
    const keys = await this.getAllConfiguredKeys();
    return keys.length > 0 || !!process.env.GEMINI_API_KEY;
  }

  /**
   * Get the next best available API key from the pool.
   * Utilizes least-in-flight and round-robin load distribution.
   * If all keys are in cooldown, gracefully waits or resets cooldown on the best key.
   */
  public async getNextApiKey(excludeKey?: string, waitIfCooling: boolean = true): Promise<string | undefined> {
    await this.syncKeys();
    const keyList = Array.from(this.keys.values());

    if (keyList.length === 0) {
      if (process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.length > 5) {
        this.registerKey(process.env.GEMINI_API_KEY);
        return process.env.GEMINI_API_KEY;
      }
      return undefined;
    }

    const now = Date.now();

    // 1. Filter candidates that are ready (not cooling down, not exhausted, and not excluded)
    const healthyCandidates = keyList.filter(
      (k) => k.key !== excludeKey && !k.isExhausted && k.rateLimitedUntil <= now
    );

    if (healthyCandidates.length > 0) {
      healthyCandidates.sort((a, b) => a.inFlight - b.inFlight || a.lastUsed - b.lastUsed);
      const chosen = healthyCandidates[0];
      chosen.lastUsed = now;
      chosen.inFlight++;
      chosen.totalRequests++;
      return chosen.key;
    }

    // 2. If all other keys are cooling down, try ANY key whose cooldown passed (including excluded one)
    const anyReady = keyList.filter((k) => !k.isExhausted && k.rateLimitedUntil <= now);
    if (anyReady.length > 0) {
      anyReady.sort((a, b) => a.inFlight - b.inFlight || a.lastUsed - b.lastUsed);
      const chosen = anyReady[0];
      chosen.lastUsed = now;
      chosen.inFlight++;
      chosen.totalRequests++;
      return chosen.key;
    }

    // 3. ALL configured keys are currently in cooldown or rate limited
    if (waitIfCooling) {
      // Find candidate with lowest remaining cooldown
      const remainingTimes = keyList.map((k) => Math.max(0, k.rateLimitedUntil - now));
      const minRemaining = Math.min(...remainingTimes);

      if (minRemaining > 0 && minRemaining <= 20000) {
        console.warn(`[KeyManager] ⏳ All ${keyList.length} API key(s) in cooldown. Waiting ${Math.ceil(minRemaining / 1000)}s for cooldown recovery...`);
        await new Promise((r) => setTimeout(r, minRemaining + 150));
      }

      // After wait (or if wait > 20s), unfreeze the best candidate
      const sortedByErrors = [...keyList].sort((a, b) => a.errorCount - b.errorCount || a.inFlight - b.inFlight);
      const best = sortedByErrors[0];
      best.rateLimitedUntil = 0;
      best.lastUsed = Date.now();
      best.inFlight++;
      best.totalRequests++;
      return best.key;
    }

    // Non-waiting caller: return least loaded key rather than failing
    const leastLoaded = [...keyList].sort((a, b) => a.inFlight - b.inFlight || a.errorCount - b.errorCount)[0];
    if (leastLoaded) {
      leastLoaded.inFlight++;
      leastLoaded.totalRequests++;
      return leastLoaded.key;
    }

    return undefined;
  }

  /**
   * Get the minimum remaining cooldown time in milliseconds across the pool.
   */
  public getMinRemainingCooldownMs(): number {
    const now = Date.now();
    const activeCooldowns = Array.from(this.keys.values())
      .map((k) => k.rateLimitedUntil - now)
      .filter((remain) => remain > 0);

    if (activeCooldowns.length === 0) return 0;
    return Math.min(...activeCooldowns);
  }

  /**
   * Mark a key as having completed an in-flight request.
   */
  public releaseKey(key: string) {
    const item = this.keys.get(key.trim());
    if (item && item.inFlight > 0) {
      item.inFlight--;
    }
  }

  /**
   * Report a 429 rate limit or quota throttle on a specific key.
   */
  public reportRateLimit(key: string, retryAfterSeconds?: number) {
    const item = this.keys.get(key.trim());
    if (item) {
      item.errorCount++;
      if (item.inFlight > 0) item.inFlight--;
      const cooldownSec = retryAfterSeconds && retryAfterSeconds > 0 ? retryAfterSeconds : 15;
      item.rateLimitedUntil = Date.now() + Math.max(cooldownSec, 5) * 1000;
      console.warn(
        `[KeyManager] ⚠️ ${item.name} rate-limited (429). Cooldown: ${cooldownSec}s. Active pool keys: ${this.getActiveKeyCount()}/${this.keys.size}`
      );
    }
  }

  /**
   * Report a 503 Service Unavailable / High Demand on a specific key.
   */
  public reportServerError(key: string, retryAfterSeconds: number = 6) {
    const item = this.keys.get(key.trim());
    if (item) {
      item.errorCount++;
      if (item.inFlight > 0) item.inFlight--;
      item.rateLimitedUntil = Date.now() + Math.max(retryAfterSeconds, 3) * 1000;
      console.warn(
        `[KeyManager] ⚠️ ${item.name} encountered 503 High Demand. Brief cooldown: ${retryAfterSeconds}s.`
      );
    }
  }

  /**
   * Report permanent or daily quota exhaustion.
   */
  public reportQuotaExhausted(key: string) {
    const item = this.keys.get(key.trim());
    if (item) {
      item.isExhausted = true;
      if (item.inFlight > 0) item.inFlight--;
      item.rateLimitedUntil = Date.now() + 60000; // 1 min check
      console.warn(
        `[KeyManager] ⚠️ ${item.name} marked quota exhausted. Rotating away from this key.`
      );
    }
  }

  /**
   * Report successful execution on an API key.
   */
  public reportSuccess(key: string) {
    const item = this.keys.get(key.trim());
    if (item) {
      if (item.inFlight > 0) item.inFlight--;
      item.errorCount = 0;
      item.isExhausted = false;
      item.rateLimitedUntil = 0;
      item.totalSuccesses++;
    }
  }

  /**
   * Return the count of currently healthy, non-throttled keys.
   */
  public getActiveKeyCount(): number {
    const now = Date.now();
    return Array.from(this.keys.values()).filter(
      (k) => !k.isExhausted && k.rateLimitedUntil <= now
    ).length;
  }

  /**
   * Diagnostic status report for the entire key pool.
   */
  public async getKeyStatuses(): Promise<KeyPoolStatus> {
    await this.syncKeys();
    const keyList = Array.from(this.keys.values());
    const now = Date.now();

    let active = 0;
    let rateLimited = 0;
    let totalInFlight = 0;

    const detailedKeys = keyList.map((k) => {
      const isLimited = k.rateLimitedUntil > now;
      const cooldownRemainingSec = isLimited
        ? Math.ceil((k.rateLimitedUntil - now) / 1000)
        : 0;

      let status: 'ACTIVE' | 'RATE_LIMITED' | 'COOLDOWN' | 'EXHAUSTED' = 'ACTIVE';
      if (k.isExhausted) {
        status = 'EXHAUSTED';
        rateLimited++;
      } else if (isLimited) {
        status = 'RATE_LIMITED';
        rateLimited++;
      } else {
        active++;
      }

      totalInFlight += k.inFlight;
      const rate =
        k.totalRequests > 0
          ? `${Math.round((k.totalSuccesses / k.totalRequests) * 100)}%`
          : '100%';

      return {
        name: k.name,
        status,
        inFlight: k.inFlight,
        cooldownRemainingSec,
        successRate: rate,
      };
    });

    const total = keyList.length;
    return {
      total,
      active: total > 0 ? (active || 1) : 0,
      rateLimited,
      inFlight: totalInFlight,
      hasAnyKey: total > 0,
      keys: detailedKeys,
    };
  }
}

export const keyManager = new KeyManager();


