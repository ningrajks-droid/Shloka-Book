import assert from 'node:assert/strict';
import { reconcileStructure, StructureClassification, StructureState } from './structureAi';
import { SanskritUnit } from '../src/types';

function unit(text: string, unitType: SanskritUnit['unitType'] = 'SHLOKA'): SanskritUnit {
  return {
    id: `test_${Math.random()}`,
    projectId: 'test', docId: 'doc', fileName: 'test.pdf', pageNumber: 1, unitIndex: 1,
    detectedWork: 'Test Grantha', unitType,
    structuralHierarchy: { level1Name: 'ಅಧ್ಯಾಯ', level1Value: 1, level3Name: 'ಶ್ಲೋಕ', formattedNumber: '1' },
    originalText: text, rawExtractedText: text, verifiedText: text, firstMeaningfulWord: text.split(/\s+/)[0] || '',
    status: 'PENDING', confidence: 'HIGH', validationScore: 0, validationIssues: [],
    timestamps: { created: new Date().toISOString(), updated: new Date().toISOString() },
  };
}

const baseState: StructureState = { documentType: 'SANSKRIT_BOOK', structurePath: [], currentHeadings: [] };

// AI recovers a missed heading.
{
  const u = unit('ब्रह्मविद्यायाः स्वरूपम्', 'SHLOKA');
  const ai: StructureClassification = {
    unitId: u.id, structureType: 'SECTION', isTitle: false, isMajorHeading: false,
    isSubHeading: true, isChapter: false, isSection: true, isVerse: false, isProse: false,
    isMetadata: false, isPageNoise: false, isOcrCorruption: false, headingLevel: 3,
    headingText: u.originalText, confidence: 0.96, reason: 'Semantic heading context.'
  };
  const r = reconcileStructure(u, ai, structuredClone(baseState));
  assert.equal(r.unit.unitType, 'HEADING');
  assert.equal(r.unit.structuralHierarchy.aiStructure?.confidenceBand, 'HIGH');
}

// AI rejects an offline heading when explicit verse numbering/context says it is a verse.
{
  const u = unit('ईशा वास्यमिदꣳ सर्वं ॥ 1 ॥', 'HEADING');
  const ai: StructureClassification = {
    unitId: u.id, structureType: 'SHLOKA', isTitle: false, isMajorHeading: false,
    isSubHeading: false, isChapter: false, isSection: false, isVerse: true, isProse: false,
    isMetadata: false, isPageNoise: false, isOcrCorruption: false, confidence: 0.98,
    reason: 'Explicit verse numbering and continuous verse syntax.'
  };
  const r = reconcileStructure(u, ai, structuredClone(baseState));
  assert.equal(r.unit.unitType, 'SHLOKA');
}

// High-confidence AI corrects a false offline heading.
{
  const u = unit('तदेजति तन्नैजति तद्दूरे तद्वन्तिके ॥ 5 ॥', 'HEADING');
  const ai: StructureClassification = {
    unitId: u.id, structureType: 'SHLOKA', isTitle: false, isMajorHeading: false,
    isSubHeading: false, isChapter: false, isSection: false, isVerse: true, isProse: false,
    isMetadata: false, isPageNoise: false, isOcrCorruption: false, confidence: 0.99,
    reason: 'Continuous numbered verse.'
  };
  const r = reconcileStructure(u, ai, structuredClone(baseState));
  assert.equal(r.unit.unitType, 'SHLOKA');
}

// Low-confidence disagreement does not erase an explicit structural marker.
{
  const u = unit('द्वितीयोऽध्यायः', 'SHLOKA');
  const ai: StructureClassification = {
    unitId: u.id, structureType: 'PROSE', isTitle: false, isMajorHeading: false,
    isSubHeading: false, isChapter: false, isSection: false, isVerse: false, isProse: true,
    isMetadata: false, isPageNoise: false, isOcrCorruption: false, confidence: 0.42,
    reason: 'Insufficient context.'
  };
  const r = reconcileStructure(u, ai, structuredClone(baseState));
  assert.equal(r.unit.unitType, 'HEADING');
}

// Structure state persists and evolves across heading transitions.
{
  const state = structuredClone(baseState);
  const u = unit('प्रथमः खण्डः', 'SHLOKA');
  const ai: StructureClassification = {
    unitId: u.id, structureType: 'SECTION', isTitle: false, isMajorHeading: true,
    isSubHeading: false, isChapter: false, isSection: true, isVerse: false, isProse: false,
    isMetadata: false, isPageNoise: false, isOcrCorruption: false, headingLevel: 2,
    headingText: u.originalText, structurePath: ['Book', 'खण्ड 1'], confidence: 0.97,
    reason: 'Explicit section heading.'
  };
  const r = reconcileStructure(u, ai, state);
  assert.deepEqual(r.state.structurePath, ['Book', 'खण्ड 1']);
  assert.equal(r.state.currentHeadings.length, 1);
}

console.log('structureAi tests: PASS (5/5)');
