/**
 * Deterministic, authentic Sanskrit Devanagari to Kannada script transliterator & Padartha Engine.
 * Adheres strictly to Sanskrit phonetic preservation in Kannada script.
 * Enforces English digits throughout (0-9).
 * Eliminates corrupt Unicode artifacts, replacement characters, and ensures symmetric shloka formatting.
 */

export const DEVA_TO_KAN_MAP: Record<string, string> = {
  // Independent Vowels
  'अ': 'ಅ', 'आ': 'ಆ', 'इ': 'ಇ', 'ई': 'ಈ', 'उ': 'ಉ', 'ऊ': 'ಊ',
  'ऋ': 'ಋ', 'ॠ': 'ೠ', 'ऌ': 'ಌ', 'ॡ': 'ೡ',
  'ए': 'ಏ', 'ऐ': 'ಐ', 'ओ': 'ಓ', 'औ': 'ಔ',

  // Consonants
  'क': 'ಕ', 'ख': 'ಖ', 'ग': 'ಗ', 'घ': 'ಘ', 'ङ': 'ಙ',
  'च': 'ಚ', 'छ': 'ಛ', 'ज': 'ಜ', 'झ': 'ಝ', 'ञ': 'ಞ',
  'ट': 'ಟ', 'ठ': 'ಠ', 'ड': 'ಡ', 'ढ': 'ಢ', 'ण': 'ಣ',
  'त': 'ತ', 'थ': 'ಥ', 'द': 'ದ', 'ध': 'ಧ', 'न': 'ನ',
  'प': 'ಪ', 'फ': 'ಫ', 'ब': 'ಬ', 'भ': 'ಭ', 'म': 'ಮ',
  'य': 'ಯ', 'र': 'ರ', 'ल': 'ಲ', 'व': 'ವ',
  'श': 'ಶ', 'ष': 'ಷ', 'स': 'ಸ', 'ह': 'ಹ',
  'ळ': 'ಳ',

  // Dependent Vowel Signs (Matras)
  'ा': 'ಾ', 'ि': 'ಿ', 'ी': 'ೀ', 'ु': 'ು', 'ू': 'ೂ',
  'ृ': 'ೃ', 'ॄ': 'ೄ', 'ॢ': 'ೢ', 'ॣ': 'ೣ',
  'े': 'ೇ', 'ै': 'ೈ', 'ो': 'ೋ', 'ौ': 'ೌ',

  // Virama / Halanta
  '्': '್',

  // Modifiers
  'ं': 'ಂ', // Anusvara
  'ः': 'ಃ', // Visarga
  'ँ': 'ಁ', // Chandrabindu
  'ऽ': 'ಽ', // Avagraha
  'ॐ': 'ಓಂ', // Om
  '़': '', // Nukta

  // Vedic Accents & Modifiers (map cleanly or preserve)
  '॑': '', // Udatta
  '॒': '', // Anudatta
  '᳚': '', // Svarita

  // Devanagari Numerals -> English Digits (Requirement: English Digits Only!)
  '०': '0', '१': '1', '२': '2', '३': '3', '४': '4',
  '५': '5', '६': '6', '७': '7', '८': '8', '९': '9',
  
  // Kannada Numerals -> English Digits
  '೦': '0', '೧': '1', '೨': '2', '೩': '3', '೪': '4',
  '೫': '5', '೬': '6', '೭': '7', '೮': '8', '೯': '9',

  // Punctuation
  '।': ' । ',
  '॥': ' ॥ ',
};

export const KAN_TO_DEVA_MAP: Record<string, string> = {
  // Independent Vowels
  'ಅ': 'अ', 'ಆ': 'आ', 'ಇ': 'इ', 'ಈ': 'ई', 'ಉ': 'उ', 'ಊ': 'ऊ',
  'ಋ': 'ऋ', 'ೠ': 'ॠ', 'ಌ': 'ऌ', 'ೡ': 'ॡ',
  'ಎ': 'ए', 'ಏ': 'ए', 'ಐ': 'ऐ', 'ಒ': 'ओ', 'ಓ': 'ओ', 'ಔ': 'औ',

  // Consonants
  'ಕ': 'क', 'ಖ': 'ख', 'ಗ': 'ग', 'ಘ': 'घ', 'ಙ': 'ङ',
  'ಚ': 'च', 'ಛ': 'छ', 'ಜ': 'ज', 'ಝ': 'झ', 'ಞ': 'ञ',
  'ಟ': 'ट', 'ಠ': 'ठ', 'ಡ': 'ड', 'ಢ': 'ढ', 'ಣ': 'ण',
  'ತ': 'त', 'ಥ': 'थ', 'ದ': 'द', 'ಧ': 'ध', 'ನ': 'न',
  'ಪ': 'प', 'ಫ': 'फ', 'ಬ': 'ब', 'ಭ': 'भ', 'ಮ': 'म',
  'ಯ': 'य', 'ರ': 'र', 'ಲ': 'ल', 'ವ': 'व',
  'ಶ': 'श', 'ಷ': 'ष', 'ಸ': 'स', 'ಹ': 'ह', 'ಳ': 'ळ',

  // Matras
  'ಾ': 'ा', 'ಿ': 'ि', 'ೀ': 'ी', 'ು': 'ु', 'ೂ': 'ू',
  'ೃ': 'ृ', 'ೄ': 'ॄ', 'ೢ': 'ॢ', 'ೣ': 'ॣ',
  'ೆ': 'े', 'ೇ': 'े', 'ೈ': 'ै', 'ೊ': 'ो', 'ೋ': 'ो', 'ೌ': 'ौ',

  // Halanta
  '್': '्',

  // Modifiers
  'ಂ': 'ं', 'ಃ': 'ः', 'ಁ': 'ँ', 'ಽ': 'ऽ',

  // Digits to English
  '೦': '0', '೧': '1', '೨': '2', '೩': '3', '೪': '4',
  '೫': '5', '೬': '6', '೭': '7', '೮': '8', '೯': '9',
};

/**
 * Sanitize raw Sanskrit text: remove Unicode replacement chars, BOM, nulls, and normalize
 */
export function sanitizeUnicodeText(text: string): string {
  if (!text) return '';
  return text
    .normalize('NFC')
    .replace(/\uFFFD/g, '')
    .replace(/[\u0000-\u0008\u000B-\u001F\u007F-\u009F\uFEFF]/g, '')
    .replace(/[\u200B\u200C\u200D\u2060]/g, '')
    .replace(/[\u00A0\u1680\u2000-\u200A\u202F\u205F\u3000]/g, ' ');
}

// Convert Devanagari and Kannada numerals to English digits
export function toEnglishDigits(text: string): string {
  if (!text) return '';
  return sanitizeUnicodeText(text)
    .replace(/[०-९]/g, (d) => String(d.charCodeAt(0) - 0x0966))
    .replace(/[೦-೯]/g, (d) => String(d.charCodeAt(0) - 0x0CE6));
}

/**
 * Convert Kannada text representing Sanskrit into pure Devanagari script
 */
export function kannadaToDevanagari(kannadaText: string): string {
  if (!kannadaText) return '';
  const sanitized = sanitizeUnicodeText(kannadaText);
  let result = '';
  for (let i = 0; i < sanitized.length; i++) {
    const char = sanitized[i];
    result += KAN_TO_DEVA_MAP[char] !== undefined ? KAN_TO_DEVA_MAP[char] : char;
  }
  return result;
}

/**
 * Transliterate Devanagari Sanskrit text to Kannada script accurately.
 * Guaranteed to output 100% Kannada script with standard dandas and English digits.
 */
export function devanagariToKannada(devanagariText: string): string {
  if (!devanagariText) return '';

  const sanitized = sanitizeUnicodeText(devanagariText);
  let result = '';
  const length = sanitized.length;
  let i = 0;

  while (i < length) {
    if (i + 1 < length) {
      const twoChar = sanitized.substring(i, i + 2);
      if (twoChar === '||' || twoChar === '//') {
        result += ' ॥ ';
        i += 2;
        continue;
      }
    }

    const char = sanitized[i];
    if (char === '|') {
      result += ' । ';
      i++;
      continue;
    }

    if (DEVA_TO_KAN_MAP[char] !== undefined) {
      result += DEVA_TO_KAN_MAP[char];
    } else if (/[A-Za-z]/.test(char)) {
      // Strip Latin/English alphabet noise from transliteration
    } else {
      result += char;
    }
    i++;
  }

  const standardized = standardizeKannadaOrthography(result);
  return formatSymmetricShlokaLines(toEnglishDigits(standardized)).trim();
}

/**
 * Standardizes Kannada orthography according to authentic classical & modern Kannada grammar rules.
 * Key rule: Homorganic nasal conjuncts before class consonants are replaced with standard Anusvara (ಅನುಸ್ವಾರ).
 * E.g.:
 * - ಖಣ್ಡ -> ಖಂಡ (ಖಣ್ಡಃ -> ಖಂಡಃ, ಖಣ್ಡದ -> ಖಂಡದ)
 * - ಶಾನ್ತಿ -> ಶಾಂತಿ (ಶಾನ್ತಿಃ -> ಶಾಂತಿಃ)
 * - ಆನನ್ದ -> ಆನಂದ (ಆನನ್ದಃ -> ಆನಂದಃ)
 * - ಸಮ್ಪೂರ್ಣ -> ಸಂಪೂರ್ಣ (ಸಮ್ಪೂರ್ಣಮ್ -> ಸಂಪೂರ್ಣಮ್)
 * - ಪಞ್ಚ -> ಪಂಚ
 * - ಮಙ್ಗಲ -> ಮಂಗಲ
 * - ಬನ್ಧ -> ಬಂಧ
 * - ಗ್ರನ್ಥ -> ಗ್ರಂಥ
 * - ಕಣ್ಠ -> ಕಂಠ, ಘಣ್ಟ -> ಘಂಟ, ದಣ್ಡ -> ದಂಡ, ಮಣ್ಡಲ -> ಮಂಡಲ, ಕುಣ್ಡಲ -> ಕುಂಡಲ
 */
export function standardizeKannadaOrthography(text: string): string {
  if (!text) return '';

  let res = text;

  // 1. Homorganic nasal conjuncts before class consonants (ವರ್ಗೀಯ ಪಂಚಮಾಕ್ಷರ -> ಅನುಸ್ವಾರ)
  // Guttural (ಕ-ವರ್ಗ): ಙ್ before ಕ, ಖ, ಗ, ಘ -> ಂ
  res = res.replace(/ಙ್[ಕಖಗಘ]/g, (match) => 'ಂ' + match.slice(2));

  // Palatal (ಚ-ವರ್ಗ): ಞ್ before ಚ, ಛ, ಜ, ಝ -> ಂ
  res = res.replace(/ಞ್[ಚಛಜಝ]/g, (match) => 'ಂ' + match.slice(2));

  // Retroflex (ಟ-ವರ್ಗ): ಣ್ before ಟ, ಠ, ಡ, ಢ -> ಂ
  res = res.replace(/ಣ್[ಟಠಡಢ]/g, (match) => 'ಂ' + match.slice(2));

  // Dental (ತ-ವರ್ಗ): ನ್ before ತ, ಥ, ದ, ಧ -> ಂ
  res = res.replace(/ನ್[ತಥದಧ]/g, (match) => 'ಂ' + match.slice(2));

  // Labial (ಪ-ವರ್ಗ): ಮ್ before ಪ, ಫ, ಬ, ಭ -> ಂ
  res = res.replace(/ಮ್[ಪಫಬಭ]/g, (match) => 'ಂ' + match.slice(2));

  // Double anusvara cleanup e.g. ಂಂ -> ಂ
  res = res.replace(/ಂ+/g, 'ಂ');

  // Anusvara followed by virama cleanup e.g. ಂ್ -> ಂ
  res = res.replace(/ಂ್/g, 'ಂ');

  return res;
}

/**
 * Universal Kannada Grammar and Spelling Correction Engine.
 * Scans, verifies, and corrects common spelling, typographic, and morphological errors across Kannada text.
 */
export function correctKannadaGrammarAndSpelling(text: string, isPadartha: boolean = false): string {
  if (!text) return '';

  // First apply orthographic standardization (anusvara substitution etc.)
  const res = standardizeKannadaOrthography(sanitizeUnicodeText(text));

  // If this is a Padartha string containing Devanagari padas (e.g. "खण्डः - ಎರಡನೆಯದಾದ ಭಾಗವು"),
  // protect Devanagari padas while ensuring Kannada meanings are pristine.
  if (isPadartha || /[\u0900-\u097F]/.test(res)) {
    const segments = res.split(/([,;\n\r]+)/);
    return segments.map((seg) => {
      const sepMatch = seg.match(/[-=—–:]/);
      if (sepMatch && sepMatch.index !== undefined) {
        const pada = seg.substring(0, sepMatch.index);
        const sep = seg[sepMatch.index];
        const artha = seg.substring(sepMatch.index + 1);
        return pada + sep + ' ' + correctKannadaGrammarAndSpelling(artha, false);
      }
      if (/^[,\s;\n\r]+$/.test(seg) || !/[\u0C80-\u0CFF]/.test(seg)) {
        return seg;
      }
      return applyKannadaSpellingAndGrammarRules(seg);
    }).join('');
  }

  return applyKannadaSpellingAndGrammarRules(res);
}

function applyKannadaSpellingAndGrammarRules(text: string): string {
  let res = text;

  // 1. Common Kannada Title / Section Typographical Fixes
  res = res.replace(/\bವಿವರಣೇ\b/g, 'ವಿವರಣೆ');
  res = res.replace(/\bವ್ಯಾಖ್ಯಾನಾ\b/g, 'ವ್ಯಾಖ್ಯಾನ');
  res = res.replace(/\bಪದಾರ್ಥಾ\b/g, 'ಪದಾರ್ಥ');
  res = res.replace(/\bತಾತ್ಪರ್ಯಾ\b/g, 'ತಾತ್ಪರ್ಯ');
  res = res.replace(/\bಶ್ಲೋಕಾ\b/g, 'ಶ್ಲೋಕ');
  res = res.replace(/\bಮಂತ್ರಾ\b/g, 'ಮಂತ್ರ');
  res = res.replace(/\bಉಪನಿಷದಾ\b/g, 'ಉಪನಿಷತ್');
  res = res.replace(/\bಖಣ್ಡ\b/g, 'ಖಂಡ');
  res = res.replace(/\bಖಣ್ಡಃ\b/g, 'ಖಂಡಃ');

  // 2. Specific philosophical and classical word spelling normalizations
  const specificReplacements: [RegExp, string | ((m: string) => string)][] = [
    [/\bಶಾನ್ತಿಃ?\b/g, (m: string) => m.endsWith('ಃ') ? 'ಶಾಂತಿಃ' : 'ಶಾಂತಿ'],
    [/\bಆನನ್ದಃ?\b/g, (m: string) => m.endsWith('ಃ') ? 'ಆನಂದಃ' : 'ಆನಂದ'],
    [/\bಸಮ್ಪೂರ್ಣ(ಮ್)?\b/g, (m: string) => m.endsWith('ಮ್') ? 'ಸಂಪೂರ್ಣಮ್' : 'ಸಂಪೂರ್ಣ'],
    [/\bಆರಮ್ಭ\b/g, 'ಆರಂಭ'],
    [/\bಸಮ್ಬನ್ಧ\b/g, 'ಸಂಬಂಧ'],
    [/\bಸಙ್ಕಲ್ಪ\b/g, 'ಸಂಕಲ್ಪ'],
    [/\bಅಙ್ಕ\b/g, 'ಅಂಕ'],
    [/\bಮಙ್ಗಲ\b/g, 'ಮಂಗಲ'],
    [/\bಪಞ್ಚ\b/g, 'ಪಂಚ'],
    [/\bಬನ್ಧು?\b/g, (m: string) => m.endsWith('ು') ? 'ಬಂಧು' : 'ಬಂಧ'],
    [/\bಗ್ರನ್ಥ\b/g, 'ಗ್ರಂಥ'],
    [/\bಅನ್ಧ\b/g, 'ಅಂಧ'],
    [/\bದನ್ತ\b/g, 'ದಂತ'],
    [/\bಕುಣ್ಡಲ\b/g, 'ಕುಂಡಲ'],
    [/\bಮಣ್ಡಲ\b/g, 'ಮಂಡಲ'],
    [/\bಕಣ್ಠ\b/g, 'ಕಂಠ'],
    [/\bಘಣ್ಟಾ?\b/g, 'ಘಂಟೆ'],
    [/\bಸಂಸ್ಕೃತಾ\b/g, 'ಸಂಸ್ಕೃತ'],
    [/\bಜ್ಞಾನಾ\b/g, 'ಜ್ಞಾನ'],
    [/\bಮೋಕ್ಷಾ\b/g, 'ಮೋಕ್ಷ'],
    [/\bಧರ್ಮಾ\b/g, 'ಧರ್ಮ'],
    [/\bಕರ್ಮಾ\b/g, 'ಕರ್ಮ'],
    [/\bಸೂತ್ರಾ\b/g, 'ಸೂತ್ರ'],
    [/\bವೇದಾ\b/g, 'ವೇದ'],
    [/\bಕಾರಣಾ\b/g, 'ಕಾರಣ'],
    [/\bಫಲಾ\b/g, 'ಫಲ'],
    [/\bಗುಣಾ\b/g, 'ಗುಣ'],
    [/\bರೂಪಾ\b/g, 'ರೂಪ'],
    [/\bಭಾವಾ\b/g, 'ಭಾವ'],
  ];

  for (const [pattern, replacement] of specificReplacements) {
    res = res.replace(pattern, replacement as any);
  }

  // 3. Punctuation and Spacing Polish
  // No space before punctuation, exactly one space after
  res = res.replace(/[ \t]+([,;:!?.])/g, '$1');
  res = res.replace(/([,;:!?])(?=[^\s\d।॥])/g, '$1 ');
  res = res.replace(/(\.)(?=[A-Za-z\u0C80-\u0CFF])/g, '$1 ');

  // Collapse multiple punctuation
  res = res.replace(/,{2,}/g, ',');
  res = res.replace(/\.{2,}/g, '.');
  res = res.replace(/[ \t]{2,}/g, ' ');

  // Clean dandas spacing
  res = res.replace(/[ \t]*।[ \t]*/g, ' । ');
  res = res.replace(/[ \t]*॥[ \t]*/g, ' ॥ ');

  return res.trim();
}

/**
 * Ensures a transliterated Kannada shloka is 100% pure Kannada script.
 */
export function ensurePureKannadaTransliteration(text: string, fallbackDevanagari?: string): string {
  if (!text || text.trim().length === 0) {
    return fallbackDevanagari ? devanagariToKannada(stripHierarchicalVerseHeader(fallbackDevanagari)) : '';
  }

  let cleaned = stripHierarchicalVerseHeader(sanitizeUnicodeText(text));

  if (/[\u0900-\u097F]/.test(cleaned)) {
    cleaned = devanagariToKannada(cleaned);
  }

  if (/[A-Za-z]/.test(cleaned) || !/[\u0C80-\u0CFF]/.test(cleaned)) {
    if (fallbackDevanagari) {
      cleaned = devanagariToKannada(stripHierarchicalVerseHeader(fallbackDevanagari));
    }
  }

  // Ensure ending verse number matches fallbackDevanagari if present e.g. ॥ 1.2.3 ॥
  if (fallbackDevanagari) {
    const endNumMatch = fallbackDevanagari.match(/॥\s*([0-9.]+)\s*॥\s*$/);
    if (endNumMatch && endNumMatch[1]) {
      const num = endNumMatch[1];
      if (!cleaned.includes(num)) {
        cleaned = cleaned.replace(/॥\s*([0-9.]+)?\s*॥\s*$/, `॥ ${num} ॥`);
      }
    }
  }

  const corrected = correctKannadaGrammarAndSpelling(cleaned);
  return formatSymmetricShlokaLines(toEnglishDigits(corrected)).trim();
}

/**
 * Ensures any Kannada text field contains pure Kannada script without Devanagari character bleed.
 */
export function ensurePureKannadaScript(text: string): string {
  if (!text) return '';
  let cleaned = sanitizeUnicodeText(text);
  if (/[\u0900-\u097F]/.test(cleaned)) {
    cleaned = cleaned.replace(/[\u0900-\u097F]+/g, (match) => devanagariToKannada(match));
  }
  const corrected = correctKannadaGrammarAndSpelling(cleaned);
  return toEnglishDigits(corrected).trim();
}

/**
 * Strips hierarchical verse/mantra headers like "मन्त्र ३ [I.ii.3]", "मन्त्र 1 [I.i.1]", "[I.ii.3]", "ಮಂತ್ರ ೩ [I.ii.3]"
 * from the start of a verse block.
 */
export function stripHierarchicalVerseHeader(text: string): string {
  if (!text) return '';
  let cleaned = text.trim();
  while (
    /^[ \t]*(?:(?:मन्त्र|मंत्र|श्लोक|verse|shloka|mantra|ಮಂತ್ರ|ಶ್ಲೋಕ)\s*[0-9०-९೦-೯]*\s*)?(?:\[[A-Za-z0-9.\-–]+\]|\([A-Za-z0-9.\-–]+\))[ \t]*(?:\r?\n|$)/i.test(
      cleaned
    )
  ) {
    cleaned = cleaned
      .replace(
        /^[ \t]*(?:(?:मन्त्र|मंत्र|श्लोक|verse|shloka|mantra|ಮಂತ್ರ|ಶ್ಲೋಕ)\s*[0-9०-९೦-೯]*\s*)?(?:\[[A-Za-z0-9.\-–]+\]|\([A-Za-z0-9.\-–]+\))[ \t]*(?:\r?\n|$)/i,
        ''
      )
      .trim();
  }
  return cleaned;
}

/**
 * Clean Sanskrit Devanagari text: ensure English digits, standard dandas, and clean line breaks.
 */
export function normalizeSanskritVerse(text: string): string {
  if (!text) return '';
  let cleaned = sanitizeUnicodeText(toEnglishDigits(text));

  // Strip any leading hierarchical verse headers e.g. "मन्त्र ३ [I.ii.3]"
  cleaned = stripHierarchicalVerseHeader(cleaned);

  if (/[\u0C80-\u0CFF]/.test(cleaned)) {
    cleaned = kannadaToDevanagari(cleaned);
  }
  
  cleaned = cleaned.replace(/\|\|/g, ' ॥ ');
  cleaned = cleaned.replace(/(?<![।|])\|(?![।|])/g, ' । ');
  cleaned = cleaned.replace(/॥\s*([0-9.]+)\s*॥/g, '॥ $1 ॥');
  cleaned = cleaned.replace(/।\s*([0-9.]+)\s*।/g, '। $1 ।');

  return formatSymmetricShlokaLines(cleaned);
}

/**
 * Ensures a Sanskrit Moola Shloka is 100% pure Devanagari script.
 */
export function ensurePureDevanagariScript(text: string): string {
  if (!text) return '';
  let cleaned = sanitizeUnicodeText(toEnglishDigits(text));
  cleaned = stripHierarchicalVerseHeader(cleaned);
  if (/[\u0C80-\u0CFF]/.test(cleaned)) {
    cleaned = kannadaToDevanagari(cleaned);
  }
  return formatSymmetricShlokaLines(cleaned).trim();
}

/**
 * Align shloka lines symmetrically so each quarter/hemistich has pristine presentation
 */
export function formatSymmetricShlokaLines(text: string): string {
  if (!text) return '';
  
  const rawLines = text.split(/\r?\n/);
  const formattedLines: string[] = [];

  for (const rawLine of rawLines) {
    const trimmed = rawLine.trim().replace(/\s+/g, ' ');
    if (!trimmed) continue;

    if (trimmed.includes('॥') && !trimmed.endsWith('॥') && !trimmed.endsWith('॥ ')) {
      const parts = trimmed.split('॥');
      const firstPart = parts[0]?.trim();
      const lastPart = parts.slice(1).join('॥').trim();
      if (firstPart) formattedLines.push(firstPart + ' ॥');
      if (lastPart) formattedLines.push(lastPart);
    } else {
      formattedLines.push(trimmed);
    }
  }

  return formattedLines.join('\n');
}

/**
 * Collapses extreme runaway repeating n-word patterns in linear time without regex backtracking.
 */
function collapseRepeatingWordSequences(text: string): string {
  const words = text.split(/\s+/);
  if (words.length < 20) return text;

  const resultWords: string[] = [];
  let i = 0;

  while (i < words.length) {
    let matchFound = false;

    const maxPatternLen = Math.min(15, Math.floor((words.length - i) / 6));
    for (let len = maxPatternLen; len >= 3; len--) {
      let isMatch = true;
      for (let k = 0; k < len; k++) {
        if (words[i + k] !== words[i + len + k]) {
          isMatch = false;
          break;
        }
      }

      if (isMatch) {
        let repeatCount = 2;
        while (i + repeatCount * len + len <= words.length) {
          let nextMatch = true;
          for (let k = 0; k < len; k++) {
            if (words[i + k] !== words[i + repeatCount * len + k]) {
              nextMatch = false;
              break;
            }
          }
          if (nextMatch) {
            repeatCount++;
          } else {
            break;
          }
        }

        if (repeatCount > 12) {
          for (let occ = 0; occ < 3; occ++) {
            for (let k = 0; k < len; k++) {
              resultWords.push(words[i + occ * len + k]);
            }
          }
          i += repeatCount * len;
          matchFound = true;
          break;
        }
      }
    }

    if (!matchFound) {
      resultWords.push(words[i]);
      i++;
    }
  }

  return resultWords.join(' ');
}

/**
 * Collapses extreme repeating substring chunks in linear time without regex
 */
function collapseRepeatingSubstrings(text: string): string {
  if (text.length < 100) return text;

  let current = text;
  for (const chunkLen of [25, 40, 60, 100]) {
    if (current.length < chunkLen * 12) continue;
    let i = 0;
    let modified = '';
    while (i < current.length) {
      if (i + chunkLen * 12 <= current.length) {
        let isRunaway = true;
        const baseChunk = current.slice(i, i + chunkLen);
        for (let r = 1; r < 12; r++) {
          if (current.slice(i + r * chunkLen, i + (r + 1) * chunkLen) !== baseChunk) {
            isRunaway = false;
            break;
          }
        }
        if (isRunaway) {
          let endIdx = i + chunkLen * 12;
          while (endIdx + chunkLen <= current.length && current.slice(endIdx, endIdx + chunkLen) === baseChunk) {
            endIdx += chunkLen;
          }
          modified += baseChunk.repeat(3);
          i = endIdx;
          continue;
        }
      }
      modified += current[i];
      i++;
    }
    current = modified;
  }
  return current;
}

/**
 * High-Performance, ReDoS-Safe Anti-Repetition and Loop Destroyer
 */
export function cleanRepetitiveLoops(text: string): string {
  if (!text) return '';
  let str = sanitizeUnicodeText(text).trim();

  if (str.length > 25000) {
    str = str.slice(0, 25000);
  }

  str = collapseRepeatingWordSequences(str);

  const sentenceDelim = /(?<=[.।॥!?\n])\s+/;
  const rawSentences = str.split(sentenceDelim);
  if (rawSentences.length > 1) {
    const deduped: string[] = [];
    const seenSentences = new Map<string, number>();
    let lastNorm = '';

    for (const s of rawSentences) {
      const trimmed = s.trim();
      if (!trimmed) continue;
      const norm = trimmed.replace(/[\s\p{P}]+/gu, ' ').trim().toLowerCase();
      if (!norm) continue;

      const consecutiveCount = (seenSentences.get(`_consec_${norm}`) || 0) + 1;
      if (norm === lastNorm && consecutiveCount > 6) {
        continue;
      }
      if (norm === lastNorm) {
        seenSentences.set(`_consec_${norm}`, consecutiveCount);
      } else {
        seenSentences.set(`_consec_${norm}`, 1);
      }

      const count = seenSentences.get(norm) || 0;
      if (count >= 25) {
        continue;
      }

      seenSentences.set(norm, count + 1);
      lastNorm = norm;
      deduped.push(trimmed);
    }
    str = deduped.join(' ');
  }

  str = collapseRepeatingSubstrings(str);
  return str.trim();
}

/**
 * Strict Title Cleaner & Length Limiter:
 */
export function cleanConciseTitle(title: string, maxLength: number = 80): string {
  if (!title) return '';
  let cleaned = cleanRepetitiveLoops(title);

  if (cleaned.includes(':')) {
    const parts = cleaned.split(':');
    const firstPart = parts[0]?.trim();
    const secondPart = parts[1]?.trim();
    if (firstPart && firstPart.length >= 8 && firstPart.length <= maxLength) {
      cleaned = firstPart;
    } else if (secondPart && secondPart.length <= maxLength) {
      cleaned = `${firstPart}: ${secondPart}`;
    }
  }

  if (cleaned.length > maxLength) {
    const truncated = cleaned.slice(0, maxLength);
    cleaned = truncated.replace(/[\s,;:–—]+[^\s]*$/, '').trim();
    if (cleaned.endsWith('(') || cleaned.endsWith('—') || cleaned.endsWith('-')) {
      cleaned = cleaned.slice(0, -1).trim();
    }
  }

  return cleaned;
}

/**
 * Shloka Number Extraction and Standardization:
 */
export function extractShlokaNumber(text: string): string | null {
  if (!text) return null;
  const sanitized = sanitizeUnicodeText(text);

  const endPattern = /[॥।|]\s*([0-9]+(?:\.[0-9]+)*)\s*[॥।|]/;
  const match = sanitized.match(endPattern);
  if (match && match[1]) {
    return match[1];
  }

  const fallbackPattern = /(?:^|\s)([0-9]+(?:\.[0-9]+)+|[0-9]+)(?:\s*[॥।|]|\s*$)/;
  const fallbackMatch = sanitized.match(fallbackPattern);
  if (fallbackMatch && fallbackMatch[1]) {
    return fallbackMatch[1];
  }

  return null;
}

/**
 * Standardize shloka ending punctuation with English digital numbers
 */
export function standardizeShlokaNumbering(text: string): string {
  if (!text) return '';
  let str = sanitizeUnicodeText(text);

  str = str.replace(/[॥।|]\s*([0-9]+(?:\.[0-9]+)*)\s*[॥।|]/g, (_m, num) => {
    return `॥ ${num} ॥`;
  });

  return str;
}

/**
 * Normalizes a Sanskrit word to its grammatical root/stem by stripping
 * terminal case markers (visarga, anusvara, virama+m), Vedic accents, and punctuation.
 */
export function normalizeSanskritStem(w: string): string {
  if (!w) return '';
  return w
    .replace(/[।॥|0-9०-೯\(\)\[\]\{\}\s.,;:!?"“”‘’_—–-]/g, '')
    .replace(/[\u0951\u0952\uA8E0-\uA8F7]/g, '')
    .replace(/[म्ंःम\u094D\u0902\u0903\u0C82\u0C83]+$/g, '')
    .replace(/^[्]+/, '')
    .toLowerCase()
    .trim();
}

export interface SanskritVerseAnalysis {
  tokens: string[];
  firstWord: string;
  lastWord: string;
  lastWordTokens: string[];
  totalWords: number;
  clauses: string[];
  repeatedWords: string[];
  isLongOrComplex: boolean;
}

/**
 * Robust Sanskrit structural & token boundary analysis.
 */
export function extractSanskritVerseAnalysis(moolaText: string): SanskritVerseAnalysis {
  if (!moolaText) {
    return {
      tokens: [],
      firstWord: '',
      lastWord: '',
      lastWordTokens: [],
      totalWords: 0,
      clauses: [],
      repeatedWords: [],
      isLongOrComplex: false,
    };
  }

  const rawClauses = moolaText
    .split(/(?<=[।॥|;\n])\s*/)
    .map((c) => c.replace(/[0-9०-೯॥|]/g, '').trim())
    .filter((c) => c.length > 0 && /[\u0900-\u097F]/.test(c));

  const cleanedText = moolaText
    .replace(/[।॥|0-9०-೯\(\)\[\]\{\}\s.,;:!?"“”‘’_—–-]/g, ' ')
    .replace(/[\u0951\u0952\uA8E0-\uA8F7]/g, '')
    .trim();

  const tokens = cleanedText
    .split(/\s+/)
    .map((w) => w.trim())
    .filter((w) => w.length > 0 && /[\u0900-\u097F]/.test(w));

  const firstWord = tokens[0] || '';
  const lastWord = tokens[tokens.length - 1] || '';
  const lastWordTokens = tokens.slice(-3);

  const freqMap = new Map<string, number>();
  for (const t of tokens) {
    const norm = t.replace(/[ःಂ]$/, '');
    if (norm.length >= 2) {
      freqMap.set(norm, (freqMap.get(norm) || 0) + 1);
    }
  }

  const repeatedWords: string[] = [];
  for (const [word, count] of freqMap.entries()) {
    if (count >= 2) {
      repeatedWords.push(word);
    }
  }

  const isLongOrComplex = tokens.length > 25 || rawClauses.length >= 3 || repeatedWords.length >= 3;

  return {
    tokens,
    firstWord,
    lastWord,
    lastWordTokens,
    totalWords: tokens.length,
    clauses: rawClauses,
    repeatedWords: repeatedWords.slice(0, 10),
    isLongOrComplex,
  };
}

export interface PadarthaCompletenessReport {
  isComplete: boolean;
  firstWord: string;
  lastWord: string;
  moolaWordCount: number;
  padarthaPadasCount: number;
  coverageRatio: number;
  reachedFirstWord: boolean;
  reachedLastWord: boolean;
  brokenPadas?: string[];
  missingWords?: string[];
  duplicatePairs?: string[];
  stoppedAtWord?: string;
  stoppedAtOccurrence?: number;
  stoppedAtClauseIndex?: number;
  stoppedAtClauseText?: string;
  nextTokenToContinue?: string;
  reason?: string;
}

export interface PadarthaAlignmentReport {
  totalWords: number;
  padasCount: number;
  stoppedAtMoolaIndex: number;
  lastAlignedPada?: string;
  lastAlignedToken?: string;
  occurrenceOfWord?: number;
  stoppedAtClauseIndex?: number;
  stoppedAtClauseText?: string;
  nextTokenToContinue?: string;
  remainingWordsCount: number;
  remainingClauses: string[];
}

/**
 * Sequential Monotonic Forward-March Alignment.
 */
export function analyzePadarthaSequentialAlignment(moolaText: string, padartha: string): PadarthaAlignmentReport {
  const analysis = extractSanskritVerseAnalysis(moolaText);
  const moolaTokens = analysis.tokens;

  const items = padartha.split(/[,;\n\r]+/).map((i) => i.trim()).filter(Boolean);
  const padas: string[] = [];
  for (const item of items) {
    const parts = item.split(/[-=—–:]/);
    if (parts.length >= 2) {
      const p = parts[0]?.replace(/[0-9०-೯\(\)\[\]\{\}\s.,;:!?"“”‘’_—–-]/g, '').trim();
      if (p && /[\u0900-\u097F]/.test(p)) {
        padas.push(p);
      }
    }
  }

  let moolaIdx = 0;
  const alignment: { pada: string; moolaIndex: number; moolaToken: string; occurrence: number }[] = [];
  const tokenOccurrences = new Map<string, number>();

  for (const pada of padas) {
    const pNorm = pada.replace(/[ःं\u0951\u0952]$/, '').toLowerCase();

    let matchIdx = -1;
    for (let i = moolaIdx; i < Math.min(moolaIdx + 12, moolaTokens.length); i++) {
      const tNorm = moolaTokens[i].replace(/[ःं\u0951\u0952]$/, '').toLowerCase();
      if (pNorm === tNorm || (pNorm.length >= 3 && tNorm.includes(pNorm)) || (tNorm.length >= 3 && pNorm.includes(tNorm))) {
        matchIdx = i;
        break;
      }
    }

    if (matchIdx !== -1) {
      moolaIdx = matchIdx + 1;
      const matchedToken = moolaTokens[matchIdx];
      const occ = (tokenOccurrences.get(matchedToken) || 0) + 1;
      tokenOccurrences.set(matchedToken, occ);
      alignment.push({ pada, moolaIndex: matchIdx, moolaToken: matchedToken, occurrence: occ });
    }
  }

  const lastAligned = alignment[alignment.length - 1];
  const stoppedAtMoolaIndex = lastAligned ? lastAligned.moolaIndex : -1;
  const remainingTokens = stoppedAtMoolaIndex >= 0 ? moolaTokens.slice(stoppedAtMoolaIndex + 1) : moolaTokens;
  const nextTokenToContinue = remainingTokens[0] || '';

  let currentClauseIdx = -1;
  let wordAcc = 0;
  for (let c = 0; c < analysis.clauses.length; c++) {
    const clauseWords = analysis.clauses[c].replace(/[।॥|0-9०-೯\(\)\[\]\{\}\s.,;:!?"“”‘’_—–-]/g, ' ').split(/\s+/).filter(Boolean);
    wordAcc += clauseWords.length;
    if (stoppedAtMoolaIndex < wordAcc) {
      currentClauseIdx = c;
      break;
    }
  }

  const validClauseIdx = currentClauseIdx >= 0 ? currentClauseIdx : 0;

  return {
    totalWords: moolaTokens.length,
    padasCount: padas.length,
    stoppedAtMoolaIndex,
    lastAlignedPada: lastAligned?.pada,
    lastAlignedToken: lastAligned?.moolaToken,
    occurrenceOfWord: lastAligned?.occurrence,
    stoppedAtClauseIndex: validClauseIdx + 1,
    stoppedAtClauseText: analysis.clauses[validClauseIdx],
    nextTokenToContinue,
    remainingWordsCount: remainingTokens.length,
    remainingClauses: analysis.clauses.slice(validClauseIdx),
  };
}

/**
 * Verifies whether Padartha covers the entire shloka from first word to final terminating word.
 */
export function verifyPadarthaCompleteness(moolaText: string, padartha: string): PadarthaCompletenessReport {
  const analysis = extractSanskritVerseAnalysis(moolaText);
  if (!padartha || padartha.trim().length === 0) {
    return {
      isComplete: false,
      firstWord: analysis.firstWord,
      lastWord: analysis.lastWord,
      moolaWordCount: analysis.totalWords,
      padarthaPadasCount: 0,
      coverageRatio: 0,
      reachedFirstWord: false,
      reachedLastWord: false,
      reason: 'ಪದಾರ್ಥವು ಸಂಪೂರ್ಣವಾಗಿ ಖಾಲಿಯಾಗಿದೆ (Padartha is completely empty).',
    };
  }

  const items = padartha.split(/[,;\n\r]+/).map((i) => i.trim()).filter(Boolean);
  const padas: string[] = [];
  const padasNormalized: string[] = [];

  for (const item of items) {
    const parts = item.split(/[-=—–:]/);
    if (parts.length >= 2) {
      const p = parts[0]?.replace(/[0-9०-೯\(\)\[\]\{\}\s.,;:!?"“”‘’_—–-]/g, '').trim();
      if (p && /[\u0900-\u097F]/.test(p)) {
        padas.push(p);
        padasNormalized.push(normalizeSanskritStem(p));
      }
    }
  }

  const duplicatePairs: string[] = [];
  for (let i = 2; i < padasNormalized.length; i++) {
    if (
      padasNormalized[i] &&
      padasNormalized[i] === padasNormalized[i - 1] &&
      padasNormalized[i] === padasNormalized[i - 2]
    ) {
      if (!duplicatePairs.includes(padas[i])) {
        duplicatePairs.push(padas[i]);
      }
    }
  }

  const moolaCount = analysis.totalWords;
  const padaCount = padas.length;
  const coverageRatio = moolaCount > 0 ? padaCount / moolaCount : 1;

  const alignment = analyzePadarthaSequentialAlignment(moolaText, padartha);

  const headPadas = padasNormalized.slice(0, 4);
  const firstTargetStem = normalizeSanskritStem(analysis.firstWord);
  let reachedFirstWord = false;

  for (const pStem of headPadas) {
    if (
      pStem === firstTargetStem ||
      (pStem.length >= 3 && firstTargetStem.startsWith(pStem)) ||
      (firstTargetStem.length >= 3 && pStem.startsWith(firstTargetStem)) ||
      firstTargetStem.includes(pStem)
    ) {
      reachedFirstWord = true;
      break;
    }
  }
  if (!reachedFirstWord && firstTargetStem) {
    for (const pStem of padasNormalized) {
      if (
        pStem === firstTargetStem ||
        (pStem.length >= 3 && firstTargetStem.includes(pStem)) ||
        (firstTargetStem.length >= 3 && pStem.includes(firstTargetStem))
      ) {
        reachedFirstWord = true;
        break;
      }
    }
  }

  const tailPadas = padasNormalized.slice(-6);
  const lastTargetStem = normalizeSanskritStem(analysis.lastWord);
  const altTargetStems = analysis.lastWordTokens.map((w) => normalizeSanskritStem(w));

  let reachedLastWord = false;
  for (const pStem of tailPadas) {
    if (
      pStem === lastTargetStem ||
      altTargetStems.includes(pStem) ||
      (pStem.length >= 3 && lastTargetStem.endsWith(pStem)) ||
      (lastTargetStem.length >= 3 && pStem.endsWith(lastTargetStem)) ||
      lastTargetStem.includes(pStem)
    ) {
      reachedLastWord = true;
      break;
    }
  }

  if (!reachedLastWord && lastTargetStem) {
    for (const pStem of padasNormalized) {
      if (
        pStem === lastTargetStem ||
        altTargetStems.includes(pStem) ||
        (pStem.length >= 4 && lastTargetStem.includes(pStem))
      ) {
        reachedLastWord = true;
        break;
      }
    }
  }

  const brokenPadas: string[] = [];
  for (const p of padas) {
    if (/^[\u093E-\u094F\u0901-\u0903]/.test(p)) {
      brokenPadas.push(p);
    }
  }

  const missingWords: string[] = [];
  for (const token of analysis.tokens) {
    const tStem = normalizeSanskritStem(token);
    if (tStem.length < 2) continue;
    const found = padasNormalized.some((pStem) => {
      return (
        pStem === tStem ||
        pStem.includes(tStem) ||
        tStem.includes(pStem) ||
        (pStem.length >= 3 && tStem.startsWith(pStem)) ||
        (tStem.length >= 3 && pStem.startsWith(tStem))
      );
    });
    if (!found) {
      missingWords.push(token);
    }
  }

  const lastFoundPada = padas[padas.length - 1] || '';
  const stoppedAtWord = reachedLastWord ? undefined : lastFoundPada;

  const isComplete =
    reachedFirstWord &&
    reachedLastWord &&
    brokenPadas.length === 0 &&
    duplicatePairs.length === 0 &&
    missingWords.length === 0 &&
    (moolaCount <= 4 || coverageRatio >= 0.50);

  let reason: string | undefined;
  if (!isComplete) {
    if (!reachedFirstWord) {
      reason = `ಶ್ಲೋಕದ ಮೊದಲ ಪದ '${analysis.firstWord}' ಬಿಟ್ಟುಹೋಗಿದೆ (Initial Sanskrit word '${analysis.firstWord}' missing from padartha).`;
    } else if (brokenPadas.length > 0) {
      reason = `ಪದಾರ್ಥದಲ್ಲಿ ವಿಕೃತ/ತುಂಡಾದ ಪದ ಕಂಡುಬಂದಿದೆ: [${brokenPadas.join(', ')}] (ಉದಾ: 'ोन्यां' ಬದಲಿಗೆ 'योन्यां' ಇರಬೇಕು).`;
    } else if (duplicatePairs.length > 0) {
      reason = `ಪದಾರ್ಥದಲ್ಲಿ ಒಂದೇ ಪದದ ಪುನರಾವರ್ತಿತ ಲೂಪ್ ಕಂಡುಬಂದಿದೆ: [${duplicatePairs.join(', ')}].`;
    } else if (missingWords.length > 0) {
      reason = `ಪದಾರ್ಥದಲ್ಲಿ 'Missing Word' ಎಚ್ಚರಿಕೆ: ಶ್ಲೋಕದಲ್ಲಿರುವ ಈ ಕೆಳಗಿನ ಪದಗಳು ಪದಾರ್ಥದಲ್ಲಿ ಬಿಟ್ಟುಹೋಗಿವೆ: [${missingWords.slice(0, 5).join(', ')}].`;
    } else if (!reachedLastWord) {
      const occText = alignment.occurrenceOfWord && alignment.occurrenceOfWord > 1
        ? ` (ಪುನರಾವರ್ತಿತ '${alignment.lastAlignedToken}' ಪದದ ${alignment.occurrenceOfWord}ನೇ ಬಾರಿ)`
        : '';
      const nextWordText = alignment.nextTokenToContinue ? ` -> ಮುಂದಿನ ಪದ '${alignment.nextTokenToContinue}' ನಿಂದ ಮುಂದುವರಿಯಬೇಕು` : '';
      reason = `ಪದಾರ್ಥವು '${lastFoundPada}'${occText} ನಲ್ಲಿ ನಿಂತಿದೆ ಮತ್ತು ಶ್ಲೋಕದ ಕೊನೆಯ ಪದ '${analysis.lastWord}' ವರೆಗೆ ತಲುಪಿಲ್ಲ${nextWordText}.`;
    } else if (coverageRatio < 0.50) {
      reason = `ಪದಾರ್ಥದಲ್ಲಿ ಮುಖ್ಯ ಸಂಸ್ಕೃತ ಪದಗಳ ಕವರೇಜ್ ಕಡಿಮೆಯಿದೆ (${Math.round(coverageRatio * 100)}%).`;
    }
  }

  return {
    isComplete,
    firstWord: analysis.firstWord,
    lastWord: analysis.lastWord,
    moolaWordCount: moolaCount,
    padarthaPadasCount: padaCount,
    coverageRatio,
    reachedFirstWord,
    reachedLastWord,
    brokenPadas: brokenPadas.length > 0 ? brokenPadas : undefined,
    missingWords: missingWords.length > 0 ? missingWords : undefined,
    duplicatePairs: duplicatePairs.length > 0 ? duplicatePairs : undefined,
    stoppedAtWord,
    stoppedAtOccurrence: alignment.occurrenceOfWord,
    stoppedAtClauseIndex: alignment.stoppedAtClauseIndex,
    stoppedAtClauseText: alignment.stoppedAtClauseText,
    nextTokenToContinue: alignment.nextTokenToContinue,
    reason,
  };
}

/**
 * Format Padartha section strictly with state-tracking:
 * Continuous single-paragraph comma-separated format.
 */
export function formatPadarthaWithDevanagariPadas(padarthaRaw: string): string {
  if (!padarthaRaw) return '';
  
  const cleaned = sanitizeUnicodeText(padarthaRaw)
    .replace(/^(\d+\.?\s*)?(ಪದಾರ್ಥ\s*[:\-])\s*/i, '')
    .trim();

  const sanitizePair = (rawPada: string, rawArtha: string): string | null => {
    let pada = rawPada?.trim().replace(/^[•\-\*\d+\.)\]\s]+/, '').trim();
    let artha = rawArtha?.trim();
    if (!pada || !artha) return null;

    if (/[\u0C80-\u0CFF]/.test(pada) && !/[\u0900-\u097F]/.test(pada) && /[\u0900-\u097F]/.test(artha) && !/[\u0C80-\u0CFF]/.test(artha)) {
      const temp = pada;
      pada = artha;
      artha = temp;
    }

    pada = pada.replace(/[\(（\[\{][^\)\]\}]+[\)）\]\}]/g, '').trim();

    if (/[\u0C80-\u0CFF]/.test(pada)) {
      pada = kannadaToDevanagari(pada);
    }

    pada = pada.replace(/^[\/\-–—:,\s]+|[\/\-–—:,\s]+$/g, '').trim();

    if (/^[\u093E-\u094F\u0901-\u0903]/.test(pada)) {
      if (pada.startsWith('ोन्यां')) {
        pada = 'य' + pada;
      } else if (pada.startsWith('ुञ्चामि')) {
        pada = 'प्रम' + pada;
      } else if (pada.startsWith('ञ्चामि')) {
        pada = 'प्रमु' + pada;
      } else if (pada.startsWith('्')) {
        pada = pada.replace(/^[्]+/, '');
      }
    }

    pada = pada.replace(/[A-Za-z]/g, '').replace(/^[.,;:!?\s]+|[.,;:!?\s]+$/g, '').trim();

    if (/[\u0900-\u097F]/.test(artha) && /[\u0C80-\u0CFF]/.test(artha)) {
      artha = artha.replace(/[\(（\[\{][\u0900-\u097F\s\d\-_,.]+[\)）\]\}]/g, '').trim();
      artha = artha.replace(/^[\u0900-\u097F\s\d।॥\-_–—:=]+\s*[-=—–:]*\s*/, '').trim();
      artha = artha.replace(/[\u0900-\u097F]+/g, (m) => devanagariToKannada(m));
    } else if (/[\u0900-\u097F]/.test(artha) && !/[\u0C80-\u0CFF]/.test(artha)) {
      artha = devanagariToKannada(artha);
    }

    artha = artha.replace(/[A-Za-z]/g, '').replace(/^[\/\-–—:=,\s]+|[\/\-–—:=,\s]+$/g, '').trim();
    artha = correctKannadaGrammarAndSpelling(artha, false);

    if (pada && artha) {
      return `${pada} - ${artha}`;
    }
    return null;
  };

  // Strategy 1: State-tracking Pair Scanner
  const items1: string[] = [];
  const pairScanner = /([^\n\r,;=—–:-]+?)\s*[-=—–:]\s*(.+?)(?=(?:[,;\n\r\s]+[•\-\*\d+\.)\]\s]*[\u0900-\u097F\u0C80-\u0CFF]+?\s*[-=—–:])|$)/g;
  let match: RegExpExecArray | null;
  while ((match = pairScanner.exec(cleaned)) !== null) {
    const pair = sanitizePair(match[1], match[2]);
    if (pair) items1.push(pair);
  }

  // Strategy 2: Line / Separator Split
  const items2: string[] = [];
  const rawLines = cleaned
    .split(/[\n\r]+|(?<=[^,\s])\s*[,;]\s*(?=[•\-\*\d+\.)\]\s]*[\u0900-\u097F\u0C80-\u0CFF]+\s*[-=—–:])/g)
    .map(s => s.trim())
    .filter(Boolean);

  for (const line of rawLines) {
    const lineMatch = line.match(/^[•\-\*\d+\.)\]\s]*([^-=—–:]+?)\s*[-=—–:]\s*(.+)$/);
    if (lineMatch) {
      const pair = sanitizePair(lineMatch[1], lineMatch[2]);
      if (pair) items2.push(pair);
    }
  }

  // Strategy 3: Parenthesized Pair Scanner
  const items3: string[] = [];
  if (items1.length < 2 && items2.length < 2) {
    const parenScanner = /([^\(\)\[\]\{\}（）,;\n]+?)\s*[\(\[（\{]([^\(\)\[\]\{\}）\}]+?)[\)\]）\}]/g;
    let pMatch: RegExpExecArray | null;
    while ((pMatch = parenScanner.exec(cleaned)) !== null) {
      const pair = sanitizePair(pMatch[1], pMatch[2]);
      if (pair) items3.push(pair);
    }
  }

  // Strategy 4: High-precision Lookahead Comma-split for standard continuous scholarly paragraph
  const items4: string[] = [];
  const commaTokens = cleaned.split(/,\s*(?=[\u0900-\u097F\u0C80-\u0CFF]+?\s*[-=—–:])/);
  for (const token of commaTokens) {
    const pIdx = token.search(/[-=—–:]/);
    if (pIdx > 0) {
      const p = token.substring(0, pIdx);
      const a = token.substring(pIdx + 1);
      const pair = sanitizePair(p, a);
      if (pair) items4.push(pair);
    }
  }

  let bestItems = items1;
  if (items2.length > bestItems.length) bestItems = items2;
  if (items4.length > bestItems.length) bestItems = items4;
  if (items3.length > bestItems.length) bestItems = items3;

  if (bestItems.length > 0) {
    return standardizeKannadaOrthography(toEnglishDigits(bestItems.join(', ')));
  }

  return standardizeKannadaOrthography(toEnglishDigits(cleaned.replace(/[A-Za-z]/g, '')));
}


// ============================================================
// PADARTHA AUTOMATIC CONTINUATION ENGINE
// ============================================================

export interface PadarthaToken {
  index: number;
  original: string;
  normalized: string;
  occurrence: number;
  clauseIndex: number;
}

export interface PadarthaChunkResult {
  chunkIndex: number;
  startTokenIndex: number;
  endTokenIndex: number;
  requestedTokens: string[];
  generatedPadartha: string;
  completedTokens: number[];
  nextTokenIndex: number;
  missingWords: string[];
  repeatedWords: string[];
  isComplete: boolean;
  rawVerification: PadarthaCompletenessReport;
}

export interface PadarthaGenerationState {
  moolaText: string;
  allTokens: PadarthaToken[];
  nextTokenIndex: number;
  chunkIndex: number;
  chunks: PadarthaChunkResult[];
  mergedPadartha: string;
  attempts: number;
  maxAttempts: number;
  maxTokensPerChunk: number;
  failedStates: Map<string, number>;
  finalVerification?: PadarthaCompletenessReport;
  completed: boolean;
  failureReason?: string;
}

/**
 * Sanskrit tokenizer with stable occurrence tracking
 */
export function tokenizeSanskritForPadartha(moolaText: string): PadarthaToken[] {
  const analysis = extractSanskritVerseAnalysis(moolaText);
  const occurrenceMap = new Map<string, number>();

  const clauseTokenLists = analysis.clauses.map((clause) =>
    clause
      .replace(/[।॥|0-9०-೯\(\)\[\]\{\}\s.,;:!?"“”‘’_—–-]/g, ' ')
      .split(/\s+/)
      .filter(Boolean)
  );

  const tokens: PadarthaToken[] = [];

  for (let i = 0; i < analysis.tokens.length; i++) {
    const original = analysis.tokens[i];
    const normalized = normalizeSanskritStem(original);

    if (!normalized) continue;

    const occurrence = (occurrenceMap.get(normalized) || 0) + 1;
    occurrenceMap.set(normalized, occurrence);

    let clauseIndex = 0;
    let running = 0;

    for (let c = 0; c < clauseTokenLists.length; c++) {
      running += clauseTokenLists[c].length;
      if (i < running) {
        clauseIndex = c;
        break;
      }
    }

    tokens.push({
      index: i,
      original,
      normalized,
      occurrence,
      clauseIndex,
    });
  }

  return tokens;
}

/**
 * Extract Sanskrit padas from generated Padartha
 */
export function extractPadarthaPadasStrict(padartha: string): string[] {
  if (!padartha) return [];
  const cleaned = sanitizeUnicodeText(padartha);
  const items = cleaned.split(/[,;\n\r]+/).map(x => x.trim()).filter(Boolean);
  const result: string[] = [];

  for (const item of items) {
    const separator = item.match(/[-=—–:]/);
    if (!separator || separator.index === undefined) continue;

    const pada = item
      .substring(0, separator.index)
      .replace(/[0-9०-೯\(\)\[\]\{\}\s.,;:!?"“”‘’_—–-]/g, '')
      .trim();

    if (!pada) continue;
    if (/[\u0900-\u097F]/.test(pada)) {
      result.push(pada);
    }
  }

  return result;
}

function normalizePadaForMatching(word: string): string {
  return normalizeSanskritStem(word)
    .replace(/[^\u0900-\u097F]/g, '')
    .trim()
    .toLowerCase();
}

function findNextTokenMatch(
  tokens: PadarthaToken[],
  target: string,
  fromIndex: number,
  maxLookahead: number = 32
): number {
  const targetNorm = normalizePadaForMatching(target);
  if (!targetNorm) return -1;

  const end = Math.min(tokens.length, fromIndex + maxLookahead + 1);

  for (let i = fromIndex; i < end; i++) {
    const tokenNorm = tokens[i].normalized;
    if (!tokenNorm) continue;
    if (tokenNorm === targetNorm) {
      return i;
    }

    if (
      targetNorm.length >= 4 &&
      tokenNorm.length >= 4 &&
      (targetNorm.includes(tokenNorm) || tokenNorm.includes(targetNorm))
    ) {
      return i;
    }
  }

  return -1;
}

/**
 * Align generated Padartha against original Sanskrit
 */
export function alignPadarthaAgainstMoola(
  moolaTokens: PadarthaToken[],
  padartha: string,
  startIndex: number
): {
  completedTokenIndices: number[];
  missingWords: string[];
  repeatedWords: string[];
  nextTokenIndex: number;
  lastMatchedIndex: number;
} {
  const padas = extractPadarthaPadasStrict(padartha);
  const completedTokenIndices: number[] = [];
  const missingWords: string[] = [];
  const repeatedWords: string[] = [];
  const usedOccurrences = new Map<string, number>();

  let cursor = startIndex;
  let lastMatchedIndex = startIndex - 1;

  for (const pada of padas) {
    const pNorm = normalizePadaForMatching(pada);
    if (!pNorm) continue;

    const matchIndex = findNextTokenMatch(moolaTokens, pNorm, cursor, 32);

    if (matchIndex < 0) {
      repeatedWords.push(pada);
      continue;
    }

    for (let i = cursor; i < matchIndex; i++) {
      const missing = moolaTokens[i];
      if (missing && missing.normalized.length >= 2) {
        missingWords.push(missing.original);
      }
    }

    const matchedToken = moolaTokens[matchIndex];
    const occurrenceKey = matchedToken.normalized;
    const generatedOccurrence = (usedOccurrences.get(occurrenceKey) || 0) + 1;
    usedOccurrences.set(occurrenceKey, generatedOccurrence);

    completedTokenIndices.push(matchIndex);
    cursor = matchIndex + 1;
    lastMatchedIndex = matchIndex;
  }

  return {
    completedTokenIndices,
    missingWords,
    repeatedWords,
    nextTokenIndex: cursor,
    lastMatchedIndex,
  };
}

/**
 * Build a SAFE Sanskrit chunk
 */
export function buildPadarthaChunk(
  tokens: PadarthaToken[],
  startIndex: number,
  maxTokens: number
): {
  startIndex: number;
  endIndex: number;
  tokens: PadarthaToken[];
  text: string;
} {
  if (startIndex >= tokens.length) {
    return {
      startIndex,
      endIndex: startIndex,
      tokens: [],
      text: '',
    };
  }

  let endIndex = Math.min(tokens.length, startIndex + maxTokens);

  const requestedClause = tokens[Math.max(startIndex, endIndex - 1)]?.clauseIndex;
  for (let i = endIndex - 1; i > startIndex; i--) {
    if (tokens[i].clauseIndex !== requestedClause) {
      endIndex = i;
      break;
    }
  }

  if (endIndex <= startIndex) {
    endIndex = Math.min(tokens.length, startIndex + maxTokens);
  }

  const selected = tokens.slice(startIndex, endIndex);

  return {
    startIndex,
    endIndex,
    tokens: selected,
    text: selected.map(t => t.original).join(' '),
  };
}

export function buildInitialPadarthaPrompt(
  chunkText: string,
  startIndex: number,
  endIndex: number,
  totalTokens: number
): string {
  return `
Generate Padartha ONLY for the Sanskrit words supplied below.

STRICT RULES:
1. Cover EVERY Sanskrit word sequentially.
2. Do NOT skip any word.
3. Do NOT merge two Sanskrit words into one entry.
4. Do NOT repeat a word unless it actually occurs repeatedly in the supplied Sanskrit.
5. Preserve the exact Sanskrit pada in Devanagari.
6. Give the meaning only in Kannada.
7. Format as ONE continuous paragraph.
8. Use: SanskritWord - Kannada meaning, SanskritWord - Kannada meaning
9. Do NOT add headings.
10. Do NOT add commentary.
11. Do NOT stop early.
12. If the supplied text is long, complete as many words as the output limit safely allows, but NEVER invent or omit words.
13. The supplied chunk begins at original Sanskrit token ${startIndex + 1}.
14. The supplied chunk ends before original Sanskrit token ${endIndex + 1}.
15. Total Sanskrit tokens in the complete source: ${totalTokens}.

SANSKRIT CHUNK:
${chunkText}
`.trim();
}

export function buildContinuationPadarthaPrompt(
  remainingText: string,
  nextTokenIndex: number,
  totalTokens: number,
  previousTail: string
): string {
  return `
CONTINUE PADARTHA FROM THE EXACT NEXT SANSKRIT WORD.

The previous Padartha generation stopped before original Sanskrit token ${nextTokenIndex + 1}.
Total Sanskrit tokens: ${totalTokens}.

IMPORTANT:
1. Start from the FIRST word supplied below.
2. Do NOT repeat any previously completed Sanskrit word.
3. Do NOT restart from the beginning.
4. Do NOT skip any word.
5. Preserve exact Sanskrit Devanagari.
6. Meaning must be Kannada only.
7. Output ONE continuous comma-separated paragraph.
8. Do NOT add a heading.
9. Do NOT add numbering.
10. Continue until the supplied remaining Sanskrit is covered or the model output limit is reached.
11. If output limit is reached, stop only after a complete Sanskrit-word/meaning pair.
12. Never invent a Sanskrit word.

Last accepted Padartha tail for context:
${previousTail}

NEXT SANSKRIT WORDS:
${remainingText}
`.trim();
}

/**
 * Remove accidental duplicate overlap between chunks
 */
export function removeChunkOverlap(
  existingPadartha: string,
  newPadartha: string
): string {
  if (!existingPadartha.trim()) {
    return formatPadarthaWithDevanagariPadas(newPadartha);
  }

  const existingPadas = extractPadarthaPadasStrict(existingPadartha);
  const newPadas = extractPadarthaPadasStrict(newPadartha);

  if (existingPadas.length === 0 || newPadas.length === 0) {
    return formatPadarthaWithDevanagariPadas(`${existingPadartha}, ${newPadartha}`);
  }

  const lastExisting = normalizePadaForMatching(existingPadas[existingPadas.length - 1]);
  let overlapCount = 0;

  for (let i = 0; i < newPadas.length; i++) {
    const current = normalizePadaForMatching(newPadas[i]);
    if (current === lastExisting) {
      overlapCount = i + 1;
    }
  }

  const trimmedNew = newPadas
    .slice(overlapCount)
    .map(p => {
      const regex = new RegExp(`${p}\\s*[-=—–:]\\s*[^,;\\n]+`, 'u');
      const match = newPadartha.match(regex);
      return match?.[0] || '';
    })
    .filter(Boolean)
    .join(', ');

  if (!trimmedNew.trim()) {
    return formatPadarthaWithDevanagariPadas(existingPadartha);
  }

  return formatPadarthaWithDevanagariPadas(`${existingPadartha}, ${trimmedNew}`);
}

function getPadarthaTail(padartha: string, maxPairs: number = 8): string {
  const items = padartha.split(/[,;\n\r]+/).map(x => x.trim()).filter(Boolean);
  return items.slice(-maxPairs).join(', ');
}

function makeFailureStateKey(tokenIndex: number, missingWords: string[]): string {
  return [
    tokenIndex,
    ...missingWords.slice(0, 10).map(normalizePadaForMatching),
  ].join('|');
}

export type PadarthaGenerator = (prompt: string) => Promise<string>;

/**
 * Main automatic continuation engine.
 */
export async function generatePadarthaAutomatically(
  moolaText: string,
  generate: PadarthaGenerator,
  options?: {
    maxTokensPerChunk?: number;
    maxAttempts?: number;
    maxLookahead?: number;
  }
): Promise<PadarthaGenerationState> {
  const maxTokensPerChunk = options?.maxTokensPerChunk ?? 60;
  const maxAttempts = options?.maxAttempts ?? 30;
  const moolaTokens = tokenizeSanskritForPadartha(moolaText);

  const state: PadarthaGenerationState = {
    moolaText,
    allTokens: moolaTokens,
    nextTokenIndex: 0,
    chunkIndex: 0,
    chunks: [],
    mergedPadartha: '',
    attempts: 0,
    maxAttempts,
    maxTokensPerChunk,
    failedStates: new Map(),
    completed: false,
  };

  if (moolaTokens.length === 0) {
    state.completed = true;
    state.finalVerification = verifyPadarthaCompleteness(moolaText, '');
    return state;
  }

  while (state.nextTokenIndex < moolaTokens.length && state.attempts < state.maxAttempts) {
    state.attempts++;
    state.chunkIndex++;

    const chunk = buildPadarthaChunk(moolaTokens, state.nextTokenIndex, state.maxTokensPerChunk);
    if (chunk.tokens.length === 0) {
      break;
    }

    const prompt = state.mergedPadartha.trim().length === 0
      ? buildInitialPadarthaPrompt(chunk.text, chunk.startIndex, chunk.endIndex, moolaTokens.length)
      : buildContinuationPadarthaPrompt(chunk.text, chunk.startIndex, moolaTokens.length, getPadarthaTail(state.mergedPadartha));

    let rawOutput = '';
    try {
      rawOutput = await generate(prompt);
    } catch (error) {
      state.failureReason = `Padartha API error: ${error instanceof Error ? error.message : String(error)}`;
      continue;
    }

    if (!rawOutput || !rawOutput.trim()) {
      state.failureReason = 'AI returned empty Padartha output.';
      continue;
    }

    const cleanedOutput = formatPadarthaWithDevanagariPadas(rawOutput);
    if (!cleanedOutput.trim()) {
      state.failureReason = 'AI Padartha became empty after sanitization.';
      continue;
    }

    const alignment = alignPadarthaAgainstMoola(moolaTokens, cleanedOutput, state.nextTokenIndex);
    const expectedStart = moolaTokens[state.nextTokenIndex];
    const firstGeneratedPada = extractPadarthaPadasStrict(cleanedOutput)[0];
    const firstGeneratedNorm = firstGeneratedPada ? normalizePadaForMatching(firstGeneratedPada) : '';
    const expectedNorm = expectedStart?.normalized || '';

    const startsCorrectly =
      !!firstGeneratedNorm &&
      (firstGeneratedNorm === expectedNorm ||
        firstGeneratedNorm.includes(expectedNorm) ||
        expectedNorm.includes(firstGeneratedNorm));

    const missingWords = alignment.missingWords;

    if (!startsCorrectly || missingWords.length > 0) {
      const failureKey = makeFailureStateKey(
        state.nextTokenIndex,
        missingWords.length > 0 ? missingWords : [expectedStart?.original || '']
      );

      const previousFailures = state.failedStates.get(failureKey) || 0;
      state.failedStates.set(failureKey, previousFailures + 1);

      if (previousFailures >= 2) {
        state.maxTokensPerChunk = Math.max(8, Math.floor(state.maxTokensPerChunk / 2));
      }

      if (previousFailures >= 5) {
        state.failureReason = `Padartha could not reliably continue at Sanskrit token ${state.nextTokenIndex + 1} (${expectedStart?.original || ''}). Missing words: ${missingWords.join(', ')}`;
        break;
      }
      continue;
    }

    const lastMatched = alignment.lastMatchedIndex;
    if (lastMatched < state.nextTokenIndex) {
      state.failureReason = 'AI output did not advance the Padartha cursor.';
      continue;
    }

    const acceptedTokenIndices = alignment.completedTokenIndices.filter(
      index => index >= state.nextTokenIndex && index <= lastMatched
    );

    if (acceptedTokenIndices.length === 0) {
      state.failureReason = 'No valid Sanskrit padas could be aligned.';
      continue;
    }

    const nextTokenIndex = lastMatched + 1;
    const repeatedWords: string[] = [];
    const occurrenceMap = new Map<string, number>();

    for (const tokenIndex of acceptedTokenIndices) {
      const token = moolaTokens[tokenIndex];
      const count = (occurrenceMap.get(token.normalized) || 0) + 1;
      occurrenceMap.set(token.normalized, count);

      if (count > moolaTokens.filter(t => t.normalized === token.normalized).length) {
        repeatedWords.push(token.original);
      }
    }

    const chunkResult: PadarthaChunkResult = {
      chunkIndex: state.chunkIndex,
      startTokenIndex: state.nextTokenIndex,
      endTokenIndex: lastMatched,
      requestedTokens: chunk.tokens.map(t => t.original),
      generatedPadartha: cleanedOutput,
      completedTokens: acceptedTokenIndices,
      nextTokenIndex,
      missingWords,
      repeatedWords,
      isComplete: nextTokenIndex >= moolaTokens.length,
      rawVerification: verifyPadarthaCompleteness(moolaText, cleanedOutput),
    };

    state.chunks.push(chunkResult);
    state.mergedPadartha = removeChunkOverlap(state.mergedPadartha, cleanedOutput);
    state.nextTokenIndex = nextTokenIndex;

    if (state.nextTokenIndex < chunk.endIndex) {
      state.maxTokensPerChunk = Math.max(8, Math.floor(state.maxTokensPerChunk * 0.75));
      continue;
    }

    if (state.nextTokenIndex >= moolaTokens.length) {
      break;
    }
  }

  state.finalVerification = verifyPadarthaCompleteness(moolaText, state.mergedPadartha);
  const finalMissing = state.finalVerification.missingWords || [];
  const finalComplete =
    state.finalVerification.isComplete &&
    finalMissing.length === 0 &&
    state.nextTokenIndex >= moolaTokens.length;

  if (finalComplete) {
    state.completed = true;
    state.failureReason = undefined;
  } else {
    state.completed = false;
    if (!state.failureReason) {
      state.failureReason =
        state.finalVerification.reason ||
        `Padartha incomplete. Next Sanskrit token: ${moolaTokens[state.nextTokenIndex]?.original || 'NONE'}`;
    }
  }

  return state;
}
