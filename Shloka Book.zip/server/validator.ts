import { SanskritUnit } from '../src/types';
import { verifyPadarthaCompleteness } from './transliteration';
import { extractExpectedSanskritWords, detectPadarthaCoverageAndMissing } from './padarthaEngine';

export interface ValidationReport {
  isValid: boolean;
  score: number; // 0 to 1
  issues: string[];
}

// Banned script character ranges
const BANNED_SCRIPTS_REGEX = /[\u0B80-\u0BFF\u0C00-\u0C7F\u0D00-\u0D7F\u0980-\u09FF\u0A80-\u0AFF\u0B00-\u0B7F\u0A00-\u0A7F]/; // Tamil, Telugu, Malayalam, Bengali, Gujarati, Odia, Gurmukhi

// Banned meta talk phrases in scholarly output
const BANNED_META_PHRASES = [
  'ai generated',
  'ai model',
  'ocr correction',
  'ocr error',
  'developer note',
  'system note',
  'review this',
  'source uncertain',
  'internal processing',
  'here is the explanation',
  'as an ai',
  'in this response',
  'ಈ ವಿವರಣೆಯನ್ನು ಕೃತಕ ಬುದ್ಧಿಮತ್ತೆ',
  'ಓಸಿಆರ್ ದೋಷ',
];

export function validateSanskritUnitOutput(unit: SanskritUnit): ValidationReport {
  const issues: string[] = [];
  const output = unit.output;

  if (!output) {
    return { isValid: false, score: 0, issues: ['No generated output found.'] };
  }

  // Headings and colophons do not undergo shloka padartha/vivarane checks
  if (unit.unitType === 'HEADING' || unit.unitType === 'COLOPHON') {
    return { isValid: true, score: 100, issues: [] };
  }

  // 1. Check Sanskrit Presence in Devanagari (Section 1: ಮೂಲ ಶ್ಲೋಕ)
  if (!output.moolaShloka || !/[\u0900-\u097F]/.test(output.moolaShloka)) {
    issues.push('ಮೂಲ ಶ್ಲೋಕ (Section 1) ದಲ್ಲಿ ದೇವನಾಗರಿ ಲಿಪಿ ಇರಬೇಕು (Missing Devanagari Sanskrit characters).');
  } else if (/[A-Za-z]/.test(output.moolaShloka)) {
    issues.push('ಮೂಲ ಶ್ಲೋಕದಲ್ಲಿ ಇಂಗ್ಲಿಷ್ ಅಕ್ಷರಗಳು ಕಂಡುಬಂದಿವೆ. ಕೇವಲ ದೇವನಾಗರಿ ಲಿಪಿ ಮಾತ್ರ ಇರಬೇಕು.');
  } else if (/[\u0C80-\u0CFF]/.test(output.moolaShloka)) {
    issues.push('ಮೂಲ ಸಂಸ್ಕೃತ ಶ್ಲೋಕದಲ್ಲಿ ಕನ್ನಡ ಅಕ್ಷರಗಳು ಕಂಡುಬಂದಿವೆ. ಕೇವಲ ದೇವನಾಗರಿ ಲಿಪಿ ಮಾತ್ರ ಇರಬೇಕು.');
  }

  // 2. Check Kannada Transliteration (Section 2: ಕನ್ನಡ ಲಿಪ್ಯಂತರ) - Strictly ONLY Kannada script
  if (!output.kannadaTransliteration || !/[\u0C80-\u0CFF]/.test(output.kannadaTransliteration)) {
    issues.push('ಕನ್ನಡ ಲಿಪ್ಯಂತರ (Section 2) is missing Kannada script transliteration.');
  } else if (/[A-Za-z]/.test(output.kannadaTransliteration)) {
    issues.push('ಕನ್ನಡ ಲಿಪ್ಯಂತರದಲ್ಲಿ ಇಂಗ್ಲಿಷ್ ಅಕ್ಷರಗಳು ಕಂಡುಬಂದಿವೆ (Kannada transliteration MUST be strictly in Kannada script, no English/Latin letters).');
  } else if (/[\u0900-\u097F]/.test(output.kannadaTransliteration)) {
    issues.push('ಕನ್ನಡ ಲಿಪ್ಯಂತರದಲ್ಲಿ ದೇವನಾಗರಿ ಅಕ್ಷರಗಳು ಕಂಡುಬಂದಿವೆ (Kannada transliteration MUST be strictly in pure Kannada script, no Devanagari letters).');
  }

  // 3. Strict Check: NO Padaccheda anywhere in output
  const allText = `${output.moolaShloka} ${output.kannadaTransliteration} ${output.padartha} ${output.saralaVivarane} ${output.vivaradaVyakhyana}`;
  if (/ಪದಚ್ಛೇದ|ಪದಛೇದ|पदच्छेद|Padaccheda|padacheda/i.test(allText)) {
    issues.push('Violation: Padaccheda section or heading detected. Padaccheda is strictly prohibited.');
  }

  // 4. Strict Check: Padartha MUST be ONE continuous paragraph with Devanagari Pada and Kannada Artha
  if (!output.padartha || output.padartha.trim().length < 10) {
    issues.push('1. ಪದಾರ್ಥ (Section 3) is missing or too short.');
  } else {
    // Check if padartha contains Devanagari script for Padas
    if (!/[\u0900-\u097F]/.test(output.padartha)) {
      issues.push('1. ಪದಾರ್ಥ ದಲ್ಲಿ ಸಂಸ್ಕೃತ ಪದಗಳು ದೇವನಾಗರಿ ಲಿಪಿಯಲ್ಲಿ ಇರಬೇಕು (Padartha must contain Sanskrit padas in Devanagari script).');
    }
    // Check if padartha contains Kannada script for Meanings
    if (!/[\u0C80-\u0CFF]/.test(output.padartha)) {
      issues.push('1. ಪದಾರ್ಥ ದಲ್ಲಿ ಅರ್ಥಗಳು ಕನ್ನಡ ಲಿಪಿಯಲ್ಲಿ ಇರಬೇಕು (Padartha must contain Kannada meanings in Kannada script).');
    }
    // Check if padartha contains newlines or bullets
    const lines = output.padartha.split('\n').filter(l => l.trim().length > 0);
    if (lines.length > 2) {
      issues.push('1. ಪದಾರ್ಥ must be ONE continuous paragraph. Detected multiple line breaks or bullet list formatting.');
    }
    if (/^[•\-\*\d+\.]\s/m.test(output.padartha)) {
      issues.push('1. ಪದಾರ್ಥ contains bullet points or numbered lists. Must be continuous comma-separated format.');
    }

    // Check 100% Sanskrit word coverage and termination anchor against moola shloka
    const moola = output.moolaShloka || unit.verifiedText || unit.originalText || '';
    if (moola) {
      const expectedWords = extractExpectedSanskritWords(moola);
      const coverage = detectPadarthaCoverageAndMissing(expectedWords, output.padartha);
      if (!coverage.isComplete) {
        issues.push(`ಪದಾರ್ಥ ಅಪೂರ್ಣತೆ: ${coverage.reason || 'ಸಂಸ್ಕೃತ ಶ್ಲೋಕದ ಕೆಲವು ಪದಗಳು ಪದಾರ್ಥದಲ್ಲಿ ಬಿಟ್ಟುಹೋಗಿವೆ.'}`);
      }
      if (coverage.duplicatePadas.length > 0) {
        issues.push(`ಪದಾರ್ಥದಲ್ಲಿ ಅನಪೇಕ್ಷಿತ ಪುನರಾವರ್ತಿತ ಪದಗಳು ಕಂಡುಬಂದಿವೆ: [${coverage.duplicatePadas.join(', ')}]`);
      }
      if (coverage.malformedPairs.length > 0) {
        issues.push(`ಪದಾರ್ಥದಲ್ಲಿ ದೋಷಪೂರಿತ ಪದಾರ್ಥ ರಚನೆ: [${coverage.malformedPairs.join(', ')}]`);
      }
    }
  }

  // 5. Check Simple Explanation (Section 4: 2. ಸರಳ ವಿವರಣೆ)
  if (!output.saralaVivarane || output.saralaVivarane.trim().length < 15) {
    issues.push('2. ಸರಳ ವಿವರಣೆ (Section 4) is missing or inadequate.');
  } else if (!/[\u0C80-\u0CFF]/.test(output.saralaVivarane)) {
    issues.push('2. ಸರಳ ವಿವರಣೆ must be written in Kannada language.');
  }

  // 6. Check Detailed Commentary (Section 5: 3. ವಿವರವಾದ ವ್ಯಾಖ್ಯಾನ)
  if (!output.vivaradaVyakhyana || output.vivaradaVyakhyana.trim().length < 30) {
    issues.push('3. ವಿವರವಾದ ವ್ಯಾಖ್ಯಾನ (Section 5) is missing or inadequate.');
  }

  // 7. Check for Non-English Digits (Requirement 16: English Digits ONLY)
  if (/[०-९]/.test(output.moolaShloka) || /[೦-೯]/.test(output.kannadaTransliteration)) {
    issues.push('Numerals must strictly use English digits (0-9). Devanagari/Kannada digits found.');
  }

  // 8. Check for Unwanted Script Leakage (Tamil, Telugu, Malayalam, Bengali, etc.)
  if (BANNED_SCRIPTS_REGEX.test(allText)) {
    issues.push('Unwanted Indian script leakage detected (e.g. Tamil/Telugu/Malayalam/Bengali).');
  }

  // 9. Check for Banned Meta Phrases
  const lowerAll = allText.toLowerCase();
  for (const phrase of BANNED_META_PHRASES) {
    if (lowerAll.includes(phrase.toLowerCase())) {
      issues.push(`Meta commentary detected ("${phrase}"). Meta talk is strictly banned from scholarly manuscripts.`);
      break;
    }
  }

  // 10. Check that table is not inside Padartha
  if (output.tableContent && output.padartha.includes('<table>')) {
    issues.push('Table found inside Padartha. Tables are prohibited inside 1. ಪದಾರ್ಥ.');
  }

  const score = Math.max(0, 1 - (issues.length * 0.2));
  const isValid = issues.length === 0;

  return {
    isValid,
    score,
    issues,
  };
}
