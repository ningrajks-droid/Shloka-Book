import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';
import { keyManager } from './keyManager';
import {
  devanagariToKannada,
  kannadaToDevanagari,
  sanitizeUnicodeText,
  toEnglishDigits,
  formatPadarthaWithDevanagariPadas,
} from './transliteration';

// ============================================================
// CONFIGURATION CONSTANTS (STEP 15)
// ============================================================
export const PADARTHA_MAX_OUTPUT_TOKENS = 65536;
export const PADARTHA_MAX_RETRIES = 5;
export const PADARTHA_CONTINUATION_ENABLED = true;
export const PADARTHA_VERIFICATION_ENABLED = true;
export const PADARTHA_CHUNK_THRESHOLD = 28; // Words threshold for chunk-based generation
export const PADARTHA_CHUNK_SIZE = 20; // Words per chunk for expansive texts

// Model priority pool
const SUPPORTED_MODELS = [
  'gemini-3.1-flash-lite',
  'gemini-3.8-flash',
  'gemini-flash-latest',
  'gemini-3.7-flash',
];
const modelCooldownMap = new Map<string, number>();

export function getPrioritizedPadarthaModels(preferredModel?: string): string[] {
  const now = Date.now();
  let primary = 'gemini-3.1-flash-lite';
  if (preferredModel && SUPPORTED_MODELS.includes(preferredModel) && (modelCooldownMap.get(preferredModel) || 0) < now) {
    primary = preferredModel;
  }
  const healthy = SUPPORTED_MODELS.filter((m) => (modelCooldownMap.get(m) || 0) < now);
  const ordered = [primary, ...healthy.filter((m) => m !== primary), ...SUPPORTED_MODELS.filter((m) => m !== primary && !healthy.includes(m))];
  return Array.from(new Set(ordered));
}

export function reportPadarthaModelCooldown(modelName: string, seconds: number = 300) {
  modelCooldownMap.set(modelName, Date.now() + seconds * 1000);
}

// ============================================================
// TYPES & INTERFACES (STEPS 1, 3, 5, 14, 19)
// ============================================================

export interface ExpectedWordItem {
  globalIndex: number;
  word: string;
  normalized: string;
  occurrenceIndex: number; // 1-based occurrence of this word
  totalOccurrences: number;
  clauseIndex: number;
}

export interface PadarthaPair {
  raw: string;
  pada: string;
  normalizedPada: string;
  artha: string;
  isComplete: boolean;
  issue?: string;
}

export interface CoverageReport {
  isComplete: boolean;
  expectedWordCount: number;
  coveredWordCount: number;
  missingWords: string[];
  coveredWords: string[];
  duplicatePadas: string[];
  malformedPairs: string[];
  hasIncompleteTail: boolean;
  incompleteTailRaw?: string;
  reason?: string;
}

export interface CompletePadarthaResult {
  padartha: string;
  complete: boolean;
  expectedWordCount: number;
  coveredWordCount: number;
  missingWords: string[];
  retryCount: number;
  continuationCount: number;
  issues?: string[];
}

export interface PadarthaOptions {
  preferredModel?: string;
  maxRetries?: number;
  chunkThreshold?: number;
  chunkSize?: number;
  signal?: AbortSignal;
}

// ============================================================
// STEP 9 & 10 — NORMALIZATION & LINGUISTIC MATCHING
// ============================================================

/**
 * STEP 9: Normalizes a Sanskrit word for robust lexical matching.
 * Converts Kannada script to Devanagari if present.
 * Cleans Unicode, accents, dandas, avagraha, punctuation, and terminal markers
 * (visarga, anusvara, halanta m) without stripping lexical consonants like 'म' or 'न'.
 */
export function normalizeSanskritWord(w: string): string {
  if (!w) return '';

  let str = w.normalize('NFKC');

  // Convert Kannada characters to Devanagari if someone entered in Kannada
  if (/[\u0C80-\u0CFF]/.test(str)) {
    str = kannadaToDevanagari(str);
  }

  return str
    // Strip Vedic accents & extended Vedic signs
    .replace(/[\u0951\u0952\uA8E0-\uA8F7]/g, '')
    // Strip dandas, digits (both English and Indian), parentheses, punctuation, quotes, slashes
    .replace(/[।॥|0-9०-೯\(\)\[\]\{\}\s.,;:!?"“”‘’_—–\/\\]/g, '')
    // Strip zero-width joiners/non-joiners
    .replace(/[\u200B-\u200D\uFEFF]/g, '')
    // Strip avagraha (ऽ)
    .replace(/ऽ/g, '')
    // Only strip terminal case markers: visarga (ः), anusvara (ं), or halanta m (म्), or terminal virama
    .replace(/(\u092E\u094D|[\u0902\u0903\u0C82\u0C83\u094D])+$/g, '')
    // Strip leading halanta if broken
    .replace(/^[्]+/, '')
    .toLowerCase()
    .trim();
}

/**
 * Extracts consonantal core by stripping boundary vowels & matras.
 * Enables Sandhi recognition (e.g. 'चात्महन' -> core 'त्महन' matches 'आत्महन' -> core 'त्महन').
 */
export function extractSanskritWordCore(w: string): string {
  return normalizeSanskritWord(w)
    .replace(/^[\u0905-\u0914\u093E-\u094C]+/, '')
    .replace(/[\u0905-\u0914\u093E-\u094C]+$/, '');
}

/**
 * STEP 10: Checks whether two Sanskrit word tokens match, either directly,
 * as prefix/suffix, or as dissolved Sandhi / compound constituents.
 */
export function sanskritWordsMatch(w1: string, w2: string): boolean {
  const s1 = normalizeSanskritWord(w1);
  const s2 = normalizeSanskritWord(w2);

  if (!s1 || !s2) return false;

  // Direct exact match
  if (s1 === s2) return true;

  // Prefix match (e.g. 'असुर्या' and 'असुर्याः', or 'तमसा' in 'तमसावृता')
  if (s1.startsWith(s2) || s2.startsWith(s1)) return true;

  // Suffix match (e.g. 'ते' in 'तांस्ते', 'वृता' in 'तमसावृता')
  if (s1.endsWith(s2) || s2.endsWith(s1)) return true;

  // Substring inclusion if length >= 2 (e.g. 'तां' in 'तांस्ते' matching 'तान्')
  if (s2.length >= 2 && s1.includes(s2)) return true;
  if (s1.length >= 2 && s2.includes(s1)) return true;

  // Sandhi Core root matching (e.g. 'चात्महनो' -> core 'त्महन' matching 'आत्महन' -> core 'त्महन')
  const c1 = extractSanskritWordCore(s1);
  const c2 = extractSanskritWordCore(s2);
  if (c1.length >= 3 && c2.length >= 3 && (c1.includes(c2) || c2.includes(c1))) {
    return true;
  }

  return false;
}

// ============================================================
// STEP 1 — SANSKRIT SOURCE WORDS EXTRACTION
// ============================================================

/**
 * Extracts Sanskrit words from the source shloka or gadya paragraph.
 * Respects source structure, clauses, and compound/sandhi boundaries.
 */
export function extractExpectedSanskritWords(moolaText: string): ExpectedWordItem[] {
  if (!moolaText || !moolaText.trim()) return [];

  // Break into clauses around dandas, linebreaks, and semicolons
  const rawClauses = moolaText
    .split(/(?<=[।॥|;\n])\s*/)
    .map((c) => c.replace(/[0-9०-೯॥|]/g, '').trim())
    .filter((c) => c.length > 0 && /[\u0900-\u097F\u0C80-\u0CFF]/.test(c));

  const items: ExpectedWordItem[] = [];
  const occurrenceCountMap = new Map<string, number>();

  let globalIdx = 0;

  for (let cIdx = 0; cIdx < rawClauses.length; cIdx++) {
    const clause = rawClauses[cIdx];
    // Strip punctuation, dandas, numbers, brackets
    const cleanedClause = clause
      .normalize('NFKC')
      .replace(/[।॥|0-9०-೯\(\)\[\]\{\}.,;:!?"“”‘’_—–\/\\]/g, ' ')
      .replace(/[\u0951\u0952\uA8E0-\uA8F7]/g, '')
      .trim();

    const rawTokens = cleanedClause
      .split(/\s+/)
      .map((t) => t.trim())
      .filter((t) => t.length > 0 && /[\u0900-\u097F\u0C80-\u0CFF]/.test(t));

    for (const token of rawTokens) {
      // If Kannada script, convert to Devanagari
      const devanagariToken = /[\u0C80-\u0CFF]/.test(token)
        ? kannadaToDevanagari(token)
        : token;

      const norm = normalizeSanskritWord(devanagariToken);
      if (!norm || norm.length < 1) continue;

      const occ = (occurrenceCountMap.get(norm) || 0) + 1;
      occurrenceCountMap.set(norm, occ);

      items.push({
        globalIndex: globalIdx++,
        word: devanagariToken,
        normalized: norm,
        occurrenceIndex: occ,
        totalOccurrences: 1, // Will update below
        clauseIndex: cIdx,
      });
    }
  }

  // Update total occurrences for each word
  for (const item of items) {
    item.totalOccurrences = occurrenceCountMap.get(item.normalized) || 1;
  }

  return items;
}

// ============================================================
// STEP 2 & 12 — SAFE PARSING & TAIL RECOVERY
// ============================================================

/**
 * Safely parses padartha text into structured pairs.
 * Checks for completeness of both Sanskrit pada and Kannada artha.
 */
export function parsePadarthaPairs(padarthaRaw: string): PadarthaPair[] {
  if (!padarthaRaw || !padarthaRaw.trim()) return [];

  const cleaned = sanitizeUnicodeText(padarthaRaw)
    .replace(/^(\d+\.?\s*)?(ಪದಾರ್ಥ\s*[:\-])\s*/i, '')
    .trim();

  // Split by comma or semicolon
  const rawSegments = cleaned
    .split(/[,;\n\r]+/)
    .map((s) => s.trim())
    .filter(Boolean);

  const pairs: PadarthaPair[] = [];

  for (const seg of rawSegments) {
    const sepMatch = seg.match(/[-=—–:]/);
    if (!sepMatch || sepMatch.index === undefined) {
      // Malformed without separator
      pairs.push({
        raw: seg,
        pada: seg,
        normalizedPada: normalizeSanskritWord(seg),
        artha: '',
        isComplete: false,
        issue: 'Separating hyphen (-) missing',
      });
      continue;
    }

    let rawPada = seg.substring(0, sepMatch.index).trim();
    let rawArtha = seg.substring(sepMatch.index + 1).trim();

    // Clean pada
    rawPada = rawPada.replace(/^[•\-\*\d+\.)\]\s]+/, '').trim();
    rawPada = rawPada.replace(/[\(（\[\{][^\)\]\}]+[\)）\]\}]/g, '').trim();

    // Convert Kannada pada to Devanagari if entered in Kannada script
    if (/[\u0C80-\u0CFF]/.test(rawPada)) {
      rawPada = kannadaToDevanagari(rawPada);
    }
    rawPada = rawPada.replace(/^[/\-–—:,\s]+|[/\-–—:,\s]+$/g, '').trim();

    // Clean artha
    rawArtha = rawArtha.replace(/^[/\-–—:=,\s]+|[/\-–—:=,\s]+$/g, '').trim();

    // Check if inverted (Kannada first, Devanagari second)
    if (/[\u0C80-\u0CFF]/.test(rawPada) && !/[\u0900-\u097F]/.test(rawPada) && /[\u0900-\u097F]/.test(rawArtha)) {
      const temp = rawPada;
      rawPada = kannadaToDevanagari(rawArtha);
      rawArtha = temp;
    }

    const normPada = normalizeSanskritWord(rawPada);
    const hasKannadaArtha = /[\u0C80-\u0CFF]/.test(rawArtha);
    const hasEnglishLetters = /[A-Za-z]/.test(rawArtha);

    // Detect cut-off mid-meaning or incomplete trailing punctuation
    const isCutOff =
      rawArtha.endsWith('...') ||
      rawArtha.endsWith('..') ||
      /[-—–:\/]$/.test(rawArtha);

    let isComplete = true;
    let issue: string | undefined;

    if (!normPada || !/[\u0900-\u097F]/.test(rawPada)) {
      isComplete = false;
      issue = 'Sanskrit pada missing or not in Devanagari';
    } else if (!rawArtha || rawArtha.length < 1 || !hasKannadaArtha) {
      isComplete = false;
      issue = 'Kannada meaning missing';
    } else if (hasEnglishLetters) {
      isComplete = false;
      issue = 'English letters found in Kannada meaning';
    } else if (isCutOff) {
      isComplete = false;
      issue = 'Meaning appears cut off mid-word';
    }

    pairs.push({
      raw: seg,
      pada: rawPada,
      normalizedPada: normPada,
      artha: rawArtha,
      isComplete,
      issue,
    });
  }

  return pairs;
}

/**
 * STEP 12: Detects and discards incomplete trailing tokens if AI response cut off mid-sentence.
 */
export function safeTrimIncompletePadarthaTail(padarthaRaw: string): { cleanPadartha: string; discardedTail?: string } {
  if (!padarthaRaw || !padarthaRaw.trim()) {
    return { cleanPadartha: '' };
  }

  const pairs = parsePadarthaPairs(padarthaRaw);
  if (pairs.length === 0) {
    return { cleanPadartha: '' };
  }

  const lastPair = pairs[pairs.length - 1];
  if (!lastPair.isComplete) {
    // Discard the incomplete last pair
    const validPairs = pairs.slice(0, -1);
    const cleanPadartha = validPairs.map((p) => `${p.pada} - ${p.artha}`).join(', ');
    return {
      cleanPadartha,
      discardedTail: lastPair.raw,
    };
  }

  const cleanPadartha = pairs.map((p) => `${p.pada} - ${p.artha}`).join(', ');
  return { cleanPadartha };
}

// ============================================================
// STEP 3 & 5 — MISSING-WORD DETECTION WITH OCCURRENCE TRACKING
// ============================================================

/**
 * Matches generated Padartha pairs against expected Sanskrit source words.
 * Strictly tracks occurrences so repeated words are not falsely marked as complete.
 */
export function detectPadarthaCoverageAndMissing(
  expectedWords: ExpectedWordItem[],
  padarthaText: string
): CoverageReport {
  if (!expectedWords || expectedWords.length === 0) {
    return {
      isComplete: true,
      expectedWordCount: 0,
      coveredWordCount: 0,
      missingWords: [],
      coveredWords: [],
      duplicatePadas: [],
      malformedPairs: [],
      hasIncompleteTail: false,
    };
  }

  const pairs = parsePadarthaPairs(padarthaText);
  const coveredWordIndices = new Set<number>();
  const occurrenceCountMatched = new Map<string, number>();
  const duplicatePadas: string[] = [];
  const malformedPairs: string[] = [];

  let cursor = 0;

  for (let pIdx = 0; pIdx < pairs.length; pIdx++) {
    const pair = pairs[pIdx];

    if (!pair.isComplete) {
      malformedPairs.push(pair.raw);
      continue;
    }

    // Check adjacent duplicates
    if (pIdx > 0 && pair.normalizedPada === pairs[pIdx - 1].normalizedPada) {
      const expectedMatches = expectedWords.filter((w) => sanskritWordsMatch(w.word, pair.pada));
      const matchedSoFar = occurrenceCountMatched.get(pair.normalizedPada) || 0;
      if (matchedSoFar >= expectedMatches.length) {
        duplicatePadas.push(pair.pada);
      }
    }

    const pNorm = pair.normalizedPada;
    if (!pNorm) continue;

    // Pass 1: Forward lookahead starting from cursor
    let matchIdx = -1;
    const lookaheadLimit = Math.min(expectedWords.length, cursor + 24);

    for (let i = cursor; i < lookaheadLimit; i++) {
      if (coveredWordIndices.has(i)) continue;
      const exp = expectedWords[i];

      if (sanskritWordsMatch(exp.word, pair.pada)) {
        matchIdx = i;
        break;
      }
    }

    // Pass 2: Global scan if not found in forward window (word order variation)
    if (matchIdx === -1) {
      for (let i = 0; i < expectedWords.length; i++) {
        if (coveredWordIndices.has(i)) continue;
        const exp = expectedWords[i];

        if (sanskritWordsMatch(exp.word, pair.pada)) {
          matchIdx = i;
          break;
        }
      }
    }

    if (matchIdx !== -1) {
      coveredWordIndices.add(matchIdx);
      const matchedToken = expectedWords[matchIdx];
      const prevOcc = occurrenceCountMatched.get(matchedToken.normalized) || 0;
      occurrenceCountMatched.set(matchedToken.normalized, prevOcc + 1);

      // Advance cursor past this matched word
      cursor = Math.max(cursor, matchIdx + 1);
    }
  }

  // Determine missing words
  const missingWords: string[] = [];
  const coveredWords: string[] = [];

  for (const exp of expectedWords) {
    if (coveredWordIndices.has(exp.globalIndex)) {
      coveredWords.push(exp.word);
    } else {
      // Include occurrence indication if word repeats in the source shloka
      const label = exp.totalOccurrences > 1 ? `${exp.word} [ಬಾರಿ ${exp.occurrenceIndex}]` : exp.word;
      missingWords.push(label);
    }
  }

  const hasIncompleteTail = malformedPairs.length > 0 && pairs[pairs.length - 1] && !pairs[pairs.length - 1].isComplete;
  const isComplete = missingWords.length === 0 && malformedPairs.length === 0 && pairs.length > 0;

  let reason: string | undefined;
  if (!isComplete) {
    if (missingWords.length > 0) {
      reason = `ಪದಾರ್ಥದಲ್ಲಿ ${missingWords.length} ಸಂಸ್ಕೃತ ಪದಗಳು ಬಿಟ್ಟುಹೋಗಿವೆ: [${missingWords.slice(0, 6).join(', ')}${missingWords.length > 6 ? '...' : ''}]`;
    } else if (malformedPairs.length > 0) {
      reason = `ಪದಾರ್ಥದಲ್ಲಿ ಅಪೂರ್ಣ/ದೋಷಪೂರಿತ ಪದ ಕಂಡುಬಂದಿದೆ: [${malformedPairs.join(', ')}]`;
    } else if (pairs.length === 0) {
      reason = 'ಪದಾರ್ಥವು ಸಂಪೂರ್ಣವಾಗಿ ಖಾಲಿಯಾಗಿದೆ.';
    }
  }

  return {
    isComplete,
    expectedWordCount: expectedWords.length,
    coveredWordCount: coveredWordIndices.size,
    missingWords,
    coveredWords,
    duplicatePadas,
    malformedPairs,
    hasIncompleteTail,
    incompleteTailRaw: hasIncompleteTail ? pairs[pairs.length - 1].raw : undefined,
    reason,
  };
}

// ============================================================
// STEP 4 & 16 — MERGING CONTINUATION RESULTS
// ============================================================

/**
 * Cleanly merges a newly generated continuation batch with the existing Padartha.
 * Removes boundary overlap and ensures source order.
 */
export function mergePadarthaContinuations(existingPadartha: string, newPadartha: string): string {
  if (!existingPadartha || !existingPadartha.trim()) {
    return formatPadarthaWithDevanagariPadas(newPadartha);
  }
  if (!newPadartha || !newPadartha.trim()) {
    return formatPadarthaWithDevanagariPadas(existingPadartha);
  }

  const existingPairs = parsePadarthaPairs(existingPadartha).filter((p) => p.isComplete);
  const newPairs = parsePadarthaPairs(newPadartha).filter((p) => p.isComplete);

  if (existingPairs.length === 0) {
    return formatPadarthaWithDevanagariPadas(newPadartha);
  }
  if (newPairs.length === 0) {
    return formatPadarthaWithDevanagariPadas(existingPadartha);
  }

  // Find overlap: check if the first few pairs of newPadartha repeat the last pair of existingPadartha
  const lastExistingNorm = existingPairs[existingPairs.length - 1].normalizedPada;
  let overlapIdx = -1;

  for (let i = 0; i < Math.min(newPairs.length, 3); i++) {
    if (newPairs[i].normalizedPada === lastExistingNorm) {
      overlapIdx = i;
      break;
    }
  }

  const nonOverlappingNew = overlapIdx !== -1 ? newPairs.slice(overlapIdx + 1) : newPairs;

  const merged = [...existingPairs, ...nonOverlappingNew];
  const formatted = merged.map((p) => `${p.pada} - ${p.artha}`).join(', ');

  return formatPadarthaWithDevanagariPadas(formatted);
}

// ============================================================
// STEP 8 & 11 — PROMPT BUILDERS
// ============================================================

export function buildPadarthaInitialPrompt(sourceText: string, wordsList: string[]): string {
  return `
TASK FOR MASTER SANSKRIT-KANNADA SCHOLAR:
Generate the comprehensive word-by-word PADARTHA (ಪದಾರ್ಥ) for the following Sanskrit text.

SOURCE SANSKRIT:
${sourceText}

EXPECTED SANSKRIT WORDS TO TRANSLATE (IN STRICT ORDER):
${wordsList.join(', ')}

MANDATORY SCHOLARLY RULES:
1. Cover EVERY SINGLE Sanskrit word in sequential order. Do NOT skip any word.
2. Every particle, pronoun, and avyaya (च, एव, तु, हि, अपि, वै, तत्, इति, वा, न, यत्, तथा, इत्यादी) MUST be explicitly translated.
3. FORMAT REQUIREMENT (CRITICAL):
   Output MUST be ONE continuous single paragraph of:
   SanskritWord - Kannada meaning, SanskritWord - Kannada meaning, SanskritWord - Kannada meaning...
4. For lineage lists, name series, or prose (such as Vamsa Brahmana), avoid repetitive robotic case suffixes (like "-ನಿಂದ", "-ನು") for every single word. Instead, provide natural, full, and contextual Kannada meanings explaining the transmission or relationship gracefully.
5. Sanskrit word MUST be in pure Devanagari script. Kannada meaning MUST be in pure Kannada script.
6. NO tables. NO bullet points. NO numbered lists. NO padaccheda heading.
7. NO English words or Latin letters anywhere.
8. End cleanly at a completed word-meaning pair with a period.
9. PERFECT KANNADA GRAMMAR & SPELLING (ಕನ್ನಡ ವ್ಯಾಕರಣ ಮತ್ತು ಕಾಗುಣಿತ ಶುದ್ಧತೆ): Zero spelling mistakes. Always write standard Kannada words with proper anusvara (e.g. ಖಂಡ, ಶಾಂತಿ, ಆನಂದ, ಸಂಪೂರ್ಣ, ಪಂಚ - never ಖಣ್ಡ, ಶಾನ್ತಿ, ಆನನ್ದ, ಸಮ್ಪೂರ್ಣ). Flawless syntax and spelling.
`.trim();
}

export function buildPadarthaContinuationPrompt(
  sourceText: string,
  coveredWords: string[],
  remainingWords: string[],
  previousTailPair?: string
): string {
  return `
TASK FOR MASTER SANSKRIT-KANNADA SCHOLAR — CONTINUATION REQUEST:
Continue the word-by-word PADARTHA (ಪದಾರ್ಥ) for the remaining Sanskrit words.

SOURCE SANSKRIT:
${sourceText}

${previousTailPair ? `LAST COMPLETED ENTRY (FOR CONTINUITY CONTEXT ONLY - DO NOT REPEAT):\n${previousTailPair}\n` : ''}

REMAINING SANSKRIT WORDS TO TRANSLATE (START FROM THE FIRST WORD BELOW):
${remainingWords.join(', ')}

MANDATORY CONTINUATION RULES:
1. Start directly with the FIRST remaining Sanskrit word: "${remainingWords[0]}".
2. Do NOT repeat any already completed words (${coveredWords.slice(-5).join(', ')}).
3. Do NOT restart from the beginning of the shloka.
4. Translate EVERY remaining word in exact sequential order. Do NOT skip any word.
5. For lineage lists or prose, use natural, full, contextual Kannada meanings instead of robotic repetitive suffixes.
6. Output format: ONE continuous comma-separated paragraph:
   SanskritWord - Kannada meaning, SanskritWord - Kannada meaning...
7. Pure Devanagari for Sanskrit, Pure Kannada script for meaning.
8. NO tables, NO bullets, NO numbered lists, NO commentary, NO English text.
9. PERFECT KANNADA GRAMMAR & SPELLING: Zero spelling mistakes. Always write standard Kannada words with proper anusvara (ಖಂಡ, ಶಾಂತಿ, ಆನಂದ, ಸಂಪೂರ್ಣ).
`.trim();
}

export function buildPadarthaRetryPrompt(
  sourceText: string,
  missingWords: string[]
): string {
  return `
TASK FOR MASTER SANSKRIT-KANNADA SCHOLAR — TARGETED MISSING WORD FILL-IN:
The following Sanskrit words from the source text were omitted or incomplete in the previous attempt.
Provide word-by-word PADARTHA entries ONLY for these specific missing words.

SOURCE SANSKRIT:
${sourceText}

MISSING SANSKRIT WORDS TO TRANSLATE NOW:
${missingWords.join(', ')}

MANDATORY RULES:
1. Translate each missing word listed above in order.
2. Format: SanskritWord - Kannada meaning, SanskritWord - Kannada meaning...
3. Sanskrit word in Devanagari, Kannada meaning in Kannada script.
4. NO extra commentary, NO headings, NO bullets.
5. PERFECT KANNADA GRAMMAR & SPELLING: Zero spelling mistakes, standard anusvara (ಖಂಡ, ಶಾಂತಿ, ಆನಂದ).
`.trim();
}

// ============================================================
// AI GENERATION RUNNER (STEP 13, 14)
// ============================================================

async function callPadarthaAI(prompt: string, preferredModel?: string): Promise<string> {
  const candidateModels = getPrioritizedPadarthaModels(preferredModel);
  let lastError: Error | null = null;

  for (const modelName of candidateModels) {
    const maxKeyAttempts = Math.max(3, Math.min(keyManager.getActiveKeyCount() || 5, 8));

    for (let attempt = 1; attempt <= maxKeyAttempts; attempt++) {
      let currentApiKey = await keyManager.getNextApiKey(undefined, true);
      if (!currentApiKey) {
        currentApiKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || process.env.API_KEY;
      }
      if (!currentApiKey) {
        throw new Error('No Gemini API key available for Padartha generation.');
      }

      try {
        const ai = new GoogleGenAI({
          apiKey: currentApiKey,
          httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
        });

        const config: any = {
          temperature: 0.1, // Low temperature for deterministic, faithful translations
          topP: 0.95,
          maxOutputTokens: PADARTHA_MAX_OUTPUT_TOKENS,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              padartha: {
                type: Type.STRING,
                description: 'ONE continuous single paragraph of Sanskrit pada in Devanagari - Kannada meaning in Kannada separated by commas. No bullets or linebreaks.',
              },
            },
            required: ['padartha'],
          },
        };

        if (modelName === 'gemini-3.1-flash-lite') {
          config.thinkingConfig = { thinkingLevel: ThinkingLevel.MINIMAL };
        } else if (modelName.includes('3.7') || modelName.includes('3.8')) {
          config.thinkingConfig = { thinkingLevel: ThinkingLevel.LOW };
        }

        const response = await ai.models.generateContent({
          model: modelName,
          contents: prompt,
          config,
        });

        keyManager.reportSuccess(currentApiKey);

        const rawText = response.text?.trim() || '';
        try {
          const parsed = JSON.parse(rawText);
          if (parsed && typeof parsed.padartha === 'string') {
            return parsed.padartha.trim();
          }
        } catch {
          const match = rawText.match(/"padartha"\s*:\s*"((?:\\.|[^"\\])*)"/s);
          if (match && match[1]) {
            return match[1].replace(/\\"/g, '"').replace(/\\n/g, '\n').trim();
          }
        }

        return rawText.replace(/^[{\s"padartha:]+/, '').replace(/[}\s"]+$/, '').trim();
      } catch (err: any) {
        lastError = err;
        const errMsg = String(err?.message || err);
        const is429 = errMsg.includes('429') || errMsg.includes('RESOURCE_EXHAUSTED') || errMsg.includes('Quota');
        const is503 = errMsg.includes('503') || errMsg.includes('UNAVAILABLE') || errMsg.includes('high demand');

        if (is429) {
          keyManager.reportRateLimit(currentApiKey, 25);
          reportPadarthaModelCooldown(modelName, 25);
          continue;
        }
        if (is503) {
          reportPadarthaModelCooldown(modelName, 60);
          break; // Switch to next model
        }
      }
    }
  }

  throw new Error(`Padartha generation failed across all models: ${lastError?.message || 'Unknown error'}`);
}

// ============================================================
// STEP 18 & 19 — MASTER FUNCTION: generateCompletePadartha
// ============================================================

/**
 * Master Padartha Generation & Automatic Continuation Engine.
 * 
 * Executes:
 * 1. Source word extraction with occurrence tracking (STEPS 1 & 5)
 * 2. Initial batch generation or chunk-based processing for long prose (STEPS 2 & 17)
 * 3. Safe trailing token detection and cutoff recovery (STEP 12)
 * 4. Programmatic missing-word and coverage analysis (STEP 3)
 * 5. Automatic continuation requests preserving context without repetition (STEPS 4 & 8)
 * 6. Clean sequential merging maintaining source order (STEPS 4 & 16)
 * 7. Multi-attempt retry mechanism for any remaining missing words (STEP 7)
 * 8. Mandatory final verification check (STEP 6)
 * 9. Returns structured CompletePadarthaResult (STEP 19)
 */
export async function generateCompletePadartha(
  sourceText: string,
  options?: PadarthaOptions
): Promise<CompletePadarthaResult> {
  const maxRetries = options?.maxRetries ?? PADARTHA_MAX_RETRIES;
  const chunkThreshold = options?.chunkThreshold ?? PADARTHA_CHUNK_THRESHOLD;
  const chunkSize = options?.chunkSize ?? PADARTHA_CHUNK_SIZE;
  const preferredModel = options?.preferredModel;

  // STEP 1: Extract expected words with occurrence tracking
  const expectedWords = extractExpectedSanskritWords(sourceText);

  if (expectedWords.length === 0) {
    return {
      padartha: '',
      complete: true,
      expectedWordCount: 0,
      coveredWordCount: 0,
      missingWords: [],
      retryCount: 0,
      continuationCount: 0,
    };
  }

  let accumulatedPadartha = '';
  let continuationCount = 0;
  let retryCount = 0;

  // STEP 17: If text is long (> chunkThreshold), handle in sequential chunks to prevent token limits
  if (expectedWords.length > chunkThreshold) {
    console.info(`[Padartha Engine] Large source detected (${expectedWords.length} words). Using chunk-based continuation pipeline.`);

    for (let i = 0; i < expectedWords.length; i += chunkSize) {
      const chunkWords = expectedWords.slice(i, i + chunkSize);
      const chunkWordStrings = chunkWords.map((w) => w.word);

      let chunkPrompt: string;
      if (i === 0) {
        chunkPrompt = buildPadarthaInitialPrompt(sourceText, chunkWordStrings);
      } else {
        const lastCompletedPairs = parsePadarthaPairs(accumulatedPadartha).filter((p) => p.isComplete);
        const tailContext = lastCompletedPairs.slice(-3).map((p) => `${p.pada} - ${p.artha}`).join(', ');
        const coveredSoFar = expectedWords.slice(0, i).map((w) => w.word);
        chunkPrompt = buildPadarthaContinuationPrompt(sourceText, coveredSoFar, chunkWordStrings, tailContext);
        continuationCount++;
      }

      try {
        const rawChunkOutput = await callPadarthaAI(chunkPrompt, preferredModel);
        const { cleanPadartha } = safeTrimIncompletePadarthaTail(rawChunkOutput);
        accumulatedPadartha = mergePadarthaContinuations(accumulatedPadartha, cleanPadartha);
      } catch (chunkErr) {
        console.warn(`[Padartha Engine] Error in chunk ${i / chunkSize + 1}:`, chunkErr);
      }
    }
  } else {
    // Normal length shloka or passage: generate first full pass
    const allWords = expectedWords.map((w) => w.word);
    const initialPrompt = buildPadarthaInitialPrompt(sourceText, allWords);

    try {
      const rawOutput = await callPadarthaAI(initialPrompt, preferredModel);
      const { cleanPadartha } = safeTrimIncompletePadarthaTail(rawOutput);
      accumulatedPadartha = formatPadarthaWithDevanagariPadas(cleanPadartha);
    } catch (initErr) {
      console.warn('[Padartha Engine] Initial generation error:', initErr);
    }
  }

  // STEP 3 & 4: Evaluate initial coverage and check for missing words
  let coverage = detectPadarthaCoverageAndMissing(expectedWords, accumulatedPadartha);

  // STEP 4 & 7: Automatic Continuation & Retry Loop
  while (!coverage.isComplete && retryCount < maxRetries) {
    retryCount++;
    console.info(`[Padartha Engine] Continuation attempt ${retryCount}/${maxRetries}. Missing words: ${coverage.missingWords.length} [${coverage.missingWords.slice(0, 4).join(', ')}]`);

    let nextPrompt: string;
    const lastPairs = parsePadarthaPairs(accumulatedPadartha).filter((p) => p.isComplete);
    const tailContext = lastPairs.slice(-2).map((p) => `${p.pada} - ${p.artha}`).join(', ');

    // If generation stopped at a specific point in the sequence, continue from there
    if (coverage.missingWords.length > 0) {
      const remainingClean = coverage.missingWords.map((w) => w.replace(/\s*\[.+?\]$/, ''));
      nextPrompt = buildPadarthaContinuationPrompt(sourceText, coverage.coveredWords, remainingClean, tailContext);
      continuationCount++;
    } else {
      // Missing words scattered: use targeted retry prompt
      nextPrompt = buildPadarthaRetryPrompt(sourceText, coverage.missingWords);
    }

    try {
      const retryRaw = await callPadarthaAI(nextPrompt, preferredModel);
      const { cleanPadartha } = safeTrimIncompletePadarthaTail(retryRaw);

      if (cleanPadartha && cleanPadartha.trim().length > 0) {
        accumulatedPadartha = mergePadarthaContinuations(accumulatedPadartha, cleanPadartha);
      }
    } catch (retryErr) {
      console.warn(`[Padartha Engine] Error in retry attempt ${retryCount}:`, retryErr);
    }

    // Re-evaluate coverage
    coverage = detectPadarthaCoverageAndMissing(expectedWords, accumulatedPadartha);

    if (coverage.isComplete) {
      console.info(`[Padartha Engine] 100% Coverage achieved on attempt ${retryCount}!`);
      break;
    }
  }

  // STEP 6: Mandatory Final Verification
  const finalCoverage = detectPadarthaCoverageAndMissing(expectedWords, accumulatedPadartha);
  const issues: string[] = [];

  if (!finalCoverage.isComplete && finalCoverage.reason) {
    issues.push(finalCoverage.reason);
  }
  if (finalCoverage.duplicatePadas.length > 0) {
    issues.push(`ಅನಪೇಕ್ಷಿತ ಪುನರಾವರ್ತಿತ ಪದಾರ್ಥಗಳು ಕಂಡುಬಂದಿವೆ: [${finalCoverage.duplicatePadas.join(', ')}]`);
  }
  if (finalCoverage.malformedPairs.length > 0) {
    issues.push(`ದೋಷಪೂರಿತ ಪದಾರ್ಥ ರಚನೆ: [${finalCoverage.malformedPairs.join(', ')}]`);
  }

  // Enforce English digits & clean final format
  const finalPadartha = formatPadarthaWithDevanagariPadas(toEnglishDigits(sanitizeUnicodeText(accumulatedPadartha)));

  return {
    padartha: finalPadartha,
    complete: finalCoverage.isComplete && issues.length === 0,
    expectedWordCount: expectedWords.length,
    coveredWordCount: finalCoverage.coveredWordCount,
    missingWords: finalCoverage.missingWords,
    retryCount,
    continuationCount,
    issues: issues.length > 0 ? issues : undefined,
  };
}
