import { toEnglishDigits, sanitizeUnicodeText, stripHierarchicalVerseHeader, devanagariToKannada } from './transliteration';
import { GranthaTableOfContents, TableOfContentsEntry, SanskritUnit, StructuralSummaryStats } from '../src/types';

export type SanskritUnitType =
  | 'SHLOKA'
  | 'UNNUMBERED_SHLOKA'
  | 'MANTRA'
  | 'SHANTI_MANTRA'
  | 'GADYA'
  | 'QUOTATION'
  | 'COLOPHON'
  | 'HEADING';

export interface DetectedStructure {
  detectedWork: string;
  detectedWorkKannada?: string;
  genre: string;
  level1Name: string;
  level1Sanskrit?: string;
  level2Name?: string;
  level2Sanskrit?: string;
  level3Name: string;
  level3Sanskrit?: string;
  confidence: number;
  isCanonical?: boolean;
}

export interface ExtractedVerseUnit {
  originalText: string;
  rawText: string;
  firstMeaningfulWord: string;
  pageNumber: number;
  unitIndex: number;
  unitType: SanskritUnitType;
  hierarchy: {
    level1Name: string;
    level1Value: string | number;
    level2Name?: string;
    level2Value?: string | number;
    level3Name?: string;
    level3Value?: string | number;
    sectionName?: string;
    subsectionName?: string;
    formattedNumber: string;
    isUnnumbered?: boolean;
  };
}

// ----------------- Sanskrit Canonical Work & Signature Knowledge Base -----------------

interface CanonicalWorkSignature {
  keywords: string[];
  work: string;
  workKannada: string;
  genre: string;
  level1Name: string;
  level1Sanskrit: string;
  level2Name?: string;
  level2Sanskrit?: string;
  level3Name: string;
  level3Sanskrit: string;
}

const CANONICAL_WORK_SIGNATURES: CanonicalWorkSignature[] = [
  // 1. Itihasa & Mahakavya
  {
    keywords: ['रामायण', 'बालकाण्ड', 'अयोध्याकाण्ड', 'अरण्यकाण्ड', 'किष्किन्धाकाण्ड', 'सुन्दरकाण्ड', 'युद्धकाण्ड', 'उत्तरकाण्ड', 'वाल्मीकिरामायण', 'ramayana', 'valmiki ramayana'],
    work: 'वाल्मीकिरामायणम्',
    workKannada: 'ವಾಲ್ಮೀಕಿ ರಾಮಾಯಣಂ',
    genre: 'ಇತಿಹಾಸ / ಮಹಾಕಾವ್ಯ',
    level1Name: 'ಕಾಂಡ',
    level1Sanskrit: 'काण्डम्',
    level2Name: 'ಸರ್ಗ',
    level2Sanskrit: 'सर्गः',
    level3Name: 'ಶ್ಲೋಕ',
    level3Sanskrit: 'श्लोकः',
  },
  {
    keywords: ['महाभारत', 'आदिपर्व', 'सभापर्व', 'वनपर्व', 'विराटपर्व', 'उद्योगपर्व', 'भीष्मपर्व', 'द्रोणपर्व', 'कर्णपर्व', 'शल्यपर्व', 'सौप्तिकपर्व', 'स्त्रीपर्व', 'शान्तिपर्व', 'अनुशासनपर्व', 'अश्वमेधिकपर्व', 'आश्रमवासिकपर्व', 'मौसलपर्व', 'महाप्रस्थानिकपर्व', 'स्वर्गारोहणपर्व', 'mahabharata'],
    work: 'महाभारतम्',
    workKannada: 'ಮಹಾಭಾರತಂ',
    genre: 'ಇತಿಹಾಸ',
    level1Name: 'ಪರ್ವ',
    level1Sanskrit: 'पर्व',
    level2Name: 'ಅಧ್ಯಾಯ',
    level2Sanskrit: 'अध्यायः',
    level3Name: 'ಶ್ಲೋಕ',
    level3Sanskrit: 'श्लोकः',
  },
  {
    keywords: ['भगवद्गीता', 'श्रीमद्भगवद्गीता', 'अर्जुनविषादयोग', 'साङ्ख्ययोग', 'कर्मयोग', 'ज्ञानकर्मसंन्यासयोग', 'कर्मसंन्यासयोग', 'आत्मसंयमयोग', 'ज्ञानविज्ञानयोग', 'अक्षरब्रह्मयोग', 'राजविद्याराजगुह्ययोग', 'विभूतियोग', 'विश्वरूपदर्शनयोग', 'भक्तियोग', 'क्षेत्रक्षेत्रज्ञविभागयोग', 'गुणत्रयविभागयोग', 'पुरुषोत्तमयोग', 'दैवासुरसम्पद्विभागयोग', 'श्रद्धात्रयविभागयोग', 'मोक्षसंन्यासयोग', 'bhagavad gita', 'bhagavadgita', 'gita'],
    work: 'श्रीमद्भगवद्गीता',
    workKannada: 'ಶ್ರೀಮದ್ಭಗವದ್ಗೀತಾ',
    genre: 'ಗೀತಾ ಶಾಸ್ತ್ರ / ಉಪನಿಷತ್ ಸಾರ',
    level1Name: 'ಅಧ್ಯಾಯ',
    level1Sanskrit: 'अध्यायः',
    level3Name: 'ಶ್ಲೋಕ',
    level3Sanskrit: 'श्लोकः',
  },
  // 2. Principal Upanishads (Mukhya Dashopanishads & Canonical Upanishads)
  {
    keywords: [
      'गर्भोपनिषत्', 'गार्भोपनिषत्', 'गभपिनषत्', 'गभोपनिषत्',
      'garbha upanishad', 'garbhopanishad', 'garbha upanishat', 'garbhopanishat',
      'पञ्चात्मकं पञ्चसु', 'पञ्चात्मकमिति कस्मात्', 'ऋतुकाले संप्रयोगात्', 'ऋतुकाले सयोगात्', 'गर्भ उपनिषद'
    ],
    work: 'गर्भोपनिषत्',
    workKannada: 'ಗರ್ಭೋಪನಿಷತ್',
    genre: 'ಉಪನಿಷತ್ / ವೇದಾಂತ',
    level1Name: '',
    level1Sanskrit: '',
    level3Name: 'ಮಂತ್ರ',
    level3Sanskrit: 'मन्त्रः',
  },
  {
    keywords: ['कैवल्योपनिषत्', 'kaivalya upanishad', 'kaivalyopanishad'],
    work: 'कैवल्योपनिषत्',
    workKannada: 'ಕೈವಲ್ಯೋಪನಿಷತ್',
    genre: 'ಉಪನಿಷತ್ / ವೇದಾಂತ',
    level1Name: '',
    level1Sanskrit: '',
    level3Name: 'ಮಂತ್ರ',
    level3Sanskrit: 'मन्त्रः',
  },
  {
    keywords: ['अमृतबिन्दूपनिषत्', 'amritabindu upanishad', 'amritabindupanishad'],
    work: 'अमृतबिन्दूपनिषत्',
    workKannada: 'ಅಮೃತಬಿನ್ದೂಪನಿಷತ್',
    genre: 'ಉಪನಿಷತ್ / ವೇದಾಂತ',
    level1Name: '',
    level1Sanskrit: '',
    level3Name: 'ಮಂತ್ರ',
    level3Sanskrit: 'मन्त्रः',
  },
  {
    keywords: ['ईशावास्योपनिषत्', 'ईशोपनिषत्', 'ईशावास्यम्', 'ईशा वास्यम्', 'ईशावास्य', 'अनेजदेकं', 'अनेजदेकम्', 'पूर्णमदः', 'कुर्वन्नेवेह', 'असूर्या नाम', 'हिरण्मयेन पात्रेण', 'विद्यां चाविद्यां', 'वायुरनिलममृतम्', 'अग्ने नय सुपथा', 'isha upanishat', 'isopanishad', 'ishopanishad', 'isha upanishad', 'isavasya', 'ishavasya'],
    work: 'ईशोपनिषत्',
    workKannada: 'ಈಶೋಪನಿಷತ್',
    genre: 'ಉಪನಿಷತ್',
    level1Name: 'ಮಂತ್ರ',
    level1Sanskrit: 'मन्त्रः',
    level3Name: 'ಮಂತ್ರ',
    level3Sanskrit: 'मन्त्रः',
  },
  {
    keywords: ['केनोपनिषत्', 'केनेषितं', 'kena upanishat', 'kenopanishad', 'kena upanishad'],
    work: 'केनोपनिषत्',
    workKannada: 'ಕೇನೋಪನಿಷತ್',
    genre: 'ಉಪನಿಷತ್',
    level1Name: 'ಖಂಡ',
    level1Sanskrit: 'खण्डः',
    level3Name: 'ಮಂತ್ರ',
    level3Sanskrit: 'मन्त्रः',
  },
  {
    keywords: ['कठोपनिषत्', 'काठकोपनिषत्', 'कठ उपनिषद', 'नचिकेता', 'नचिकेतस्', 'यम-नचिकेत', 'उत्तिष्ठत जाग्रत', 'katha upanishat', 'kathopanishad', 'katha upanishad'],
    work: 'कठोपनिषत्',
    workKannada: 'ಕಠೋಪನಿಷತ್',
    genre: 'ಉಪನಿಷತ್',
    level1Name: 'ಅಧ್ಯಾಯ',
    level1Sanskrit: 'अध्यायः',
    level2Name: 'ವಲ್ಲಿ',
    level2Sanskrit: 'वल्ली',
    level3Name: 'ಮಂತ್ರ',
    level3Sanskrit: 'मन्त्रः',
  },
  {
    keywords: ['प्रश्नोपनिषत्', 'prashna upanishat', 'prashnopanishad', 'prashna upanishad'],
    work: 'प्रश्नोपनिषत्',
    workKannada: 'ಪ್ರಶ್ನೋಪನಿಷತ್',
    genre: 'ಉಪನಿಷತ್',
    level1Name: 'ಪ್ರಶ್ನೆ',
    level1Sanskrit: 'प्रश्नः',
    level3Name: 'ಮಂತ್ರ',
    level3Sanskrit: 'मन्त्रः',
  },
  {
    keywords: ['मुण्डकोपनिषत्', 'mundaka upanishat', 'mundakopanishad', 'mundaka upanishad', 'द्वा सुपर्णा'],
    work: 'मुण्डकोपನಿषत्',
    workKannada: 'ಮುಂಡಕೋಪನಿಷತ್',
    genre: 'ಉಪನಿಷತ್',
    level1Name: 'ಮುಂಡಕ',
    level1Sanskrit: 'मुण्डकम्',
    level2Name: 'ಖಂಡ',
    level2Sanskrit: 'खण्डः',
    level3Name: 'ಮಂತ್ರ',
    level3Sanskrit: 'मन्त्रः',
  },
  {
    keywords: ['माण्डूक्‍योपनिषत्', 'माण्डूक्योपनिषत्', 'mandukya upanishad', 'mandukyopanishad'],
    work: 'माण्डूक्योपनिषत्',
    workKannada: 'ಮಾಣ್ಡೂಕ್ಯೋಪನಿಷತ್',
    genre: 'ಉಪನಿಷತ್',
    level1Name: 'ಖಂಡ',
    level1Sanskrit: 'खण्डः',
    level3Name: 'ಮಂತ್ರ',
    level3Sanskrit: 'मन्त्रः',
  },
  {
    keywords: ['तैत्तिरीयोपनिषत्', 'शीक्षावल्ली', 'ब्रह्मानन्दवल्ली', 'भृगुवल्ली', 'taittiriya upanishad'],
    work: 'तैत्तिरीयोपनिषत्',
    workKannada: 'ತೈತ್ತಿರೀಯೋಪನಿಷತ್',
    genre: 'ಉಪನಿಷತ್',
    level1Name: 'ವಲ್ಲಿ',
    level1Sanskrit: 'वल्ली',
    level2Name: 'ಅನುವಾಕ',
    level2Sanskrit: 'अनुवाकः',
    level3Name: 'ಮಂತ್ರ',
    level3Sanskrit: 'मन्त्रः',
  },
  {
    keywords: ['ऐतरेयोपनिषत्', 'aitareya upanishad', 'aitareyopanishad'],
    work: 'ऐतरेयोपनिषत्',
    workKannada: 'ಐತರೇಯೋಪನಿಷತ್',
    genre: 'ಉಪನಿಷತ್',
    level1Name: 'ಅಧ್ಯಾಯ',
    level1Sanskrit: 'अध्यायः',
    level2Name: 'ಖಂಡ',
    level2Sanskrit: 'खण्डः',
    level3Name: 'ಮಂತ್ರ',
    level3Sanskrit: 'मन्त्रः',
  },
  {
    keywords: ['छान्दोग्योपनिषत्', 'chandogya upanishad', 'chandogyopanishad'],
    work: 'छान्दोग्योपनिषत्',
    workKannada: 'ಛಾಂದೋಗ್ಯೋಪನಿಷತ್',
    genre: 'ಉಪನಿಷತ್',
    level1Name: 'ಪ್ರಪಾಠಕ',
    level1Sanskrit: 'प्रपाठकः',
    level2Name: 'ಖಂಡ',
    level2Sanskrit: 'खण्डः',
    level3Name: 'ಮಂತ್ರ',
    level3Sanskrit: 'मन्त्रः',
  },
  {
    keywords: ['बृहदारण्यकोपनिषत्', 'brihadaranyaka upanishad'],
    work: 'बृहदारण्यकोपनिषत्',
    workKannada: 'ಬೃಹದಾರಣ್ಯಕೋಪನಿಷತ್',
    genre: 'ಉಪನಿಷತ್',
    level1Name: 'ಅಧ್ಯಾಯ',
    level1Sanskrit: 'अध्यायः',
    level2Name: 'ಬ್ರಾಹ್ಮಣ',
    level2Sanskrit: 'ब्राह्मणम्',
    level3Name: 'ಮಂತ್ರ',
    level3Sanskrit: 'मन्त्रः',
  },
  {
    keywords: ['श्वेताश्वतरोपनिषत्', 'shvetashvatara upanishad'],
    work: 'श्वेताश्वतरोपनिषत्',
    workKannada: 'ಶ್ವೇತಾಶ್ವತರೋಪನಿಷತ್',
    genre: 'ಉಪನಿಷತ್',
    level1Name: 'ಅಧ್ಯಾಯ',
    level1Sanskrit: 'अध्यायः',
    level3Name: 'ಮಂತ್ರ',
    level3Sanskrit: 'मन्त्रः',
  },
  {
    keywords: ['108 upanishat', '108 upanishad', 'ಅಷ್ಟೋತ್ತರಶತೋಪನಿಷತ್', '१०८ उपनिषद', '१०८ उपनिषत्', 'उपनिषत्सङ्ग्रह', 'अष्टोत्तरशतोपनिषदः'],
    work: 'अष्टोत्तरशतोपनिषदः (108 Upanishads)',
    workKannada: 'ಅಷ್ಟೋತ್ತರಶತೋಪನಿಷದಃ (108 ಉಪನಿಷತ್ತುಗಳು)',
    genre: 'ಉಪನಿಷತ್ ಸಾರ / ವೇದಾಂತ',
    level1Name: 'ಉಪನಿಷತ್',
    level1Sanskrit: 'उपनिषत्',
    level2Name: 'ಖಂಡ',
    level2Sanskrit: 'खण्डः',
    level3Name: 'ಮಂತ್ರ',
    level3Sanskrit: 'मन्त्रः',
  },
  // 3. Vedic Samhitas & Suktas
  {
    keywords: ['ऋग्वेद', 'ऋग्वेदसंहिता', 'ऋग्वेदम्', 'rigveda', 'rgveda'],
    work: 'ऋग्वेदसंहिता',
    workKannada: 'ಋಗ್ವೇದಸಂಹಿತಾ',
    genre: 'ವೇದ ಸಂಹಿತಾ',
    level1Name: 'ಮಂಡಲ',
    level1Sanskrit: 'मण्डलम्',
    level2Name: 'ಸೂಕ್ತ',
    level2Sanskrit: 'सूक्तम्',
    level3Name: 'ಋಕ್',
    level3Sanskrit: 'ऋक्',
  },
  {
    keywords: ['सामवेद', 'सामवेदसंहिता', 'samaveda'],
    work: 'सामवेदसंहिता',
    workKannada: 'ಸಾಮವೇದಸಂಹಿತಾ',
    genre: 'ವೇದ ಸಂಹಿತಾ',
    level1Name: 'ಪ್ರಪಾಠಕ',
    level1Sanskrit: 'प्रपाठकः',
    level2Name: 'ದಶತಿ',
    level2Sanskrit: 'दशती',
    level3Name: 'ಮಂತ್ರ',
    level3Sanskrit: 'मन्त्रः',
  },
  {
    keywords: ['यजुर्वेद', 'शुक्ल यजुर्वेद', 'कृष्ण यजुर्वेद', 'वाजसनेयिसंहिता', 'yajurveda'],
    work: 'यजुर्वेदसंहिता',
    workKannada: 'ಯಜುರ್ವೇದಸಂಹಿತಾ',
    genre: 'ವೇದ ಸಂಹಿತಾ',
    level1Name: 'ಅಧ್ಯಾಯ',
    level1Sanskrit: 'अध्यायः',
    level2Name: 'ಅನುವಾಕ',
    level2Sanskrit: 'अनुवाकः',
    level3Name: 'ಮಂತ್ರ',
    level3Sanskrit: 'मन्त्रः',
  },
  {
    keywords: ['अथर्ववेद', 'अथर्ववेदसंहिता', 'atharvaveda'],
    work: 'अथर्ववेदसंहिता',
    workKannada: 'ಅಥರ್ವವೇದಸಂಹಿತಾ',
    genre: 'ವೇದ ಸಂಹಿತಾ',
    level1Name: 'ಕಾಂಡ',
    level1Sanskrit: 'काण्डम्',
    level2Name: 'ಸೂಕ್ತ',
    level2Sanskrit: 'सूक्तम्',
    level3Name: 'ಮಂತ್ರ',
    level3Sanskrit: 'मन्त्रः',
  },
  // 4. Puranas & Mahapuranas
  {
    keywords: ['श्रीमद्भागवत', 'श्रीमद्भागवतपुराण', 'भागवतपुराण', 'bhagavata purana'],
    work: 'श्रीमद्भागवतपुराणम्',
    workKannada: 'ಶ್ರೀಮದ್ಭಾಗವತಪುರಾಣಂ',
    genre: 'ಮಹಾಪುರಾಣ',
    level1Name: 'ಸ್ಕಂಧ',
    level1Sanskrit: 'स्कन्धः',
    level2Name: 'ಅಧ್ಯಾಯ',
    level2Sanskrit: 'अध्यायः',
    level3Name: 'ಶ್ಲೋಕ',
    level3Sanskrit: 'श्लोकः',
  },
  {
    keywords: ['विष्णुपुराण', 'श्रीविष्णुपुराण', 'vishnu purana', 'vishnupurana'],
    work: 'श्रीविष्णुपुराणम्',
    workKannada: 'ಶ್ರೀವಿಷ್ಣುಪುರಾಣಂ',
    genre: 'ಪುರಾಣ',
    level1Name: 'ಅಂಶ',
    level1Sanskrit: 'अंशः',
    level2Name: 'ಅಧ್ಯಾಯ',
    level2Sanskrit: 'अध्यायः',
    level3Name: 'ಶ್ಲೋಕ / ಗದ್ಯ',
    level3Sanskrit: 'श्लोकः/गद्यम्',
  },
  {
    keywords: ['शिवपुराण', 'शिवमहापुराण', 'shiva purana'],
    work: 'शिवमहापुराणम्',
    workKannada: 'ಶಿವಮಹಾಪುರಾಣಂ',
    genre: 'ಮಹಾಪುರಾಣ',
    level1Name: 'ಸಂಹಿತಾ',
    level1Sanskrit: 'संहिता',
    level2Name: 'ಅಧ್ಯಾಯ',
    level2Sanskrit: 'अध्यायः',
    level3Name: 'ಶ್ಲೋಕ',
    level3Sanskrit: 'श्लोकः',
  },
  // 5. Darshanas & Shastras
  {
    keywords: ['पातञ्जलयोगसूत्र', 'योगसूत्र', 'पातञ्जल', 'समाधिपाद', 'साधनपाद', 'विभूतिपाद', 'कैवल्यपाद', 'yoga sutra'],
    work: 'पातञ्जलयोगसूत्राणि',
    workKannada: 'ಪಾತಂಜಲಯೋಗಸೂತ್ರಾಣಿ',
    genre: 'ದರ್ಶನ / ಯೋಗ ಶಾಸ್ತ್ರ',
    level1Name: 'ಪಾದ',
    level1Sanskrit: 'पादः',
    level3Name: 'ಸೂತ್ರ',
    level3Sanskrit: 'सूत्रम्',
  },
  {
    keywords: ['ब्रह्मसूत्र', 'ब्रह्मसूत्राणि', 'शारीरकसूत्र', 'brahma sutra'],
    work: 'ब्रह्मसूत्राणि',
    workKannada: 'ಬ್ರಹ್ಮಸೂತ್ರಾಣಿ',
    genre: 'ದರ್ಶನ / ವೇದಾಂತ',
    level1Name: 'ಅಧ್ಯಾಯ',
    level1Sanskrit: 'अध्यायः',
    level2Name: 'ಪಾದ',
    level2Sanskrit: 'पादः',
    level3Name: 'ಸೂತ್ರ',
    level3Sanskrit: 'सूत्रम्',
  },
  {
    keywords: ['मनुस्मृति', 'मनुस्मृतिः', 'manusmriti'],
    work: 'मनुस्मृतिः',
    workKannada: 'ಮನುಸ್ಮೃತಿಃ',
    genre: 'ಧರ್ಮಶಾಸ್ತ್ರ',
    level1Name: 'ಅಧ್ಯಾಯ',
    level1Sanskrit: 'अध्यायः',
    level3Name: 'ಶ್ಲೋಕ',
    level3Sanskrit: 'श्लोकः',
  },
  {
    keywords: ['अर्थशास्त्र', 'कौटिलीय', 'arthashastra', 'kautilya'],
    work: 'कौटिलीयम् अर्थशास्त्रम्',
    workKannada: 'ಕೌಟಿಲೀಯಂ ಅರ್ಥಶಾಸ್ತ್ರಂ',
    genre: 'ಅರ್ಥಶಾಸ್ತ್ರ / ರಾಜನೀತಿ',
    level1Name: 'ಅಧಿಕರಣ',
    level1Sanskrit: 'अधिकरणम्',
    level2Name: 'ಅಧ್ಯಾಯ',
    level2Sanskrit: 'अध्यायः',
    level3Name: 'ಪ್ರಕರಣ / ಸೂತ್ರ',
    level3Sanskrit: 'प्रकरणम्/सूत्रम्',
  },
  {
    keywords: ['साङ्ख्यकारिका', 'सांख्यकारिका', 'samkhyakarika'],
    work: 'साङ्ख्यकारिका',
    workKannada: 'ಸಾಂಖ್ಯಕಾರಿಕಾ',
    genre: 'ದರ್ಶನ / ಸಾಂಖ್ಯ ಶಾಸ್ತ್ರ',
    level1Name: 'ಕಾರಿಕಾ',
    level1Sanskrit: 'कारिका',
    level3Name: 'ಕಾರಿಕಾ',
    level3Sanskrit: 'कारिका',
  },
  // 6. Classical Sanskrit Literature (Kavya, Nataka, Gadya)
  {
    keywords: ['रघुवंश', 'रघुवंशम्', 'raghuvamsha'],
    work: 'रघुवंशम्',
    workKannada: 'ರಘುವಂಶಂ',
    genre: 'ಮಹಾಕಾವ್ಯ',
    level1Name: 'ಸರ್ಗ',
    level1Sanskrit: 'सर्गः',
    level3Name: 'ಶ್ಲೋಕ',
    level3Sanskrit: 'श्लोकः',
  },
  {
    keywords: ['कुमारसम्भव', 'कुमारसम्भवम्', 'kumarasambhava'],
    work: 'कुमारसम्भवम्',
    workKannada: 'ಕುಮಾರಸಂಭವಂ',
    genre: 'ಮಹಾಕಾವ್ಯ',
    level1Name: 'ಸರ್ಗ',
    level1Sanskrit: 'सर्गः',
    level3Name: 'ಶ್ಲೋಕ',
    level3Sanskrit: 'श्लोकः',
  },
  {
    keywords: ['मेघदूत', 'मेघदूतम्', 'पूर्वमेघ', 'उत्तरमेघ', 'meghaduta'],
    work: 'मेघदूतम्',
    workKannada: 'ಮೇಘದೂತಂ',
    genre: 'ಖಂಡಕಾವ್ಯ',
    level1Name: 'ಭಾಗ',
    level1Sanskrit: 'भागः',
    level3Name: 'ಶ್ಲೋಕ',
    level3Sanskrit: 'श्लोकः',
  },
  {
    keywords: ['अभिज्ञानशाकुन्तल', 'शाकुन्तल', 'abhijnanashakuntala'],
    work: 'अभिज्ञानशाकुन्तलम्',
    workKannada: 'ಅಭಿಜ್ಞಾನಶಾಕುಂತಲಂ',
    genre: 'ರೂಪಕ / ನಾಟಕ',
    level1Name: 'ಅಂಕ',
    level1Sanskrit: 'अङ्कः',
    level3Name: 'ಶ್ಲೋಕ / ಗದ್ಯ',
    level3Sanskrit: 'श्लोकः/गद्यम्',
  },
  {
    keywords: ['कादम्बरी', 'kadambari'],
    work: 'कादम्बरी',
    workKannada: 'ಕಾದಂಬರೀ',
    genre: 'ಗದ್ಯ ಕಾವ್ಯ',
    level1Name: 'ಭಾಗ',
    level1Sanskrit: 'भागः',
    level3Name: 'ಗದ್ಯ ಭಾಗ / ಶ್ಲೋಕ',
    level3Sanskrit: 'गद्यभागः',
  },
  {
    keywords: ['पञ्चतन्त्र', 'पञ्चतन्त्रम्', 'मित्रभेद', 'मित्रप्राप्ति', 'काकोलूकीय', 'लब्धप्रणाश', 'अपरीक्षितकारक', 'panchatantra'],
    work: 'पञ्चतन्त्रम्',
    workKannada: 'ಪಂಚತಂತ್ರಂ',
    genre: 'ನೀತಿ ಕಥಾ ಸಾಹಿತ್ಯ',
    level1Name: 'ತಂತ್ರ',
    level1Sanskrit: 'तन्त्रम्',
    level3Name: 'ಕಥಾ ಭಾಗ / ಶ್ಲೋಕ',
    level3Sanskrit: 'कथा/श्लोकः',
  },
  // 7. Stotras & Tantra
  {
    keywords: ['विष्णुसहस्रनाम', 'विष्णुसहस्रनामस्तोत्र', 'vishnu sahasranama'],
    work: 'श्रीविष्णुसहस्रनामस्तोत्रम्',
    workKannada: 'ಶ್ರೀವಿಷ್ಣುಸಹಸ್ರನಾಮಸ್ತೋತ್ರಂ',
    genre: 'ಸ್ತೋತ್ರ ಸಾಹಿತ್ಯ',
    level1Name: 'ಭಾಗ',
    level1Sanskrit: 'भागः',
    level3Name: 'ಶ್ಲೋಕ',
    level3Sanskrit: 'श्लोकः',
  },
  {
    keywords: ['ललितासहस्रनाम', 'ललितासहस್ರನಾಮಸ್ತೋತ್ರ', 'lalitha sahasranama'],
    work: 'श्रीललितासहस्रनामस्तोत्रम्',
    workKannada: 'ಶ್ರೀಲಲಿತಾಸಹಸ್ರನಾಮಸ್ತೋತ್ರಂ',
    genre: 'ಸ್ತೋತ್ರ / ತಂತ್ರ',
    level1Name: 'ಭಾಗ',
    level1Sanskrit: 'भागः',
    level3Name: 'ಶ್ಲೋಕ',
    level3Sanskrit: 'श्लोकः',
  },
  {
    keywords: ['सौन्दर्यलहरी', 'soundaryalahari'],
    work: 'सौन्दर्यलहरी',
    workKannada: 'ಸೌಂದರ್ಯಲಹರೀ',
    genre: 'ಸ್ತೋತ್ರ / ತಂತ್ರ',
    level1Name: 'ಲಹರಿ',
    level1Sanskrit: 'लहरी',
    level3Name: 'ಶ್ಲೋಕ',
    level3Sanskrit: 'ಶ್ಲೋಕಃ',
  },
  {
    keywords: ['शिवमहिम्नस्तोत्र', 'शिवमहिम्नः', 'shivamahimna'],
    work: 'शिवमहिम्नः स्तोत्रम्',
    workKannada: 'ಶಿವಮಹಿಮ್ನಃ ಸ್ತೋತ್ರಂ',
    genre: 'ಸ್ತೋತ್ರ ಸಾಹಿತ್ಯ',
    level1Name: 'ಭಾಗ',
    level1Sanskrit: 'भागः',
    level3Name: 'ಶ್ಲೋಕ',
    level3Sanskrit: 'श्लोकः',
  },
];

// ----------------- Sanskrit Ordinal to Integer Mapping -----------------

const SANSKRIT_ORDINALS: Array<{ patterns: RegExp[]; value: number; kanNumber: string }> = [
  { patterns: [/प्रथम[ः|ो|ा|म्]?/i, /^೧$/], value: 1, kanNumber: '೧' },
  { patterns: [/द्वितीय[ः|ो|ा|म्]?/i, /^೨$/], value: 2, kanNumber: '೨' },
  { patterns: [/तृतीय[ः|ो|ा|म्]?/i, /^೩$/], value: 3, kanNumber: '೩' },
  { patterns: [/चतुर्थ[ः|ो|ी|म्]?/i, /^೪$/], value: 4, kanNumber: '೪' },
  { patterns: [/पञ्चम[ः|ो|ी|म्]?/i, /^೫$/], value: 5, kanNumber: '೫' },
  { patterns: [/षष्ठ[ः|ो|ी|म्]?/i, /^೬$/], value: 6, kanNumber: '೬' },
  { patterns: [/सप्तम[ः|ो|ी|म्]?/i, /^೭$/], value: 7, kanNumber: '೭' },
  { patterns: [/अष्टम[ः|ो|ी|म्]?/i, /^೮$/], value: 8, kanNumber: '೮' },
  { patterns: [/नवम[ः|ो|ी|म्]?/i, /^೯$/], value: 9, kanNumber: '೯' },
  { patterns: [/दशम[ः|ो|ी|म्]?/i, /^೧೦$/], value: 10, kanNumber: '೧೦' },
  { patterns: [/एकादश[ः|ो|ी|म्]?/i], value: 11, kanNumber: '೧೧' },
  { patterns: [/द्वादश[ः|ो|ी|म्]?/i], value: 12, kanNumber: '೧೨' },
  { patterns: [/त्रयोदश[ः|ो|ी|म्]?/i], value: 13, kanNumber: '೧೩' },
  { patterns: [/चतुर्दश[ः|ो|ी|म्]?/i], value: 14, kanNumber: '೧೪' },
  { patterns: [/पञ्चदश[ः|ो|ी|म्]?/i], value: 15, kanNumber: '೧೫' },
  { patterns: [/षोडश[ः|ो|ी|म्]?/i], value: 16, kanNumber: '೧೬' },
  { patterns: [/सप्तदश[ः|ो|ी|म्]?/i], value: 17, kanNumber: '೧೭' },
  { patterns: [/अष्टादश[ः|ो|ी|म्]?/i], value: 18, kanNumber: '೧೮' },
  { patterns: [/एकोनविंश[ः|ो|ी|त]?/i], value: 19, kanNumber: '೧೯' },
  { patterns: [/विंश[ः|ो|ी|त]?/i], value: 20, kanNumber: '೨೦' },
  { patterns: [/एकविंश[ः|ो|ी|त]?/i], value: 21, kanNumber: '೨೧' },
  { patterns: [/द्वाविंश[ः|ो|ी|त]?/i], value: 22, kanNumber: '೨೨' },
  { patterns: [/त्रयोविंश[ः|ो|ी|त]?/i], value: 23, kanNumber: '೨೩' },
  { patterns: [/चतुर्विंश[ः|ो|ी|त]?/i], value: 24, kanNumber: '೨೪' },
  { patterns: [/पञ्चविंश[ः|ो|ी|त]?/i], value: 25, kanNumber: '೨೫' },
  { patterns: [/षड्विंश[ः|ो|ी|त]?|षड्वಿंशतितम/i], value: 26, kanNumber: '೨೬' },
  { patterns: [/सप्तविंश[ः|ो|ी|त]?/i], value: 27, kanNumber: '೨೭' },
  { patterns: [/अष्टाविंश[ः|ो|ी|त]?/i], value: 28, kanNumber: '೨೮' },
  { patterns: [/एकोनत्रिंश[ः|ो|ी|त]?/i], value: 29, kanNumber: '೨೯' },
  { patterns: [/त्रिंश[ः|ो|ी|त]?/i], value: 30, kanNumber: '೩೦' },
  { patterns: [/चत्वारिंश[ः|ो|ी|त]?/i], value: 40, kanNumber: '೪೦' },
  { patterns: [/पञ्चाश[ः|ो|ी|त]?/i], value: 50, kanNumber: '೫೦' },
  { patterns: [/षष्टि/i], value: 60, kanNumber: '೬೦' },
  { patterns: [/सप्तति/i], value: 70, kanNumber: '೭೦' },
  { patterns: [/अशीति/i], value: 80, kanNumber: '೮೦' },
  { patterns: [/नवति/i], value: 90, kanNumber: '೯೦' },
  { patterns: [/शत[ः|म्|तम]?/i], value: 100, kanNumber: '೧೦೦' },
];

export function parseSanskritOrdinal(text: string): number | null {
  const norm = text.toLowerCase();
  for (const item of SANSKRIT_ORDINALS) {
    for (const pat of item.patterns) {
      if (pat.test(norm)) return item.value;
    }
  }
  // Try direct digits
  const digitMatch = toEnglishDigits(text).match(/\b(\d+)\b/);
  if (digitMatch && digitMatch[1]) {
    return parseInt(digitMatch[1], 10);
  }
  return null;
}

// ----------------- Sanskrit Structural Division Terms -----------------

interface DivisionTerm {
  pattern: RegExp;
  kannadaName: string;
  sanskritName: string;
  level: 1 | 2;
}

const DIVISION_TERMS: DivisionTerm[] = [
  { pattern: /प्रपाठक[ः|े|म्]?/i, kannadaName: 'ಪ್ರಪಾಠಕ', sanskritName: 'प्रपाठकः', level: 1 },
  { pattern: /काण्ड[म्|ः|े]?/i, kannadaName: 'ಕಾಂಡ', sanskritName: 'काण्डम्', level: 1 },
  { pattern: /पर्व[णि|म्|ः]?/i, kannadaName: 'ಪರ್ವ', sanskritName: 'पर्व', level: 1 },
  { pattern: /अध्याय[ः|े|म्]?/i, kannadaName: 'ಅಧ್ಯಾಯ', sanskritName: 'अध्यायः', level: 1 },
  { pattern: /सर्ग[ः|े|म्]?/i, kannadaName: 'ಸರ್ಗ', sanskritName: 'सर्गः', level: 2 },
  { pattern: /मण्डल[म्|े|ः]?/i, kannadaName: 'ಮಂಡಲ', sanskritName: 'मण्डलम्', level: 1 },
  { pattern: /वल्ली/i, kannadaName: 'ವಲ್ಲಿ', sanskritName: 'वल्ली', level: 1 },
  { pattern: /प्रश्न[ः|े|म्]?/i, kannadaName: 'ಪ್ರಶ್ನೆ', sanskritName: 'प्रश्नः', level: 1 },
  { pattern: /खण्ड[ः|े|म्]?/i, kannadaName: 'ಖಂಡ', sanskritName: 'खण्डः', level: 2 },
  { pattern: /पाद[ः|े|म्]?/i, kannadaName: 'ಪಾದ', sanskritName: 'पादः', level: 2 },
  { pattern: /स्कन्ध[ः|े|म्]?/i, kannadaName: 'ಸ್ಕಂಧ', sanskritName: 'स्कन्धः', level: 1 },
  { pattern: /उल्लास[ः|े|म्]?/i, kannadaName: 'ಉಲ್ಲಾಸ', sanskritName: 'उल्लासः', level: 1 },
  { pattern: /तरङ्ग[ः|े|म्]?/i, kannadaName: 'ತರಂಗ', sanskritName: 'तरङ्गः', level: 1 },
  { pattern: /परिच्छेद[ः|े|म्]?/i, kannadaName: 'ಪರಿಚ್ಛೇದ', sanskritName: 'परिच्छेदः', level: 1 },
  { pattern: /प्रकरण[म्|े|ः]?/i, kannadaName: 'ಪ್ರಕರಣ', sanskritName: 'प्रकरणम्', level: 1 },
  { pattern: /अंश[ः|े|म्]?/i, kannadaName: 'ಅಂಶ', sanskritName: 'अंशः', level: 1 },
  { pattern: /स्थान[म्|े|ः]?/i, kannadaName: 'ಸ್ಥಾನ', sanskritName: 'स्थानम्', level: 1 },
  { pattern: /स्तबक[ः|े|म्]?/i, kannadaName: 'ಸ್ತಬಕ', sanskritName: 'स्तबकः', level: 1 },
  { pattern: /प्रकाश[ः|े|म्]?/i, kannadaName: 'ಪ್ರಕಾಶ', sanskritName: 'प्रकाशः', level: 1 },
  { pattern: /उच्छ्वास[ः|े|म्]?/i, kannadaName: 'ಉಚ್ಛ್ವಾಸ', sanskritName: 'उच्छ्वासः', level: 1 },
  { pattern: /विलास[ः|े|म्]?/i, kannadaName: 'ವಿಲಾಸ', sanskritName: 'विलासः', level: 1 },
  { pattern: /लहरी/i, kannadaName: 'ಲಹರಿ', sanskritName: 'लहरी', level: 1 },
  { pattern: /अङ्क[ः|े|म्]?/i, kannadaName: 'ಅಂಕ', sanskritName: 'अङ्कः', level: 1 },
  { pattern: /ब्राह्मण[म्|े|ः]?/i, kannadaName: 'ಬ್ರಾಹ್ಮಣ', sanskritName: 'ब्राह्मणम्', level: 2 },
  { pattern: /अनुवाक[ः|े|म्]?/i, kannadaName: 'ಅನುವಾಕ', sanskritName: 'अनुवाकः', level: 2 },
  { pattern: /सूक्त[म्|े|ः]?/i, kannadaName: 'ಸೂಕ್ತ', sanskritName: 'सूक्तम्', level: 2 },
  { pattern: /दशती/i, kannadaName: 'ದಶತಿ', sanskritName: 'दशती', level: 2 },
];

// ----------------- Dynamic Grantha & Document Structure Detection -----------------

/**
 * Dynamically identifies Sanskrit book title, genre, and hierarchical naming conventions
 * from the complete document text or file metadata without assuming fake divisions or headers.
 */
export function detectDocumentStructure(textOrFileName: string): DetectedStructure {
  const normalized = textOrFileName.toLowerCase();

  // 1. Check against Canonical Knowledge Base for precise signature matching
  for (const sig of CANONICAL_WORK_SIGNATURES) {
    for (const kw of sig.keywords) {
      if (textOrFileName.includes(kw) || normalized.includes(kw.toLowerCase())) {
        return {
          detectedWork: sig.work,
          detectedWorkKannada: sig.workKannada,
          genre: sig.genre,
          level1Name: sig.level1Name,
          level1Sanskrit: sig.level1Sanskrit,
          level2Name: sig.level2Name,
          level2Sanskrit: sig.level2Sanskrit,
          level3Name: sig.level3Name,
          level3Sanskrit: sig.level3Sanskrit,
          confidence: 0.98,
          isCanonical: true,
        };
      }
    }
  }

  // 2. Generic Upanishad Title Matcher (e.g. Garbha Upanishad, Kaivalya Upanishad, etc.)
  const upanishadMatch = textOrFileName.match(/(?:([A-Za-z\u0900-\u097F\u0C80-\u0CFF]+)\s*(?:Upanishad|Upanishat|उपनिषत्|उपनिषद|ೋಪನಿಷತ್|ಉಪನಿಷತ್))/i);
  if (upanishadMatch) {
    const rawUpanishad = upanishadMatch[0].trim();
    if (rawUpanishad.length >= 4) {
      return {
        detectedWork: rawUpanishad,
        detectedWorkKannada: rawUpanishad,
        genre: 'ಉಪನಿಷತ್ / ವೇದಾಂತ',
        level1Name: '',
        level1Sanskrit: '',
        level3Name: 'ಮಂತ್ರ',
        level3Sanskrit: 'मन्त्रः',
        confidence: 0.92,
        isCanonical: false,
      };
    }
  }

  // 3. Dynamic Title Extraction from Invocations & Headings (e.g. "॥ अथ ... ॥", "॥ श्रीमद्... ॥")
  const titleRegexes = [
    /॥\s*(?:अथ|श्री|श्रीमद्)\s*([^॥\n]+?)\s*(?:प्रारम्भः|प्रारभ्यते|समाप्तः|सम्पूर्णम्)?\s*॥/i,
    /(?:ग्रन्थनाम|ग्रन्थस्य\s*नाम|Title\s*:|Book\s*:)\s*[:\-]?\s*([^\n,।॥]{3,50})/i,
    /इति\s+श्रीमद्?([^\n,।॥]{3,50}?)(?:समाप्त|सम्पूर्ण|अध्याय)/i,
    /(?:^|\n)\s*([A-Za-z\u0900-\u097F\u0C80-\u0CFF\s]{4,40}\s*(?:स्तोत्रम्|स्तोत्र|उपनिषत्|उपनिषद|संहिता|पुराणम्|काव्यम्|सूक्तम्|ಸೂಕ್ತ|ಸ್ತೋತ್ರ|ಉಪನಿಷತ್))\s*(?:\n|$)/i,
  ];

  let dynamicTitle = '';
  for (const rx of titleRegexes) {
    const m = textOrFileName.match(rx);
    if (m && m[1] && m[1].trim().length > 3) {
      const candidate = m[1].trim();
      // Ensure candidate has Devanagari or Latin letters and is not a random sentence
      if (/[\u0900-\u097F\u0C80-\u0CFF]/.test(candidate) && !/चतुर्थे\s*मासे|पञ्चमे\s*मासे/i.test(candidate)) {
        dynamicTitle = candidate.replace(/[॥|।0-9]/g, '').trim();
        break;
      }
    }
  }

  // 4. Dynamic Structural Division Detection (ONLY if explicit chapter/division headers are present)
  // We NEVER assume divisions like 'ಪಾದ' or 'ಅಧ್ಯಾಯ' unless there is an explicit numbered heading.
  const explicitDivisionRegexes: Array<{ rx: RegExp; kannadaName: string; sanskritName: string; level: 1 | 2 }> = [
    { rx: /(?:॥\s*)?(?:प्रथम|द्वितीय|तृतीय|चतुर्थ|पञ्चम|षष्ठ|सप्तम|अष्टम|नवम|दशम|[0-9०-९]+)[ः|ो|ा|म्]?\s*अध्याय/i, kannadaName: 'ಅಧ್ಯಾಯ', sanskritName: 'अध्यायः', level: 1 },
    { rx: /(?:॥\s*)?(?:प्रथम|द्वितीय|तृतीय|चतुर्थ|पञ्चम|षष्ठ|सप्तम|अष्टम|[0-9०-९]+)[ः|ो|ा|म्]?\s*सर्ग/i, kannadaName: 'ಸರ್ಗ', sanskritName: 'सर्गः', level: 1 },
    { rx: /(?:॥\s*)?(?:प्रथम|द्वितीय|तृतीय|चतुर्थ|पञ्चम|[0-9०-९]+)[ः|ो|ा|म्]?\s*पर्व/i, kannadaName: 'ಪರ್ವ', sanskritName: 'पर्व', level: 1 },
    { rx: /(?:॥\s*)?(?:प्रथम|द्वितीय|तृतीय|चतुर्थ|[0-9०-९]+)[ः|ो|ा|म्]?\s*काण्ड/i, kannadaName: 'ಕಾಂಡ', sanskritName: 'काण्डम्', level: 1 },
    { rx: /(?:॥\s*)?(?:प्रथम|द्वितीय|तृतीय|चतुर्थ|[0-9०-९]+)[ः|ो|ा|म्]?\s*वल्ली/i, kannadaName: 'ವಲ್ಲಿ', sanskritName: 'वल्ली', level: 1 },
    { rx: /(?:॥\s*)?(?:प्रथम|द्वितीय|तृतीय|चतुर्थ|[0-9०-९]+)[ः|ो|ा|म्]?\s*खण्ड/i, kannadaName: 'ಖಂಡ', sanskritName: 'खण्डः', level: 1 },
    { rx: /(?:॥\s*)?(?:प्रथम|द्वितीय|तृतीय|चतुर्थ|[0-9०-९]+)[ः|ो|ा|म्]?\s*पाद/i, kannadaName: 'ಪಾದ', sanskritName: 'पादः', level: 1 },
    { rx: /(?:॥\s*)?(?:प्रथम|द्वितीय|तृतीय|चतुर्थ|[0-9०-९]+)[ः|ो|ा|म्]?\s*स्कन्ध/i, kannadaName: 'ಸ್ಕಂಧ', sanskritName: 'स्कन्धः', level: 1 },
    { rx: /(?:॥\s*)?(?:प्रथम|द्वितीय|तृतीय|चतुर्थ|[0-9०-९]+)[ः|ो|ा|म्]?\s*उल्लास/i, kannadaName: 'ಉಲ್ಲಾಸ', sanskritName: 'उल्लासः', level: 1 },
    { rx: /(?:अध्याय|सर्ग|काण्ड|पर्व|स्कन्ध|ವಲ್ಲಿ|ಖಂಡ|ಅಧ್ಯಾಯ|ಕಾಂಡ|ಸರ್ಗ)\s*[:\-]?\s*[0-9०-९]+/i, kannadaName: 'ಅಧ್ಯಾಯ', sanskritName: 'अध्यायः', level: 1 },
  ];

  let detectedLevel1: { kannadaName: string; sanskritName: string } | null = null;
  let detectedLevel2: { kannadaName: string; sanskritName: string } | null = null;

  for (const div of explicitDivisionRegexes) {
    if (div.rx.test(textOrFileName)) {
      if (div.level === 1 && !detectedLevel1) {
        detectedLevel1 = { kannadaName: div.kannadaName, sanskritName: div.sanskritName };
      } else if (div.level === 2 && !detectedLevel2) {
        detectedLevel2 = { kannadaName: div.kannadaName, sanskritName: div.sanskritName };
      }
    }
  }

  // Determine Level 3 Unit name based on genre cues
  let level3Name = 'ಶ್ಲೋಕ';
  let level3Sanskrit = 'श्लोकः';
  let genre = 'ಸಂಸ್ಕೃತ ಸಾಹಿತ್ಯ / ಶಾಸ್ತ್ರ ಗ್ರಂಥ';

  if (/उपनिषत्|उपनिषद|मन्त्र|ऋक्/i.test(textOrFileName)) {
    level3Name = 'ಮಂತ್ರ';
    level3Sanskrit = 'मन्त्रः';
    genre = 'ಉಪನಿಷತ್ / ವೇದಾಂತ';
  } else if (/सूत्र/i.test(textOrFileName)) {
    level3Name = 'ಸೂತ್ರ';
    level3Sanskrit = 'सूत्रम्';
    genre = 'ದರ್ಶನ / ಸೂತ್ರ ಶಾಸ್ತ್ರ';
  } else if (/गद्य|आख्यायिका|कथा/i.test(textOrFileName)) {
    level3Name = 'ಗದ್ಯ ಭಾಗ / ಶ್ಲೋಕ';
    level3Sanskrit = 'गद्यभागः/श्लोकः';
    genre = 'ಗದ್ಯ ಸಾಹಿತ್ಯ / ಕಥಾ ಸಾಹಿತ್ಯ';
  } else if (/स्तोत्र|सहस्रनाम|लहरी|कवच/i.test(textOrFileName)) {
    level3Name = 'ಶ್ಲೋಕ';
    level3Sanskrit = 'श्लोकः';
    genre = 'ಸ್ತೋತ್ರ ಸಾಹಿತ್ಯ';
  }

  return {
    detectedWork: dynamicTitle || 'संस्कृतग्रन्थः (Sanskrit Grantha)',
    genre,
    level1Name: detectedLevel1 ? detectedLevel1.kannadaName : '',
    level1Sanskrit: detectedLevel1 ? detectedLevel1.sanskritName : '',
    level2Name: detectedLevel2 ? detectedLevel2.kannadaName : undefined,
    level2Sanskrit: detectedLevel2 ? detectedLevel2.sanskritName : undefined,
    level3Name,
    level3Sanskrit,
    confidence: dynamicTitle ? 0.85 : 0.70,
    isCanonical: false,
  };
}

// ----------------- Block-Level Classification & Noise Filtration -----------------

/**
 * Filter out web headers, running page footers, volunteer notes, and publication metadata
 */
export function cleanDocumentNoise(text: string): string {
  if (!text) return '';
  const lines = text.split('\n');
  const result: string[] = [];
  let prevWasEmpty = false;

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) {
      // Preserve single blank line as paragraph boundary, don't allow multiple consecutive blank lines
      if (!prevWasEmpty && result.length > 0) {
        result.push('');
        prevWasEmpty = true;
      }
      continue;
    }
    prevWasEmpty = false;

    // Filter out standalone solitary numbers (page numbers)
    if (/^[0-9०-९]+$/.test(trimmed)) continue;
    // Filter out website / document headers & footers
    if (/sanskritdocuments\.org/i.test(trimmed)) continue;
    if (/archive\.org/i.test(trimmed)) continue;
    if (/wikisource\.org/i.test(trimmed)) continue;
    if (/gitapress\.org/i.test(trimmed)) continue;
    if (/Document Information/i.test(trimmed)) continue;
    if (/Text title\s*:/i.test(trimmed)) continue;
    if (/File name\s*:/i.test(trimmed)) continue;
    if (/Category\s*:/i.test(trimmed)) continue;
    if (/Location\s*:/i.test(trimmed)) continue;
    if (/Author\s*:/i.test(trimmed)) continue;
    if (/Transliterated by/i.test(trimmed)) continue;
    if (/Proofread by/i.test(trimmed)) continue;
    if (/Description-comments/i.test(trimmed)) continue;
    if (/Latest update/i.test(trimmed)) continue;
    if (/Send corrections to/i.test(trimmed)) continue;
    if (/This text is prepared by volunteers/i.test(trimmed)) continue;
    if (/Please help to maintain/i.test(trimmed)) continue;
    if (/Please note that proofreading/i.test(trimmed)) continue;
    if (/pdf was typeset on/i.test(trimmed)) continue;
    if (/are generated using sanscript/i.test(trimmed)) continue;
    if (/^page\s*\d+\s*(of|\/)\s*\d+$/i.test(trimmed)) continue;

    result.push(line);
  }

  return result.join('\n');
}

// ----------------- Heading Candidate Guards (conservative, precision-first) -----------------
// These guards exist purely to REJECT weak heading candidates before they are accepted.
// They never invent or accept a heading on their own; they only tighten the existing
// division-term / "अथ" heuristics below so that ordinary śloka/prose lines that merely
// CONTAIN a structural word (e.g. "अध्याय", "सर्ग", "पर्व") are not mistaken for an
// actual chapter/section title. Extract, don't invent; when uncertain, reject.

const SANSKRIT_ORDINAL_WORD_PATTERN =
  /(?:प्रथम|द्वितीय|तृतीय|चतुर्थ|पञ्चम|षष्ठ|सप्तम|अष्टम|नवम|दशम|एकादश|द्वादश|त्रयोदश|चतुर्दश|पञ्चदश|षोडश|सप्तदश|अष्टादश|एकोनविंश|विंश|[०-९0-9]+)/i;

const DIVISION_TERM_WORD_PATTERN =
  /(?:खण्ड|वल्ली|प्रपाठक|काण्ड|सर्ग|पर्व|अध्याय|ब्राह्मण|अनुवाक|सूक्त|मण्डल|अष्टक|प्रश्न|अङ्क|उच्छ्वास|उल्लास|तरङ्ग|प्रकाश|पाद)/i;

// Words/particles that strongly indicate the candidate is a grammatically live clause
// (part of a sentence or verse) rather than an isolated title.
const SENTENCE_CONTINUATION_MARKER_PATTERN =
  /(?:सन्तु|भवन्तु|नमः|वदेत्|उवाच|उवाचेति|कुरु|कुर्यात्|अस्ति|स्यात्|अहम्|तस्मात्|तस्य|तस्याः|यदि|यथा|तथा|इति\s+च|न\s|मे\s|ते\s|वै\s|हि$|एव$|तु$|वा$|च$)/i;

/**
 * A genuine printed title is (almost always) a single short clause: at most one
 * daṇḍa/double-daṇḍa, and only at the very end (as a closing mark), never in the
 * middle. Two or more daṇḍa-delimited clauses in one candidate line means it is far
 * more likely to be verse content (e.g. two pādas of a śloka) than a title.
 */
function isStructurallyIsolatedTitle(stripped: string): boolean {
  const interiorText = stripped.replace(/[\u0964\u0965]+\s*$/g, '');
  const interiorDandaCount = (interiorText.match(/[\u0964\u0965]/g) || []).length;
  return interiorDandaCount === 0;
}

function hasSentenceContinuationMarkers(stripped: string): boolean {
  return SENTENCE_CONTINUATION_MARKER_PATTERN.test(stripped);
}

/**
 * Requires a division term (काण्ड/सर्ग/अध्याय/पर्व/...) to sit next to an ordinal
 * number/word (प्रथम, द्वितीय, १, २, ...) within a small window, matching the classic
 * title pattern "प्रथमः सर्गः" / "अध्याय १" / "द्वितीयोऽध्यायः". A bare mention of a
 * division word inside a longer sentence (e.g. describing an event "that chapter")
 * will NOT satisfy this and is correctly rejected as a heading candidate.
 */
function hasOrdinalAdjacentToDivisionTerm(text: string): boolean {
  const tokens = text.split(/\s+/).filter(Boolean);
  for (let i = 0; i < tokens.length; i++) {
    if (DIVISION_TERM_WORD_PATTERN.test(tokens[i])) {
      const windowStart = Math.max(0, i - 2);
      const windowEnd = Math.min(tokens.length, i + 3);
      const window = tokens.slice(windowStart, windowEnd).join(' ');
      if (SANSKRIT_ORDINAL_WORD_PATTERN.test(window)) return true;
    }
  }
  return false;
}

/**
 * Combined conservative check applied to every division-term / "अथ"-prefixed heading
 * candidate. A candidate must pass ALL guards to be treated as a heading; failing any
 * one of them causes it to fall through to normal śloka/gadya classification instead.
 */
function passesConservativeHeadingGuards(stripped: string): boolean {
  return isStructurallyIsolatedTitle(stripped) && !hasSentenceContinuationMarkers(stripped);
}

/**
 * Classify a Sanskrit text block into precise semantic structural category
 */
export function classifyTextBlock(block: string): {
  unitType: SanskritUnitType;
  sectionName?: string;
  isShantiMantra: boolean;
  isColophon: boolean;
  isHeading: boolean;
  isGadya: boolean;
} {
  const norm = block.trim();
  const lower = norm.toLowerCase();
  const stripped = norm.replace(/^[॥।।|।\s]+|[॥।।|।\s]+$/g, '').trim();
  const words = stripped.split(/\s+/).filter(Boolean);
  const wordCount = words.length;

  // 1. Shanti Mantra check
  const isShantiMantra =
    /शान्ति(मन्त्र|पाठ|ः)|श‍ृणुयाम|भद्रं कर्णेभिः|स्वस्ति न|सह नाववतु|पूर्णमदः|वाङ् मे मनसि|शं नो मित्रः|आप्यायन्तु|द्यौः शान्तिरन्तरिक्षं/i.test(
      norm
    );
  if (isShantiMantra) {
    return {
      unitType: 'SHANTI_MANTRA',
      sectionName: 'ಶಾಂತಿ ಪಾಠ (Shanti Mantra)',
      isShantiMantra: true,
      isColophon: false,
      isHeading: false,
      isGadya: false,
    };
  }

  // 2. Colophon check (ಪುಷ್ಪಿಕಾ / ಸಮಾಪ್ತಿ ವಾಕ್ಯ)
  // Handles:
  // - "॥ इति प्रथमः खण्डः ॥", "इति प्रथमः खण्डः", "॥ इति द्वितीया वल्ली ॥", "॥ इति शिक्षावल्ली समाप्ता ॥"
  // - "॥ इति श्रीमद्रामायणे वाल्मीकीये आदिकाव्ये बालकाण्डे प्रथमः सर्गः ॥"
  // - "॥ इति श्रीमहाभारते शतसाहस्र्यां संहितायां सभापर्वणि... ॥"
  // - "॥ इति श्रीमद्भगवद्गीतासूपनिषत्सु... ॥", "॥ इति प्रथमोऽध्यायः ॥", "॥ इति चतुर्थः पादः ॥"
  // - Any block starting with "इति" / "॥ इति" / "ಇತಿ" / "॥ ಇತಿ"
  // - Or ending with "समाप्तम्", "समाप्ता", "सम्पूर्णम्", "ಸಮಾಪ್ತ", etc.
  const isColophon =
    /^(?:॥|।।|\|\|)?\s*(?:इति|ಇತಿ)\s+/i.test(norm) ||
    /^(?:इति|ಇತಿ)\s+/i.test(stripped) ||
    /(?:समाप्त[ः|म्|ा]?|सम्पूर्ण[म्|ः|ा]?|ಸಮಾಪ್ತ[ಃ|ಂ]?|ಸಂಪೂರ್ಣ[ಂ|ಃ]?)\s*(?:॥|।।|\|\|)?$/i.test(norm) ||
    /(?:समाप्त[ः|म्|ा]?|सम्पूर्ण[म्|ः|ा]?|ಸಮಾಪ್ತ[ಃ|ಂ]?|ಸಂಪೂರ್ಣ[ಂ|ಃ]?)$/i.test(stripped);

  if (isColophon) {
    return {
      unitType: 'COLOPHON',
      sectionName: 'ಪುಷ್ಪಿಕಾ / ಸಮಾಪ್ತಿ ವಾಕ್ಯ (Colophon)',
      isShantiMantra: false,
      isColophon: true,
      isHeading: false,
      isGadya: false,
    };
  }

  // 3. Standalone Heading / Subheading check across Upanishads, Epics (Ramayana, Mahabharata), Puranas, Kavyas
  // Division keywords:
  // - खण्ड / ಖಂಡ, वल्ली / ವಲ್ಲೀ, प्रपाठक / ಪ್ರಪಾಠಕ, काण्ड / ಕಾಂಡ, सर्ग / ಸರ್ಗ, पर्व / ಪರ್ವ, अध्याय / ಅಧ್ಯಾಯ
  // - ब्राह्मण / ಬ್ರಾಹ್ಮಣ, अनुवाक / ಅನುವಾಕ, सूक्त / ಸೂಕ್ತ, मण्डल / ಮಂಡಲ, अष्टक / ಅಷ್ಟಕ, प्रश्न / ಪ್ರಶ್ನೆ, अङ्क / ಅಂಕ
  // - Named sections: शिक्षावल्ली, भृगुवल्ली, आनन्दवल्ली, बालकाण्ड, अयोध्याकाण्ड, आदिपर्व, सभापर्व, भीष्मपर्व, etc.
  // - Incipits: "॥ अथ ... ॥", "अथ ...", "॥ ध्यानम् ॥", "॥ सङ्कल्पः ॥", "॥ फलश्रुतिः ॥", "॥ न्यासः ॥"
  const isDivisionHeading =
    /(?:खण्ड|वल्ली|प्रपाठक|काण्ड|सर्ग|पर्व|अध्याय|ब्राह्मण|अनुवाक|सूक्त|मण्डल|अष्टक|प्रश्न|अङ्क|उच्छ्वास|उल्लास|तरङ्ग|प्रकाश|पाद|ಭಾಗ|ಖಂಡ|ವಲ್ಲೀ|ಪ್ರಪಾಠಕ|ಕಾಂಡ|ಸರ್ಗ|ಪರ್ವ|ಅಧ್ಯಾಯ)/i.test(stripped);

  const isNamedValliOrKanda =
    /(?:शिक्षावल्ली|भृगुवल्ली|आनन्दवल्ली|वारुणीवल्ली|ब्रह्मवल्ली|बालकाण्ड|अयोध्याकाण्ड|अरण्यकाण्ड|किष्किन्धाकाण्ड|सुन्दरकाण्ड|युद्धकाण्ड|उत्तरकाण्ड|आदिपर्व|सभापर्व|वनपर्व|विराटपर्व|उद्योगपर्व|भीष्मपर्व|द्रोणपर्व|कर्णपर्व|शल्यपर्व|सौप्तिकपर्व|स्त्रीपर्व|शान्तिपर्व|अनुशासनपर्व|अश्वमेधिकपर्व|ಆದಿಪರ್ವ|ಸಭಾಪರ್ವ|ಭೀಷ್ಮಪರ್ವ|ಶಿಕ್ಷಾವಲ್ಲೀ|ಭೃಗುವಲ್ಲೀ|ಆನಂದವಲ್ಲೀ|ಬಾಲಕಾಂಡ)/i.test(stripped);

  const isRitualSectionHeading =
    /^(?:॥|।।|\|\|)?\s*(?:अथ|श्री|ಓಂ|ॐ)?\s*(?:शान्तिपाठ|ध्यानम्|न्यासः|सङ्कल्पः|माहात्म्यम्|मङ्गलाचरणम्|पूर्वपीठिका|उत्तरपीठिका|फलश्रुति[ः|म्]?)\s*(?:॥|।।|\|\|)?$/i.test(norm) ||
    /^(?:अथ|श्री|ಓಂ|ॐ)?\s*(?:शान्तिपाठ|ध्यानम्|न्यासः|सङ्कल्पः|माहात्म्यम्|मङ्गलाचरणम्|पूर्वपीठिका|उत्तरपीठिका|फलश्रुति[ः|म्]?)$/i.test(stripped);

  const isHeading =
    !isColophon &&
    (
      isRitualSectionHeading ||
      // Named section (शिक्षावल्ली, बालकाण्ड, आदिपर्व, ...) is inherently a proper-noun
      // title, so it only needs the structural-isolation / continuation-marker guards.
      (isNamedValliOrKanda && wordCount <= 15 && stripped.length <= 150 && passesConservativeHeadingGuards(stripped)) ||
      // Generic division term (सर्ग/अध्याय/काण्ड/पर्व/...) additionally requires an
      // adjacent ordinal ("प्रथमः सर्गः", "अध्याय १") so a bare mention of the word
      // inside ordinary śloka/prose text is never mistaken for a chapter title.
      (isDivisionHeading && wordCount <= 15 && stripped.length <= 150 &&
        hasOrdinalAdjacentToDivisionTerm(stripped) && passesConservativeHeadingGuards(stripped)) ||
      // Starts with "अथ" (e.g. "॥ अथ प्रथमोऽध्यायः ॥", "अथ द्वितीयः खण्डः") — tightened to
      // require an accompanying ordinal+division-term pair, since "अथ" ("now"/"then") is
      // also a common narrative particle that opens ordinary verse/prose sentences.
      (/^(?:अथ|ಅಥ)\s+/i.test(stripped) && wordCount <= 10 && stripped.length <= 100 &&
        hasOrdinalAdjacentToDivisionTerm(stripped) && passesConservativeHeadingGuards(stripped)) ||
      // Short standalone enclosed header (॥ ... ॥) without full sentence verbs
      (/^॥\s*[^॥\n]{2,60}\s*॥$/i.test(norm) && wordCount <= 12 &&
        !/(?:सन्तु|भवन्तु|नमः|वदेत्|उवाच|कुरु|अस्ति|स्यात्|अहम्)/i.test(norm))
    );

  if (isHeading) {
    return {
      unitType: 'HEADING',
      sectionName: 'ಶೀರ್ಷಿಕೆ (Heading)',
      isShantiMantra: false,
      isColophon: false,
      isHeading: true,
      isGadya: false,
    };
  }

  // 4. Sanskrit Prose (Gadya) check: contains continuous prose with no dandas or sparse dandas
  const dandaCount = (norm.match(/[\u0964\u0965|]/g) || []).length;
  const proseWordCount = norm.split(/\s+/).length;
  const isGadya = proseWordCount > 18 && (dandaCount === 0 || dandaCount <= 2);
  if (isGadya) {
    return {
      unitType: 'GADYA',
      sectionName: 'ಗದ್ಯ ಭಾಗ (Gadya Section)',
      isShantiMantra: false,
      isColophon: false,
      isHeading: false,
      isGadya: true,
    };
  }

  // 5. Check if Shloka has explicit verse number
  const hasVerseNum = extractOriginalVerseNumber(norm) !== null;
  if (hasVerseNum) {
    return {
      unitType: 'SHLOKA',
      isShantiMantra: false,
      isColophon: false,
      isHeading: false,
      isGadya: false,
    };
  }

  // 6. Regular Shloka (treat cleanly without any asankyatha/unnumbered labels)
  return {
    unitType: 'SHLOKA',
    sectionName: 'ಶ್ಲೋಕ',
    isShantiMantra: false,
    isColophon: false,
    isHeading: false,
    isGadya: false,
  };
}

/**
 * Universal evaluator to check if a Sanskrit unit is a Heading, Subheading, or Colophon.
 * Checks both metadata unitType AND text content fallback.
 */
export function isHeadingOrColophonUnit(unit: {
  unitType?: SanskritUnitType;
  output?: { moolaShloka?: string; kannadaTransliteration?: string };
  verifiedText?: string;
  originalText?: string;
}): boolean {
  if (unit.unitType === 'HEADING' || unit.unitType === 'COLOPHON') {
    return true;
  }
  const text = (unit.output?.moolaShloka || unit.verifiedText || unit.originalText || '').trim();
  if (!text) return false;

  const classification = classifyTextBlock(text);
  if (classification.isHeading || classification.isColophon) {
    return true;
  }

  const stripped = text.replace(/^[॥।।|।\s]+|[॥।।|।\s]+$/g, '').trim();
  const wordCount = stripped.split(/\s+/).filter(Boolean).length;
  if (wordCount <= 15 && stripped.length <= 150) {
    if (/^(?:इति|ಇತಿ)\s+|(?:समाप्त|सम्पूर्ण|ಸಮಾಪ್ತ|ಸಂಪೂರ್ಣ)/i.test(stripped)) return true;
    // Kept in sync with the conservative guards in classifyTextBlock() above: a bare
    // mention of a division word is not enough, it must sit next to an ordinal and
    // must not look like a live grammatical clause (see passesConservativeHeadingGuards).
    if (
      /(?:खण्ड|वल्ली|प्रपाठक|काण्ड|सर्ग|पर्व|अध्याय|ब्राह्मण|अनुवाक|सूक्त|मण्डल|अष्टक|प्रश्न|अङ्क|उच्छ्वास|पाद|ಭಾಗ|ಖಂಡ|ವಲ್ಲೀ|ಪ್ರಪಾಠಕ|ಕಾಂಡ|ಸರ್ಗ|ಪರ್ವ|ಅಧ್ಯಾಯ)/i.test(stripped) &&
      hasOrdinalAdjacentToDivisionTerm(stripped) &&
      passesConservativeHeadingGuards(stripped)
    ) {
      return true;
    }
    if (/^(?:अथ|ಅಥ)\s+/i.test(stripped) && hasOrdinalAdjacentToDivisionTerm(stripped) && passesConservativeHeadingGuards(stripped)) {
      return true;
    }
  }

  return false;
}

// ----------------- High-Precision Verse Number Extraction -----------------

/**
 * Extract the exact original verse number present in the uploaded PDF / source text
 * Normalizes all numbers strictly to English digits (0-9).
 */
// Helper: Parse Roman numeral to number
function parseRomanNumeral(romanStr: string): number | null {
  const s = romanStr.toUpperCase().trim();
  if (!/^[IVXLCDM]+$/.test(s)) return null;
  const romanMap: Record<string, number> = { I: 1, V: 5, X: 10, L: 50, C: 100, D: 500, M: 1000 };
  let num = 0;
  for (let i = 0; i < s.length; i++) {
    const curr = romanMap[s[i]];
    const next = romanMap[s[i + 1]];
    if (next && next > curr) {
      num += (next - curr);
      i++;
    } else {
      num += curr;
    }
  }
  return num > 0 ? num : null;
}

// Helper: Parse Sanskrit ordinals (e.g. विंशतितमः -> 20, तृतीयः -> 3)
const SANSKRIT_ORDINAL_MAP: Array<{ regex: RegExp; value: number }> = [
  { regex: /प्रथम/i, value: 1 },
  { regex: /द्वितीय/i, value: 2 },
  { regex: /तृतीय/i, value: 3 },
  { regex: /चतुर्थ/i, value: 4 },
  { regex: /पञ्चम/i, value: 5 },
  { regex: /षष्ठ/i, value: 6 },
  { regex: /सप्तम/i, value: 7 },
  { regex: /अष्टम/i, value: 8 },
  { regex: /नवम/i, value: 9 },
  { regex: /दशम/i, value: 10 },
  { regex: /एकादश/i, value: 11 },
  { regex: /द्वादश/i, value: 12 },
  { regex: /त्रयोदश/i, value: 13 },
  { regex: /चतुर्दश/i, value: 14 },
  { regex: /पञ्चदश/i, value: 15 },
  { regex: /षोडश/i, value: 16 },
  { regex: /सप्तदश/i, value: 17 },
  { regex: /अष्टादश/i, value: 18 },
  { regex: /एकोनविंश/i, value: 19 },
  { regex: /विंशतितम|विंश/i, value: 20 },
  { regex: /एकविंश/i, value: 21 },
  { regex: /द्वाविंश/i, value: 22 },
  { regex: /त्रयोविंश/i, value: 23 },
  { regex: /चतुर्विंश/i, value: 24 },
  { regex: /पञ्चविंश/i, value: 25 },
  { regex: /त्रिंश/i, value: 30 },
  { regex: /चत्वारिंश/i, value: 40 },
  { regex: /पञ्चाश/i, value: 50 },
  { regex: /शत/i, value: 100 },
];

/**
 * Parses hierarchical notation like "I.ii.3", "[I.ii.3]", "I.i.1", "1.2.3", "IV.v.6"
 * into a clean dot-separated decimal number like "1.2.3", "1.1.1", "4.5.6".
 */
export function parseHierarchicalNotation(notation: string): string | null {
  if (!notation) return null;
  const clean = notation.replace(/[\[\]\(\)\{\}【】〔〕«»⟨⟩（）［］]/g, '').trim();
  if (!clean) return null;

  const parts = clean.split(/[\.\-–]/);
  if (parts.length < 2) return null;

  const convertedParts: string[] = [];
  for (const part of parts) {
    const p = part.trim();
    if (!p) return null;

    // Check roman numeral (e.g. I, ii, iv, x, xi)
    const romanVal = parseRomanNumeral(p);
    if (romanVal !== null) {
      convertedParts.push(String(romanVal));
      continue;
    }

    // Check integer (convert Devanagari/Kannada digits if any)
    const engDigits = toEnglishDigits(p);
    if (/^[0-9]+$/.test(engDigits)) {
      convertedParts.push(String(parseInt(engDigits, 10)));
      continue;
    }

    return null;
  }

  return convertedParts.join('.');
}

export interface HierarchicalHeaderMatch {
  rawHeader: string;
  hierarchicalNumber: string; // e.g. "1.2.3"
  localNumber?: string; // e.g. "3"
}

/**
 * Detects if a line is a hierarchical verse/mantra header like:
 * "मन्त्र ३  [I.ii.3]", "मन्त्र 1 [I.i.1]", "[I.ii.3]", "मन्त्र 2[I.ii.2]", "ಮಂತ್ರ ೩ [I.ii.3]"
 */
export function detectHierarchicalVerseHeader(line: string): HierarchicalHeaderMatch | null {
  const norm = toEnglishDigits(line.trim());
  if (!norm) return null;

  // Bracketed hierarchical notation, e.g. "मन्त्र ३ [I.ii.3]", "[I.ii.3]", "मन्त्र 2[I.ii.2]"
  const bracketMatch = norm.match(
    /^(?:(?:मन्त्र|मंत्र|श्लोक|verse|shloka|mantra|ಮಂತ್ರ|ಶ್ಲೋಕ)\s*[0-9]*\s*)?(?:\[([A-Za-z0-9.\-–]+)\]|\(([A-Za-z0-9.\-–]+)\))\s*$/i
  );
  if (bracketMatch) {
    const rawNotation = bracketMatch[1] || bracketMatch[2];
    const parsed = parseHierarchicalNotation(rawNotation);
    if (parsed) {
      const localNumMatch = norm.match(/(?:मन्त्र|मंत्र|श्लोक|verse|shloka|mantra|ಮಂತ್ರ|ಶ್ಲೋಕ)\s*([0-9]+)/i);
      return {
        rawHeader: line.trim(),
        hierarchicalNumber: parsed,
        localNumber: localNumMatch ? localNumMatch[1] : undefined,
      };
    }
  }

  // Short line (<= 60 chars) with bracket notation embedded
  if (norm.length <= 60) {
    const embeddedMatch = norm.match(
      /(?:(?:मन्त्र|मंत्र|श्लोक|verse|shloka|mantra|ಮಂತ್ರ|ಶ್ಲೋಕ)\s*[0-9]*\s*)?(?:\[([A-Za-z0-9.\-–]+)\]|\(([A-Za-z0-9.\-–]+)\))/i
    );
    if (embeddedMatch) {
      const rawNotation = embeddedMatch[1] || embeddedMatch[2];
      const parsed = parseHierarchicalNotation(rawNotation);
      if (parsed) {
        const localNumMatch = norm.match(/(?:मन्त्र|मंत्र|श्लोक|verse|shloka|mantra|ಮಂತ್ರ|ಶ್ಲೋಕ)\s*([0-9]+)/i);
        return {
          rawHeader: line.trim(),
          hierarchicalNumber: parsed,
          localNumber: localNumMatch ? localNumMatch[1] : undefined,
        };
      }
    }
  }

  return null;
}

/**
 * Strips any hierarchical verse header (e.g. "मन्त्र ३ [I.ii.3]") and standardizes
 * the terminating danda number to the hierarchical format (e.g. "॥ 1.2.3 ॥").
 */
export function stripHierarchicalVerseHeaderAndStandardizeNumber(text: string): {
  cleanText: string;
  hierarchicalNumber: string | null;
} {
  if (!text) return { cleanText: '', hierarchicalNumber: null };

  const hierMatch = text.match(/(?:\[([A-Za-z0-9.\-–]+)\]|\(([A-Za-z0-9.\-–]+)\))/);
  let hierarchicalNumber: string | null = null;
  if (hierMatch) {
    hierarchicalNumber = parseHierarchicalNotation(hierMatch[1] || hierMatch[2]);
  }

  let cleanText = stripHierarchicalVerseHeader(text);

  if (hierarchicalNumber) {
    if (/॥\s*([0-9.]+)?\s*॥\s*$/.test(cleanText)) {
      cleanText = cleanText.replace(/॥\s*([0-9.]+)?\s*॥\s*$/, `॥ ${hierarchicalNumber} ॥`);
    } else if (cleanText.endsWith('॥')) {
      cleanText = cleanText.replace(/॥\s*$/, `॥ ${hierarchicalNumber} ॥`);
    } else {
      cleanText = `${cleanText} ॥ ${hierarchicalNumber} ॥`;
    }
  }

  return { cleanText, hierarchicalNumber };
}

export function extractOriginalVerseNumber(rawChunk: string): string | null {
  if (!rawChunk) return null;
  const normalized = toEnglishDigits(rawChunk);

  // 0. Check for bracketed hierarchical notation anywhere in chunk: e.g. [I.ii.3], [I.i.1], [1.2.3]
  const hierMatch = normalized.match(/(?:\[([A-Za-z0-9.\-–]+)\]|\(([A-Za-z0-9.\-–]+)\))/);
  if (hierMatch) {
    const rawNotation = hierMatch[1] || hierMatch[2];
    const parsed = parseHierarchicalNotation(rawNotation);
    if (parsed) {
      return parsed;
    }
  }

  // 1. Match separator-enclosed numbers at the end: ॥ 1.1 ॥, // 12 //, \\ 12 \\, II 12 II, || 12 ||, / 12 /, \ 12 \, etc.
  const dandaEndMatch = normalized.match(/(?:॥|\|\||\/\/|\\\\|\/|\\|II|।|\|)\s*([0-9]+(?:[\.\-–][0-9]+)*)\s*(?:॥|\|\||\/\/|\\\\|\/|\\|II|।|\|)?\s*$/i);
  if (dandaEndMatch && dandaEndMatch[1]) {
    return dandaEndMatch[1].trim();
  }

  // 2. If multiple separator numbers exist, take the LAST separator number in the verse block
  const allDandaMatches = Array.from(normalized.matchAll(/(?:॥|\|\||\/\/|\\\\|\/|\\|II|।|\|)\s*([0-9]+(?:[\.\-–][0-9]+)*)\s*(?:॥|\|\||\/\/|\\\\|\/|\\|II|।|\|)/gi));
  if (allDandaMatches.length > 0) {
    const lastMatch = allDandaMatches[allDandaMatches.length - 1];
    if (lastMatch && lastMatch[1]) {
      return lastMatch[1].trim();
    }
  }

  // 3. Match bracketed / parenthesized numbers at end or body: (), [], {}, 【】, 〔〕, «», ⟨⟩, （）, ［］
  const parenEndMatch = normalized.match(/(?:\(|\[|\{|【|〔|«|⟨|（|［)\s*([0-9]+(?:[\.\-–][0-9]+)*)\s*(?:\)|\]|\}|】|〕|»|⟩|）|］)\s*(?:॥|\|\||\/\/|\\\\|II|\.)?\s*$/i);
  if (parenEndMatch && parenEndMatch[1]) {
    return parenEndMatch[1].trim();
  }

  const allParenMatches = Array.from(normalized.matchAll(/(?:\(|\[|\{|【|〔|«|⟨|（|［)\s*([0-9]+(?:[\.\-–][0-9]+)*)\s*(?:\)|\]|\}|】|〕|»|⟩|）|］)/g));
  if (allParenMatches.length > 0) {
    const lastMatch = allParenMatches[allParenMatches.length - 1];
    if (lastMatch && lastMatch[1]) {
      return lastMatch[1].trim();
    }
  }

  // 4. Match trailing standalone number before closing danda/separator or at end of verse
  const trailingMatch = normalized.match(/(?:॥|\|\||\/\/|\\\\|\/|\\|II)?\s*([0-9]+(?:[\.\-–][0-9]+)*)\s*(?:॥|\|\||\/\/|\\\\|\/|\\|II|\.)?\s*$/i);
  if (trailingMatch && trailingMatch[1] && parseInt(trailingMatch[1], 10) > 0) {
    return trailingMatch[1].trim();
  }

  // 5. Match prefix number only if at the beginning of the text: e.g. "12. " or "ಶ್ಲೋಕ 12:" or "श्लोक १२:"
  const prefixMatch = normalized.match(
    /^(?:(?:ಶ್ಲೋಕ|श्लोक|verse|shloka|मंत्र|ಮಂತ್ರ)\s*)?([0-9]+(?:[\.\-–][0-9]+)*)\s*[:.\-–]/i
  );
  if (prefixMatch && prefixMatch[1]) {
    return prefixMatch[1].trim();
  }

  // 6. Roman numeral in brackets at the end: (xx), [XX], ॥ XX ॥
  const romanMatch = normalized.match(/(?:\(|\[|\{|【|॥)\s*([ivxlcdm]+)\s*(?:\)|\]|\}|】|॥)\s*$/i);
  if (romanMatch && romanMatch[1]) {
    const parsed = parseRomanNumeral(romanMatch[1]);
    if (parsed) return String(parsed);
  }

  return null;
}

// ----------------- High-Precision Chunking & Boundary Engine -----------------

/**
 * Detects if a line explicitly contains a verse/shloka number
 * Supports:
 * - Separators: ॥ 20 ॥, || 20 ||, // 20 //, \\ 20 \\, II 20 II, / 20 /, \ 20 \, । 20 ।
 * - Standalone line number: "20", "20.", "॥ 20 ॥", "(20)", "[20]", "{20}", "【20】", "〔20〕"
 * - All bracket varieties: (), [], {}, 【】, 〔〕, «», ⟨⟩, （）, ［］
 * - Keyword prefixes/suffixes: "श्लोक 20", "ಶ್ಲೋಕ 20", "मन्त्र 20", "ಮಂತ್ರ 20", "Verse 20", "Mantra 20"
 * - Trailing number at line end without dandas: "... विन्दति 20" or "... विन्दति 20."
 * - Roman numerals: (xx), [XX], ॥ XX ॥, (iv), [IV]
 * - Sanskrit ordinal colophons: "इति विंशतितमः श्लोकः", "इति तृतीयो मन्त्रः"
 */
export function detectExplicitVerseNumberInLine(line: string): string | null {
  const norm = toEnglishDigits(line.trim());
  if (!norm) return null;

  // If this line is a hierarchical verse/mantra header (e.g. "मन्त्र ३ [I.ii.3]", "[I.ii.3]"),
  // it is the START of a verse/mantra, NOT an ending verse number! Do not treat as end-of-verse STOP RULE!
  if (detectHierarchicalVerseHeader(line)) {
    return null;
  }

  // 1. Standalone number on its own line: e.g. "20", "20.", "॥ 20 ॥", "(20)", "[20]", "{20}", "【20】", "〔20〕"
  const standaloneMatch = norm.match(/^(?:॥|\|\||\/\/|\\\\|\/|\\|II|।|\||\(|\{|\[|【|〔|«|⟨|（|［)?\s*([0-9]+(?:[\.\-–][0-9]+)*)\s*(?:॥|\|\||\/\/|\\\\|\/|\\|II|।|\||\)|\}|\]|】|〕|»|⟩|）|］|\.)?$/i);
  if (standaloneMatch && standaloneMatch[1]) {
    const val = parseInt(standaloneMatch[1], 10);
    if (val > 0 && val < 5000) return standaloneMatch[1].trim();
  }

  // 2. Explicit separator-enclosed number anywhere in line: ॥ 20 ॥, || 20 ||, // 20 //, \\ 20 \\, II 20 II, / 20 /, \ 20 \, । 20 ।
  const dandaMatch = norm.match(/(?:॥|\|\||\/\/|\\\\|\/|\\|II|।|\|)\s*([0-9]+(?:[\.\-–][0-9]+)*)\s*(?:॥|\|\||\/\/|\\\\|\/|\\|II|।|\|)/i);
  if (dandaMatch && dandaMatch[1]) return dandaMatch[1].trim();

  // 3. Trailing separator number: ॥ 20, || 20, // 20, \\ 20, II 20, | 20
  const trailingDanda = norm.match(/(?:॥|\|\||\/\/|\\\\|\/|\\|II|।|\|)\s*([0-9]+(?:[\.\-–][0-9]+)*)\s*$/i);
  if (trailingDanda && trailingDanda[1]) return trailingDanda[1].trim();

  // 4. Parentheses / brackets at end of line (supports (), [], {}, 【】, 〔〕, «», ⟨⟩, （）, ［］)
  const parenMatch = norm.match(/(?:\(|\[|\{|【|〔|«|⟨|（|［)\s*([0-9]+(?:[\.\-–][0-9]+)*)\s*(?:\)|\]|\}|】|〕|»|⟩|）|］)\s*(?:॥|\|\||\/\/|\\\\|II|\.)?$/i);
  if (parenMatch && parenMatch[1]) return parenMatch[1].trim();

  // 5. Explicit Shloka / Mantra / Verse keyword prefix or suffix:
  // e.g. "श्लोक 20", "श्लोकः 20", "मंत्र 20", "मन्त्रः 20", "ಶ್ಲೋಕ 20", "ಮಂತ್ರ 20", "Verse 20", "Mantra 20"
  const keywordMatch = norm.match(/(?:(?:श्लोक|श्लोकः|ಶ್ಲೋಕ|verse|shloka|मंत्र|मन्त्र|मन्त्रः|ಮಂತ್ರ)\s*[:.\-–]?\s*)([0-9]+(?:[\.\-–][0-9]+)*)/i);
  if (keywordMatch && keywordMatch[1]) return keywordMatch[1].trim();

  // 6. Prefix number at start of line: "20. " or "20 - " or "20: "
  const prefixMatch = norm.match(/^([0-9]+(?:[\.\-–][0-9]+)*)\s*[:.\-–]\s+/i);
  if (prefixMatch && prefixMatch[1]) return prefixMatch[1].trim();

  // 7. Trailing standalone number at the very end of the line (e.g. "... कर्म विन्दति 20" or "... कर्म विन्दति 20.")
  const trailingNumMatch = norm.match(/\s+([0-9]+(?:[\.\-–][0-9]+)*)\s*\.?\s*$/i);
  if (trailingNumMatch && trailingNumMatch[1]) {
    const val = parseInt(trailingNumMatch[1], 10);
    // Ensure reasonable verse number (e.g. 1-4999) and not a common 4-digit Gregorian year
    if (val > 0 && val < 5000 && val !== 1980 && val !== 1990 && val !== 2000 && val !== 2024 && val !== 2025 && val !== 2026) {
      return trailingNumMatch[1].trim();
    }
  }

  // 8. Roman numerals in brackets or between dandas at end of line: (xx), [XX], ॥ XX ॥, ॥ IV ॥
  const romanMatch = norm.match(/(?:॥|\|\||\(|\{|\[|【)\s*([ivxlcdm]+)\s*(?:॥|\|\||\)|\}|\]|】)\s*$/i);
  if (romanMatch && romanMatch[1]) {
    const parsed = parseRomanNumeral(romanMatch[1]);
    if (parsed) return String(parsed);
  }

  // 9. Sanskrit Ordinals with Shloka / Mantra / Adhyaya words:
  // e.g. "इति विंशतितमः श्लोकः", "इति तृतीयो मन्त्रः"
  if (/(?:श्लोक|मन्त्र|खण्ड|अध्याय|वल्ली|ಸೂಕ್ತ|ಶ್ಲೋಕ|ಮಂತ್ರ|verse|mantra)/i.test(line)) {
    for (const entry of SANSKRIT_ORDINAL_MAP) {
      if (entry.regex.test(line)) {
        return String(entry.value);
      }
    }
  }

  return null;
}

/**
 * Detects if a line contains a definitive textual end sign (colophon, conclusion, shanti patha closing)
 */
export function detectDefinitiveEndSignInLine(line: string): boolean {
  const norm = line.trim();
  if (!norm) return false;

  // Colophons: इति श्रीमद्..., इति ... अध्यायः, समाप्तम्, सम्पूर्णम्
  if (/^इति\s+[\u0900-\u097F\s]+(?:समाप्त|सम्पूर्ण|ಸಮಾಪ್ತ|ಸಂಪೂರ್ಣ|ಅಧ್ಯಾಯ|अध्याय|खण्ड|ಖಂಡ|वल्ली|ವಲ್ಲಿ)/i.test(norm)) return true;
  if (/(?:समाप्तम्|समाप्तः|सम्पूर्णम्|ಸಮಾಪ್ತವಾಯಿತು|ಸಂಪೂರ್ಣ|ಸಮಾಪ್ತಃ|समाप्ता)\s*(?:॥|\|\||\/\/|\\\\|II)?$/i.test(norm)) return true;

  // Triple Shanti closing: शान्तिः शान्तिः शान्तिः or शान್ತಿಃ शान್ತಿಃ शान್ತಿಃ
  if (/शान्ति[ः|:\s]+शान्ति[ः|:\s]+शान्ति[ः|:\s]*(?:॥|\|\||\/\/|\\\\|II)?$/i.test(norm)) return true;

  // Auspicious closing mantras
  if (/(?:शुभं\s*भवतु|शुभಂ\s*ಭವತು|हरिः\s*ॐ\s*तत्\s*सत्|हरಿಃ\s*ॐ)\s*(?:॥|\|\||\/\/|\\\\|II)?$/i.test(norm)) return true;

  return false;
}

/**
 * Checks whether a line ends at a proper ending point:
 * - full stop ('.', '!', '?', or traditional dandas '।', '॥')
 * - end of paragraph (blank line or newline break)
 * - separator ('//', '\\', 'II', '/', '\', '||', '|')
 */
export function isLineEndingAtProperPoint(line: string, nextLineIsBlank: boolean): boolean {
  const trimmed = line.trim();
  if (!trimmed) return false;
  if (nextLineIsBlank) return true;
  return /(?:[।॥.!?]|\/\/|\\\\|\/|\\|\|\||II)\s*$/i.test(trimmed);
}

export interface TextChunkUnit {
  rawChunk: string;
  charPos: number;
  originalVerseNum: string | null;
  hasExplicitNumber: boolean;
  isDefinitiveEnd: boolean;
  lineCount: number;
  splitReason: 'EXPLICIT_NUMBER' | 'DEFINITIVE_END' | '10_15_LINES_BLOCK' | 'PARAGRAPH_BOUNDARY' | 'END_OF_TEXT';
}

/**
 * STRICT AUTOMATED PARSING & CHUNKING ENGINE:
 * 1. Do NOT split the text immediately when encountering symbols like //, \\, /, \, or II.
 * 2. Read and process the text continuously to form meaningful logical blocks of exactly 10 to 15 lines.
 * 3. Only split after 10-15 lines, ensuring the break happens at a proper ending point (full stop, end of paragraph, or separator).
 * 4. STOP RULE: If an explicit shloka number or definitive end sign is reached, stop and process that specific unit immediately.
 * 5. PARAGRAPH BOUNDARY RULE: A blank line gap or paragraph break marks the end of a unit; the subsequent paragraph starts as the NEXT unit.
 */
export function chunkSanskritTextWithRules(fullText: string): TextChunkUnit[] {
  if (!fullText || !fullText.trim()) return [];
  const normalized = toEnglishDigits(fullText);

  // Segment lines while preserving offsets
  const rawLinesWithOffset: Array<{ line: string; charPos: number }> = [];
  const rawSplit = normalized.split('\n');
  let currentOffset = 0;

  for (let i = 0; i < rawSplit.length; i++) {
    const rawLine = rawSplit[i];
    // DO NOT split lines immediately on symbols like //, \\, /, \, or II.
    // Only if a single physical line is exceptionally long (>300 chars with no newlines) and contains traditional dandas
    if (rawLine.length > 300 && /(?:॥|\|\||।)/.test(rawLine)) {
      const subSegments = rawLine.split(/(?<=(?:॥|\|\||।))\s+/);
      let subOffset = currentOffset;
      for (const seg of subSegments) {
        if (seg.trim()) {
          rawLinesWithOffset.push({ line: seg.trim(), charPos: subOffset });
        }
        subOffset += seg.length + 1;
      }
    } else {
      rawLinesWithOffset.push({ line: rawLine.trim(), charPos: currentOffset });
    }
    currentOffset += rawLine.length + 1;
  }

  const chunks: TextChunkUnit[] = [];
  let accumulatedLines: string[] = [];
  let accumulatedCharStart = 0;
  let accumulatedLineCount = 0;
  let pendingHierarchicalNumber: string | null = null;

  const flushChunk = (
    reason: 'EXPLICIT_NUMBER' | 'DEFINITIVE_END' | '10_15_LINES_BLOCK' | 'PARAGRAPH_BOUNDARY' | 'END_OF_TEXT',
    explicitNum: string | null = null,
    isDefEnd: boolean = false
  ) => {
    if (accumulatedLines.length === 0) return;
    let textBlock = accumulatedLines.join('\n').trim();
    if (textBlock.length >= 3) {
      let detectedNum = pendingHierarchicalNumber || explicitNum || extractOriginalVerseNumber(textBlock);
      if (pendingHierarchicalNumber) {
        detectedNum = pendingHierarchicalNumber;
        if (/॥\s*([0-9.]+)?\s*॥\s*$/.test(textBlock)) {
          textBlock = textBlock.replace(/॥\s*([0-9.]+)?\s*॥\s*$/, `॥ ${pendingHierarchicalNumber} ॥`);
        } else if (textBlock.endsWith('॥')) {
          textBlock = textBlock.replace(/॥\s*$/, `॥ ${pendingHierarchicalNumber} ॥`);
        } else {
          textBlock = `${textBlock} ॥ ${pendingHierarchicalNumber} ॥`;
        }
      }
      chunks.push({
        rawChunk: textBlock,
        charPos: accumulatedCharStart,
        originalVerseNum: detectedNum,
        hasExplicitNumber: !!detectedNum,
        isDefinitiveEnd: isDefEnd,
        lineCount: accumulatedLineCount,
        splitReason: reason,
      });
    }
    accumulatedLines = [];
    accumulatedLineCount = 0;
    pendingHierarchicalNumber = null;
  };

  // Helper: Check if an upcoming line within the next N lines contains an explicit verse number or definitive end sign.
  // If an explicit shloka number is coming up within the SAME paragraph, this text is part of a single numbered shloka/mantra (even 20, 25, 30, or 40 lines long),
  // so we MUST NOT cut the shloka in half at 10-15 lines. We allow it to reach its natural explicit verse number!
  // CRITICAL: If a blank line (paragraph boundary) intervenes, it returns false, because an upcoming verse number in a SUBSEQUENT paragraph does NOT belong to the current paragraph!
  const hasUpcomingExplicitVerse = (startIndex: number, maxLookahead: number = 45): boolean => {
    const limit = Math.min(startIndex + maxLookahead, rawLinesWithOffset.length);
    for (let j = startIndex; j < limit; j++) {
      const aheadLine = rawLinesWithOffset[j].line;
      // If there is an empty line / blank line gap, the current paragraph has ended!
      if (!aheadLine.trim()) {
        return false;
      }
      if (detectExplicitVerseNumberInLine(aheadLine) || detectDefinitiveEndSignInLine(aheadLine)) {
        return true;
      }
    }
    return false;
  };

  for (let i = 0; i < rawLinesWithOffset.length; i++) {
    const { line, charPos } = rawLinesWithOffset[i];
    if (!line) {
      // Empty line / one line gap:
      // PARAGRAPH BOUNDARY RULE: When a blank line or one line gap is encountered,
      // the current paragraph has ended and the next paragraph starts.
      // Must be considered as NEXT unit, NOT the same!
      if (accumulatedLines.length > 0 && accumulatedLines.some((l) => l.trim().length > 0)) {
        flushChunk('PARAGRAPH_BOUNDARY');
      }
      continue;
    }

    // 0. Check if this line is a hierarchical verse/mantra header (e.g. "मन्त्र ३ [I.ii.3]", "[I.ii.3]", "श्लोक १ [1.1]")
    const hierHeader = detectHierarchicalVerseHeader(line);
    if (hierHeader) {
      if (accumulatedLines.length > 0 && accumulatedLines.some((l) => l.trim().length > 0)) {
        flushChunk('PARAGRAPH_BOUNDARY');
      }
      pendingHierarchicalNumber = hierHeader.hierarchicalNumber;
      accumulatedCharStart = charPos;
      // Do NOT push the header line itself to accumulatedLines!
      // This ensures "मन्त्र ३ [I.ii.3]" is removed from the shloka body!
      continue;
    }

    // 0b. Check if this line is a standalone heading or colophon (e.g. "॥ इति प्रथमः खण्डः ॥", "प्रथमः खण्डः", "॥ अथ शिक्षावल्ली ॥")
    const trimmedLine = line.trim();
    const lineClass = classifyTextBlock(trimmedLine);
    if ((lineClass.isHeading || lineClass.isColophon) && trimmedLine.length <= 120 && !trimmedLine.includes('\n')) {
      if (accumulatedLines.length > 0 && accumulatedLines.some((l) => l.trim().length > 0)) {
        flushChunk('PARAGRAPH_BOUNDARY');
      }
      accumulatedLines.push(trimmedLine);
      accumulatedLineCount = 1;
      accumulatedCharStart = charPos;
      flushChunk('DEFINITIVE_END', null, true);
      continue;
    }

    if (accumulatedLines.length === 0) {
      accumulatedCharStart = charPos;
    }

    // 1. Check STOP RULE: Explicit shloka number or definitive end sign
    const explicitNum = detectExplicitVerseNumberInLine(line);
    const isDefinitiveEnd = detectDefinitiveEndSignInLine(line);

    if (explicitNum || isDefinitiveEnd) {
      accumulatedLines.push(line);
      accumulatedLineCount++;
      flushChunk(
        explicitNum ? 'EXPLICIT_NUMBER' : 'DEFINITIVE_END',
        explicitNum,
        isDefinitiveEnd
      );
      continue;
    }

    // 2. Normal line accumulation (Immunity to //, \\, /, \, II - continuous reading):
    accumulatedLines.push(line);
    accumulatedLineCount++;

    // 3. Check 10-15 line block splitting for unnumbered continuous text within a single unbroken paragraph:
    // Only split after 10-15 lines if:
    // - There is NO upcoming explicit shloka number in this paragraph (i.e. it is truly continuous unnumbered commentary / prose),
    //   ensuring complete numbered shlokas/mantras (even 20-40 lines long) stay as ONE complete unit!
    // - OR if the continuous text exceeds 60 lines (safety threshold).
    if (accumulatedLineCount >= 10) {
      const nextLine = i + 1 < rawLinesWithOffset.length ? rawLinesWithOffset[i + 1].line : '';
      const nextIsBlank = !nextLine.trim();
      const endsProperly = isLineEndingAtProperPoint(line, nextIsBlank);
      const isApproachingExplicitVerse = hasUpcomingExplicitVerse(i + 1, 45);

      // If an explicit verse number (like ॥ 20 ॥, (20), etc.) is approaching in the next lines, DO NOT split!
      // Let the shloka reach its natural closing number intact.
      if (!isApproachingExplicitVerse || accumulatedLineCount >= 60) {
        if (endsProperly || accumulatedLineCount >= 15) {
          flushChunk('10_15_LINES_BLOCK');
        }
      }
    }
  }

  // Flush remaining accumulated lines
  if (accumulatedLines.length > 0) {
    flushChunk('END_OF_TEXT');
  }

  return chunks;
}

// ----------------- Dynamic Chapter & Section Hierarchy Tracker -----------------

export interface HierarchyState {
  currentBook: string;
  level1Name: string;
  level1Value: string | number;
  level2Name?: string;
  level2Value?: string | number;
  currentSection?: string;
}

export function detectChapterChange(
  text: string,
  currentState: HierarchyState
): HierarchyState | null {
  const norm = text.toLowerCase();

  // Check all division terms
  for (const div of DIVISION_TERMS) {
    if (div.pattern.test(norm)) {
      const ordinal = parseSanskritOrdinal(text);
      if (ordinal !== null) {
        // If current state has an explicit level2Name and this matches level 2 or is marked level 2:
        const isLevel2 = (currentState.level2Name && div.kannadaName === currentState.level2Name) || div.level === 2;
        if (isLevel2) {
          return {
            ...currentState,
            level2Name: div.kannadaName,
            level2Value: ordinal,
          };
        } else {
          return {
            ...currentState,
            level1Name: div.kannadaName,
            level1Value: ordinal,
            level2Value: undefined,
          };
        }
      }
    }
  }

  // Check section changes (e.g. "ध्यानम्", "फलश्रुतिः", "सङ्कल्पः", "न्यासः", "माहात्म्यम्")
  const sectionKeywords: Array<[RegExp, string]> = [
    [/ध्यान[म्|े|ः]?/i, 'ಧ್ಯಾನ ಶ್ಲೋಕ (Dhyana Shloka)'],
    [/फलश्रुति[ः|म्]?/i, 'ಫಲಶ್ರುತಿ (Phala Shruti)'],
    [/सङ्कल्प[ः|म्]?/i, 'ಸಂಕಲ್ಪ (Sankalpa)'],
    [/न्यास[ः|म्]?/i, 'ನ್ಯಾಸ (Nyasa)'],
    [/माहात्म्य[म्|ः]?/i, 'ಮಾಹಾತ್ಮ್ಯ (Mahatmya)'],
    [/मङ्गलाचरण[म्|ः]?/i, 'ಮಂಗಳಾಚರಣ (Mangalacharana)'],
    [/पूर्वपीठिका/i, 'ಪೂರ್ವಪೀಠಿಕೆ (Purvapithika)'],
    [/उत्तरपीठिका/i, 'ಉತ್ತರಪೀಠಿಕೆ (Uttarピithika)'],
  ];

  for (const [rx, secName] of sectionKeywords) {
    if (rx.test(norm)) {
      return {
        ...currentState,
        currentSection: secName,
      };
    }
  }

  return null;
}

// ----------------- Intelligent Document-Wide Sanskrit Extractor -----------------

/**
 * Universal Document-Wide Sanskrit Verse / Shloka / Mantra / Gadya Extractor.
 * Processes the COMPLETE PDF from first page to last page with 0 dropped verses.
 */
export function extractAllSanskritUnitsFromDocument(
  pages: Array<{ pageNumber: number; text: string }>,
  structure: DetectedStructure
): ExtractedVerseUnit[] {
  if (!pages || pages.length === 0) return [];

  // Build unified continuous text while tracking page boundaries
  interface PageSegment {
    pageNumber: number;
    startChar: number;
    endChar: number;
  }

  let fullCombinedText = '';
  const pageSegments: PageSegment[] = [];

  for (const p of pages) {
    const cleaned = cleanDocumentNoise(p.text);
    if (!cleaned.trim()) continue;

    const startChar = fullCombinedText.length;
    fullCombinedText += (fullCombinedText.length > 0 ? '\n\n' : '') + cleaned;
    const endChar = fullCombinedText.length;

    pageSegments.push({
      pageNumber: p.pageNumber,
      startChar,
      endChar,
    });
  }

  if (!fullCombinedText.trim()) return [];

  const findPageNumber = (charPos: number): number => {
    for (const seg of pageSegments) {
      if (charPos >= seg.startChar && charPos <= seg.endChar) {
        return seg.pageNumber;
      }
    }
    return pageSegments[0]?.pageNumber || 1;
  };

  const normalized = toEnglishDigits(fullCombinedText);

  // High precision verse & 10-15 line logical chunking engine:
  // Strictly respects:
  // 1) Continuous line reading without splitting immediately on //, \\, /, \, or II
  // 2) 10-15 line meaningful logical blocks breaking at proper ending points
  // 3) STOP RULE: Immediate processing upon explicit shloka number or definitive end sign
  const chunks = chunkSanskritTextWithRules(normalized);

  const units: ExtractedVerseUnit[] = [];
  let unitIndex = 1;

  let hierarchyState: HierarchyState = {
    currentBook: structure.detectedWork,
    level1Name: structure.level1Name || '',
    level1Value: structure.level1Name ? 1 : undefined,
    level2Name: structure.level2Name,
    level2Value: undefined,
    currentSection: undefined,
  };

  for (const chunk of chunks) {
    let rawChunk = chunk.rawChunk?.trim();
    if (!rawChunk || rawChunk.length < 4) continue;

    // Strict requirement: Only Sanskrit Devanagari script is considered a shloka or Sanskrit gadya.
    // Reject English, Kannada, or any other languages.
    const hasDevanagari = /[\u0900-\u097F]/.test(rawChunk);
    if (!hasDevanagari) {
      continue;
    }

    const matchCharPos = chunk.charPos;
    const pageNumber = findPageNumber(matchCharPos);

    // Track dynamic chapter / section change in stream
    const updatedState = detectChapterChange(rawChunk, hierarchyState);
    if (updatedState) {
      hierarchyState = updatedState;
    }

    // Classify text block (Shanti Mantra, Shloka, Unnumbered Shloka, Gadya, Colophon, Heading)
    const classification = classifyTextBlock(rawChunk);

    // If it's a Heading or Colophon:
    // As per user requirement: "wherever you find ॥ इति प्रथमः खण्डः ॥ ... or prathama khanda ... like head or sub head
    // do not consider it has shloka because it was head so just show me in kannada lipyanatara word instead of doing 5 stages"
    if (classification.unitType === 'HEADING' || classification.unitType === 'COLOPHON') {
      const cleanOriginal = sanitizeUnicodeText(rawChunk).trim();
      units.push({
        originalText: cleanOriginal,
        rawText: cleanOriginal,
        firstMeaningfulWord: cleanOriginal.split(/\s+/)[0] || '',
        pageNumber,
        unitIndex: unitIndex++,
        unitType: classification.unitType,
        hierarchy: {
          level1Name: hierarchyState.level1Name,
          level1Value: hierarchyState.level1Value || 1,
          level2Name: hierarchyState.level2Name,
          level2Value: hierarchyState.level2Value,
          sectionName: classification.sectionName || (classification.unitType === 'COLOPHON' ? 'ಪುಷ್ಪಿಕಾ / ಸಮಾಪ್ತಿ ವಾಕ್ಯ' : 'ಶೀರ್ಷಿಕೆ'),
          formattedNumber: classification.unitType === 'COLOPHON' ? 'ಪುಷ್ಪಿಕಾ' : 'ಶೀರ್ಷಿಕೆ',
          isUnnumbered: true,
        },
      });
      continue;
    }

    // Check if this chunk is just a trailing Shanti Patha closing (e.g. "॥ ॐ शान्तिः शान्तिः शान्तिः ॥" or "ॐ शान्तिः शान्तिः शान्तिः ॥")
    const isTrailingShantiClosing = /^(?:॥\s*)?(?:ॐ\s*)?शान्ति[ः|:\s]+शान्ति[ः|:\s]+शान्ति[ः|:\s]*(?:॥)?$/i.test(rawChunk);
    if (isTrailingShantiClosing && units.length > 0) {
      const prevUnit = units[units.length - 1];
      if (prevUnit.unitType === 'SHANTI_MANTRA' || /आप्यायन्तु|पूर्णमदः|सह नाववतु|भद्रं कर्णेभिः|वाङ् मे मनसि/i.test(prevUnit.originalText)) {
        prevUnit.originalText = `${prevUnit.originalText}\n${rawChunk}`;
        prevUnit.rawText = `${prevUnit.rawText}\n${rawChunk}`;
        continue;
      }
    }

    // Extract verse number
    const originalVerseNum = extractOriginalVerseNumber(rawChunk);
    const isUnnumbered = !originalVerseNum;

    let formattedNumber = originalVerseNum || '';
    let l1Val: any = hierarchyState.level1Name ? hierarchyState.level1Value : undefined;
    let l2Val: any = hierarchyState.level2Name ? hierarchyState.level2Value : undefined;
    let l3Val: any = originalVerseNum || undefined;

    if (originalVerseNum) {
      const parts = originalVerseNum.split('.').map((p) => parseInt(p, 10) || p);
      if (parts.length === 3) {
        l1Val = parts[0];
        l2Val = parts[1];
        l3Val = parts[2];
      } else if (parts.length === 2) {
        if (hierarchyState.level1Name) {
          l1Val = parts[0];
          l3Val = parts[1];
          hierarchyState.level1Value = typeof parts[0] === 'number' ? parts[0] : hierarchyState.level1Value;
        } else {
          l3Val = originalVerseNum;
          l1Val = undefined;
        }
      } else if (parts.length === 1) {
        l3Val = parts[0];
      }
    } else {
      if (classification.unitType === 'SHANTI_MANTRA') {
        formattedNumber = 'ಶಾಂತಿ ಮಂತ್ರ';
      } else if (classification.unitType === 'GADYA') {
        formattedNumber = `ಗದ್ಯ ${unitIndex}`;
      } else {
        formattedNumber = `ಶ್ಲೋಕ ${unitIndex}`;
      }
    }

    // First meaningful Sanskrit word for alphabetical index / search
    const words = rawChunk
      .replace(/[॥|।0-9.,;:!?()\-[\]{}"'`~@#$%^&*+=/\\]/g, ' ')
      .trim()
      .split(/\s+/);
    const firstMeaningfulWord = words.find((w) => w.length >= 2 && /[\u0900-\u097F]/.test(w)) || words[0] || 'मङ्गलाचरणम्';

    // Clean up verse text and strip any hierarchical verse headers (e.g. "मन्त्र ३ [I.ii.3]")
    let cleanOriginal = sanitizeUnicodeText(
      rawChunk
        .replace(/\r\n/g, '\n')
        .replace(/\n{3,}/g, '\n\n')
        .trim()
    );

    const { cleanText: headerStrippedText, hierarchicalNumber: hierNum } = stripHierarchicalVerseHeaderAndStandardizeNumber(cleanOriginal);
    cleanOriginal = headerStrippedText;
    const finalVerseNum = hierNum || originalVerseNum;

    if (finalVerseNum) {
      const parts = String(finalVerseNum).split('.').map((p) => parseInt(p, 10) || p);
      if (parts.length === 3) {
        l1Val = parts[0];
        l2Val = parts[1];
        l3Val = parts[2];
      } else if (parts.length === 2) {
        if (hierarchyState.level1Name) {
          l1Val = parts[0];
          l3Val = parts[1];
        } else {
          l3Val = finalVerseNum;
          l1Val = undefined;
        }
      } else if (parts.length === 1) {
        l3Val = parts[0];
      }
      formattedNumber = String(finalVerseNum);

      if (/॥\s*([0-9.]+)?\s*॥\s*$/.test(cleanOriginal)) {
        cleanOriginal = cleanOriginal.replace(/॥\s*([0-9.]+)?\s*॥\s*$/, `॥ ${finalVerseNum} ॥`);
      } else if (cleanOriginal.endsWith('॥')) {
        cleanOriginal = cleanOriginal.replace(/॥\s*$/, `॥ ${finalVerseNum} ॥`);
      } else if (!cleanOriginal.includes('||') && !cleanOriginal.includes('॥')) {
        cleanOriginal = `${cleanOriginal} ॥ ${finalVerseNum} ॥`;
      }
    } else if (!cleanOriginal.includes('||') && !cleanOriginal.includes('॥')) {
      cleanOriginal = `${cleanOriginal} ॥`;
    }

    units.push({
      originalText: cleanOriginal,
      rawText: rawChunk,
      firstMeaningfulWord,
      pageNumber,
      unitIndex,
      unitType: classification.unitType,
      hierarchy: {
        level1Name: hierarchyState.level1Name || undefined,
        level1Value: l1Val,
        level2Name: hierarchyState.level2Name || undefined,
        level2Value: l2Val,
        level3Name: structure.level3Name || 'ಶ್ಲೋಕ',
        level3Value: l3Val,
        sectionName: classification.sectionName || hierarchyState.currentSection,
        formattedNumber,
        isUnnumbered,
      },
    });

    unitIndex++;
  }

  return units;
}

/**
 * Split extracted Sanskrit page text into distinct verse / text units (Single Page Fallback)
 */
export function splitTextIntoSanskritUnits(
  pageText: string,
  pageNumber: number,
  structure: DetectedStructure,
  startingUnitIndex: number = 1
): ExtractedVerseUnit[] {
  return extractAllSanskritUnitsFromDocument([{ pageNumber, text: pageText }], structure);
}

// ----------------- Dynamic Table of Contents (TOC) Builder -----------------

/**
 * Universal Table of Contents Index Generator.
 * Aggregates the ACTUAL detected structural hierarchy and validated counts
 * from the database. NEVER assumes or hardcodes Adhyaya/Valli.
 * Seamlessly adapts between Multi-Chapter/Multi-Valli hierarchical tables
 * and Flat Verse-by-Verse tables (for Stotras, standalone hymns, simple works).
 */
export function buildTableOfContents(
  units: SanskritUnit[] | Array<{
    id?: string;
    pageNumber: number;
    detectedWork?: string;
    unitType?: SanskritUnitType;
    originalText?: string;
    rawExtractedText?: string;
    verifiedText?: string;
    confidence?: number;
    reviewRequired?: boolean;
    verificationStatus?: string;
    structuralHierarchy: {
      level1Name: string;
      level1Value: string | number;
      level2Name?: string;
      level2Value?: string | number;
      level3Name?: string;
      level3Value?: string | number;
      sectionName?: string;
      subsectionName?: string;
      formattedNumber?: string;
      isUnnumbered?: boolean;
    };
  }>,
  bookTitle?: string
): GranthaTableOfContents {
  const emptySummary: StructuralSummaryStats = {
    totalBooksCount: 1,
    totalChaptersCount: 0,
    totalVallisCount: 0,
    totalKhandasCount: 0,
    totalSectionsCount: 0,
    totalNumberedShlokasCount: 0,
    totalUnnumberedShlokasCount: 0,
    totalMantrasCount: 0,
    totalShantiMantrasCount: 0,
    totalGadyaCount: 0,
    totalQuotationsCount: 0,
    totalReviewRequiredCount: 0,
  };

  if (!units || units.length === 0) {
    return {
      bookTitle: bookTitle || 'ಸಂಸ್ಕೃತ ಗ್ರಂಥ',
      isFlatVerseList: false,
      columns: ['ಕ್ರಮ ಸಂ.', 'ಅಧ್ಯಾಯ', 'ಒಟ್ಟು ಶ್ಲೋಕಗಳು', 'ಪುಟ ಶ್ರೇಣಿ'],
      hasLevel1: true,
      level1Name: 'ಅಧ್ಯಾಯ',
      hasLevel2: false,
      hasSection: false,
      totalUnitsCount: 0,
      totalNumberedCount: 0,
      totalUnnumberedCount: 0,
      totalMantraCount: 0,
      totalShantiMantraCount: 0,
      totalGadyaCount: 0,
      totalOtherCount: 0,
      pageStart: 1,
      pageEnd: 1,
      pageRange: '1',
      summaryStats: emptySummary,
      entries: [],
    };
  }

  // Count overall structural statistics
  const distinctLevel1Vals = new Set<string>();
  const distinctLevel2Vals = new Set<string>();
  const distinctKhandas = new Set<string>();
  const distinctSections = new Set<string>();
  let totalReviewReq = 0;

  for (const u of units as any[]) {
    if (
      u.status === 'REVIEW_REQUIRED' ||
      u.reviewRequired ||
      u.confidence === 'LOW' ||
      (typeof u.confidence === 'number' && u.confidence < 0.85) ||
      u.verificationStatus === 'FLAGGED_FOR_REVIEW'
    ) {
      totalReviewReq++;
    }
    const h = u.structuralHierarchy;
    if (h) {
      if (h.level1Value !== undefined && h.level1Value !== null && h.level1Value !== '') {
        distinctLevel1Vals.add(`${h.level1Name || 'L1'}_${h.level1Value}`);
      }
      if (h.level2Value !== undefined && h.level2Value !== null && h.level2Value !== '') {
        distinctLevel2Vals.add(`${h.level2Name || 'L2'}_${h.level2Value}`);
        if (/ಖಂಡ|खण्ड/i.test(h.level2Name || '')) {
          distinctKhandas.add(String(h.level2Value));
        }
      }
      if (h.sectionName) {
        distinctSections.add(h.sectionName);
      }
    }
  }

  // Helper to generate concise and accurate teaching/essence description for Head & Sub-head
  const generateTeachingDescription = (
    grp: {
      level1Name: string;
      level1Value: string | number;
      level2Name?: string;
      level2Value?: string | number;
      sectionName?: string;
      subsectionName?: string;
      units: any[];
    },
    bTitle: string
  ): string => {
    const l1Num = Number(grp.level1Value) || 1;
    const l2Num = Number(grp.level2Value) || 1;
    const titleLower = (bTitle || '').toLowerCase();

    // 1. If explicit section/topic was detected
    if (grp.sectionName && grp.sectionName.length > 5 && !/ಅಧ್ಯಾಯ|ಖಂಡ|ಸರ್ಗ|ಭಾಗ|ಪರ್ವ/i.test(grp.sectionName)) {
      return grp.sectionName;
    }

    // 2. Canonical Upanishads & Classics
    if (/ಗರ್ಭ|गर्भ|garbha/i.test(titleLower)) {
      if (l1Num === 1 || l2Num === 1) return 'ಶರೀರದ ಪಂಚಭೂತಾತ್ಮಕ ಸ್ವರೂಪ ಮತ್ತು ಮೂಲತತ್ತ್ವಗಳ ವಿವರಣೆ';
      if (l1Num === 2 || l2Num === 2) return 'ಗರ್ಭೋತ್ಪತ್ತಿ ಮತ್ತು ಋತುಕಾಲದ ಶಾರೀರಿಕ ಪರಿವರ್ತನೆಗಳು';
      if (l1Num === 3 || l2Num === 3) return 'ಮಾಸಾನುಮಾಸ ಗರ್ಭವೃದ್ಧಿ ಕ್ರಮ ಮತ್ತು ಅಂಗಾಂಗ ಉತ್ಪತ್ತಿ';
      if (l1Num === 4 || l2Num === 4) return 'ಜೀವನ ಜ್ಞಾನೋದಯ, ಗರ್ಭಸ್ಥ ಪ್ರಾರ್ಥನೆ ಮತ್ತು ಜನನ ರಹಸ್ಯ';
    }

    if (/ಈಶ|ईश|isha/i.test(titleLower)) {
      if (l1Num === 1 || l2Num === 1) return 'ಈಶ್ವರ ವ್ಯಾಪಕತೆ, ತ್ಯಾಗಪೂರ್ವಕ ಭೋಗ, ಕರ್ಮಯೋಗ ಹಾಗೂ ಸತ್ಯದ ಸಾಕ್ಷಾತ್ಕಾರ';
    }

    if (/ಕೇನ|केन|kena/i.test(titleLower)) {
      if (l1Num === 1) return 'ಇಂದ್ರಿಯ-ಮನಸ್ಸುಗಳ ಪ್ರೇರಕ ಪರಬ್ರಹ್ಮ ತತ್ತ್ವ';
      if (l1Num === 2) return 'ಬ್ರಹ್ಮಜ್ಞಾನದ ರಹಸ್ಯ ಮತ್ತು ಅರಿವಿನ ಸ್ವರೂಪ';
      if (l1Num === 3) return 'ಯಕ್ಷೋಪಾಖ್ಯಾನ ಮತ್ತು ದೇವತೆಗಳ ಗರ್ವಭಂಗ';
      if (l1Num === 4) return 'ತಪಸ್ಸು, ಇಂದ್ರಿಯ ನಿಗ್ರಹ ಮತ್ತು ಬ್ರಹ್ಮಪ್ರಾಪ್ತಿಯ ಸಾಧನ';
    }

    if (/ಕಠ|कठ|katha/i.test(titleLower)) {
      if (l1Num === 1 && l2Num === 1) return 'ನಚಿಕೇತ-ಯಮ ಸಂವಾದ ಮತ್ತು ಮೂರು ವರಗಳು';
      if (l1Num === 1 && l2Num === 2) return 'ಶ್ರೇಯಸ್ಸು-ಪ್ರೇಯಸ್ಸುಗಳ ವಿವೇಚನೆ ಮತ್ತು ಆತ್ಮಸ್ವರೂಪ';
      if (l1Num === 1 && l2Num === 3) return 'ರಥ-ರಥಿಕ ರೂಪಕ ಮತ್ತು ಆತ್ಮದರ್ಶನದ ಮಾರ್ಗ';
      if (l1Num === 2 && l2Num === 1) return 'ಬ್ರಹ್ಮಾಂಡದಲ್ಲಿ ಆತ್ಮನ ಏಕತೆ ಮತ್ತು ದಿವ್ಯದರ್ಶನ';
      if (l1Num === 2 && l2Num === 2) return 'ಹೃದಯಸ್ಥ ಪುರುಷ ಮತ್ತು ನಿತ್ಯಾನಂದ ಪ್ರಾಪ್ತಿ';
      if (l1Num === 2 && l2Num === 3) return 'ಯೋಗ ಸಾಧನೆ, ನಾಡೀ ಚಕ್ರ ಮತ್ತು ಮೋಕ್ಷ ಪ್ರಾಪ್ತಿ';
    }

    if (/ಗೀತಾ|गीता|gita/i.test(titleLower)) {
      const gitaTeachings: Record<number, string> = {
        1: 'ಅರ್ಜುನವಿಷಾದ ಯೋಗ - ಮೋಹ, ಕರ್ತವ್ಯ ಗೊಂದಲ ಮತ್ತು ಶರಣಾಗತಿ',
        2: 'ಸಾಂಖ್ಯಯೋಗ - ಆತ್ಮನ ಅವಿನಾಶಿ ತತ್ತ್ವ, ಕರ್ಮಯೋಗ ಮತ್ತು ಸ್ಥಿತಪ್ರಜ್ಞ ಲಕ್ಷಣ',
        3: 'ಕರ್ಮಯೋಗ - ಲೋಕಸಂಗ್ರಹ, ಸ್ವಧರ್ಮ ಪಾಲನೆ ಮತ್ತು ನಿಷ್ಕಾಮ ಕರ್ಮ',
        4: 'ಜ್ಞಾನಕರ್ಮಸಂನ್ಯಾಸ ಯೋಗ - ಅವತಾರ ರಹಸ್ಯ ಮತ್ತು ಜ್ಞಾನಯಜ್ಞದ ಮಹತ್ವ',
        5: 'ಕರ್ಮಸಂನ್ಯಾಸ ಯೋಗ - ಕರ್ಮ ಮತ್ತು ಸಂನ್ಯಾಸಗಳ ಸಮನ್ವಯ',
        6: 'ಆತ್ಮಸಂಯಮ ಯೋಗ - ಧ್ಯಾನ ವಿಧಾನ, ಮನೋನಿಗ್ರಹ ಮತ್ತು ಯೋಗಾರೂಢ ಸ್ಥಿತಿ',
        7: 'ಜ್ಞಾನವಿಜ್ಞಾನ ಯೋಗ - ಪರಾ-ಅಪರಾ ಪ್ರಕೃತಿ ಮತ್ತು ಭಗವಂತನ ದಿವ್ಯ ವಿಭೂತಿ',
        8: 'ಅಕ್ಷರಬ್ರಹ್ಮ ಯೋಗ - ಪ್ರಣವೋಪಾಸನೆ ಮತ್ತು ಕಾಲಗತಿ-ಮೋಕ್ಷ ಚಿಂತನೆ',
        9: 'ರಾಜವಿದ್ಯಾರಾಜಗುಹ್ಯ ಯೋಗ - ಪರಮ ರಹಸ್ಯಜ್ಞಾನ ಮತ್ತು ಭಕ್ತಿ ಮಹಿಮೆ',
        10: 'ವಿಭೂತಿ ಯೋಗ - ಸಮಸ್ತ ಸೃಷ್ಟಿಯಲ್ಲಿ ಭಗವಂತನ ಶ್ರೇಷ್ಠ ವಿಭೂತಿಗಳ ದರ್ಶನ',
        11: 'ವಿಶ್ವರೂಪದರ್ಶನ ಯೋಗ - ಪರಮಾತ್ಮನ ಅನಂತ ಕಾಲ-ವಿಶ್ವರೂಪ ಸಾಕ್ಷಾತ್ಕಾರ',
        12: 'ಭಕ್ತಿ ಯೋಗ - ಸಾಕಾರ-ನಿರಾಕಾರ ಉಪಾಸನೆ ಮತ್ತು ಭಕ್ತನ ಸದ್ಗುಣಗಳು',
        13: 'ಕ್ಷೇತ್ರಕ್ಷೇತ್ರಜ್ಞವಿಭಾಗ ಯೋಗ - ಶರೀರ-ಆತ್ಮ ವಿವೇಕ ಮತ್ತು ಪ್ರಕೃತಿ-ಪುರುಷ ತತ್ತ್ವ',
        14: 'ಗುಣತ್ರಯವಿಭಾಗ ಯೋಗ - ಸತ್ತ್ವ-ರಜಸ್-ತಮೋಗುಣಗಳ ಬಂಧನ ಮತ್ತು ಗುಣಾತೀತ ಸ್ಥಿತಿ',
        15: 'ಪುರುಷೋತ್ತಮ ಯೋಗ - ಅಶ್ವತ್ಥ ವೃಕ್ಷ ರೂಪಕ ಮತ್ತು ಕ್ಷರ-ಅಕ್ಷರ-ಉತ್ತಮ ಪುರುಷ',
        16: 'ದೈವಾಸುರಸಂಪದ್ವಿಭಾಗ ಯೋಗ - ದೈವೀ ಮತ್ತು ಆಸುರೀ ಗುಣಗಳ ವಿವೇಚನೆ',
        17: 'ಶ್ರದ್ಧಾತ್ರಯವಿಭಾಗ ಯೋಗ - ಆಹಾರ, ಯಜ್ಞ, ತಪಸ್ಸು, ದಾನಗಳಲ್ಲಿ ತ್ರಿವಿಧ ಶ್ರದ್ಧೆ',
        18: 'ಮೋಕ್ಷಸಂನ್ಯಾಸ ಯೋಗ - ತ್ಯಾಗ-ಸಂನ್ಯಾಸ ಸಿದ್ಧಾಂತ, ಶರಣಾಗತಿ ಮತ್ತು ಅಂತಿಮ ಮುಕ್ತಿ',
      };
      if (gitaTeachings[l1Num]) return gitaTeachings[l1Num];
    }

    // 3. Fallback to extracting from meanings/simpleExplanation of units in group
    for (const u of grp.units) {
      if (u.simpleExplanation && u.simpleExplanation.length > 15) {
        const firstSentence = u.simpleExplanation.split(/[।.\n]/)[0].trim();
        if (firstSentence && firstSentence.length > 10) {
          return firstSentence.length > 90 ? firstSentence.slice(0, 87) + '...' : firstSentence;
        }
      }
      if (u.meaning && u.meaning.length > 15) {
        const firstSentence = u.meaning.split(/[।.\n]/)[0].trim();
        if (firstSentence && firstSentence.length > 10) {
          return firstSentence.length > 90 ? firstSentence.slice(0, 87) + '...' : firstSentence;
        }
      }
    }

    // 4. Default structural teaching title
    if (grp.level2Name && grp.level2Value) {
      return `${grp.level1Name} ${grp.level1Value} • ${grp.level2Name} ${grp.level2Value} - ತಾತ್ತ್ವಿಕ ವಿಷಯ ಪ್ರತಿಪಾದನೆ`;
    }
    return `${grp.level1Name} ${grp.level1Value} - ಪ್ರಮುಖ ಸಿದ್ಧಾಂತ ಹಾಗೂ ಉಪದೇಶ`;
  };

  // -------------------------------------------------------------
  // PURE STRUCTURAL HEAD & SUB-HEAD GROUPING MODE (Adhyaya, Valli, Khanda, Parva, Kanda, Sarga)
  // Master Index MUST NOT include individual shlokas as rows!
  // -------------------------------------------------------------
  let overallMinPage = 999999;
  let overallMaxPage = 1;

  const entries: TableOfContentsEntry[] = [];
  let slNo = 1;

  interface GroupAcc {
    key: string;
    level1Name: string;
    level1Value: string | number;
    level2Name?: string;
    level2Value?: string | number;
    sectionName?: string;
    subsectionName?: string;
    units: any[];
  }

  const groupsMap = new Map<string, GroupAcc>();

  // Decide primary grouping strategy:
  // If multiple Level 1s exist (e.g. 8 Prapathakas/Adhyayas/Vallis): group by Level 1 so each row is a Chapter/Prapathaka/Valli
  // If single Level 1 and multiple Level 2s exist (e.g. Garbhopanishad with 4 Khandas): group by Level 2
  const hasMultipleLevel1 = distinctLevel1Vals.size > 1;
  const hasMultipleLevel2Only = distinctLevel1Vals.size <= 1 && distinctLevel2Vals.size > 1;

  for (const u of units) {
    const l1Name = u.structuralHierarchy?.level1Name || 'ಅಧ್ಯಾಯ';
    const l1Val =
      u.structuralHierarchy?.level1Value !== undefined &&
      u.structuralHierarchy?.level1Value !== null &&
      u.structuralHierarchy?.level1Value !== ''
        ? u.structuralHierarchy.level1Value
        : 1;
    const l2Name = u.structuralHierarchy?.level2Name;
    const l2Val = u.structuralHierarchy?.level2Value;
    const secName = u.structuralHierarchy?.sectionName;
    const subSec = u.structuralHierarchy?.subsectionName;

    let groupKey = '';
    if (hasMultipleLevel1) {
      groupKey = `${l1Name}_${l1Val}`;
    } else if (hasMultipleLevel2Only) {
      groupKey = `${l1Name}_${l1Val}_${l2Name || 'L2'}_${l2Val || ''}`;
    } else {
      groupKey = `${l1Name}_${l1Val}_${secName || ''}`;
    }

    let grp = groupsMap.get(groupKey);
    if (!grp) {
      grp = {
        key: groupKey,
        level1Name: l1Name,
        level1Value: l1Val,
        level2Name: l2Name,
        level2Value: l2Val,
        sectionName: secName,
        subsectionName: subSec,
        units: [],
      };
      groupsMap.set(groupKey, grp);
    }
    grp.units.push(u);
  }

  // Sort groups numerically by level1Value, then level2Value
  const groups = Array.from(groupsMap.values()).sort((a, b) => {
    const a1 = typeof a.level1Value === 'number' ? a.level1Value : parseInt(String(a.level1Value), 10) || 0;
    const b1 = typeof b.level1Value === 'number' ? b.level1Value : parseInt(String(b.level1Value), 10) || 0;
    if (a1 !== b1) return a1 - b1;
    const a2 = typeof a.level2Value === 'number' ? a.level2Value : parseInt(String(a.level2Value), 10) || 0;
    const b2 = typeof b.level2Value === 'number' ? b.level2Value : parseInt(String(b.level2Value), 10) || 0;
    return a2 - b2;
  });

  let hasLevel2 = distinctLevel2Vals.size > 0;
  let hasSection = distinctSections.size > 0;
  const level1NameSet = new Set<string>();
  const level2NameSet = new Set<string>();

  for (const grp of groups) {
    let minPage = 999999;
    let maxPage = 1;
    const unitIds: string[] = [];

    const subheadValsSet = new Set<string | number>();
    let subheadName = grp.level2Name || 'ಖಂಡ';

    for (const u of grp.units) {
      if (u.id) unitIds.push(u.id);

      const p = u.pageNumber || 1;
      if (p < minPage) minPage = p;
      if (p > maxPage) maxPage = p;
      if (p < overallMinPage) overallMinPage = p;
      if (p > overallMaxPage) overallMaxPage = p;

      const uL2Val = u.structuralHierarchy?.level2Value;
      if (uL2Val !== undefined && uL2Val !== null && uL2Val !== '') {
        subheadValsSet.add(uL2Val);
        if (u.structuralHierarchy?.level2Name) {
          subheadName = u.structuralHierarchy.level2Name;
        }
      }
    }

    if (minPage === 999999) minPage = 1;
    const pageRange = minPage === maxPage ? `${minPage}` : `${minPage}–${maxPage}`;

    if (grp.level1Name) level1NameSet.add(grp.level1Name);
    if (subheadValsSet.size > 0) {
      level2NameSet.add(subheadName);
    }

    // Build clear subheads summary for this row
    let subheadSummary = '—';
    const subheadList = Array.from(subheadValsSet);
    if (subheadList.length === 1) {
      subheadSummary = `${subheadName} ${subheadList[0]}`;
    } else if (subheadList.length > 1) {
      const numList = subheadList
        .filter((v) => typeof v === 'number' || !isNaN(Number(v)))
        .map((v) => Number(v))
        .sort((a, b) => a - b);
      if (numList.length === subheadList.length) {
        subheadSummary = `${subheadName}ಗಳು: ${numList[0]} – ${numList[numList.length - 1]} (ಒಟ್ಟು ${numList.length} ${subheadName}ಗಳು)`;
      } else {
        subheadSummary = `${subheadName}ಗಳು: ${subheadList.join(', ')} (ಒಟ್ಟು ${subheadList.length} ${subheadName}ಗಳು)`;
      }
    }

    const resolvedBookTitle = bookTitle || units[0]?.detectedWork || 'ಸಂಸ್ಕೃತ ಗ್ರಂಥ';
    const whatItTeaches = generateTeachingDescription(grp, resolvedBookTitle);

    entries.push({
      slNo: slNo++,
      level1Name: grp.level1Name,
      level1Value: grp.level1Value,
      level2Name: subheadList.length > 0 ? subheadName : undefined,
      level2Value: subheadList.length === 1 ? subheadList[0] : (subheadList.length > 1 ? `${subheadList[0]}–${subheadList[subheadList.length - 1]}` : undefined),
      subheadSummary,
      sectionName: grp.sectionName,
      subsectionName: grp.subsectionName,
      topic: whatItTeaches,
      whatItTeaches,
      pageStart: minPage,
      pageEnd: maxPage,
      pageRange,
      unitIds,
    });
  }

  if (overallMinPage === 999999) overallMinPage = 1;
  const overallPageRange = overallMinPage === overallMaxPage ? `${overallMinPage}` : `${overallMinPage}–${overallMaxPage}`;

  const primaryLevel1Name = Array.from(level1NameSet)[0] || 'ಅಧ್ಯಾಯ';
  const primaryLevel2Name = Array.from(level2NameSet)[0] || (hasLevel2 ? 'ಖಂಡ' : undefined);

  // Determine clean dynamic columns based purely on Head, Sub-head, What It Teaches, Page
  const columns: string[] = ['ಕ್ರಮ ಸಂ. (Sl. No.)'];
  columns.push(`${primaryLevel1Name} (Head)`);
  if (hasLevel2 && primaryLevel2Name) {
    columns.push(`${primaryLevel2Name} (Sub-head)`);
  }
  columns.push('ವಿಷಯ ಮತ್ತು ಬೋಧಿಸುವ ತತ್ತ್ವಾರ್ಥ (What It Teaches)');
  columns.push('ಪುಟ (Page)');

  const resolvedBookTitle = bookTitle || units[0]?.detectedWork || 'ಸಂಸ್ಕೃತ ಗ್ರಂಥ';

  let totalVallisCount = 0;
  for (const name of level1NameSet) {
    if (/ವಲ್ಲಿ|वल्ली/i.test(name)) totalVallisCount += distinctLevel1Vals.size;
  }
  for (const name of level2NameSet) {
    if (/ವಲ್ಲಿ|वल्ली/i.test(name)) totalVallisCount += distinctLevel2Vals.size;
  }

  const summaryStats: StructuralSummaryStats = {
    totalBooksCount: 1,
    totalChaptersCount: distinctLevel1Vals.size || 1,
    totalVallisCount,
    totalKhandasCount: distinctLevel2Vals.size,
    totalSectionsCount: distinctSections.size,
    totalNumberedShlokasCount: units.length,
    totalUnnumberedShlokasCount: 0,
    totalMantrasCount: units.filter(u => u.unitType === 'MANTRA').length,
    totalShantiMantrasCount: units.filter(u => u.unitType === 'SHANTI_MANTRA').length,
    totalGadyaCount: units.filter(u => u.unitType === 'GADYA').length,
    totalQuotationsCount: units.filter(u => u.unitType === 'QUOTATION' || u.unitType === 'COLOPHON').length,
    totalReviewRequiredCount: totalReviewReq,
  };

  return {
    bookTitle: resolvedBookTitle,
    isFlatVerseList: false,
    columns,
    hasLevel1: true,
    level1Name: primaryLevel1Name,
    hasLevel2,
    level2Name: primaryLevel2Name,
    hasSection,
    totalUnitsCount: units.length,
    totalNumberedCount: units.length,
    totalUnnumberedCount: 0,
    totalMantraCount: units.filter(u => u.unitType === 'MANTRA').length,
    totalShantiMantraCount: units.filter(u => u.unitType === 'SHANTI_MANTRA').length,
    totalGadyaCount: units.filter(u => u.unitType === 'GADYA').length,
    totalOtherCount: units.filter(u => u.unitType === 'QUOTATION' || u.unitType === 'COLOPHON').length,
    pageStart: overallMinPage,
    pageEnd: overallMaxPage,
    pageRange: overallPageRange,
    summaryStats,
    entries,
  };
}
