import {
  Document,
  Paragraph,
  TextRun,
  AlignmentType,
  Table,
  TableRow,
  TableCell,
  WidthType,
  BorderStyle,
  Packer,
  ImageRun,
} from 'docx';
import ExcelJS from 'exceljs';
import JSZip from 'jszip';
import PDFDocument from 'pdfkit';
import sharp from 'sharp';
import { SanskritUnit, GranthaProject, GranthaDocument } from '../src/types';
import {
  formatSymmetricShlokaLines,
  sanitizeUnicodeText,
  formatPadarthaWithDevanagariPadas,
  devanagariToKannada,
  correctKannadaGrammarAndSpelling,
  standardizeKannadaOrthography,
} from './transliteration';
import { generateScholarlySvgDiagram, renderSvgToPngBuffer } from './visualGenerator';
import { isHeadingOrColophonUnit } from './structureDetector';

/**
 * Universal Indic safe fonts with Noto Sans as primary scholarly font
 */
const DEFAULT_DOCX_FONT = 'Noto Sans';
const SCRIPT_FONT_KANNADA = 'Noto Sans Kannada';
const SCRIPT_FONT_DEVANAGARI = 'Noto Sans Devanagari';
const SCRIPT_FONT_LATIN = 'Noto Sans';

function fontForChar(ch: string, fallback = SCRIPT_FONT_KANNADA): string {
  if (/[\u0C80-\u0CFF]/.test(ch)) return SCRIPT_FONT_KANNADA;
  if (/[\u0900-\u097F]/.test(ch)) return SCRIPT_FONT_DEVANAGARI;
  if (/[A-Za-z]/.test(ch)) return SCRIPT_FONT_LATIN;
  return fallback;
}

function createScriptAwareRuns(text: string, baseSize: number, options: { bold?: boolean; italics?: boolean; color?: string } = {}): TextRun[] {
  if (!text) return [];
  const runs: TextRun[] = [];
  let current = '';
  let currentFont = fontForChar(text[0] || '');
  const flush = () => {
    if (!current) return;
    runs.push(new TextRun({
      text: current,
      bold: options.bold,
      italics: options.italics,
      color: options.color,
      size: baseSize,
      font: { name: currentFont, cs: currentFont, ascii: currentFont, hAnsi: currentFont },
    }));
    current = '';
  };
  for (const ch of text) {
    const f = fontForChar(ch, currentFont);
    if (f !== currentFont && current.trim()) {
      flush();
      currentFont = f;
    } else if (f !== currentFont && !current.trim()) {
      currentFont = f;
    }
    current += ch;
  }
  flush();
  return runs;
}

async function validateGeneratedDocxBuffer(buffer: Buffer): Promise<{ valid: boolean; issues: string[] }> {
  const zip = await JSZip.loadAsync(buffer);
  const documentXml = await zip.file('word/document.xml')?.async('text') || '';
  const issues: string[] = [];

  if (/<w:pStyle[^>]+w:val="(?:Title|Subtitle|Heading[1-9])"/i.test(documentXml)) {
    issues.push('DOCX contains a paragraph using a Word structural heading/title style.');
  }

  const runFontPairs = [...documentXml.matchAll(/<w:rPr>([\s\S]*?)<\/w:rPr>[\s\S]*?<w:t[^>]*>([\s\S]*?)<\/w:t>/g)];
  for (const m of runFontPairs) {
    const rpr = m[1];
    const text = m[2];
    const fontMatch = rpr.match(/<w:rFonts[^>]*w:ascii="([^"]+)"/);
    const font = fontMatch?.[1] || '';
    if (/[\u0C80-\u0CFF]/.test(text) && font !== SCRIPT_FONT_KANNADA) {
      issues.push(`Kannada text is not directly formatted with ${SCRIPT_FONT_KANNADA}.`);
      break;
    }
    if (/[\u0900-\u097F]/.test(text) && font !== SCRIPT_FONT_DEVANAGARI) {
      issues.push(`Devanagari text is not directly formatted with ${SCRIPT_FONT_DEVANAGARI}.`);
      break;
    }
  }
  return { valid: issues.length === 0, issues };
}


/**
 * Format structural location label before each individual textual unit
 */
function formatUnitLocationHeader(
  unit: SanskritUnit,
  fontKannada: string,
  fontSizePt: number
): Paragraph[] {
  const h = unit.structuralHierarchy;
  const lines: string[] = [];

  if (h.level1Name && h.level1Value !== undefined && h.level1Value !== null && h.level1Value !== '') {
    lines.push(`${h.level1Name}: ${h.level1Value}`);
  }
  if (h.level2Name && h.level2Value !== undefined && h.level2Value !== null && h.level2Value !== '') {
    lines.push(`${h.level2Name}: ${h.level2Value}`);
  }
  
  const unitTypeName = unit.unitType === 'SHANTI_MANTRA' ? 'ಶಾಂತಿ ಮಂತ್ರ' :
    unit.unitType === 'MANTRA' ? 'ಮಂತ್ರ' :
    unit.unitType === 'GADYA' ? 'ಗದ್ಯ ಭಾಗ' :
    unit.unitType === 'COLOPHON' ? 'ಪುಷ್ಪಿಕಾ / ಸಮಾಪ್ತಿ' :
    (h.level3Name || 'ಶ್ಲೋಕ');

  if (h.formattedNumber) {
    const cleanNum = h.formattedNumber.replace(/\|\|/g, '').trim();
    lines.push(`${unitTypeName}: ${cleanNum}`);
  } else if (unit.unitIndex) {
    lines.push(`${unitTypeName}: ${unit.unitIndex}`);
  }

  const locationLabel = lines.join('   |   ');

  return [
    new Paragraph({
      alignment: AlignmentType.LEFT,
      spacing: { before: 260, after: 80 },
      children: [
        new TextRun({
          text: `【 ${locationLabel} 】`,
          bold: true,
          font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
          size: fontSizePt * 2,
          color: '1A365D',
        }),
        new TextRun({
          text: `   [ಪುಟ ${unit.pageNumber}]`,
          font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
          size: (fontSizePt - 1) * 2,
          color: '64748B',
        }),
      ],
    }),
  ];
}

/**
 * Generate Pure Shloka & Explanation DOCX (Focused Manuscript without Audit/Diagram Clutter)
 */
export async function generatePureShlokaDocx(
  project: GranthaProject,
  units: SanskritUnit[],
  fontDevanagari = 'Noto Sans Devanagari',
  fontKannada = 'Noto Sans Kannada',
  fontSizePt = 12
): Promise<Buffer> {
  const children: (Paragraph | Table)[] = [];
  const headingSize = 26; // 13pt bold (26 half-points)
  const bodySize = fontSizePt * 2; // 12pt (24 half-points)

  // Book Title
  children.push(
    new Paragraph({
      text: project.name || 'ಸಂಸ್ಕೃತ-ಕನ್ನಡ ಶ್ಲೋಕಾರ್ಥ ಗ್ರಂಥ (Sanskrit-Kannada Shloka Vivarana)',
      alignment: AlignmentType.CENTER,
      spacing: { after: 150, before: 200 },
      run: {
        font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
        size: 32, // 16pt
        bold: true,
        color: '8B1E0F',
      },
    }),
    new Paragraph({
      text: '॥ ಮೂಲ ಶ್ಲೋಕ, ಕನ್ನಡ ಲಿಪ್ಯಂತರ, ಪದಾರ್ಥ, ಸರಳ ವಿವರಣೆ ಹಾಗೂ ವಿಸ್ತೃತ ವ್ಯಾಖ್ಯಾನ ॥',
      alignment: AlignmentType.CENTER,
      spacing: { after: 350 },
      run: {
        font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
        size: bodySize, // 12pt
        italics: true,
        color: '4A4A4A',
      },
    })
  );

  let currentWork = '';

  for (const unit of units) {
    const rawMoola = unit.output?.moolaShloka || unit.verifiedText || unit.originalText || '';
    if (!rawMoola.trim()) continue;

    let rawKannadaTranslit = unit.output?.kannadaTransliteration;
    if (!rawKannadaTranslit || /[A-Za-z]/.test(rawKannadaTranslit) || !/[\u0C80-\u0CFF]/.test(rawKannadaTranslit)) {
      rawKannadaTranslit = devanagariToKannada(rawMoola);
    }
    const rawPadartha = unit.output?.padartha || '(ಸಂಸ್ಕರಣೆ ಬಾಕಿ ಇದೆ - AI ಸಂಸ್ಕರಣೆ ಆರಂಭಿಸಿ)';
    const rawSarala = unit.output?.saralaVivarane || '(ಸಂಸ್ಕರಣೆ ಬಾಕಿ ಇದೆ - AI ಸಂಸ್ಕರಣೆ ಆರಂಭಿಸಿ)';
    const rawVyakhyana = unit.output?.vivaradaVyakhyana || '(ಸಂಸ್ಕರಣೆ ಬಾಕಿ ಇದೆ - AI ಸಂಸ್ಕರಣೆ ಆರಂಭಿಸಿ)';

    // Header if new work
    if (unit.detectedWork && unit.detectedWork !== currentWork) {
      currentWork = unit.detectedWork;
      children.push(
        new Paragraph({
          text: `॥ ${currentWork} ॥`,
          alignment: AlignmentType.CENTER,
          spacing: { before: 400, after: 180 },
          run: {
            font: { name: fontDevanagari, cs: fontDevanagari, ascii: fontDevanagari, hAnsi: fontDevanagari },
            size: 28,
            bold: true,
            color: '1A365D',
          },
        })
      );
    }

    // HEADING or COLOPHON (Chapter/Section Titles, Iti Khanda, etc.)
    // Rendered directly in Kannada transliteration without 5-stage shloka breakdown
    if (isHeadingOrColophonUnit(unit)) {
      const headingKannada = sanitizeUnicodeText(rawKannadaTranslit).trim();
      const cleanHeading = headingKannada.replace(/^[॥।।|।\s]+|[॥।।|।\s]+$/g, '').trim();
      const isCol = unit.unitType === 'COLOPHON' || /^(?:इति|ಇತಿ)\s+|(?:समाप्त|सम्पूर्ण|ಸಮಾಪ್ತ|ಸಂಪೂರ್ಣ)/i.test(rawMoola);
      const displayTitle = cleanHeading.startsWith('॥') ? cleanHeading : `॥ ${cleanHeading} ॥`;
      children.push(
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 360, after: 180 },
          children: [
            new TextRun({
              text: displayTitle,
              bold: true,
              font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
              size: 28, // 14pt bold
              color: isCol ? '701A75' : '1A365D',
            }),
          ],
        }),
        new Paragraph({ text: '', spacing: { after: 120 } })
      );
      continue;
    }

    // 1. ಮೂಲ ಸಂಸ್ಕೃತ ಶ್ಲೋಕ (Devanagari Sanskrit) - Heading CENTERED, 13pt Bold, Maroon
    children.push(
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 240, after: 60 },
        children: [
          new TextRun({
            text: '॥ ಮೂಲ ಸಂಸ್ಕೃತ ಶ್ಲೋಕಃ ॥',
            bold: true,
            italics: false,
            font: { name: fontDevanagari, cs: fontDevanagari, ascii: fontDevanagari, hAnsi: fontDevanagari },
            size: headingSize, // 13pt bold
            color: '8B1E0F',
          }),
        ],
      }),
      // 1 Line Gap
      new Paragraph({ text: '', spacing: { after: 120 } })
    );

    const moolaFormatted = formatSymmetricShlokaLines(sanitizeUnicodeText(rawMoola));
    const moolaLines = moolaFormatted.split('\n');

    for (const mLine of moolaLines) {
      if (!mLine.trim()) continue;
      children.push(
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 30, after: 30 },
          children: [
            new TextRun({
              text: mLine.trim(),
              font: { name: fontDevanagari, cs: fontDevanagari, ascii: fontDevanagari, hAnsi: fontDevanagari },
              size: bodySize, // 12pt
              bold: true,
              color: '1A202C',
            }),
          ],
        })
      );
    }

    // 1 Line Gap
    children.push(new Paragraph({ text: '', spacing: { after: 140 } }));

    // 2. ಕನ್ನಡ ಲಿಪ್ಯಂತರಿತ ಶ್ಲೋಕ (Kannada Transliteration) - Heading CENTERED, 13pt Bold, Terracotta Amber
    children.push(
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 120, after: 60 },
        children: [
          new TextRun({
            text: '॥ ಕನ್ನಡ ಲಿಪ್ಯಂತರ ॥',
            bold: true,
            italics: false,
            font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
            size: headingSize, // 13pt bold
            color: 'C2410C',
          }),
        ],
      }),
      // 1 Line Gap
      new Paragraph({ text: '', spacing: { after: 120 } })
    );

    const kanFormatted = formatSymmetricShlokaLines(sanitizeUnicodeText(rawKannadaTranslit));
    const kanLines = kanFormatted.split('\n');

    for (const kLine of kanLines) {
      if (!kLine.trim()) continue;
      children.push(
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 30, after: 30 },
          children: [
            new TextRun({
              text: kLine.trim(),
              font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
              size: bodySize, // 12pt
              bold: true,
              italics: false,
              color: '1A202C',
            }),
          ],
        })
      );
    }

    // 1 Line Gap
    children.push(new Paragraph({ text: '', spacing: { after: 140 } }));

    // 3. ಪದಾರ್ಥ (Heading: LEFT ALIGNED, 13pt Bold, Deep Emerald Green, NO Numbering)
    const formattedPadartha = formatPadarthaWithDevanagariPadas(rawPadartha);
    const padarthaItems = formattedPadartha.split(/,\s*/);
    const padarthaDocxRuns: TextRun[] = [];

    padarthaItems.forEach((item, idx) => {
      const parts = item.split(/\s*[-=:—–]\s*/);
      if (parts.length >= 2) {
        const pada = parts[0];
        const artha = parts.slice(1).join(' - ');
        padarthaDocxRuns.push(
          new TextRun({
            text: pada,
            font: { name: fontDevanagari, cs: fontDevanagari, ascii: fontDevanagari, hAnsi: fontDevanagari },
            size: bodySize, // 12pt
            bold: true,
            color: '8B1E0F',
          }),
          new TextRun({
            text: ' - ',
            font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
            size: bodySize, // 12pt
            bold: false,
            color: '718096',
          }),
          new TextRun({
            text: artha + (idx < padarthaItems.length - 1 ? ', ' : ''),
            font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
            size: bodySize, // 12pt
            bold: false,
            color: '1A202C',
          })
        );
      } else {
        padarthaDocxRuns.push(
          new TextRun({
            text: item + (idx < padarthaItems.length - 1 ? ', ' : ''),
            font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
            size: bodySize, // 12pt
            bold: false,
            color: '1A202C',
          })
        );
      }
    });

    children.push(
      new Paragraph({
        alignment: AlignmentType.LEFT,
        spacing: { before: 140, after: 60 },
        children: [
          new TextRun({
            text: 'ಪದಾರ್ಥ:',
            bold: true,
            italics: false,
            font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
            size: headingSize, // 13pt bold
            color: '0F766E',
          }),
        ],
      }),
      // 1 Line Gap
      new Paragraph({ text: '', spacing: { after: 100 } }),
      new Paragraph({
        alignment: AlignmentType.JUSTIFIED,
        spacing: { before: 20, after: 140 },
        children: padarthaDocxRuns.length > 0 ? padarthaDocxRuns : [
          new TextRun({
            text: sanitizeUnicodeText(formattedPadartha),
            font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
            size: bodySize, // 12pt
            bold: false,
            italics: false,
            color: '1A202C',
          }),
        ],
      })
    );

    // 1 Line Gap
    children.push(new Paragraph({ text: '', spacing: { after: 120 } }));

    // 4. ಸರಳ ವಿವರಣೆ (Heading: LEFT ALIGNED, 13pt Bold, Royal Sapphire Blue, NO Numbering)
    const cleanSarala = sanitizeUnicodeText(rawSarala)
      .replace(/^(\d+\.?\s*)?(ಸರಳ\s*ವಿವರಣೆ\s*[:\-])\s*/i, '')
      .trim();
    children.push(
      new Paragraph({
        alignment: AlignmentType.LEFT,
        spacing: { before: 140, after: 60 },
        children: [
          new TextRun({
            text: 'ಸರಳ ವಿವರಣೆ:',
            bold: true,
            italics: false,
            font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
            size: headingSize, // 13pt bold
            color: '1E40AF',
          }),
        ],
      }),
      // 1 Line Gap
      new Paragraph({ text: '', spacing: { after: 100 } }),
      new Paragraph({
        alignment: AlignmentType.JUSTIFIED,
        spacing: { before: 20, after: 140 },
        children: [
          new TextRun({
            text: cleanSarala,
            font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
            size: bodySize, // 12pt
            bold: false,
            italics: false,
            color: '1A202C',
          }),
        ],
      })
    );

    // 1 Line Gap
    children.push(new Paragraph({ text: '', spacing: { after: 120 } }));

    // 5. ವಿವರವಾದ ವ್ಯಾಖ್ಯಾನ (Heading: LEFT ALIGNED, 13pt Bold, Regal Deep Purple, NO Numbering)
    const cleanVyakhyana = sanitizeUnicodeText(rawVyakhyana)
      .replace(/^(\d+\.?\s*)?(ವಿವರವಾದ\s*ವ್ಯಾಖ್ಯಾನ\s*[:\-])\s*/i, '')
      .trim();
    children.push(
      new Paragraph({
        alignment: AlignmentType.LEFT,
        spacing: { before: 140, after: 60 },
        children: [
          new TextRun({
            text: 'ವಿವರವಾದ ವ್ಯಾಖ್ಯಾನ:',
            bold: true,
            italics: false,
            font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
            size: headingSize, // 13pt bold
            color: '6B21A8',
          }),
        ],
      }),
      // 1 Line Gap
      new Paragraph({ text: '', spacing: { after: 100 } }),
      new Paragraph({
        alignment: AlignmentType.JUSTIFIED,
        spacing: { before: 20, after: 180 },
        children: [
          new TextRun({
            text: cleanVyakhyana,
            font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
            size: bodySize, // 12pt
            bold: false,
            italics: false,
            color: '1A202C',
          }),
        ],
      })
    );

    // 6. Scholarly Table (Horizontally Centered & Perfectly Fitted to A4 Page Area)
    if (unit.output?.tableContent && unit.output.tableContent.headers && unit.output.tableContent.rows && unit.output.tableContent.rows.length > 0) {
      const headers = unit.output.tableContent.headers;
      const numCols = headers.length || 1;
      const a4PrintableWidth = 9020; // 9020 DXA (~6.27 inches, perfectly fits inside 1-inch A4 margins)
      const colWidthDxa = Math.floor(a4PrintableWidth / numCols);

      const tableRows: TableRow[] = [];
      tableRows.push(
        new TableRow({
          tableHeader: true,
          children: headers.map(h => (
            new TableCell({
              width: { size: colWidthDxa, type: WidthType.DXA },
              shading: { fill: '8B1E0F' },
              margins: { top: 120, bottom: 120, left: 140, right: 140 },
              borders: {
                top: { style: BorderStyle.SINGLE, size: 4, color: 'DBC8B0' },
                bottom: { style: BorderStyle.SINGLE, size: 6, color: '6B1408' },
                left: { style: BorderStyle.SINGLE, size: 4, color: 'DBC8B0' },
                right: { style: BorderStyle.SINGLE, size: 4, color: 'DBC8B0' },
              },
              children: [
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  children: createScriptAwareRuns(h, (fontSizePt - 1) * 2, { bold: true, color: 'FFFFFF' }),
                }),
              ],
            })
          )),
        })
      );
      for (const [rIdx, r] of unit.output.tableContent.rows.entries()) {
        tableRows.push(
          new TableRow({
            children: r.map((cell, cIdx) => (
              new TableCell({
                width: { size: colWidthDxa, type: WidthType.DXA },
                shading: rIdx % 2 === 1 ? { fill: 'F9F6F0' } : undefined,
                margins: { top: 100, bottom: 100, left: 140, right: 140 },
                borders: {
                  top: { style: BorderStyle.SINGLE, size: 4, color: 'E2D8C7' },
                  bottom: { style: BorderStyle.SINGLE, size: 4, color: 'E2D8C7' },
                  left: { style: BorderStyle.SINGLE, size: 4, color: 'E2D8C7' },
                  right: { style: BorderStyle.SINGLE, size: 4, color: 'E2D8C7' },
                },
                children: [
                  new Paragraph({
                    alignment: cIdx === 0 ? AlignmentType.CENTER : AlignmentType.LEFT,
                    children: createScriptAwareRuns(cell, (fontSizePt - 1) * 2),
                  }),
                ],
              })
            )),
          })
        );
      }

      children.push(
        new Paragraph({
          children: [
            new TextRun({
              text: unit.output.tableContent.title ? `📊 ಕೋಷ್ಟಕ: ${unit.output.tableContent.title}` : '📊 ವಿವರಣಾತ್ಮಕ ಕೋಷ್ಟಕ:',
              bold: true,
              color: '8B1E0F',
              font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
              size: headingSize, // 13pt bold
            }),
          ],
          spacing: { before: 120, after: 60 },
        }),
        new Table({
          alignment: AlignmentType.CENTER,
          width: { size: a4PrintableWidth, type: WidthType.DXA },
          columnWidths: Array(numCols).fill(colWidthDxa),
          rows: tableRows,
        }),
        new Paragraph({ text: '', spacing: { after: 80 } })
      );

      if (unit.output.tableContent.explanation) {
        children.push(
          new Paragraph({
            children: [
              new TextRun({
                text: `ವಿವರಣೆ: ${unit.output.tableContent.explanation}`,
                italics: true,
                color: '4A5568',
                font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
                size: bodySize,
              }),
            ],
            spacing: { before: 40, after: 120 },
          })
        );
      }
    }

    // 7. Embedded Real Image for Diagram / Rekha Chitra / Asana / Astronomy / Geometry / Philosophy
    if (unit.output?.diagramContent && (unit.output.diagramContent.title || unit.output.diagramContent.description || unit.output.diagramContent.svgDiagram)) {
      const diag = unit.output.diagramContent;
      const diagTitle = diag.title || 'ಶಾಸ್ತ್ರೀಯ ಪರಿಕಲ್ಪನಾ ರೇಖಾಚಿತ್ರ';
      let svgMarkup = diag.svgDiagram;
      if (!svgMarkup || svgMarkup.trim().length < 20) {
        svgMarkup = generateScholarlySvgDiagram(
          diagTitle,
          diag.description || unit.output.vivaradaVyakhyana || '',
          null,
          unit.output.tableContent?.headers,
          unit.output.tableContent?.rows
        );
      }

      try {
        const pngBuffer = await renderSvgToPngBuffer(svgMarkup, 1400);
        let imgWidth = 490;
        let imgHeight = 240;
        try {
          const meta = await sharp(pngBuffer).metadata();
          if (meta.width && meta.height) {
            imgHeight = Math.min(Math.max(Math.round(imgWidth * (meta.height / meta.width)), 120), 480);
          }
        } catch {
          // fallback
        }

        children.push(
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { before: 140, after: 60 },
            children: [
              new ImageRun({
                data: pngBuffer,
                transformation: {
                  width: imgWidth,
                  height: imgHeight,
                },
                type: 'png',
              }),
            ],
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { before: 20, after: 60 },
            children: [
              new TextRun({
                text: `ಚಿತ್ರ: ${diag.caption || diagTitle}`,
                italics: true,
                bold: true,
                color: '4A5568',
                font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
                size: (fontSizePt - 1) * 2,
              }),
            ],
          })
        );

        if (diag.description) {
          children.push(
            new Paragraph({
              alignment: AlignmentType.LEFT,
              spacing: { before: 20, after: 120 },
              children: [
                new TextRun({
                  text: `ಶಾಸ್ತ್ರೀಯ ವಿವರಣೆ: ${diag.description}`,
                  color: '2D3748',
                  font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
                  size: bodySize,
                }),
              ],
            })
          );
        }
      } catch (err) {
        console.error(`Failed to embed diagram image for unit ${unit.id}:`, err);
      }
    }

    // 8. Embedded Real Image for Iconographic Picture / Sacred Form / Dhyana Moorti
    if (unit.output?.pictureContent && (unit.output.pictureContent.title || unit.output.pictureContent.description)) {
      const pic = unit.output.pictureContent;
      const picTitle = pic.title || 'ದೇವತಾ ರೂಪ / ಶಾಸ್ತ್ರೀಯ ಚಿತ್ರಣ';
      const svgMarkup = generateScholarlySvgDiagram(
        picTitle,
        pic.description || unit.output.vivaradaVyakhyana || '',
        null,
        unit.output.tableContent?.headers,
        unit.output.tableContent?.rows
      );

      try {
        const pngBuffer = await renderSvgToPngBuffer(svgMarkup, 1400);
        let imgWidth = 490;
        let imgHeight = 240;
        try {
          const meta = await sharp(pngBuffer).metadata();
          if (meta.width && meta.height) {
            imgHeight = Math.min(Math.max(Math.round(imgWidth * (meta.height / meta.width)), 120), 480);
          }
        } catch {
          // fallback
        }

        children.push(
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { before: 140, after: 60 },
            children: [
              new ImageRun({
                data: pngBuffer,
                transformation: {
                  width: imgWidth,
                  height: imgHeight,
                },
                type: 'png',
              }),
            ],
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { before: 20, after: 60 },
            children: [
              new TextRun({
                text: `ಚಿತ್ರ: ${pic.caption || picTitle}`,
                italics: true,
                bold: true,
                color: '8B1E0F',
                font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
                size: (fontSizePt - 1) * 2,
              }),
            ],
          })
        );

        if (pic.description) {
          children.push(
            new Paragraph({
              alignment: AlignmentType.LEFT,
              spacing: { before: 20, after: 120 },
              children: [
                new TextRun({
                  text: `ಧ್ಯಾಹ್ನ ಸ್ವರೂಪ ವಿವರಣೆ: ${pic.description}`,
                  color: '2D3748',
                  font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
                  size: bodySize,
                }),
              ],
            })
          );
        }
      } catch (err) {
        console.error(`Failed to embed picture image for unit ${unit.id}:`, err);
      }
    }

    // Subtle Section Divider
    children.push(
      new Paragraph({
        text: '❖  ❖  ❖',
        alignment: AlignmentType.CENTER,
        spacing: { before: 120, after: 240 },
        run: {
          font: { name: fontDevanagari, cs: fontDevanagari, ascii: fontDevanagari, hAnsi: fontDevanagari },
          size: 18,
          color: 'CBD5E0',
        },
      })
    );
  }

  const doc = new Document({
    sections: [
      {
        properties: {
          page: {
            margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 }, // 1 inch
          },
        },
        children,
      },
    ],
  });

  return await Packer.toBuffer(doc);
}

/**
 * Generate Master DOCX scholarly manuscript (Comprehensive Edition with Index)
 */
export async function generateMasterDocx(
  project: GranthaProject,
  units: SanskritUnit[],
  fontDevanagari = 'Noto Sans Devanagari',
  fontKannada = 'Noto Sans Kannada',
  fontSizePt = 12
): Promise<Buffer> {
  // Scholarly manuscript font contract: never permit configurable/fallback fonts
  // to replace the required script-specific Noto fonts.
  fontDevanagari = SCRIPT_FONT_DEVANAGARI;
  fontKannada = SCRIPT_FONT_KANNADA;

  const children: (Paragraph | Table)[] = [];
  const headingSize = 26; // 13pt bold (26 half-points)
  const bodySize = fontSizePt * 2; // 12pt (24 half-points)

  // Title Section
  children.push(
    new Paragraph({
      text: project.name || 'ಸಂಸ್ಕೃತ-ಕನ್ನಡ ವಿದ್ವತ್ ಪ್ರಕಾಶನ ಗ್ರಂಥ (Scholarly Edition)',
      alignment: AlignmentType.CENTER,
      spacing: { after: 200, before: 300 },
      run: {
        font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
        size: 32, // 16pt
        bold: true,
        color: '8B1E0F',
      },
    }),
    new Paragraph({
      text: `ಮೂಲ ಸಂಸ್ಕೃತ, ಕನ್ನಡ ಲಿಪ್ಯಂತರ, ಪದಾರ್ಥ, ಸರಳ ವಿವರಣೆ ಮತ್ತು ವಿವರವಾದ ವ್ಯಾಖ್ಯಾನ ಸಹಿತ`,
      alignment: AlignmentType.CENTER,
      spacing: { after: 400 },
      run: {
        font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
        size: bodySize, // 12pt
        italics: true,
        color: '4A4A4A',
      },
    })
  );

  let currentWork = '';

  for (const unit of units) {
    const rawMoola = unit.output?.moolaShloka || unit.verifiedText || unit.originalText || '';
    if (!rawMoola.trim()) continue;

    const rawKannadaTranslit = unit.output?.kannadaTransliteration || devanagariToKannada(rawMoola);
    const rawPadartha = unit.output?.padartha || '(ಸಂಸ್ಕರಣೆ ಬಾಕಿ ಇದೆ - AI ಸಂಸ್ಕರಣೆ ಆರಂಭಿಸಿ)';
    const rawSarala = unit.output?.saralaVivarane || '(ಸಂಸ್ಕರಣೆ ಬಾಕಿ ಇದೆ - AI ಸಂಸ್ಕರಣೆ ಆರಂಭಿಸಿ)';
    const rawVyakhyana = unit.output?.vivaradaVyakhyana || '(ಸಂಸ್ಕರಣೆ ಬಾಕಿ ಇದೆ - AI ಸಂಸ್ಕರಣೆ ಆರಂಭಿಸಿ)';

    // Header if new work
    if (unit.detectedWork && unit.detectedWork !== currentWork) {
      currentWork = unit.detectedWork;
      children.push(
        new Paragraph({
          text: `॥ ${currentWork} ॥`,
          alignment: AlignmentType.CENTER,
          spacing: { before: 500, after: 200 },
          run: {
            font: { name: fontDevanagari, cs: fontDevanagari, ascii: fontDevanagari, hAnsi: fontDevanagari },
            size: 28,
            bold: true,
            color: '1A365D',
          },
        })
      );
    }

    // HEADING or COLOPHON (Chapter/Section Titles, Iti Khanda, etc.)
    // Rendered directly in Kannada transliteration without 5-stage shloka breakdown
    if (isHeadingOrColophonUnit(unit)) {
      const headingKannada = sanitizeUnicodeText(rawKannadaTranslit).trim();
      const cleanHeading = headingKannada.replace(/^[॥।।|।\s]+|[॥।।|।\s]+$/g, '').trim();
      const isCol = unit.unitType === 'COLOPHON' || /^(?:इति|ಇತಿ)\s+|(?:समाप्त|सम्पूर्ण|ಸಮಾಪ್ತ|ಸಂಪೂರ್ಣ)/i.test(rawMoola);
      const displayTitle = cleanHeading.startsWith('॥') ? cleanHeading : `॥ ${cleanHeading} ॥`;
      children.push(
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 360, after: 180 },
          children: [
            new TextRun({
              text: displayTitle,
              bold: true,
              font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
              size: 28, // 14pt bold
              color: isCol ? '701A75' : '1A365D',
            }),
          ],
        }),
        new Paragraph({ text: '', spacing: { after: 120 } })
      );
      continue;
    }

    // 1. ಮೂಲ ಸಂಸ್ಕೃತ ಶ್ಲೋಕ (Devanagari) - Heading CENTERED, 13pt Bold, Maroon
    children.push(
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 240, after: 60 },
        children: [
          new TextRun({
            text: '॥ ಮೂಲ ಸಂಸ್ಕೃತ ಶ್ಲೋಕಃ ॥',
            bold: true,
            italics: false,
            font: { name: fontDevanagari, cs: fontDevanagari, ascii: fontDevanagari, hAnsi: fontDevanagari },
            size: headingSize, // 13pt bold
            color: '8B1E0F',
          }),
        ],
      }),
      // 1 Line Gap
      new Paragraph({ text: '', spacing: { after: 120 } })
    );

    const moolaFormatted = formatSymmetricShlokaLines(sanitizeUnicodeText(rawMoola));
    const moolaLines = moolaFormatted.split('\n');
    for (const mLine of moolaLines) {
      if (!mLine.trim()) continue;
      children.push(
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 30, after: 30 },
          children: [
            new TextRun({
              text: mLine.trim(),
              font: { name: fontDevanagari, cs: fontDevanagari, ascii: fontDevanagari, hAnsi: fontDevanagari },
              size: bodySize, // 12pt
              bold: true,
              color: '1A202C',
            }),
          ],
        })
      );
    }

    // 1 Line Gap
    children.push(new Paragraph({ text: '', spacing: { after: 140 } }));

    // 2. ಕನ್ನಡ ಲಿಪ್ಯಂತರಿತ ಶ್ಲೋಕ - Heading CENTERED, 13pt Bold, Terracotta Amber
    children.push(
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 120, after: 60 },
        children: [
          new TextRun({
            text: '॥ ಕನ್ನಡ ಲಿಪ್ಯಂತರ ॥',
            bold: true,
            italics: false,
            font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
            size: headingSize, // 13pt bold
            color: 'C2410C',
          }),
        ],
      }),
      // 1 Line Gap
      new Paragraph({ text: '', spacing: { after: 120 } })
    );

    const kanFormatted = formatSymmetricShlokaLines(sanitizeUnicodeText(rawKannadaTranslit));
    const kanLines = kanFormatted.split('\n');
    for (const kLine of kanLines) {
      if (!kLine.trim()) continue;
      children.push(
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 25, after: 25 },
          children: [
            new TextRun({
              text: kLine.trim(),
              font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
              size: bodySize, // 12pt
              bold: true,
              italics: false,
              color: '1A202C',
            }),
          ],
        })
      );
    }

    // 1 Line Gap
    children.push(new Paragraph({ text: '', spacing: { after: 140 } }));

    // 3. ಪದಾರ್ಥ (Heading: LEFT ALIGNED, 13pt Bold, Deep Emerald Green, NO Numbering)
    const formattedPadartha = formatPadarthaWithDevanagariPadas(rawPadartha);
    children.push(
      new Paragraph({
        alignment: AlignmentType.LEFT,
        spacing: { before: 140, after: 60 },
        children: [
          new TextRun({
            text: 'ಪದಾರ್ಥ:',
            bold: true,
            italics: false,
            font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
            size: headingSize, // 13pt bold
            color: '0F766E',
          }),
        ],
      }),
      // 1 Line Gap
      new Paragraph({ text: '', spacing: { after: 100 } }),
      new Paragraph({
        alignment: AlignmentType.JUSTIFIED,
        spacing: { before: 20, after: 140 },
        children: createScriptAwareRuns(sanitizeUnicodeText(formattedPadartha), bodySize, {
          color: '1A202C',
        }),
      })
    );

    // 1 Line Gap
    children.push(new Paragraph({ text: '', spacing: { after: 120 } }));

    // 4. ಸರಳ ವಿವರಣೆ (Heading: LEFT ALIGNED, 13pt Bold, Royal Sapphire Blue, NO Numbering)
    const cleanSarala = sanitizeUnicodeText(rawSarala)
      .replace(/^(\d+\.?\s*)?(ಸರಳ\s*ವಿವರಣೆ\s*[:\-])\s*/i, '')
      .trim();
    children.push(
      new Paragraph({
        alignment: AlignmentType.LEFT,
        spacing: { before: 140, after: 60 },
        children: [
          new TextRun({
            text: 'ಸರಳ ವಿವರಣೆ:',
            bold: true,
            italics: false,
            font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
            size: headingSize, // 13pt bold
            color: '1E40AF',
          }),
        ],
      }),
      // 1 Line Gap
      new Paragraph({ text: '', spacing: { after: 100 } }),
      new Paragraph({
        alignment: AlignmentType.JUSTIFIED,
        spacing: { before: 20, after: 140 },
        children: [
          new TextRun({
            text: cleanSarala,
            font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
            size: bodySize, // 12pt
            bold: false,
            italics: false,
            color: '1A202C',
          }),
        ],
      })
    );

    // 1 Line Gap
    children.push(new Paragraph({ text: '', spacing: { after: 120 } }));

    // 5. ವಿವರವಾದ ವ್ಯಾಖ್ಯಾನ (Heading: LEFT ALIGNED, 13pt Bold, Regal Deep Purple, NO Numbering)
    const cleanVyakhyana = sanitizeUnicodeText(rawVyakhyana)
      .replace(/^(\d+\.?\s*)?(ವಿವರವಾದ\s*ವ್ಯಾಖ್ಯಾನ\s*[:\-])\s*/i, '')
      .trim();
    children.push(
      new Paragraph({
        alignment: AlignmentType.LEFT,
        spacing: { before: 140, after: 60 },
        children: [
          new TextRun({
            text: 'ವಿವರವಾದ ವ್ಯಾಖ್ಯಾನ:',
            bold: true,
            italics: false,
            font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
            size: headingSize, // 13pt bold
            color: '6B21A8',
          }),
        ],
      }),
      // 1 Line Gap
      new Paragraph({ text: '', spacing: { after: 100 } }),
      new Paragraph({
        alignment: AlignmentType.JUSTIFIED,
        spacing: { before: 20, after: 180 },
        children: [
          new TextRun({
            text: cleanVyakhyana,
            font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
            size: bodySize, // 12pt
            bold: false,
            italics: false,
            color: '1A202C',
          }),
        ],
      })
    );

    // Optional Table (Horizontally Centered & Perfectly Fitted to A4 Page Area)
    if (unit.output?.tableContent && unit.output.tableContent.headers && unit.output.tableContent.rows && unit.output.tableContent.rows.length > 0) {
      const headers = unit.output.tableContent.headers;
      const numCols = headers.length || 1;
      const a4PrintableWidth = 9020; // 9020 DXA (~6.27 inches, perfectly fits inside 1-inch A4 margins)
      const colWidthDxa = Math.floor(a4PrintableWidth / numCols);

      const tableRows: TableRow[] = [];
      tableRows.push(
        new TableRow({
          tableHeader: true,
          children: headers.map(h => (
            new TableCell({
              width: { size: colWidthDxa, type: WidthType.DXA },
              shading: { fill: '8B1E0F' },
              margins: { top: 120, bottom: 120, left: 140, right: 140 },
              borders: {
                top: { style: BorderStyle.SINGLE, size: 4, color: 'DBC8B0' },
                bottom: { style: BorderStyle.SINGLE, size: 6, color: '6B1408' },
                left: { style: BorderStyle.SINGLE, size: 4, color: 'DBC8B0' },
                right: { style: BorderStyle.SINGLE, size: 4, color: 'DBC8B0' },
              },
              children: [
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  children: createScriptAwareRuns(h, (fontSizePt - 1) * 2, { bold: true, color: 'FFFFFF' }),
                }),
              ],
            })
          )),
        })
      );
      for (const [rIdx, r] of unit.output.tableContent.rows.entries()) {
        tableRows.push(
          new TableRow({
            children: r.map((cell, cIdx) => (
              new TableCell({
                width: { size: colWidthDxa, type: WidthType.DXA },
                shading: rIdx % 2 === 1 ? { fill: 'F9F6F0' } : undefined,
                margins: { top: 100, bottom: 100, left: 140, right: 140 },
                borders: {
                  top: { style: BorderStyle.SINGLE, size: 4, color: 'E2D8C7' },
                  bottom: { style: BorderStyle.SINGLE, size: 4, color: 'E2D8C7' },
                  left: { style: BorderStyle.SINGLE, size: 4, color: 'E2D8C7' },
                  right: { style: BorderStyle.SINGLE, size: 4, color: 'E2D8C7' },
                },
                children: [
                  new Paragraph({
                    alignment: cIdx === 0 ? AlignmentType.CENTER : AlignmentType.LEFT,
                    children: createScriptAwareRuns(cell, (fontSizePt - 1) * 2),
                  }),
                ],
              })
            )),
          })
        );
      }

      children.push(
        new Paragraph({
          children: [
            new TextRun({
              text: unit.output.tableContent.title ? `📊 ಕೋಷ್ಟಕ: ${unit.output.tableContent.title}` : '📊 ವಿವರಣಾತ್ಮಕ ಕೋಷ್ಟಕ:',
              bold: true,
              color: '8B1E0F',
              font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
              size: headingSize,
            }),
          ],
          spacing: { before: 120, after: 60 },
        }),
        new Table({
          alignment: AlignmentType.CENTER,
          width: { size: a4PrintableWidth, type: WidthType.DXA },
          columnWidths: Array(numCols).fill(colWidthDxa),
          rows: tableRows,
        }),
        new Paragraph({ text: '', spacing: { after: 80 } })
      );

      if (unit.output.tableContent.explanation) {
        children.push(
          new Paragraph({
            children: [
              new TextRun({
                text: `ವಿವರಣೆ: ${unit.output.tableContent.explanation}`,
                italics: true,
                color: '4A5568',
                font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
                size: bodySize,
              }),
            ],
            spacing: { before: 40, after: 120 },
          })
        );
      }
    }

    // Optional Diagram / Illustration in Master Docx (Embedded Real Image)
    if (unit.output?.diagramContent && (unit.output.diagramContent.title || unit.output.diagramContent.description || unit.output.diagramContent.svgDiagram)) {
      const diag = unit.output.diagramContent;
      const diagTitle = diag.title || 'ಶಾಸ್ತ್ರೀಯ ಪರಿಕಲ್ಪನಾ ರೇಖಾಚಿತ್ರ';
      let svgMarkup = diag.svgDiagram;
      if (!svgMarkup || svgMarkup.trim().length < 20) {
        svgMarkup = generateScholarlySvgDiagram(
          diagTitle,
          diag.description || unit.output.vivaradaVyakhyana || '',
          null,
          unit.output.tableContent?.headers,
          unit.output.tableContent?.rows
        );
      }

      try {
        const pngBuffer = await renderSvgToPngBuffer(svgMarkup, 1400);
        let imgWidth = 490;
        let imgHeight = 240;
        try {
          const meta = await sharp(pngBuffer).metadata();
          if (meta.width && meta.height) {
            imgHeight = Math.min(Math.max(Math.round(imgWidth * (meta.height / meta.width)), 120), 480);
          }
        } catch {
          // fallback
        }

        children.push(
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { before: 140, after: 60 },
            children: [
              new ImageRun({
                data: pngBuffer,
                transformation: {
                  width: imgWidth,
                  height: imgHeight,
                },
                type: 'png',
              }),
            ],
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { before: 20, after: 60 },
            children: [
              new TextRun({
                text: `ಚಿತ್ರ: ${diag.caption || diagTitle}`,
                italics: true,
                bold: true,
                color: '4A5568',
                font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
                size: (fontSizePt - 1) * 2,
              }),
            ],
          })
        );

        if (diag.description) {
          children.push(
            new Paragraph({
              alignment: AlignmentType.LEFT,
              spacing: { before: 20, after: 120 },
              children: [
                new TextRun({
                  text: `ಶಾಸ್ತ್ರೀಯ ವಿವರಣೆ: ${diag.description}`,
                  color: '2D3748',
                  font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
                  size: bodySize,
                }),
              ],
            })
          );
        }
      } catch (err) {
        console.error(`Failed to embed diagram image for master unit ${unit.id}:`, err);
      }
    }

    // Optional Picture / Iconography in Master Docx (Embedded Real Image)
    if (unit.output?.pictureContent && (unit.output.pictureContent.title || unit.output.pictureContent.description)) {
      const pic = unit.output.pictureContent;
      const picTitle = pic.title || 'ದೇವತಾ ರೂಪ / ಶಾಸ್ತ್ರೀಯ ಚಿತ್ರಣ';
      const svgMarkup = generateScholarlySvgDiagram(
        picTitle,
        pic.description || unit.output.vivaradaVyakhyana || '',
        null,
        unit.output.tableContent?.headers,
        unit.output.tableContent?.rows
      );

      try {
        const pngBuffer = await renderSvgToPngBuffer(svgMarkup, 1400);
        let imgWidth = 490;
        let imgHeight = 240;
        try {
          const meta = await sharp(pngBuffer).metadata();
          if (meta.width && meta.height) {
            imgHeight = Math.min(Math.max(Math.round(imgWidth * (meta.height / meta.width)), 120), 480);
          }
        } catch {
          // fallback
        }

        children.push(
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { before: 140, after: 60 },
            children: [
              new ImageRun({
                data: pngBuffer,
                transformation: {
                  width: imgWidth,
                  height: imgHeight,
                },
                type: 'png',
              }),
            ],
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { before: 20, after: 60 },
            children: [
              new TextRun({
                text: `ಚಿತ್ರ: ${pic.caption || picTitle}`,
                italics: true,
                bold: true,
                color: '8B1E0F',
                font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
                size: (fontSizePt - 1) * 2,
              }),
            ],
          })
        );

        if (pic.description) {
          children.push(
            new Paragraph({
              alignment: AlignmentType.LEFT,
              spacing: { before: 20, after: 120 },
              children: [
                new TextRun({
                  text: `ಧ್ಯಾಹ್ನ ಸ್ವರೂಪ ವಿವರಣೆ: ${pic.description}`,
                  color: '2D3748',
                  font: { name: fontKannada, cs: fontKannada, ascii: fontKannada, hAnsi: fontKannada },
                  size: bodySize,
                }),
              ],
            })
          );
        }
      } catch (err) {
        console.error(`Failed to embed picture image for master unit ${unit.id}:`, err);
      }
    }
  }

  const doc = new Document({
    sections: [
      {
        properties: {
          page: {
            margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 }, // 1 inch
          },
        },
        children,
      },
    ],
  });

  const docxBuffer = await Packer.toBuffer(doc);
  const docxValidation = await validateGeneratedDocxBuffer(docxBuffer);
  if (!docxValidation.valid) {
    throw new Error(`Final DOCX validation failed: ${docxValidation.issues.join(' | ')}`);
  }
  return docxBuffer;
}

/**
 * Generate Pure Shloka Text/Markdown representation
 */
export function generatePureShlokaText(project: GranthaProject, units: SanskritUnit[]): string {
  let output = `================================================================================\n`;
  output += `${project.name || 'ಸಂಸ್ಕೃತ-ಕನ್ನಡ ಶ್ಲೋಕಾರ್ಥ ಗ್ರಂಥ'}\n`;
  output += `================================================================================\n\n`;

  for (const unit of units) {
    if (!unit.output) continue;

    if (isHeadingOrColophonUnit(unit)) {
      const rawKannada = unit.output.kannadaTransliteration || devanagariToKannada(unit.output.moolaShloka || unit.verifiedText || unit.originalText);
      const headingKannada = sanitizeUnicodeText(rawKannada).trim();
      const cleanHeading = headingKannada.replace(/^[॥।।|।\s]+|[॥।।|।\s]+$/g, '').trim();
      const displayTitle = cleanHeading.startsWith('॥') ? cleanHeading : `॥ ${cleanHeading} ॥`;
      output += `--------------------------------------------------------------------------------\n\n`;
      output += `${displayTitle}\n\n`;
      continue;
    }

    output += `--------------------------------------------------------------------------------\n\n`;
    
    // 1. Moola Sanskrit Shloka with 1 line gap
    output += `॥ ಮೂಲ ಸಂಸ್ಕೃತ ಶ್ಲೋಕಃ ॥\n\n`;
    output += `${formatSymmetricShlokaLines(unit.output.moolaShloka)}\n\n`;

    // 2. Kannada Lipyantara with 1 line gap
    output += `॥ ಕನ್ನಡ ಲಿಪ್ಯಂತರ ॥\n\n`;
    output += `${formatSymmetricShlokaLines(unit.output.kannadaTransliteration)}\n\n`;

    const formattedPadartha = formatPadarthaWithDevanagariPadas(unit.output.padartha);
    const cleanSarala = sanitizeUnicodeText(unit.output.saralaVivarane)
      .replace(/^(\d+\.?\s*)?(ಸರಳ\s*ವಿವರಣೆ\s*[:\-])\s*/i, '')
      .trim();
    const cleanVyakhyana = sanitizeUnicodeText(unit.output.vivaradaVyakhyana)
      .replace(/^(\d+\.?\s*)?(ವಿವರವಾದ\s*ವ್ಯಾಖ್ಯಾನ\s*[:\-])\s*/i, '')
      .trim();

    // 3. Padartha with 1 line gap
    output += `ಪದಾರ್ಥ:\n\n${formattedPadartha}\n\n`;

    // 4. Sarala Vivarane with 1 line gap
    output += `ಸರಳ ವಿವರಣೆ:\n\n${cleanSarala}\n\n`;

    // 5. Vivarada Vyakhyana with 1 line gap
    output += `ವಿವರವಾದ ವ್ಯಾಖ್ಯಾನ:\n\n${cleanVyakhyana}\n\n`;

    if (unit.output.tableContent && unit.output.tableContent.headers && unit.output.tableContent.rows && unit.output.tableContent.rows.length > 0) {
      output += `ಕೋಷ್ಟಕ: ${unit.output.tableContent.title || 'ವಿವರಣಾತ್ಮಕ ಕೋಷ್ಟಕ'}\n\n`;
      output += `[ ${unit.output.tableContent.headers.join(' | ')} ]\n`;
      for (const row of unit.output.tableContent.rows) {
        output += `| ${row.join(' | ')} |\n`;
      }
      if (unit.output.tableContent.explanation) {
        output += `\nವಿವರಣೆ: ${unit.output.tableContent.explanation}\n`;
      }
      output += `\n`;
    }

    if (unit.output.diagramContent && (unit.output.diagramContent.title || unit.output.diagramContent.description)) {
      output += `ರೇಖಾಚಿತ್ರ / ಚಿತ್ರ: ${unit.output.diagramContent.title || 'ಪರಿಕಲ್ಪನಾತ್ಮಕ ನಿರೂಪಣೆ'}\n\n`;
      if (unit.output.diagramContent.caption) {
        output += `ಶೀರ್ಷಿಕೆ: ${unit.output.diagramContent.caption}\n`;
      }
      if (unit.output.diagramContent.description) {
        output += `ವಿವರಣೆ: ${unit.output.diagramContent.description}\n`;
      }
      output += `\n`;
    }
  }

  return output;
}

/**
 * Generate Pure Shloka & Explanation Text-Only PDF (Lossless reading edition with 13pt font and 1-line gaps)
 */
export async function generatePureShlokaPdf(
  project: GranthaProject,
  units: SanskritUnit[]
): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({
        margin: 50,
        size: 'A4',
        info: {
          Title: project.name || 'Sanskrit-Kannada Scholarly Grantha',
          Author: 'Universal Sanskrit-Kannada Scholarly Grantha Engine',
        },
      });

      const chunks: Buffer[] = [];
      doc.on('data', chunk => chunks.push(chunk));
      doc.on('end', () => resolve(Buffer.concat(chunks)));
      doc.on('error', err => reject(err));

      // Title
      doc.fontSize(16).fillColor('#8B1E0F').text(project.name || 'ಸಂಸ್ಕೃತ-ಕನ್ನಡ ವಿದ್ವತ್ ಗ್ರಂಥ', { align: 'center' });
      doc.moveDown(0.6);
      doc.fontSize(12).fillColor('#4A4A4A').text('॥ ಕೇವಲ ಶ್ಲೋಕ, ಲಿಪ್ಯಂತರ, ಪದಾರ್ಥ, ಸರಳ ವಿವರಣೆ ಹಾಗೂ ವ್ಯಾಖ್ಯಾನ (Scholarly Text-Only Edition) ॥', { align: 'center' });
      doc.moveDown(1.0);
      doc.strokeColor('#E0D6C8').lineWidth(1).moveTo(50, doc.y).lineTo(545, doc.y).stroke();
      doc.moveDown(1.2);

      for (const unit of units) {
        if (!unit.output) continue;

        if (isHeadingOrColophonUnit(unit)) {
          const rawKannada = unit.output.kannadaTransliteration || devanagariToKannada(unit.output.moolaShloka || unit.verifiedText || unit.originalText);
          const headingKannada = sanitizeUnicodeText(rawKannada).trim();
          const cleanHeading = headingKannada.replace(/^[॥।।|।\s]+|[॥।।|।\s]+$/g, '').trim();
          const displayTitle = cleanHeading.startsWith('॥') ? cleanHeading : `॥ ${cleanHeading} ॥`;
          doc.moveDown(0.8);
          doc.fillColor(unit.unitType === 'COLOPHON' ? '#701A75' : '#1A365D').fontSize(14).text(displayTitle, { align: 'center' });
          doc.moveDown(1.0);
          continue;
        }

        // Verse Header
        const h = unit.structuralHierarchy;
        const locLabel = h.formattedNumber ? `ಶ್ಲೋಕ / ಮಂತ್ರ: ${h.formattedNumber}` : `ಘಟಕ #${unit.unitIndex}`;
        doc.fillColor('#1A365D').fontSize(13).text(`【 ${locLabel} 】`, { align: 'left' });
        doc.moveDown(0.8);

        // 1. Moola Shloka (Devanagari Sanskrit) - 13pt Bold
        doc.fillColor('#8B1E0F').fontSize(13).text('॥ ಮೂಲ ಸಂಸ್ಕೃತ ಶ್ಲೋಕಃ ॥', { align: 'center' });
        doc.moveDown(0.6); // 1 line gap
        doc.fillColor('#1F1916').fontSize(13).text(formatSymmetricShlokaLines(unit.output.moolaShloka), { align: 'center' });
        doc.moveDown(0.8); // 1 line gap

        // 2. Kannada Transliteration - 13pt Bold
        doc.fillColor('#C2410C').fontSize(13).text('॥ ಕನ್ನಡ ಲಿಪ್ಯಂತರ ॥', { align: 'center' });
        doc.moveDown(0.6); // 1 line gap
        doc.fillColor('#1F1916').fontSize(13).text(formatSymmetricShlokaLines(unit.output.kannadaTransliteration), { align: 'center' });
        doc.moveDown(0.8); // 1 line gap

        // 3. Padartha - 13pt
        doc.fillColor('#0F766E').fontSize(13).text('ಪದಾರ್ಥ:', { underline: false });
        doc.moveDown(0.6); // 1 line gap
        const formattedPadartha = formatPadarthaWithDevanagariPadas(unit.output.padartha);
        doc.fillColor('#1F1916').fontSize(13).text(formattedPadartha, { align: 'justify' });
        doc.moveDown(0.8); // 1 line gap

        // 4. Sarala Vivarane - 13pt
        doc.fillColor('#1E40AF').fontSize(13).text('ಸರಳ ವಿವರಣೆ:', { underline: false });
        doc.moveDown(0.6); // 1 line gap
        const cleanSarala = sanitizeUnicodeText(unit.output.saralaVivarane)
          .replace(/^(\d+\.?\s*)?(ಸರಳ\s*ವಿವರಣೆ\s*[:\-])\s*/i, '')
          .trim();
        doc.fillColor('#1F1916').fontSize(13).text(cleanSarala, { align: 'justify' });
        doc.moveDown(0.8); // 1 line gap

        // 5. Vivarada Vyakhyana - 13pt
        doc.fillColor('#6B21A8').fontSize(13).text('ವಿವರವಾದ ವ್ಯಾಖ್ಯಾನ:', { underline: false });
        doc.moveDown(0.6); // 1 line gap
        const cleanVyakhyana = sanitizeUnicodeText(unit.output.vivaradaVyakhyana)
          .replace(/^(\d+\.?\s*)?(ವಿವರವಾದ\s*ವ್ಯಾಖ್ಯಾನ\s*[:\-])\s*/i, '')
          .trim();
        doc.fillColor('#1F1916').fontSize(13).text(cleanVyakhyana, { align: 'justify' });
        doc.moveDown(1.2); // 1 line gap between units

        // Visual Contextual Explanation
        if (unit.output.tableContent && unit.output.tableContent.title) {
          doc.fillColor('#2D3748').fontSize(11).text(`[ಶಾಸ್ತ್ರೀಯ ವರ್ಗೀಕರಣ ವಿಷಯ: ${unit.output.tableContent.title} - ${unit.output.tableContent.explanation || ''}]`);
          doc.moveDown(0.6);
        }
        if (unit.output.diagramContent && unit.output.diagramContent.description) {
          doc.fillColor('#2D3748').fontSize(11).text(`[ಪರಿಕಲ್ಪನಾತ್ಮಕ ರೇಖಾಚಿತ್ರ ವಿವರಣೆ: ${unit.output.diagramContent.description}]`);
          doc.moveDown(0.6);
        }

        // Divider
        doc.strokeColor('#EADECF').lineWidth(0.5).moveTo(50, doc.y).lineTo(545, doc.y).stroke();
        doc.moveDown(1.2);
      }

      doc.end();
    } catch (e) {
      reject(e);
    }
  });
}


/**
 * Generate Complete Multi-Tab Audit XLSX Workbook
 */
export async function generateCompleteAuditXlsx(
  project: GranthaProject,
  documents: GranthaDocument[],
  units: SanskritUnit[]
): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'Universal Sanskrit Grantha Engine';
  workbook.created = new Date();

  // Tab 1: Master Index
  const wsIndex = workbook.addWorksheet('Master Index');
  wsIndex.columns = [
    { header: 'Unit ID', key: 'id', width: 22 },
    { header: 'File Name', key: 'fileName', width: 25 },
    { header: 'Page', key: 'page', width: 8 },
    { header: 'Work', key: 'work', width: 22 },
    { header: 'Verse Number', key: 'verseNum', width: 16 },
    { header: 'First Word', key: 'firstWord', width: 18 },
    { header: 'Status', key: 'status', width: 16 },
    { header: 'Confidence', key: 'confidence', width: 14 },
    { header: 'Validation Score', key: 'score', width: 16 },
  ];
  units.forEach(u => {
    wsIndex.addRow({
      id: u.id,
      fileName: u.fileName,
      page: u.pageNumber,
      work: u.detectedWork,
      verseNum: u.structuralHierarchy.formattedNumber,
      firstWord: u.firstMeaningfulWord,
      status: u.status,
      confidence: u.confidence,
      score: u.validationScore,
    });
  });

  // Tab 2: Change Log
  const wsChanges = workbook.addWorksheet('Change Log');
  wsChanges.columns = [
    { header: 'Timestamp', key: 'timestamp', width: 20 },
    { header: 'Unit ID', key: 'id', width: 20 },
    { header: 'Work', key: 'work', width: 20 },
    { header: 'Verse Number', key: 'verseNum', width: 14 },
    { header: 'Category', key: 'category', width: 25 },
    { header: 'Original Text', key: 'original', width: 35 },
    { header: 'Corrected Text', key: 'corrected', width: 35 },
    { header: 'Reason', key: 'reason', width: 35 },
    { header: 'Source / Reference', key: 'source', width: 30 },
    { header: 'Confidence', key: 'confidence', width: 12 },
    { header: 'Method', key: 'method', width: 16 },
  ];
  units.forEach(u => {
    if (u.changeLog && u.changeLog.length > 0) {
      u.changeLog.forEach(c => {
        wsChanges.addRow({
          timestamp: c.timestamp,
          id: u.id,
          work: u.detectedWork,
          verseNum: u.structuralHierarchy.formattedNumber,
          category: c.category,
          original: c.originalText,
          corrected: c.correctedText,
          reason: c.reason,
          source: c.source,
          confidence: c.confidence,
          method: c.method,
        });
      });
    }
  });

  // Tab 3: Review Required
  const wsReview = workbook.addWorksheet('Review Required');
  wsReview.columns = [
    { header: 'Unit ID', key: 'id', width: 20 },
    { header: 'File Name', key: 'fileName', width: 22 },
    { header: 'Page', key: 'page', width: 8 },
    { header: 'Work', key: 'work', width: 20 },
    { header: 'Verse Number', key: 'verseNum', width: 14 },
    { header: 'Original Text', key: 'original', width: 35 },
    { header: 'Verified Candidate', key: 'verified', width: 35 },
    { header: 'Confidence', key: 'confidence', width: 14 },
    { header: 'Issues Flagged', key: 'issues', width: 35 },
  ];
  units.filter(u => u.status === 'REVIEW_REQUIRED' || u.confidence === 'LOW').forEach(u => {
    wsReview.addRow({
      id: u.id,
      fileName: u.fileName,
      page: u.pageNumber,
      work: u.detectedWork,
      verseNum: u.structuralHierarchy.formattedNumber,
      original: u.originalText,
      verified: u.verifiedText,
      confidence: u.confidence,
      issues: (u.validationIssues || []).join('; '),
    });
  });

  // Tab 4: Processing Statistics
  const wsStats = workbook.addWorksheet('Processing Statistics');
  wsStats.columns = [
    { header: 'Metric', key: 'metric', width: 30 },
    { header: 'Value', key: 'value', width: 30 },
  ];
  wsStats.addRow({ metric: 'Project Name', value: project.name });
  wsStats.addRow({ metric: 'Total Input Files', value: documents.length });
  wsStats.addRow({ metric: 'Total Pages Processed', value: project.totalPages });
  wsStats.addRow({ metric: 'Total Text Units / Verses', value: units.length });
  wsStats.addRow({ metric: 'Completed Units', value: units.filter(u => u.status === 'COMPLETED').length });
  wsStats.addRow({ metric: 'High Confidence Units', value: units.filter(u => u.confidence === 'HIGH').length });
  wsStats.addRow({ metric: 'Review Required Units', value: units.filter(u => u.status === 'REVIEW_REQUIRED').length });
  wsStats.addRow({ metric: 'Failed Units', value: units.filter(u => u.status === 'FAILED').length });

  // Tab 5: Validation Results
  const wsVal = workbook.addWorksheet('Validation Results');
  wsVal.columns = [
    { header: 'Unit ID', key: 'id', width: 20 },
    { header: 'Verse Number', key: 'verseNum', width: 14 },
    { header: 'Validation Score', key: 'score', width: 16 },
    { header: 'Status', key: 'status', width: 14 },
    { header: 'Detected Issues', key: 'issues', width: 45 },
  ];
  units.forEach(u => {
    wsVal.addRow({
      id: u.id,
      verseNum: u.structuralHierarchy.formattedNumber,
      score: u.validationScore,
      status: u.status,
      issues: (u.validationIssues || []).join(' | '),
    });
  });

  // Tab 6: Source Verification
  const wsSrc = workbook.addWorksheet('Source Verification');
  wsSrc.columns = [
    { header: 'Unit ID', key: 'id', width: 20 },
    { header: 'Work', key: 'work', width: 20 },
    { header: 'Verse Number', key: 'verseNum', width: 14 },
    { header: 'Matched Reference', key: 'refSource', width: 35 },
    { header: 'Confidence Score', key: 'score', width: 16 },
    { header: 'Diff Found', key: 'diff', width: 12 },
    { header: 'Verification Notes', key: 'notes', width: 40 },
  ];
  units.forEach(u => {
    wsSrc.addRow({
      id: u.id,
      work: u.detectedWork,
      verseNum: u.structuralHierarchy.formattedNumber,
      refSource: u.sourceVerification?.referenceSource || 'Primary Manuscript',
      score: u.sourceVerification?.confidenceScore || 0,
      diff: u.sourceVerification?.diffFound ? 'YES' : 'NO',
      notes: u.sourceVerification?.notes || '',
    });
  });

  // Format all sheets (frozen headers & nice borders)
  workbook.worksheets.forEach(ws => {
    ws.views = [{ state: 'frozen', ySplit: 1 }];
    const headerRow = ws.getRow(1);
    headerRow.font = { bold: true, color: { argb: 'FFFFFFFF' } };
    headerRow.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FF8B1E0F' },
    };
  });

  const arrayBuffer = await workbook.xlsx.writeBuffer();
  return Buffer.from(arrayBuffer);
}

/**
 * Generate Shloka Index XLSX
 */
export async function generateShlokaIndexXlsx(units: SanskritUnit[]): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  const ws = workbook.addWorksheet('Shloka Index');
  ws.columns = [
    { header: 'First Word (Devanagari)', key: 'firstWord', width: 25 },
    { header: 'Work Name', key: 'work', width: 25 },
    { header: 'Structural Number', key: 'verseNum', width: 18 },
    { header: 'Source File', key: 'fileName', width: 25 },
    { header: 'Page Number', key: 'page', width: 12 },
    { header: 'Moola Shloka Beginning', key: 'moolaPreview', width: 45 },
  ];

  const sorted = [...units].sort((a, b) => a.firstMeaningfulWord.localeCompare(b.firstMeaningfulWord, 'sa'));
  sorted.forEach(u => {
    ws.addRow({
      firstWord: u.firstMeaningfulWord,
      work: u.detectedWork,
      verseNum: u.structuralHierarchy.formattedNumber,
      fileName: u.fileName,
      page: u.pageNumber,
      moolaPreview: (u.output?.moolaShloka || u.originalText).slice(0, 80),
    });
  });

  ws.views = [{ state: 'frozen', ySplit: 1 }];
  const headerRow = ws.getRow(1);
  headerRow.font = { bold: true, color: { argb: 'FFFFFFFF' } };
  headerRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1A365D' } };

  const arrayBuffer = await workbook.xlsx.writeBuffer();
  return Buffer.from(arrayBuffer);
}

/**
 * Bundle final deliverables into FINAL_PACKAGE.zip
 */
export async function generateFinalPackageZip(
  project: GranthaProject,
  documents: GranthaDocument[],
  units: SanskritUnit[]
): Promise<Buffer> {
  const zip = new JSZip();

  // 0. Pure Shloka & Explanation DOCX & TXT (Focused Edition requested by user)
  const pureDocxBuffer = await generatePureShlokaDocx(project, units);
  zip.file('00_PURE_SHLOKA_EXPLANATION.docx', pureDocxBuffer);

  const pureTxt = generatePureShlokaText(project, units);
  zip.file('00_PURE_SHLOKA_EXPLANATION.txt', pureTxt);

  // 1. Final Manuscript DOCX
  const docxBuffer = await generateMasterDocx(project, units);
  zip.file('01_FINAL_SCHOLARLY_MANUSCRIPT.docx', docxBuffer);

  // 2. Complete Audit XLSX
  const auditXlsxBuffer = await generateCompleteAuditXlsx(project, documents, units);
  zip.file('02_COMPLETE_AUDIT.xlsx', auditXlsxBuffer);

  // 3. Shloka Index XLSX
  const indexXlsxBuffer = await generateShlokaIndexXlsx(units);
  zip.file('03_SHLOKA_INDEX.xlsx', indexXlsxBuffer);

  // 4. Processing Report TXT
  const completedCount = units.filter(u => u.status === 'COMPLETED').length;
  const reviewCount = units.filter(u => u.status === 'REVIEW_REQUIRED').length;
  const failedCount = units.filter(u => u.status === 'FAILED').length;

  const reportTxt = `================================================================================
UNIVERSAL SANSKRIT -> KANNADA SCHOLARLY GRANTHA ENGINE
PROCESSING & PRODUCTION REPORT
================================================================================
Project Name: ${project.name}
Project ID: ${project.id}
Created At: ${project.createdAt}
Generated At: ${new Date().toISOString()}

TOTAL METRICS:
- Total Input Files: ${documents.length}
- Total Pages: ${project.totalPages}
- Total Units / Verses: ${units.length}
- Successfully Completed: ${completedCount}
- Review Required: ${reviewCount}
- Failed: ${failedCount}

MANDATORY EDITORIAL SECTIONS IN MANUSCRIPT:
1. ಮೂಲ ಶ್ಲೋಕ (Verified Sanskrit in Devanagari script, English digits)
2. ಕನ್ನಡ ಲಿಪ್ಯಂತರ (Accurate phonetic Kannada script transliteration)
3. 1. ಪದಾರ್ಥ (Continuous single paragraph format)
4. 2. ಸರಳ ವಿವರಣೆ (Lucid literary Kannada explanation)
5. 3. ವಿವರವಾದ ವ್ಯಾಖ್ಯಾನ (In-depth scholarly Kannada commentary)

STANDARDS ADHERENCE:
[x] Zero Padaccheda sections (strictly banned)
[x] English digits only (0-9)
[x] Zero unwanted Indian script leakage
[x] Native PDF text prioritization
[x] Traceable SQLite checkpoint database
[x] SanskritDocuments.org canonical verification
================================================================================
`;
  zip.file('04_PROCESSING_REPORT.txt', reportTxt);

  // 5. Source Manifest TXT
  let manifestTxt = `================================================================================
SOURCE MANIFEST & TRACEABILITY LOG
================================================================================\n`;
  documents.forEach((doc, idx) => {
    manifestTxt += `${String(idx + 1).padStart(2, '0')} | ${doc.fileName} (${doc.pageCount} pages, ${doc.detectedType}, Detected Work: ${doc.detectedWork || 'N/A'})\n`;
  });
  zip.file('05_SOURCE_MANIFEST.txt', manifestTxt);

  return await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
}

/**
 * Generate Desktop Offline Runner Bundle ZIP
 * Allows running the entire Sanskrit Grantha Engine offline on Windows / Mac / Linux laptops
 */
export async function generateDesktopOfflineBundle(): Promise<Buffer> {
  const zip = new JSZip();

  // 1. Windows Launcher BAT
  const batScript = `@echo off
title Universal Sanskrit -> Kannada Scholarly Grantha Engine (Laptop Offline Edition)
color 0F
echo ==============================================================================
echo       UNIVERSAL SANSKRIT -^> KANNADA SCHOLARLY GRANTHA ENGINE
echo                  Laptop / Desktop Standalone Runner
echo ==============================================================================
echo.
echo 1. Verifying Node.js environment...
where node >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Node.js is not installed or not in PATH!
    echo Please download and install Node.js (LTS version) from https://nodejs.org
    echo After installing Node.js, double-click this file again.
    pause
    exit /b 1
)

echo [OK] Node.js detected.
echo.
echo 2. Checking dependencies...
if not exist "node_modules" (
    echo Installing local dependencies (one-time setup)...
    call npm install
)

echo.
echo 3. Starting Grantha Engine Local Server on http://localhost:3000 ...
echo Database: grantha_data\\grantha_engine.sqlite
echo.

start http://localhost:3000
npm run dev

pause
`;
  zip.file('Run_Grantha_Engine_Windows.bat', batScript);

  // 2. Mac/Linux Launcher SH
  const shScript = `#!/usr/bin/env bash
echo "=============================================================================="
echo "      UNIVERSAL SANSKRIT -> KANNADA SCHOLARLY GRANTHA ENGINE"
echo "                 Laptop / Desktop Standalone Runner"
echo "=============================================================================="
echo ""
if ! command -v node &> /dev/null; then
    echo "[ERROR] Node.js is not installed!"
    echo "Please install Node.js from https://nodejs.org"
    exit 1
fi

if [ ! -d "node_modules" ]; then
    echo "Installing local dependencies..."
    npm install
fi

echo "Starting Grantha Engine on http://localhost:3000 ..."
if which xdg-open > /dev/null; then
  xdg-open http://localhost:3000 &
elif which open > /dev/null; then
  open http://localhost:3000 &
fi

npm run dev
`;
  zip.file('Run_Grantha_Engine_Mac_Linux.sh', shScript);

  // 3. Quick Start Readme HTML (Beautiful styled guide)
  const readmeHtml = `<!DOCTYPE html>
<html lang="kn">
<head>
  <meta charset="UTF-8">
  <title>Grantha Engine - Desktop / Laptop Quick Start Guide</title>
  <style>
    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #FAF7F2; color: #1F1916; margin: 0; padding: 40px 20px; line-height: 1.6; }
    .container { max-width: 800px; margin: 0 auto; background: white; border: 1px solid #E8DFC9; border-radius: 16px; padding: 36px; box-shadow: 0 4px 20px rgba(0,0,0,0.06); }
    h1 { color: #8B1E0F; margin-top: 0; font-size: 24px; border-bottom: 2px solid #F0E8DD; padding-bottom: 12px; }
    h2 { color: #2D231E; font-size: 18px; margin-top: 24px; }
    .step { background: #FAF8F5; border-left: 4px solid #8B1E0F; padding: 14px 18px; margin: 12px 0; border-radius: 0 8px 8px 0; }
    code { background: #EFE9E0; padding: 2px 6px; border-radius: 4px; font-family: monospace; font-size: 13px; }
    .badge { display: inline-block; padding: 4px 10px; background: #8B1E0F; color: white; border-radius: 20px; font-size: 12px; font-weight: bold; }
    ul { padding-left: 20px; }
  </style>
</head>
<body>
  <div class="container">
    <span class="badge">Offline Desktop Edition</span>
    <h1>ಸಂಸ್ಕೃತ-ಕನ್ನಡ ವಿದ್ವತ್ ಗ್ರಂಥ ಎಂಜಿನ್ (Sanskrit Grantha Engine Desktop)</h1>
    <p>ನಿಮ್ಮ ಲ್ಯಾಪ್ಟಾಪ್ ಅಥವಾ ಕಂಪ್ಯೂಟರ್‌ನಲ್ಲಿ ಸಂಪೂರ್ಣ ಆಫ್‌ಲೈನ್‌ನಲ್ಲಿ ಚಲಾಯಿಸಲು ಈ ಕೆಳಗಿನ ಸರಳ ಹಂತಗಳನ್ನು ಅನುಸರಿಸಿ:</p>
    
    <h2>🚀 ಚಾಲನೆ ಮಾಡುವ ಸುಲಭ ವಿಧಾನ (How to Run in 2 Steps):</h2>
    <div class="step">
      <strong>ಹಂತ ೧ (Step 1): Node.js ಸ್ಥಾಪನೆ (ಒಮ್ಮೆ ಮಾತ್ರ)</strong><br>
      ನಿಮ್ಮ ಲ್ಯಾಪ್ಟಾಪ್‌ನಲ್ಲಿ Node.js ಇಲ್ಲದಿದ್ದರೆ, <a href="https://nodejs.org" target="_blank">https://nodejs.org</a> ನಿಂದ ಉಚಿತವಾಗಿ ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ ಇನ್‌ಸ್ಟಾಲ್ ಮಾಡಿ.
    </div>

    <div class="step">
      <strong>ಹಂತ ೨ (Step 2): ನೇರ ಚಾಲನೆ (Double Click Launcher)</strong><br>
      • <strong>Windows ಬಳಕೆದಾರರು:</strong> <code>Run_Grantha_Engine_Windows.bat</code> ಮೇಲೆ ಡಬಲ್ ಕ್ಲಿಕ್ ಮಾಡಿ.<br>
      • <strong>Mac / Linux ಬಳಕೆದಾರರು:</strong> <code>Run_Grantha_Engine_Mac_Linux.sh</code> ಚಲಾಯಿಸಿ.
    </div>

    <h2>✨ ಪ್ರಮುಖ ವೈಶಿಷ್ಟ್ಯಗಳು (Key Desktop Features):</h2>
    <ul>
      <li><strong>೧೦೦% ಆಫ್‌ಲೈನ್ ಹಾಗೂ ಸುರಕ್ಷಿತ:</strong> ಎಲ್ಲಾ ಸಂಸ್ಕೃತ PDF ಕಡತಗಳು ಹಾಗೂ SQLite ಡೇಟಾಬೇಸ್ ಸ್ಥಳೀಯ <code>grantha_data/</code> ಫೋಲ್ಡರ್‌ನಲ್ಲಿ ಉಳಿಯುತ್ತವೆ.</li>
      <li><strong>ಪುನರಾರಂಭ (Resume Checkpoints):</strong> ಅರ್ಧಕ್ಕೆ ನಿಲ್ಲಿಸಿದರೂ ಸಹ ಮುಂದಿನ ಬಾರಿ ಅದೇ ಶ್ಲೋಕದಿಂದ ಮುಂದುವರಿಯುತ್ತದೆ.</li>
      <li><strong>ಉತ್ತಮ ಗುಣಮಟ್ಟದ DOCX & XLSX ರಫ್ತು:</strong> ಪೂರ್ಣ ವಿದ್ವತ್ ಗ್ರಂಥ, ಶ್ಲೋಕ ಸೂಚಿ ಹಾಗೂ ಆಡಿಟ್ ವರದಿಗಳನ್ನು ಸಿದ್ಧಪಡಿಸುತ್ತದೆ.</li>
    </ul>
  </div>
</body>
</html>`;
  zip.file('START_DESKTOP_GUIDE.html', readmeHtml);

  // 4. Readme Markdown
  const readmeMd = `# Universal Sanskrit → Kannada Scholarly Grantha Engine
## Laptop / Desktop Offline Portable Edition

### Quick Start:
1. Ensure **Node.js** (v18+ or v20+) is installed from [https://nodejs.org](https://nodejs.org).
2. For Windows: Double-click \`Run_Grantha_Engine_Windows.bat\`.
3. For Mac / Linux: Run \`bash Run_Grantha_Engine_Mac_Linux.sh\`.
4. The system opens your browser automatically at \`http://localhost:3000\`.

### Local Persistence & Storage:
- All projects, extracted verses, and checkpoints are stored in local SQLite format inside \`grantha_data/grantha_engine.sqlite\`.
- All generated Word (.docx) and Excel (.xlsx) books are processed locally with 0 data loss.
`;
  zip.file('README_DESKTOP_OFFLINE.md', readmeMd);

  return await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
}

