import {
  getProjectById,
  updateProject,
  getUnitsByProjectId,
  saveUnit,
  getSettings,
  getStructureState,
  saveStructureState,
  saveStructureAudit,
} from './db';
import { verifySanskritUnit } from './sourceVerifier';
import {
  generateScholarlyUnitContent,
  generateScholarlyUnitContentStream,
  extractRetryDelaySeconds,
  formatGeminiErrorMessage,
  completeMissingScholarlySections,
} from './gemini';
import {
  devanagariToKannada,
  formatPadarthaWithDevanagariPadas,
  cleanRepetitiveLoops,
  cleanConciseTitle,
  standardizeShlokaNumbering,
  ensurePureKannadaTransliteration,
  ensurePureKannadaScript,
  normalizeSanskritVerse,
  verifyPadarthaCompleteness,
} from './transliteration';
import { validateSanskritUnitOutput } from './validator';
import { SanskritUnit } from '../src/types';
import { keyManager } from './keyManager';
import {
  generateCompletePadartha,
  extractExpectedSanskritWords,
  detectPadarthaCoverageAndMissing,
} from './padarthaEngine';
import { isHeadingOrColophonUnit, classifyTextBlock } from './structureDetector';
import { analyzeStructureBatch, StructureState } from './structureAi';

export interface ProjectLogEntry {
  id: string;
  timestamp: string;
  level: 'info' | 'success' | 'warn' | 'error';
  message: string;
  verseNumber?: string;
  stage?: string;
}

export interface ProjectLiveState {
  currentUnitId?: string;
  currentVerse?: string;
  currentStage?: string;
  accumulatedText: string;
  latestChunk: string;
  charCount: number;
  updatedAt: number;
  originalText?: string;
}

const projectLogsMap = new Map<string, ProjectLogEntry[]>();
const projectLiveStateMap = new Map<string, ProjectLiveState>();

type StreamSubscriber = (event: { type: string; data: any }) => void;
const projectSubscribers = new Map<string, Set<StreamSubscriber>>();

export function subscribeProjectStream(projectId: string, subscriber: StreamSubscriber): () => void {
  if (!projectSubscribers.has(projectId)) {
    projectSubscribers.set(projectId, new Set());
  }
  const set = projectSubscribers.get(projectId)!;
  set.add(subscriber);
  return () => {
    set.delete(subscriber);
  };
}

export function broadcastProjectStream(projectId: string, event: { type: string; data: any }): void {
  const set = projectSubscribers.get(projectId);
  if (set) {
    for (const sub of set) {
      try {
        sub(event);
      } catch (err) {
        console.error('Error broadcasting stream event:', err);
      }
    }
  }
}

export function getProjectLiveState(projectId: string): ProjectLiveState | null {
  return projectLiveStateMap.get(projectId) || null;
}

export function setProjectLiveState(projectId: string, state: Partial<ProjectLiveState>): void {
  const current = projectLiveStateMap.get(projectId) || {
    accumulatedText: '',
    latestChunk: '',
    charCount: 0,
    updatedAt: Date.now(),
  };
  const updated = {
    ...current,
    ...state,
    updatedAt: Date.now(),
  };
  projectLiveStateMap.set(projectId, updated);
}

export function addProjectLog(
  projectId: string,
  log: { level: 'info' | 'success' | 'warn' | 'error'; message: string; verseNumber?: string; stage?: string }
): ProjectLogEntry {
  if (!projectLogsMap.has(projectId)) {
    projectLogsMap.set(projectId, []);
  }
  const logs = projectLogsMap.get(projectId)!;
  const now = new Date();
  const timeStr = now.toLocaleTimeString('kn-IN', { hour12: false });
  const entry: ProjectLogEntry = {
    id: 'log_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
    timestamp: timeStr,
    ...log,
  };
  logs.push(entry);
  if (logs.length > 250) {
    logs.shift();
  }
  return entry;
}

export function getProjectLogs(projectId: string): ProjectLogEntry[] {
  return projectLogsMap.get(projectId) || [];
}

export function clearProjectLogs(projectId: string): void {
  projectLogsMap.delete(projectId);
}

interface JobStatus {
  projectId: string;
  isRunning: boolean;
  isPaused: boolean;
  total: number;
  completed: number;
  failed: number;
  reviewRequired: number;
  currentUnitId?: string;
  currentVerse?: string;
  message: string;
  currentStage?: string;
}

interface ActiveJobRunner {
  runnerId: string;
  projectId: string;
  isCancelled: boolean;
  isPaused: boolean;
  unpauseResolver?: () => void;
}

const activeRunners = new Map<string, ActiveJobRunner>();

export async function startOrResumeProjectProcessing(
  projectId: string,
  onProgress?: (status: JobStatus) => void,
  forceReprocess: boolean = false
): Promise<void> {
  const project = await getProjectById(projectId);
  if (!project) throw new Error('Project not found');

  const existingRunner = activeRunners.get(projectId);
  if (existingRunner && !existingRunner.isCancelled && !forceReprocess) {
    if (existingRunner.isPaused) {
      console.log(`[JobRunner] Unpausing existing runner for project ${projectId}...`);
      existingRunner.isPaused = false;
      if (existingRunner.unpauseResolver) {
        existingRunner.unpauseResolver();
      }
      await updateProject({ id: projectId, status: 'PROCESSING' });
      addProjectLog(projectId, {
        level: 'info',
        message: `ವಿದ್ವತ್ ಪ್ರಕಾಶನ ಸಂಸ್ಕರಣೆ ಪುನರಾರಂಭಗೊಂಡಿದೆ (Project processing resumed).`,
        stage: 'RESUME',
      });
      broadcastProjectStream(projectId, { type: 'resumed', data: { projectId } });
      return;
    } else {
      console.log(`[JobRunner] Runner for project ${projectId} is already actively running.`);
      return;
    }
  }

  // If existing runner is cancelled or force reprocess, clean it up
  if (existingRunner) {
    existingRunner.isCancelled = true;
    if (existingRunner.unpauseResolver) {
      existingRunner.unpauseResolver();
    }
    activeRunners.delete(projectId);
  }

  // Create new active runner
  const runnerId = 'run_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
  const runner: ActiveJobRunner = {
    runnerId,
    projectId,
    isCancelled: false,
    isPaused: false,
  };
  activeRunners.set(projectId, runner);

  await updateProject({ id: projectId, status: 'PROCESSING' });

  addProjectLog(projectId, {
    level: 'info',
    message: forceReprocess
      ? `ಸಂಪೂರ್ಣ ಗ್ರಂಥ ಮರುಸಂಸ್ಕರಣೆ ಆರಂಭಗೊಂಡಿದೆ (Full project reprocessing started)...`
      : `ವಿದ್ವತ್ ಪ್ರಕಾಶನ ಸಂಸ್ಕರಣೆ ಆರಂಭಗೊಂಡಿದೆ (Project processing started)...`,
    stage: 'START',
  });

  let units = await getUnitsByProjectId(projectId);

  if (forceReprocess) {
    // Explicit Full Reprocess requested by user: reset all units to PENDING
    for (const u of units) {
      u.status = 'PENDING';
      u.errorMessage = undefined;
      await saveUnit(u);
    }
  } else {
    // Resume / Continue: PRESERVE all COMPLETED units!
    // Only reset in-flight, interrupted, or failed units back to PENDING
    for (const u of units) {
      if (
        u.status === 'VERIFYING' ||
        u.status === 'GENERATING' ||
        u.status === 'VALIDATING' ||
        u.status === 'EXTRACTING' ||
        u.status === 'FAILED'
      ) {
        u.status = 'PENDING';
        u.errorMessage = undefined;
        await saveUnit(u);
      }
    }
  }

  // Refresh units after sanitization
  units = await getUnitsByProjectId(projectId);
  let pendingUnits = units.filter(u => u.status === 'PENDING');
  const settings = await getSettings();

  // Existing projects may predate AI structure metadata. Reconcile only units
  // that do not yet have a canonical AI structure record.
  let structurePendingUnits = units.filter(u => !u.structuralHierarchy.aiStructure);
  if (forceReprocess) structurePendingUnits = [...units];

  // If no pending units, check if user has units with REVIEW_REQUIRED or if all are complete
  if (pendingUnits.length === 0 && structurePendingUnits.length === 0) {
    const completedCount = units.filter(u => u.status === 'COMPLETED').length;
    const reviewReqCount = units.filter(u => u.status === 'REVIEW_REQUIRED').length;
    const failedCount = units.filter(u => u.status === 'FAILED').length;
    await updateProject({
      id: projectId,
      status: 'COMPLETED',
      completedUnits: completedCount,
      reviewRequiredUnits: reviewReqCount,
      failedUnits: failedCount,
    });
    addProjectLog(projectId, {
      level: 'success',
      message: `ಎಲ್ಲಾ ${units.length} ಶ್ಲೋಕಗಳ ಸಂಸ್ಕರಣೆ ಈಗಾಗಲೇ ಪೂರ್ಣಗೊಂಡಿದೆ (${completedCount} ಯಶಸ್ವಿ, ${reviewReqCount} ಪರಿಶೀಲನೆ ಅಗತ್ಯ).`,
      stage: 'COMPLETE',
    });
    activeRunners.delete(projectId);
    broadcastProjectStream(projectId, { type: 'complete', data: { projectId } });
    if (onProgress) {
      onProgress({
        projectId,
        isRunning: false,
        isPaused: false,
        total: units.length,
        completed: completedCount,
        failed: failedCount,
        reviewRequired: reviewReqCount,
        message: 'All units processed.',
      });
    }
    return;
  }

  addProjectLog(projectId, {
    level: 'info',
    message: `ಒಟ್ಟು ${units.length} ಶ್ಲೋಕಗಳು, ಬಾಕಿ ಸಂಸ್ಕರಣೆ: ${pendingUnits.length} ಶ್ಲೋಕಗಳು.`,
    stage: 'INIT',
  });

  const notify = (msg: string, currentUnit?: SanskritUnit, currentStage?: string) => {
    const completed = units.filter(u => u.status === 'COMPLETED').length;
    const failed = units.filter(u => u.status === 'FAILED').length;
    const reviewReq = units.filter(u => u.status === 'REVIEW_REQUIRED').length;

    updateProject({
      id: projectId,
      completedUnits: completed,
      failedUnits: failed,
      reviewRequiredUnits: reviewReq,
      currentDocName: currentUnit?.fileName,
      currentPage: currentUnit?.pageNumber,
      currentUnitNumber: currentUnit?.structuralHierarchy.formattedNumber,
    });

    if (onProgress) {
      onProgress({
        projectId,
        isRunning: true,
        isPaused: activeRunners.get(projectId)?.isPaused || false,
        total: units.length,
        completed,
        failed,
        reviewRequired: reviewReq,
        currentUnitId: currentUnit?.id,
        currentVerse: currentUnit?.structuralHierarchy.formattedNumber,
        message: msg,
        currentStage,
      });
    }
  };

  try {
    // ============================================================
    // AI CONTEXT-AWARE STRUCTURE PASS
    // Offline extraction remains a candidate generator only. The
    // semantic structure pass runs in batches before scholarly
    // generation, persists the reconciled hierarchy, and supplies
    // that hierarchy/context to the generation prompt.
    // ============================================================
    const persistedStructureState = await getStructureState(projectId);
    let structureState: StructureState = persistedStructureState ? {
      documentType: persistedStructureState.documentType || project.detectedGenre || 'SANSKRIT_BOOK',
      structurePath: persistedStructureState.structurePath || [],
      currentHeadings: persistedStructureState.currentHeadings || [],
      lastUnitId: persistedStructureState.lastUnitId,
      lastPage: persistedStructureState.lastPage,
    } : {
      documentType: project.detectedGenre || 'SANSKRIT_BOOK',
      structurePath: [],
      currentHeadings: [],
    };

    if (forceReprocess) {
      structureState = {
        documentType: project.detectedGenre || 'SANSKRIT_BOOK',
        structurePath: [],
        currentHeadings: [],
      };
      await saveStructureState(projectId, structureState);
    }

    const structureBatchSize = Math.max(4, Math.min(settings.batchSize || 12, 24));
    addProjectLog(projectId, {
      level: 'info',
      message: `🧠 AI ರಚನಾ ವಿಶ್ಲೇಷಣೆ ಆರಂಭ: ${structurePendingUnits.length} ಘಟಕಗಳನ್ನು ${structureBatchSize}-ಘಟಕಗಳ context batches ನಲ್ಲಿ ಪರಿಶೀಲಿಸಲಾಗುತ್ತದೆ.`,
      stage: 'STRUCTURE_AI',
    });

    let structureAiUsed = false;
    for (let start = 0; start < structurePendingUnits.length; start += structureBatchSize) {
      const batch = structurePendingUnits.slice(start, start + structureBatchSize);
      const result = await analyzeStructureBatch(batch, structureState, settings.geminiModel);
      structureState = result.state;
      structureAiUsed = structureAiUsed || result.aiUsed;

      const resultMap = new Map(result.classifications.map(c => [c.unitId, c]));
      for (const unit of result.units) {
        const before = units.find(u => u.id === unit.id);
        const offline = {
          unitType: before?.unitType,
          hierarchy: before?.structuralHierarchy,
        };
        const ai = resultMap.get(unit.id) || null;
        const finalStructure = unit.structuralHierarchy.aiStructure || {};
        await saveUnit(unit);
        await saveStructureAudit({
          projectId,
          unitId: unit.id,
          pageNumber: unit.pageNumber,
          chunkId: `structure_batch_${Math.floor(start / structureBatchSize) + 1}`,
          offline,
          ai,
          final: {
            unitType: unit.unitType,
            hierarchy: finalStructure,
            structurePath: unit.structuralHierarchy.structurePath || [],
          },
          validationStatus: finalStructure.validationStatus || (ai ? 'FLAGGED' : 'OFFLINE_ONLY'),
          reason: finalStructure.reason || result.error || 'Offline candidate retained.',
          confidence: Number(finalStructure.confidence || 0),
        });
      }

      // Keep the in-memory working set aligned for generation workers.
      const updatedById = new Map(result.units.map(u => [u.id, u]));
      units = units.map(u => updatedById.get(u.id) || u);

      // If semantic reconciliation changes an already-completed structural unit
      // into content (or vice versa), reopen it so the final manuscript cannot
      // retain stale heading/verse output.
      for (const updated of result.units) {
        const previous = batch.find(u => u.id === updated.id);
        const wasHeading = previous?.unitType === 'HEADING' || previous?.unitType === 'COLOPHON';
        const isHeading = updated.unitType === 'HEADING' || updated.unitType === 'COLOPHON';
        if (previous?.status === 'COMPLETED' && wasHeading !== isHeading) {
          updated.status = 'PENDING';
          updated.output = undefined;
          updated.validationScore = 0;
          updated.validationIssues = [];
          await saveUnit(updated);
        }
      }

      pendingUnits = units.filter(u => u.status === 'PENDING');

      await saveStructureState(projectId, structureState);
      addProjectLog(projectId, {
        level: result.aiUsed ? 'success' : 'warn',
        message: result.aiUsed
          ? `🧠 Structure batch ${Math.floor(start / structureBatchSize) + 1} reconciled with AI context.`
          : `⚠️ Structure batch ${Math.floor(start / structureBatchSize) + 1} retained offline candidates: ${result.error || 'AI unavailable'}.`,
        stage: 'STRUCTURE_RECONCILE',
      });
    }

    // Refresh the persistent state once more before content generation.
    await saveStructureState(projectId, structureState);
    addProjectLog(projectId, {
      level: structureAiUsed ? 'success' : 'warn',
      message: structureAiUsed
        ? 'AI ರಚನಾ ತಿಳುವಳಿಕೆ canonical processing state ಗೆ ಸೇರಿಸಲಾಗಿದೆ.'
        : 'AI ರಚನಾ ತಿಳುವಳಿಕೆ ಲಭ್ಯವಿಲ್ಲ; offline candidates ಮಾತ್ರ retained ಆಗಿವೆ.',
      stage: 'STRUCTURE_READY',
    });

    // Structure-only resume may finish without any scholarly units left to generate.
    pendingUnits = units.filter(u => u.status === 'PENDING');
    if (pendingUnits.length === 0) {
      const completedCount = units.filter(u => u.status === 'COMPLETED').length;
      const reviewReqCount = units.filter(u => u.status === 'REVIEW_REQUIRED').length;
      const failedCount = units.filter(u => u.status === 'FAILED').length;
      await updateProject({
        id: projectId,
        status: 'COMPLETED',
        completedUnits: completedCount,
        reviewRequiredUnits: reviewReqCount,
        failedUnits: failedCount,
      });
      addProjectLog(projectId, {
        level: 'success',
        message: `ರಚನಾ reconciliation ನಂತರ ಎಲ್ಲಾ ${units.length} ಘಟಕಗಳು ಪೂರ್ಣಗೊಂಡಿವೆ.`,
        stage: 'COMPLETE',
      });
      activeRunners.delete(projectId);
      broadcastProjectStream(projectId, { type: 'complete', data: { projectId } });
      if (onProgress) {
        onProgress({
          projectId,
          isRunning: false,
          isPaused: false,
          total: units.length,
          completed: completedCount,
          failed: failedCount,
          reviewRequired: reviewReqCount,
          message: 'All units processed.',
        });
      }
      return;
    }

    // 1. Determine optimal worker concurrency based on configured API Key Pool
    const configuredKeys = await keyManager.getAllConfiguredKeys();
    const effectiveKeyCount = configuredKeys.length > 0 ? configuredKeys.length : (process.env.GEMINI_API_KEY ? 1 : 0);
    
    // Concurrency Calculation for High-Speed Generation:
    // - With 1 key: 2 to 3 workers with smart staggered dispatch (generates ~6-10+ shlokas/min)
    // - With 2 keys: 4 to 6 workers with key pool rotation (generates ~12-18+ shlokas/min)
    // - With 3+ keys: up to 8 workers (generates ~20+ shlokas/min)
    const keyBasedMaxWorkers = Math.max(3, Math.min(Math.max(1, effectiveKeyCount) * 2, 8));
    const requestedConcurrency = settings.concurrency && settings.concurrency >= 1 ? settings.concurrency : 3;
    const workerCount = Math.max(1, Math.min(requestedConcurrency, keyBasedMaxWorkers, pendingUnits.length));

    addProjectLog(projectId, {
      level: 'info',
      message: `⚡ ಬಲ್ಕ್ ಪ್ರೊಸೆಸಿಂಗ್ ಸಕ್ರಿಯ: ${workerCount} ಸಮಾನಾಂತರ ವರ್ಕರ್‌ಗಳು (Concurrent Batch Workers), ${effectiveKeyCount} ಸಕ್ರಿಯ API ಕೀಗಳು. (ನಿರೀಕ್ಷಿತ ವೇಗ: ~${Math.min(workerCount * 4, 20)} ಶ್ಲೋಕ/ನಿಮಿಷ)...`,
      stage: 'CONCURRENCY_START',
    });

    let queueIndex = 0;

    const processUnitWorker = async (workerId: number) => {
      // Stagger worker start by 250ms to prevent initial burst collision
      if (workerId > 0) {
        await new Promise((r) => setTimeout(r, workerId * 250));
      }

      while (true) {
        // Check cancellation & validity of this runner
        const currentRunner = activeRunners.get(projectId);
        if (!currentRunner || currentRunner.runnerId !== runnerId || currentRunner.isCancelled) {
          return;
        }

        // Check pause state
        if (currentRunner.isPaused) {
          await new Promise<void>((resolve) => {
            currentRunner.unpauseResolver = resolve;
          });
          if (currentRunner.isCancelled || activeRunners.get(projectId)?.runnerId !== runnerId) {
            return;
          }
        }

        // Pick next unit from shared queue
        const i = queueIndex++;
        if (i >= pendingUnits.length) {
          return; // No more units for this worker
        }

        const unit = pendingUnits[i];
        const unitPos = units.indexOf(unit);
        const previous = unitPos > 0 ? units[unitPos - 1] : undefined;
        const next = unitPos >= 0 ? units[unitPos + 1] : undefined;
        unit.structuralHierarchy.structureContext = {
          previousUnitId: previous?.id,
          previousText: previous?.verifiedText || previous?.originalText,
          nextUnitId: next?.id,
          nextText: next?.verifiedText || next?.originalText,
          activePath: unit.structuralHierarchy.structurePath || structureState.structurePath,
          nearbyVerseNumbers: units
            .slice(Math.max(0, unitPos - 2), Math.min(units.length, unitPos + 3))
            .map(u => u.structuralHierarchy.formattedNumber)
            .filter(Boolean),
        };
        const verseNum = unit.structuralHierarchy.formattedNumber || `ಘಟಕ ${i + 1}`;

        notify(`ಸಂಸ್ಕರಣೆ: ಶ್ಲೋಕ ${verseNum} (${i + 1}/${pendingUnits.length})`, unit, 'GENERATE');
        addProjectLog(projectId, {
          level: 'info',
          message: `[${i + 1}/${pendingUnits.length}] ಶ್ಲೋಕ ${verseNum} ಸಂಸ್ಕರಣೆ ಆರಂಭಿಸಲಾಗಿದೆ... (Worker #${workerId + 1})`,
          verseNumber: verseNum,
          stage: 'START',
        });

        // HEADINGS & COLOPHONS:
        // Do not process as shlokas (no 5-stages). Provide clean Kannada transliteration immediately.
        if (isHeadingOrColophonUnit(unit)) {
          unit.unitType = unit.unitType === 'COLOPHON' || classifyTextBlock(unit.originalText).isColophon ? 'COLOPHON' : 'HEADING';
          const normText = normalizeSanskritVerse(unit.originalText);
          const kannadaTrans = devanagariToKannada(normText);
          unit.verifiedText = normText;
          unit.confidence = 'HIGH';
          unit.output = {
            moolaShloka: normText,
            kannadaTransliteration: kannadaTrans,
            padartha: '',
            saralaVivarane: '',
            vivaradaVyakhyana: '',
          };
          unit.status = 'COMPLETED';
          unit.validationScore = 100;
          unit.validationIssues = [];
          await saveUnit(unit);
          addProjectLog(projectId, {
            level: 'info',
            message: `[${i + 1}/${pendingUnits.length}] ಶೀರ್ಷಿಕೆ/ಪುಷ್ಪಿಕಾ: "${kannadaTrans}" - ಕನ್ನಡ ಲಿಪ್ಯಂತರ ಸಿದ್ಧವಾಗಿದೆ.`,
            verseNumber: verseNum,
            stage: 'COMPLETE',
          });
          continue;
        }

        // STEP 1: Fast & Canonical Sanskrit Verification
        unit.status = 'VERIFYING';
        await saveUnit(unit);

        try {
          // Normalize Sanskrit text with deterministic rules first
          const fastNormalized = normalizeSanskritVerse(unit.originalText);
          let verifiedDevanagari = fastNormalized;

          // If text is clean Devanagari Sanskrit, verification succeeds immediately
          if (fastNormalized.length > 5 && !/[A-Za-z]/.test(fastNormalized)) {
            unit.verifiedText = fastNormalized;
            unit.confidence = 'HIGH';
            unit.sourceVerification = {
              referenceSource: 'Canonical Sanskrit Standard (NFC Normalized)',
              matchedWork: unit.detectedWork,
              matchedVerseNum: unit.structuralHierarchy.formattedNumber,
              confidenceScore: 0.98,
              notes: 'ಮೂಲ ಸಂಸ್ಕೃತ ಧ್ವನಿ ಸಂರಕ್ಷಣೆ & ಲಿಪ್ಯಂತರ ನಿಖರತೆ ಪರಿಶೀಲಿಸಲಾಗಿದೆ.',
              diffFound: false,
            };
          } else {
            const verResult = await verifySanskritUnit(
              unit.originalText,
              unit.detectedWork,
              unit.structuralHierarchy.formattedNumber
            );
            unit.verifiedText = verResult.verifiedText;
            unit.confidence = verResult.confidence;
            unit.sourceVerification = {
              referenceSource: verResult.referenceSource,
              matchedWork: verResult.matchedWork,
              matchedVerseNum: verResult.matchedVerseNum,
              confidenceScore: verResult.confidenceScore,
              notes: verResult.notes,
              diffFound: verResult.diffFound,
            };
            unit.changeLog = verResult.changeLogEntries;
          }

          // STEP 2: AI Scholarly Generation (with multi-key failover and live streaming)
          unit.status = 'GENERATING';
          await saveUnit(unit);
          notify(`ಶ್ಲೋಕ ${verseNum} ರ ಕನ್ನಡ ಲಿಪ್ಯಂತರ, ಪದಾರ್ಥ & ವ್ಯಾಖ್ಯಾನ ರಚಿಸಲಾಗುತ್ತಿದೆ...`, unit, 'GENERATE');

          setProjectLiveState(projectId, {
            currentUnitId: unit.id,
            currentVerse: verseNum,
            currentStage: 'STREAMING_AI_TEXT',
            accumulatedText: '',
            latestChunk: '',
            charCount: 0,
            originalText: unit.originalText,
          });

          broadcastProjectStream(projectId, {
            type: 'unit_start',
            data: {
              unitId: unit.id,
              verseNumber: verseNum,
              originalText: unit.originalText,
              detectedWork: unit.detectedWork,
            },
          });

          let generated: any = null;
          let attempt = 0;
          const maxRetries = Math.max(settings.maxRetries || 4, 4);

          while (attempt < maxRetries) {
            try {
              attempt++;
              generated = await generateScholarlyUnitContentStream(
                unit,
                (chunk) => {
                  setProjectLiveState(projectId, {
                    currentUnitId: unit.id,
                    currentVerse: verseNum,
                    currentStage: 'STREAMING_AI_TEXT',
                    accumulatedText: chunk.fullTextSoFar,
                    latestChunk: chunk.text,
                    charCount: chunk.fullTextSoFar.length,
                    originalText: unit.originalText,
                  });
                  broadcastProjectStream(projectId, {
                    type: 'chunk',
                    data: {
                      unitId: unit.id,
                      verseNumber: verseNum,
                      chunk: chunk.text,
                      fullTextSoFar: chunk.fullTextSoFar,
                      charCount: chunk.fullTextSoFar.length,
                    },
                  });
                },
                settings.temperature,
                settings.geminiModel
              );
              break;
            } catch (genErr: any) {
              const rawMsg = genErr.message || String(genErr);
              const is429 = rawMsg.includes('429') || rawMsg.includes('RESOURCE_EXHAUSTED') || rawMsg.includes('quota') || rawMsg.includes('Quota') || rawMsg.includes('Rate Limit') || rawMsg.includes('ದರ ಮಿತಿ') || rawMsg.includes('cooldown');
              const retryDelaySec = extractRetryDelaySeconds(genErr);
              const formattedMsg = formatGeminiErrorMessage(genErr);

              console.warn(`[JobRunner] Unit ${unit.id} attempt ${attempt}/${maxRetries} notice:`, rawMsg);
              addProjectLog(projectId, {
                level: 'warn',
                message: `ಶ್ಲೋಕ ${verseNum} ಪುನರ್ಪ್ರಯತ್ನ (${attempt}/${maxRetries}): ${formattedMsg}`,
                verseNumber: verseNum,
                stage: 'RETRY',
              });
              if (attempt >= maxRetries) {
                throw new Error(formattedMsg);
              }

              // Dynamic rate-limit backoff with jitter
              let backoffMs = attempt * 2500 + Math.floor(Math.random() * 1000);
              if (is429 && retryDelaySec > 0) {
                backoffMs = Math.max(backoffMs, Math.min((retryDelaySec + 2) * 1000, 30000));
              } else if (is429) {
                backoffMs = Math.max(backoffMs, 10000);
              }
              await new Promise((r) => setTimeout(r, backoffMs));
            }
          }

          // Enforce 100% pure script constraints across all fields
          const cleanMoola = standardizeShlokaNumbering(generated.moolaShloka);
          const pureKannadaTranslit = ensurePureKannadaTransliteration(
            generated.kannadaTransliteration,
            cleanMoola || unit.verifiedText || unit.originalText
          );

          unit.output = {
            moolaShloka: cleanMoola,
            kannadaTransliteration: standardizeShlokaNumbering(pureKannadaTranslit),
            padartha: formatPadarthaWithDevanagariPadas(generated.padartha),
            saralaVivarane: ensurePureKannadaScript(cleanRepetitiveLoops(generated.saralaVivarane)),
            vivaradaVyakhyana: ensurePureKannadaScript(cleanRepetitiveLoops(generated.vivaradaVyakhyana)),
            visualAnalysis: generated.visualAnalysis,
            tableContent: generated.tableContent,
            diagramContent: generated.diagramContent,
            pictureContent: generated.pictureContent,
          };

          // STEP 3: Strict Language Purity & Scholarly Validation
          unit.status = 'VALIDATING';
          notify(`ಶ್ಲೋಕ ${verseNum} ಗುಣಮಟ್ಟ & ಶಾಸ್ತ್ರೀಯ ನಿಯಮಗಳ ಪರೀಕ್ಷೆ...`, unit, 'VALIDATE');

          let valReport = validateSanskritUnitOutput(unit);

          // If Padartha or any scholarly section was truncated, incomplete, or missing due to output limits, run targeted completion pass
          const moolaText = unit.output?.moolaShloka || unit.verifiedText || unit.originalText || '';
          const expectedWords = extractExpectedSanskritWords(moolaText);
          const padarthaCoverage = detectPadarthaCoverageAndMissing(expectedWords, unit.output?.padartha || '');
          const hasMissingPadartha = !unit.output?.padartha || !padarthaCoverage.isComplete;
          const hasMissingSarala = !unit.output?.saralaVivarane || unit.output.saralaVivarane.trim().length < 80;
          const hasMissingVyakhyana = !unit.output?.vivaradaVyakhyana || unit.output.vivaradaVyakhyana.trim().length < 150;

          if (unit.output && (hasMissingPadartha || hasMissingSarala || hasMissingVyakhyana)) {
            try {
              console.log(`[JobRunner] Unit ${unit.id} completing scholarly sections (padarthaComplete: ${padarthaCoverage.isComplete}, missingWords: ${padarthaCoverage.missingWords.length}, sarala: ${hasMissingSarala}, vyakhyana: ${hasMissingVyakhyana})...`);

              // If Padartha is incomplete, invoke master Padartha Engine for 100% word coverage with continuation
              if (hasMissingPadartha && moolaText) {
                const completePadarthaRes = await generateCompletePadartha(moolaText, {
                  preferredModel: settings.geminiModel,
                });
                if (completePadarthaRes.padartha && completePadarthaRes.padartha.trim().length >= 20) {
                  unit.output.padartha = completePadarthaRes.padartha;
                }
              }

              // Complete Sarala and Vyakhyana if needed
              if (hasMissingSarala || hasMissingVyakhyana) {
                const completed = await completeMissingScholarlySections(
                  moolaText,
                  unit.output.padartha || '',
                  unit.output.saralaVivarane,
                  unit.output.vivaradaVyakhyana,
                  unit.detectedWork,
                  settings.geminiModel
                );
                if (completed.saralaVivarane && completed.saralaVivarane.trim().length >= 50) {
                  unit.output.saralaVivarane = ensurePureKannadaScript(cleanRepetitiveLoops(completed.saralaVivarane));
                }
                if (completed.vivaradaVyakhyana && completed.vivaradaVyakhyana.trim().length >= 80) {
                  unit.output.vivaradaVyakhyana = ensurePureKannadaScript(cleanRepetitiveLoops(completed.vivaradaVyakhyana));
                }
              }
              valReport = validateSanskritUnitOutput(unit);
            } catch (compErr) {
              console.warn('[JobRunner] Scholarly completion pass error:', compErr);
            }
          }

          // If validation failed on basic script or empty fields, do a targeted fallback across available models
          if (!valReport.isValid && (!unit.output?.padartha || !/[\u0C80-\u0CFF]/.test(unit.output?.saralaVivarane || ''))) {
            try {
              console.log(`[JobRunner] Unit ${unit.id} validation fallback...`);
              const retryGenerated = await generateScholarlyUnitContent(unit, 0.2, undefined);
              if (retryGenerated) {
                unit.output = {
                  moolaShloka: retryGenerated.moolaShloka,
                  kannadaTransliteration: ensurePureKannadaTransliteration(retryGenerated.kannadaTransliteration, retryGenerated.moolaShloka),
                  padartha: formatPadarthaWithDevanagariPadas(retryGenerated.padartha),
                  saralaVivarane: ensurePureKannadaScript(cleanRepetitiveLoops(retryGenerated.saralaVivarane)),
                  vivaradaVyakhyana: ensurePureKannadaScript(cleanRepetitiveLoops(retryGenerated.vivaradaVyakhyana)),
                  visualAnalysis: retryGenerated.visualAnalysis,
                  tableContent: retryGenerated.tableContent,
                  diagramContent: retryGenerated.diagramContent,
                  pictureContent: retryGenerated.pictureContent,
                };
                valReport = validateSanskritUnitOutput(unit);
              }
            } catch (retryErr) {
              console.warn('[JobRunner] Retry validation attempt error:', retryErr);
            }
          }

          unit.validationScore = valReport.score;
          unit.validationIssues = valReport.issues;

          // Pre-filter verification step: pre-filters out fully validated units (Poornagondide)
          // so they never trigger a review alert, ensuring 'Parisheelane' only contains genuine errors.
          const hasCriticalErrors = valReport.issues.some(iss =>
            iss.includes('missing') ||
            iss.includes('Violation') ||
            iss.includes('ಖಾಲಿಯಾಗಿದೆ') ||
            iss.includes('ಪದಾರ್ಥ ಅಪೂರ್ಣತೆ') ||
            iss.includes('ಬಿಟ್ಟುಹೋಗಿವೆ') ||
            iss.includes('ದೋಷಪೂರಿತ')
          );

          if (valReport.isValid || (!hasCriticalErrors && valReport.score >= 0.7 && unit.output?.moolaShloka && unit.output?.kannadaTransliteration && unit.output?.padartha)) {
            unit.status = 'COMPLETED';
            unit.errorMessage = undefined;
            unit.validationIssues = []; // Clear minor non-critical notices for fully validated units
            addProjectLog(projectId, {
              level: 'success',
              message: `✅ ಶ್ಲೋಕ ${verseNum} ಯಶಸ್ವಿಯಾಗಿ ಪೂರ್ಣಗೊಂಡಿದೆ (Poornagondide, ನಿಖರತೆ: ${Math.round(valReport.score * 100)}%).`,
              verseNumber: verseNum,
              stage: 'VALIDATED',
            });
          } else {
            unit.status = 'REVIEW_REQUIRED';
            unit.errorMessage = valReport.issues.join('; ');
            addProjectLog(projectId, {
              level: 'warn',
              message: `⚠️ ಶ್ಲೋಕ ${verseNum} ಪರಿಶೀಲನೆ ಅಗತ್ಯವಿದೆ: ${valReport.issues.slice(0, 2).join(', ')}`,
              verseNumber: verseNum,
              stage: 'REVIEW_REQUIRED',
            });
          }

          // STEP 4: Immediate SQLite Checkpoint
          await saveUnit(unit);

          setProjectLiveState(projectId, {
            currentUnitId: unit.id,
            currentVerse: verseNum,
            currentStage: unit.status === 'COMPLETED' ? 'UNIT_COMPLETED' : 'UNIT_REVIEW_REQUIRED',
            latestChunk: '',
          });

          broadcastProjectStream(projectId, {
            type: 'unit_complete',
            data: {
              unitId: unit.id,
              verseNumber: verseNum,
              status: unit.status,
              unitIndex: i + 1,
              totalUnits: pendingUnits.length,
            },
          });
        } catch (unitErr: any) {
          console.error(`Error processing unit ${unit.id}:`, unitErr);
          unit.status = 'FAILED';
          unit.errorMessage = unitErr.message || String(unitErr);
          addProjectLog(projectId, {
            level: 'error',
            message: `❌ ಶ್ಲೋಕ ${verseNum} ಸಂಸ್ಕರಣೆಯಲ್ಲಿ ದೋಷ: ${unit.errorMessage}`,
            verseNumber: verseNum,
            stage: 'ERROR',
          });
          await saveUnit(unit);

          setProjectLiveState(projectId, {
            currentUnitId: unit.id,
            currentVerse: verseNum,
            currentStage: 'UNIT_FAILED',
            latestChunk: '',
          });

          broadcastProjectStream(projectId, {
            type: 'unit_failed',
            data: {
              unitId: unit.id,
              verseNumber: verseNum,
              error: unit.errorMessage,
            },
          });
        }

        // Fast throttle interval (150ms delay) between consecutive requests on this worker
        await new Promise((r) => setTimeout(r, 150));
      }
    };

    // Run workers concurrently in parallel batch pool
    const workerPromises: Promise<void>[] = [];
    for (let w = 0; w < workerCount; w++) {
      workerPromises.push(processUnitWorker(w));
    }
    await Promise.all(workerPromises);

    // Refresh completed units
    const finalUnits = await getUnitsByProjectId(projectId);
    const finalCompleted = finalUnits.filter(u => u.status === 'COMPLETED').length;
    const finalFailed = finalUnits.filter(u => u.status === 'FAILED').length;
    const finalReview = finalUnits.filter(u => u.status === 'REVIEW_REQUIRED').length;

    await updateProject({
      id: projectId,
      status: 'COMPLETED',
      completedUnits: finalCompleted,
      failedUnits: finalFailed,
      reviewRequiredUnits: finalReview,
    });

    addProjectLog(projectId, {
      level: 'success',
      message: `🎉 ಸಂಪೂರ್ಣ ಗ್ರಂಥ ಸಂಸ್ಕರಣೆ ಯಶಸ್ವಿಯಾಗಿ ಪೂರ್ಣಗೊಂಡಿದೆ! (${finalCompleted} ಪೂರ್ಣ, ${finalReview} ಪರಿಶೀಲನೆ, ${finalFailed} ವಿಫಲ).`,
      stage: 'COMPLETE',
    });

    activeRunners.delete(projectId);
    broadcastProjectStream(projectId, { type: 'complete', data: { projectId } });
    if (onProgress) {
      onProgress({
        projectId,
        isRunning: false,
        isPaused: false,
        total: finalUnits.length,
        completed: finalCompleted,
        failed: finalFailed,
        reviewRequired: finalReview,
        message: 'Project processing finished.',
      });
    }
  } catch (globalErr: any) {
    console.error(`Fatal job error on project ${projectId}:`, globalErr);
    addProjectLog(projectId, {
      level: 'error',
      message: `ವ್ಯವಸ್ಥೆಯ ಗಂಭೀರ ದೋಷ: ${globalErr.message}`,
      stage: 'FATAL_ERROR',
    });
    await updateProject({ id: projectId, status: 'ERROR' });
    activeRunners.delete(projectId);
    broadcastProjectStream(projectId, { type: 'error', data: { error: globalErr.message } });
  } finally {
    const current = activeRunners.get(projectId);
    if (current && current.runnerId === runnerId && !current.isPaused) {
      activeRunners.delete(projectId);
    }
  }
}

export function pauseProjectProcessing(projectId: string) {
  const runner = activeRunners.get(projectId);
  if (runner) {
    runner.isPaused = true;
    updateProject({ id: projectId, status: 'PAUSED' }).catch(console.error);
    addProjectLog(projectId, {
      level: 'warn',
      message: 'ಸಂಸ್ಕರಣೆಯನ್ನು ವಿರಾಮಗೊಳಿಸಲಾಗಿದೆ (Processing paused). ಪುನರಾರಂಭಿಸಲು "ಮುಂದುವರಿಸಿ (Resume)" ಒತ್ತಿರಿ.',
      stage: 'PAUSE',
    });
    broadcastProjectStream(projectId, { type: 'paused', data: { projectId } });
  }
}

export function cancelProjectProcessing(projectId: string) {
  const runner = activeRunners.get(projectId);
  if (runner) {
    runner.isCancelled = true;
    if (runner.unpauseResolver) {
      runner.unpauseResolver();
    }
    activeRunners.delete(projectId);
    updateProject({ id: projectId, status: 'IDLE' }).catch(console.error);
    addProjectLog(projectId, {
      level: 'warn',
      message: 'ಬಳಕೆದಾರರಿಂದ ಸಂಸ್ಕರಣೆ ರದ್ದುಗೊಳಿಸಲಾಗಿದೆ (Processing cancelled by user).',
      stage: 'CANCEL',
    });
    broadcastProjectStream(projectId, { type: 'cancelled', data: { projectId } });
  }
}

export function isProjectProcessing(projectId: string): boolean {
  const runner = activeRunners.get(projectId);
  return Boolean(runner && !runner.isCancelled && !runner.isPaused);
}
