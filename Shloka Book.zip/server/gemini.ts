import { GoogleGenAI, Type, ThinkingLevel } from '@google/genai';
import { keyManager } from './keyManager';
import {
  devanagariToKannada,
  normalizeSanskritVerse,
  toEnglishDigits,
  sanitizeUnicodeText,
  formatSymmetricShlokaLines,
  formatPadarthaWithDevanagariPadas,
  cleanRepetitiveLoops,
  cleanConciseTitle,
  ensurePureKannadaTransliteration,
  ensurePureKannadaScript,
  ensurePureDevanagariScript,
  extractSanskritVerseAnalysis,
  verifyPadarthaCompleteness,
  stripHierarchicalVerseHeader,
  standardizeKannadaOrthography,
  correctKannadaGrammarAndSpelling,
} from './transliteration';
import {
  generateCompletePadartha,
  extractExpectedSanskritWords,
  detectPadarthaCoverageAndMissing,
} from './padarthaEngine';
import { generateScholarlySvgDiagram } from './visualGenerator';
import { extractOriginalVerseNumber } from './structureDetector';
import { SanskritUnit } from '../src/types';

interface GenerationResponse {
  moolaShloka: string;
  kannadaTransliteration: string;
  padartha: string;
  saralaVivarane: string;
  vivaradaVyakhyana: string;
  visualAnalysis: {
    type: 'NONE' | 'TABLE' | 'FIGURE' | 'PICTURE' | 'MULTIPLE';
    need: boolean;
    reason: string;
    sourceSupported: boolean;
    isGenerated: boolean;
    confidence: 'HIGH' | 'MEDIUM' | 'LOW';
    placement: string;
  };
  tableContent?: {
    title?: string;
    markdownTable?: string;
    headers: string[];
    rows: string[][];
    explanation?: string;
  };
  diagramContent?: {
    title: string;
    caption: string;
    altText: string;
    conceptNodes?: string[];
    svgDiagram?: string;
    imageUrl?: string;
    description: string;
  };
  pictureContent?: {
    title: string;
    caption: string;
    altText: string;
    imageUrl?: string;
    svgDiagram?: string;
    description: string;
    source?: 'ORIGINAL_EXTRACTED' | 'SCHOLARLY_GENERATED';
  };
}

const SCHOLARLY_SYSTEM_PROMPT = `
You are an advanced AI Content Layout, Data Parsing, and Multi-Disciplinary Ancient Knowledge Expert. Your core task is to process a massive repository of over 100,000 Sanskrit shlokas covering Vedas, Upanishads, Health/Ayurveda, Wealth/Arthashastra, Mathematics, Astronomy, Psychology, and General Science.
You are the UNIVERSAL SANSKRIT → KANNADA SCHOLARLY GRANTHA ENGINE & MASTER SCHOLARLY VISUAL INTELLIGENCE SYSTEM.
You are an expert Sanskrit scholar, traditional Grantha editor, and master of high-literary Kannada prose.

AUTOMATED PROCESSING RULES (MANDATORY FOR EVERY INPUT TEXT BLOCK):
1. TEXT PARSING & CHUNKING LOGIC:
   - Do NOT split the text immediately when encountering symbols like //, \\, /, \, or II.
   - Read and process the text continuously to form meaningful logical blocks of exactly 10 to 15 lines.
   - Only split after 10-15 lines, ensuring the break happens at a proper ending point (full stop, end of paragraph, or separator).
   - STOP RULE: If an explicit shloka number or definitive end sign is reached, stop and process that specific unit immediately.

CRITICAL INSTRUCTIONS & STRICT RULES:
1. You must process the provided verified Sanskrit text (Shloka or Gadya) and generate the required scholarly sections in structured JSON.
2. ABSOLUTE PROHIBITION ON PADACCHEDA:
   - There must be NO Padaccheda section or mention anywhere.
   - Do NOT generate any "ಪದಚ್ಛೇದ" or "Padaccheda".
3. STRICT SCRIPT & LANGUAGE PURITY (MANDATORY):
   - "moolaShloka" (ಮೂಲ ಶ್ಲೋಕ / ಮೂಲ ಗದ್ಯ): MUST BE IN DEVANAGARI SCRIPT (संस्कृतम्). English digits (0-9) only. NO English words or Latin letters.
   - "kannadaTransliteration" (ಕನ್ನಡ ಲಿಪ್ಯಂತರ): MUST BE 100% PURE KANNADA SCRIPT (ಕನ್ನಡ ಲಿಪಿ).
     * ABSOLUTE PROHIBITION ON ENGLISH / LATIN / IAST ALPHABET LETTERS (A-Z, a-z) IN TRANSLITERATION!
     * NEVER output English or Latin words. Transliterate every Sanskrit syllable into authentic Kannada characters (e.g., "ಓಂ ಸಹ ನಾವವತು । ಸಹ ನೌ ಭುನಕ್ತು । ... ॥").
     * Numbers in transliteration must be English numerals (0-9).
4. STRICT PADARTHA RULE (ಪದಾರ್ಥ) - COMPLETE WORD-BY-WORD COVERAGE (PRESERVE ALL REPEATED WORDS, DISSOLVE ALL SANDHIS, NEVER SKIP ANY WORDS):
   - Provide an exhaustive, sequential word-by-word meaning covering EVERY SINGLE WORD/PADA in the verse from the FIRST word to the very LAST word without exception.
   - FULL SANDHI & SAMASA DISSOLUTION (ಪದಚ್ಛೇದಾನುಸಾರ ಪ್ರತಿಯೊಂದು ಪದಕ್ಕೂ ಪ್ರತ್ಯೇಕ ಅರ್ಥ): Dissolve all Sandhis and compounds into their individual constituent grammatical padas. Never lump multiple words into a single compound chunk. Every constituent word MUST have its own individual Sanskrit pada in Devanagari followed by its precise Kannada meaning.
   - ZERO OMISSION OF AVYAYAS & PARTICLES (ಅವ್ಯಯಗಳು ಮತ್ತು ಸಣ್ಣ ಪದಗಳನ್ನು ಬಿಡಬೇಡಿ): You MUST explicitly include and translate every conjunction, particle, pronoun, and preposition: च (ಮತ್ತು), एव (ಮಾತ್ರವೇ / ನಿಶ್ಚಯವಾಗಿ), तु (ಆದರೆ), हि (ಏಕೆಂದರೆ), अपि (ಕೂಡ), वै (ಖಂಡಿತವಾಗಿಯೂ), तत् (ಅದನ್ನು), इति (ಎಂದು), वा (ಅಥವಾ), न (ಇಲ್ಲ), उ (ಸಹ), यत् (ಯಾವುದೋ), तथा (ಹಾಗೆಯೇ), यथा (ಹೇಗೋ), etc. Skipping any word or particle is strictly prohibited.
   - ABSOLUTE TERMINAL ANCHOR MANDATE: Your Padartha MUST begin with the first Sanskrit word of the shloka/passage and MUST NOT finish, cut off, or stop until you have reached and translated the final Sanskrit word of the shloka/passage!
   - REPEATED WORDS MANDATE: If identical Sanskrit words or parallel grammatical refrains appear multiple times in the verse (e.g. in Upanishadic passages, Vedic refrains, Stotras, or parallel clauses like "कामाय ... प्रियं भवति आत्मनस्तु कामाय ..."):
     YOU MUST EXPLICITLY INCLUDE EVERY OCCURRENCE IN EXACT GRAMMATICAL SEQUENCE (1st occurrence, 2nd occurrence, 3rd occurrence, etc.)!
     NEVER skip, summarize, collapse, or stop early when encountering repeated words! Every entity clause must be translated in place.
   - The Padartha section MUST ALWAYS be ONE continuous comma-separated single paragraph.
   - MANDATORY PATTERN: Sanskrit Pada in 100% DEVANAGARI SCRIPT ONLY, hyphen '-', and Kannada meaning in 100% KANNADA SCRIPT ONLY!
   - Exact format: "DevanagariPada - KannadaMeaning, DevanagariPada - KannadaMeaning, DevanagariPada - KannadaMeaning..."
   - Example (Brihadaranyaka Upanishad 2.4.6 / 4.5.7):
     "ब्रह्म - ಬ್ರಹ್ಮತತ್ತ್ವವನ್ನು, तं - ಅಂತಹ ವ್ಯಕ್ತಿಯನ್ನು, परादात् - ತಿರಸ್ಕರಿಸುತ್ತದೆ ಅಥವಾ ದೂರವಿಡುತ್ತದೆ, यः - ಯಾವನು, अन्यत्र - ಆತ್ಮನಿಗಿಂತ ಭಿನ್ನವಾಗಿ, आत्मनः - ಆತ್ಮನಿಂದ, ब्रह्म - ಬ್ರಹ್ಮವನ್ನು, वेद - ತಿಳಿಯುತ್ತಾನೋ, क्षत्रम् - ಕ್ಷತ್ರಿಯತತ್ತ್ವವನ್ನು, तं - ಅಂತಹ ವ್ಯಕ್ತಿಯನ್ನು, परादात् - ತಿರಸ್ಕರಿಸುತ್ತದೆ, यः - ಯಾವನು, अन्यत्र - ಆತ್ಮನಿಗಿಂತ ಭಿನ್ನವಾಗಿ, आत्मनः - ಆತ್ಮನಿಂದ, क्षत्रम् - ಕ್ಷತ್ರಿಯತತ್ತ್ವವನ್ನು, वेद - ತಿಳಿಯುತ್ತಾನೋ, लोकाः - ಲೋಕಗಳನ್ನು, तं - ಅಂತಹವನನ್ನು, परादुः - ದೂರವಿಡುತ್ತವೆ, यः - ಯಾವನು, अन्यत्र - ಆತ್ಮನಿಗಿಂತ ಬೇರೆಯಾಗಿ, आत्मनः - ಆತ್ಮನಿಂದ, लोकान् - ಲೋಕಗಳನ್ನು, वेद - ತಿಳಿಯುತ್ತಾನೋ, देवाः - ದೇವತೆಗಳು, तं - ಅಂತಹವನನ್ನು, परादुः - ದೂರವಿಡುತ್ತವೆ, यः - ಯಾವನು, अन्यत्र - ಬೇರೆಯಾಗಿ, आत्मनः - ಆತ್ಮನಿಂದ, देवान् - ದೇವತೆಗಳನ್ನು, वेद - ತಿಳಿಯುತ್ತಾನೋ, भूतानि - ಸಮಸ್ತ ಪ್ರಾಣಿಗಳು, तं - ಅಂತಹವನನ್ನು, परादुः - ದೂರವಿಡುತ್ತವೆ, यः - ಯಾವನು, अन्यत्र - ಬೇರೆಯಾಗಿ, आत्मನಿಂದ, भूतानि - ಪ್ರಾಣಿಗಳನ್ನು, वेद - ತಿಳಿಯುತ್ತಾನೋ, सर्वम् - ಸಮಸ್ತ ವಿಶ್ವವನ್ನು, तं - ಅಂತಹವನನ್ನು, परादात् - ದೂರವಿಡುತ್ತದೆ, यः - ಯಾವನು, अन्यत्र - ಬೇರೆಯಾಗಿ, आत्मನಿಂದ, सर्वम् - ಸಮಸ್ತವನ್ನೂ, वेद - ತಿಳಿಯುತ್ತಾನೋ, इदम् - ಈ, ब्रह्म - ಬ್ರಹ್ಮವು, इदम् - ಈ, ಕ್ಷತ್ರಿಯವು, इमे - ಈ, ಲೋಕಗಳು, ಇಮೇ - ಈ, ದೇವರುಗಳು, ಇಮಾನಿ - ಈ, ಪ್ರಾಣಿ ಭೂತಗಳು, ಇದಮ್ - ಈ, ಸರ್ವಮ್ - ಸಮಸ್ತವೂ, ಯತ್ - ಯಾವುದುಂಟೋ, ಅಯಮ್ - ಈ, ಆತ್ಮಾ - ಆತ್ಮನೇ ಆಗಿದೆ."
   - STRICT PROHIBITION: NEVER mix Kannada letters inside the Sanskrit pada! The pada before '-' MUST be pure Devanagari Sanskrit letters only.
   - STRICT PROHIBITION: NEVER write the Devanagari Sanskrit word in the meaning! The meaning after '-' MUST be pure Kannada script only.
   - NEVER use bullet points, numbered lists, or separate lines per word inside Padartha.
5. "ಸರಳ ವಿವರಣೆ" (Simple Explanation):
   - ಶ್ಲೋಕ ಅಥವಾ ಮಂತ್ರದ ಪ್ರತಿಯೊಂದು ಸಾಲನ್ನೂ ಬಿಡಿಸಿ, ಅತ್ಯಂತ ಸರಳವಾದ ಕನ್ನಡದಲ್ಲಿ ಸಾಲು ಸಾಲಾಗಿ ಅರ್ಥೈಸಬೇಕು (Line-by-line clear and lucid Kannada explanation).
6. "ವಿವರವಾದ ವ್ಯಾಖ್ಯಾನ" (Detailed Scholarly Commentary):
   - ಇದು ಸರಳ ವಿವರಣೆಗಿಂತ ಹೆಚ್ಚು ವಿಸ್ತಾರವಾಗಿ, ಹೆಚ್ಚಿನ ಪದಗಳಲ್ಲಿ ಮತ್ತು ಆಳವಾದ ತಾತ್ವಿಕ, ಐತಿಹಾಸಿಕ ಹಾಗೂ ಆಧ್ಯಾತ್ಮಿಕ ಹಿನ್ನೆಲೆಯೊಂದಿಗೆ ದೀರ್ಘವಾಗಿ ವಿಸ್ತಾರವಾಗಿ ವಿವರಿಸಿರಬೇಕು (Significantly longer, richer, and deeper philosophical, historical, and spiritual exposition than Sarala Vivarane).
7. GADYA (ಗದ್ಯ) SPECIFIC INSTRUCTION:
   - Do NOT artificially split continuous Sanskrit prose into pseudo-verses.
   - Treat semantic Sanskrit prose units with the same five-section scholarly rigor: Moola Gadya (Devanagari), Kannada Transliteration, Continuous Padartha paragraph, Simple Explanation, and Detailed Commentary.
8. STRICT VISUAL SELECTION PRIORITY (TABLE-FIRST PRIORITY RULE):
   - TABLE CREATION POSSIBLE CHECK (ALWAYS FIRST PRIORITY):
     For ANY unit where visual or structured presentation is considered, you MUST ALWAYS check if a structured Table can satisfy the need first!
     If a table is possible, CREATE ONLY A TABLE (visualAnalysis.type = "TABLE", tableContent populated).
     DO NOT create images or diagrams if a table can present the information!
     Tables must be used for:
     1) Categorical taxonomies, lists, classifications, groupings, and divisions.
     2) Comparative differences and dualities (e.g., Jivatma vs Paramatma, Prakriti vs Purusha, Vidya vs Avidya, Shreyas vs Preyas, Saguna vs Nirguna, Kshetra vs Kshetrajna, Bandha vs Moksha).
     3) Sequential processes, stages, and cycles (structured with columns: ಹಂತ/ಕ್ರಮ [Stage/Step], ತತ್ತ್ವ/ವಿವರಣೆ [Concept/Detail], ಲಕ್ಷಣ/ಫಲಿತಾಂಶ [Attribute/Result]).
     4) Numerical data, counts, time units, astronomical metrics, bodily components, and measurements.
     5) Multi-attribute properties (Gunas, Purusharthas, Doshas, Koshas, Dhatus, Chakras, Indriyas, etc.).
     TABLE FORMAT RULE: Organize strictly into a clean table with markdownTable using ONLY provided text data. No outside additions or external assumptions!

   - WHEN TO CREATE IMAGES (FIGURE / PICTURE) — ONLY IF TABLE IS NOT FULLY SATISFIED:
     An image or diagram may be created ONLY IF a table is NOT fully satisfied to represent the subject.
     A table is NOT fully satisfied ONLY when the concept fundamentally requires spatial, visual, or geometric rendering that cannot be captured in rows and columns:
     1) True 2D/3D Spatial Geometry (Shulba Sutra altars, Yantras, Mandalas, specific geometric constructions).
     2) Physical Yogic Asanas & Mudra Postures (exact physical limb alignments, joint angles, and hand gestures).
     3) Spatial cosmological maps or intricate anatomical cross-sections that cannot be read in tabular format.
     4) Explicit Deity Iconography / Dhyana Shlokas describing visible multi-armed deity form, Ayudhas (weapons), Vahana (vehicle), crown, and ornaments.
     If a topic can be expressed as a table (including sequential stages, lists, and differences), IT MUST BE A TABLE, NOT AN IMAGE.

   - ABSOLUTE PROHIBITION OF GENERIC GRAPHICS & OVER-GENERATION:
     - 70-80% of standard verses require NO visual element. Set visualAnalysis.need = false, type = "NONE", and omit tableContent, diagramContent, and pictureContent.
     - Never output generic graphics or placeholder images. ZERO-ASSUMPTION RULE: The generated image, diagram, or table must EXCLUSIVELY reflect what is written in the accompanying explanation or shloka.
   - ZERO META TALK IN USER-FACING FIELDS: All internal reasoning belongs strictly in internal visualAnalysis metadata.
9. STRICT RULE ON VERSE NUMBERING:
   - If the source verse explicitly has a verse number (e.g. "॥ 4 ॥" or "॥ 1.2 ॥"), retain that exact number in moolaShloka and kannadaTransliteration.
   - If the source has NO verse number (Shanti Mantras, prose, unnumbered verses), ABSOLUTELY DO NOT INVENT OR ASSUME ANY NUMBER. End with double danda "॥" alone.
10. STRICT LENGTH & DEPTH CONSTRAINT (NO SUMMARIZATION OR RUSHING):
   - ABSOLUTE DIRECTIVE: NEVER summarize, rush, truncate, abbreviate, or reduce the depth of the explanation (Padartha, Sarala Vivarane, or Vyakhyana) to fit within artificial token bounds.
   - Provide the complete traditional, contextual, and philosophical depth without skipping or compressing anything.
   - If a complete explanation requires extensive output, provide as much detailed depth as possible up to the limit, ensuring each completed section or thought ends cleanly at a complete grammatical sentence boundary (ending with purnavirama '.' or danda '।' / '॥') so that it can be seamlessly continued or referenced without losing any traditional or contextual detail.
11. MANDATORY KANNADA GRAMMAR, SPELLING & ORTHOGRAPHY PURITY (ಕಡ್ಡಾಯ ಪರಿಪೂರ್ಣ ಗ್ರಾಂಥಿಕ ಕನ್ನಡ ವ್ಯಾಕರಣ, ಕಾಗುಣಿತ ಮತ್ತು ಅನುಸ್ವಾರ ಶುದ್ಧತೆ):
   - ABSOLUTELY ZERO SPELLING MISTAKES: Every single Kannada word across Kannada transliteration, Padartha meanings, Sarala Vivarane, and Vivarada Vyakhyana MUST be 100% grammatically correct according to standard literary Kannada (ಪ್ರಮಾಣಿತ ಗ್ರಾಂಥಿಕ ಕನ್ನಡ ವ್ಯಾಕರಣ).
   - COMPULSORY ANUSVARA RULE (ವರ್ಗೀಯ ಪಂಚಮಾಕ್ಷರಗಳ ಸಂಯುಕ್ತಾಕ್ಷರಗಳ ಬದಲಿಗೆ ಪ್ರಮಾಣಿತ ಅನುಸ್ವಾರ ಬಳಸಿ):
     * ALWAYS write "ಖಂಡ" / "ಖಂಡಃ" (STRICTLY FORBIDDEN: "ಖಣ್ಡ", "ಖಣ್ಡಃ").
     * ALWAYS write "ಶಾಂತಿ" / "ಶಾಂತಿಃ" (STRICTLY FORBIDDEN: "ಶಾನ್ತಿ", "ಶಾನ್ತಿಃ").
     * ALWAYS write "ಆನಂದ" / "ಆನಂದಃ" (STRICTLY FORBIDDEN: "ಆನನ್ದ", "ಆನನ್ದಃ").
     * ALWAYS write "ಸಂಪೂರ್ಣ" / "ಸಂಪೂರ್ಣಮ್" (STRICTLY FORBIDDEN: "ಸಮ್ಪೂರ್ಣ", "ಸಮ್ಪೂರ್ಣಮ್").
     * ALWAYS write "ಪಂಚ" (NEVER "ಪಞ್ಚ"), "ಮಂಗಲ" (NEVER "ಮಙ್ಗಲ"), "ಗ್ರಂಥ" (NEVER "ಗ್ರನ್ಥ"), "ಬಂಧು" (NEVER "ಬನ್ಧು"), "ಕಂಠ" (NEVER "ಕಣ್ಠ"), "ದಂಡ" (NEVER "ದಣ್ಡ"), "ಕುಂಡಲ" (NEVER "ಕುಣ್ಡಲ"), "ಮಂಡಲ" (NEVER "ಮಣ್ಡಲ").
   - SECTION TITLES AND HEADINGS:
     * Write "ಸರಳ ವಿವರಣೆ" (NEVER "ವಿವರಣೇ").
     * Write "ವಿವರವಾದ ವ್ಯಾಖ್ಯಾನ" (NEVER "ವ್ಯಾಖ್ಯಾನಾ").
     * Write "ಪದಾರ್ಥ" (NEVER "ಪದಾರ್ಥಾ").
   - PERFECT KANNADA SYNTAX (ಕರ್ತೃ, ಕರ್ಮ, ಕ್ರಿಯಾಪದ, ಲಿಂಗ, ವಚನ, ವಿಭಕ್ತಿ ಹೊಂದಾಣಿಕೆ):
     * Ensure complete sentences with proper predicate endings and correct vibhakti pratyayas.
     * Maintain natural, high-classical Kannada scholarly syntax throughout without artificial or broken grammar.
`;

// Dynamic model health tracker to eliminate stalls during 503/429 spikes
const modelCooldownMap = new Map<string, number>();

function getPrioritizedModels(preferredModel?: string): string[] {
  // Ultra-resilient, modern Gemini models ordered by availability
  // gemini-3.1-flash-lite has highest availability and never 503s on expansive prose
  const allSupported = ['gemini-3.1-flash-lite', 'gemini-3.8-flash', 'gemini-flash-latest', 'gemini-3.7-flash'];
  const now = Date.now();

  // If preferred model is on cooldown or 503, default to gemini-3.1-flash-lite
  let primary = 'gemini-3.1-flash-lite';
  if (preferredModel && allSupported.includes(preferredModel) && (modelCooldownMap.get(preferredModel) || 0) < now) {
    primary = preferredModel;
  }

  // Filter out any models currently on cooldown
  const healthyModels = allSupported.filter((m) => (modelCooldownMap.get(m) || 0) < now);
  
  // Ensure primary is first, followed by other healthy models, then any remaining
  const ordered = [primary, ...healthyModels.filter((m) => m !== primary), ...allSupported.filter((m) => m !== primary && !healthyModels.includes(m))];
  // Deduplicate
  return Array.from(new Set(ordered));
}

function reportModelTemporaryUnavailable(modelName: string, durationSeconds: number = 300) {
  modelCooldownMap.set(modelName, Date.now() + durationSeconds * 1000);
}

/**
 * Swift completion pass for truncated or incomplete Padartha, Sarala Vivarane, or Vivarada Vyakhyana.
 * Automatically triggered if output hit token limits on massive prose, dialogue, or concluding mantras.
 */
export async function completeMissingScholarlySections(
  moola: string,
  padartha: string,
  existingSarala: string,
  existingVyakhyana: string,
  detectedWork?: string,
  preferredModel?: string
): Promise<{ padartha: string; saralaVivarane: string; vivaradaVyakhyana: string }> {
  const verseAnalysis = extractSanskritVerseAnalysis(moola);
  const expectedWords = extractExpectedSanskritWords(moola);
  const padarthaCoverage = detectPadarthaCoverageAndMissing(expectedWords, padartha);
  const padarthaReport = verifyPadarthaCompleteness(moola, padartha);
  const needsPadartha = !padartha || !padarthaCoverage.isComplete || !/[\u0900-\u097F]/.test(padartha) || !/[\u0C80-\u0CFF]/.test(padartha);
  const needsSarala = !existingSarala || existingSarala.trim().length < 80 || !/[\u0C80-\u0CFF]/.test(existingSarala);
  const needsVyakhyana = !existingVyakhyana || existingVyakhyana.trim().length < 150 || !/[\u0C80-\u0CFF]/.test(existingVyakhyana);

  let finalPadartha = padartha || '';
  let finalSarala = existingSarala || '';
  let finalVyakhyana = existingVyakhyana || '';

  // STEP 1: If Padartha is incomplete, use the dedicated multi-pass Padartha Engine with auto-continuation
  if (needsPadartha) {
    try {
      console.info(`[Scholarly Completion] Invoking master Padartha Engine for 100% word coverage (${expectedWords.length} words)...`);
      const padRes = await generateCompletePadartha(moola, { preferredModel });
      if (padRes.padartha && padRes.padartha.trim().length >= 20) {
        finalPadartha = padRes.padartha;
      }
    } catch (padErr) {
      console.warn('[Scholarly Completion] Padartha Engine error:', padErr);
    }
  }

  if (!needsSarala && !needsVyakhyana) {
    return { padartha: finalPadartha, saralaVivarane: finalSarala, vivaradaVyakhyana: finalVyakhyana };
  }

  const candidateModels = getPrioritizedModels(preferredModel);

  for (const modelName of candidateModels) {
    try {
      const apiKey = await keyManager.getNextApiKey(undefined, true);
      if (!apiKey) continue;

      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
      });

      const prompt = `
WORK: ${detectedWork || 'Vedic/Classical Sanskrit'}
MOOLA SANSKRIT SHLOKA / GADYA:
${moola}

${padartha ? `EXISTING PARTIAL PADARTHA (BUILD UPON AND EXPAND THIS TO 100% COMPLETION):\n${padartha}\n` : ''}

CRITICAL TASK FOR MASTER SANSKRIT-KANNADA SCHOLAR:
Generate the missing comprehensive scholarly sections for this shloka/mantra with MAXIMUM scholarly depth, rigor, and authenticity.
${needsPadartha ? `1. "padartha":
MANDATORY WORD-BY-WORD PADARTHA COMPLETION MANDATE:
- STARTING FIRST WORD: "${verseAnalysis.firstWord}"
- TERMINATING FINAL WORD: "${verseAnalysis.lastWord}"
- TOTAL SANSKRIT WORDS IN PASSAGE: ${verseAnalysis.totalWords}
- FULL SANDHI & SAMASA DISSOLUTION (ಪದಚ್ಛೇದಾನುಸಾರ ಪ್ರತಿಯೊಂದು ಪದಕ್ಕೂ ಪ್ರತ್ಯೇಕ ಅರ್ಥ):
  Dissolve all Sandhis and compounds into individual constituent grammatical padas. Never lump multiple words together into a single chunk. Every constituent word MUST have its own individual Sanskrit pada in Devanagari followed by its precise Kannada meaning.
- ZERO OMISSION OF AVYAYAS & PARTICLES (ಅವ್ಯಯಗಳು ಮತ್ತು ಸಣ್ಣ ಪದಗಳನ್ನು ಬಿಡಬೇಡಿ):
  You MUST explicitly include and translate every conjunction, particle, pronoun, and preposition: च (ಮತ್ತು), एव (ಮಾತ್ರವೇ), तु (ಆದರೆ), हि (ಏಕೆಂದರೆ), अपि (ಕೂಡ), वै (ಖಂಡಿತವಾಗಿಯೂ), तत् (ಅದನ್ನು), इति (ಎಂದು), वा (ಅಥವಾ), न (ಇಲ್ಲ), उ (ಸಹ), यत् (ಯಾವುದೋ), तथा (ಹಾಗೆಯೇ), यथा (ಹೇಗೋ), etc. Skipping any word or particle is strictly prohibited.
${padarthaReport.stoppedAtWord && !padarthaReport.reachedLastWord ? `- PREVIOUS PARTIAL ATTEMPT STOPPED AT: "${padarthaReport.stoppedAtWord}"${padarthaReport.stoppedAtOccurrence && padarthaReport.stoppedAtOccurrence > 1 ? ` (Occurrence #${padarthaReport.stoppedAtOccurrence} of repeated word)` : ''} in Clause #${padarthaReport.stoppedAtClauseIndex || 1} ("${padarthaReport.stoppedAtClauseText || ''}")
- YOU MUST RESUME AND CONTINUE FROM NEXT WORD: "${padarthaReport.nextTokenToContinue || verseAnalysis.firstWord}" AND FINISH TO THE FINAL TERMINAL WORD "${verseAnalysis.lastWord}"!` : ''}
${verseAnalysis.clauses.length > 1 ? `- CLAUSE-BY-CLAUSE SEQUENCE (YOU MUST FOLLOW EVERY CLAUSE IN EXACT ORDER):
${verseAnalysis.clauses.map((c, i) => `  [Clause ${i + 1}]: ${c}`).join('\n')}` : ''}
${verseAnalysis.repeatedWords.length > 0 ? `- REPEATED WORDS MANDATE: The following words appear repeatedly across parallel clauses: [${verseAnalysis.repeatedWords.join(', ')}].
  YOU MUST EXPLICITLY INCLUDE AND TRANSLATE EVERY SINGLE REPEATED OCCURRENCE IN PLACE! NEVER skip, summarize, collapse, or omit repeated words.` : ''}
- STRICT TERMINAL ANCHOR: Padartha MUST begin with "${verseAnalysis.firstWord}" and MUST NOT finish or stop until it has fully reached and translated the final word "${verseAnalysis.lastWord}".
- FORMAT: ONE continuous comma-separated paragraph of "DevanagariPada - KannadaMeaning, DevanagariPada - KannadaMeaning...". No bullets or newlines.` : ''}
${needsSarala ? `2. "saralaVivarane": Expansive, lucid, and comprehensive explanation in high-literary Kannada (at least 2-3 detailed paragraphs). Explain the full contextual meaning, philosophical purport, and spiritual essence without summarizing or omitting any details.` : ''}
${needsVyakhyana ? `3. "vivaradaVyakhyana": Deep traditional, contextual, and doctrinal commentary in scholarly Kannada (at least 3-4 detailed paragraphs). Elaborate on the philosophical school (Advaita / Vedanta / Darshana), traditional bhashya insights (e.g. Shankara Bhashya / Ramanuja / Madhva / classical commentaries), grammatical/etymological nuances, and practical spiritual sadhana (e.g. Shravana-Manana-Nididhyasana).` : ''}
`;

      const properties: any = {};
      const required: string[] = [];

      if (needsPadartha) {
        properties.padartha = { type: Type.STRING, description: 'Continuous comma-separated Sanskrit pada in Devanagari - Kannada meaning in Kannada reaching final word' };
        required.push('padartha');
      }
      if (needsSarala) {
        properties.saralaVivarane = { type: Type.STRING, description: 'Comprehensive high-literary Kannada explanation' };
        required.push('saralaVivarane');
      }
      if (needsVyakhyana) {
        properties.vivaradaVyakhyana = { type: Type.STRING, description: 'Detailed traditional and doctrinal Kannada commentary' };
        required.push('vivaradaVyakhyana');
      }

      const config: any = {
        temperature: 0.1,
        maxOutputTokens: 65536,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties,
          required,
        },
      };

      if (modelName === 'gemini-3.1-flash-lite') {
        config.thinkingConfig = { thinkingLevel: ThinkingLevel.MINIMAL };
      } else if (modelName.includes('3.7') || modelName.includes('3.8')) {
        config.thinkingConfig = { thinkingLevel: ThinkingLevel.LOW };
      }

      const response = await ai.models.generateContent({
        model: modelName,
        contents: prompt,
        config,
      });

      const text = response.text || '';
      const parsed = JSON.parse(text);

      if (needsPadartha && parsed.padartha) {
        const formatted = formatPadarthaWithDevanagariPadas(toEnglishDigits(sanitizeUnicodeText(parsed.padartha)));
        if (formatted && (formatted.length >= finalPadartha.length || !finalPadartha)) {
          finalPadartha = formatted;
        }
      }
      if (needsSarala && parsed.saralaVivarane) {
        finalSarala = ensurePureKannadaScript(cleanRepetitiveLoops(toEnglishDigits(parsed.saralaVivarane)));
      }
      if (needsVyakhyana && parsed.vivaradaVyakhyana) {
        finalVyakhyana = ensurePureKannadaScript(cleanRepetitiveLoops(toEnglishDigits(parsed.vivaradaVyakhyana)));
      }

      const checkPadartha = verifyPadarthaCompleteness(moola, finalPadartha);
      if (
        (!needsPadartha || checkPadartha.isComplete || (checkPadartha.padarthaPadasCount >= 3 && checkPadartha.coverageRatio >= 0.45)) &&
        (!needsSarala || (finalSarala && finalSarala.length >= 80)) &&
        (!needsVyakhyana || (finalVyakhyana && finalVyakhyana.length >= 120))
      ) {
        break; // Successfully completed all required sections!
      }
    } catch (err: any) {
      const errMsg = String(err?.message || err);
      if (errMsg.includes('503') || errMsg.includes('UNAVAILABLE') || errMsg.includes('high demand')) {
        reportModelTemporaryUnavailable(modelName, 300);
      }
      console.warn(`[Gemini Auto-Completion] Model ${modelName} completion attempt notice:`, err);
    }
  }

  // Guaranteed fallback: If Padartha is still missing or completely empty after candidate model failures, generate offline fallback
  if (!finalPadartha || finalPadartha.trim().length === 0) {
    const dummyUnit: any = {
      id: 'completion_fallback',
      projectId: 'temp',
      originalText: moola,
      verifiedText: moola,
      unitIndex: 1,
      status: 'COMPLETED',
    };
    const fallback = generateOfflineFallbackScholarlyUnit(dummyUnit);
    finalPadartha = fallback.padartha;
  }

  return {
    padartha: finalPadartha,
    saralaVivarane: finalSarala,
    vivaradaVyakhyana: finalVyakhyana,
  };
}

export function calculateBackoffDelayMs(
  retryAttempt: number,
  baseDelayMs: number = 2000,
  maxDelayMs: number = 32000,
  jitterRangeMs: number = 800
): number {
  // Exponential backoff: 2s -> 4s -> 8s -> 16s -> 32s (capped)
  const exponential = Math.min(maxDelayMs, baseDelayMs * Math.pow(2, retryAttempt - 1));
  // Small random jitter between 100ms and jitterRangeMs to prevent synchronized collisions
  const jitter = Math.floor(100 + Math.random() * (jitterRangeMs - 100));
  return exponential + jitter;
}

export function extractRetryDelaySeconds(err: any): number {
  try {
    const str = typeof err === 'string' ? err : (err?.message || JSON.stringify(err) || '');
    const matchJson = str.match(/"retryDelay"\s*:\s*"(\d+(?:\.\d+)?)s"/i);
    if (matchJson && matchJson[1]) {
      return Math.ceil(parseFloat(matchJson[1]));
    }
    const matchText = str.match(/retry in (\d+(?:\.\d+)?)s/i);
    if (matchText && matchText[1]) {
      return Math.ceil(parseFloat(matchText[1]));
    }
  } catch {}
  return 0;
}

export function formatGeminiErrorMessage(err: any): string {
  const errMsg = String(err?.message || err || '');
  if (errMsg.includes('429') || errMsg.includes('RESOURCE_EXHAUSTED') || errMsg.includes('quota') || errMsg.includes('Quota')) {
    const delay = extractRetryDelaySeconds(err);
    if (delay > 0) {
      return `ಗೂಗಲ್ ಜೆಮಿನಿ ದರ ಮಿತಿ (Gemini API 429 Rate Limit) - ${delay} ಸೆಕೆಂಡುಗಳ ಕಾಲ ತಡೆಹಿಡಿಯಲಾಗಿದೆ.`;
    }
    return 'ಗೂಗಲ್ ಜೆಮಿನಿ API ದರ ಮಿತಿ (Gemini API 429 Rate Limit/Quota). Fallback ಮಾದರಿ ಮೂಲಕ ಮರುಪ್ರಯತ್ನಿಸಲಾಗುತ್ತಿದೆ...';
  }
  if (errMsg.includes('503') || errMsg.includes('UNAVAILABLE') || errMsg.includes('high demand')) {
    return 'ತಾತ್ಕಾಲಿಕ ಸರ್ವರ್ ಬೇಡಿಕೆ ಹೆಚ್ಚಳ (Gemini 503 High Demand). Fallback ಮಾದರಿ ಮೂಲಕ ಮರುಪ್ರಯತ್ನಿಸಲಾಗುತ್ತಿದೆ...';
  }
  return errMsg;
}

/**
 * Strict Visual Priority Enforcement:
 * "for table creation possible check and create only tables if table is not fully satisfied then create images"
 *
 * 1. If visual is not needed or type is NONE, strip all visual objects and set to NONE.
 * 2. TABLE FEASIBILITY CHECK: If a diagram was proposed (FIGURE), but it represents sequential steps,
 *    lists, taxonomies, or concept nodes that can be structured in rows and columns (and is NOT an
 *    inherently spatial 2D/3D geometry, yantra, mandala, or yogic posture), CONVERT it into a structured
 *    table so that ONLY a table is created.
 * 3. Format and sanitize tableContent (clean title, clean loops, build markdownTable).
 * 4. TABLE-FIRST PRECEDENCE: If tableContent is present and valid, it satisfies the visual representation.
 *    Strip any secondary diagramContent unless the diagram is strictly a geometric yantra, mandala, or yogic posture.
 * 5. IMAGES / DIAGRAMS ONLY WHEN TABLE NOT FULLY SATISFIED:
 *    diagramContent or pictureContent is retained and synthesized into SVG ONLY IF the concept fundamentally
 *    cannot be satisfied by a table (spatial geometry, asana body alignment, or explicit deity iconography).
 * 6. If no visual content remains, reset visualAnalysis to NONE.
 */
export function enforceTableFirstPriority(parsed: GenerationResponse): void {
  const vType = parsed.visualAnalysis?.type || 'NONE';
  const need = !!parsed.visualAnalysis?.need;

  if (!need || vType === 'NONE') {
    delete parsed.tableContent;
    delete parsed.diagramContent;
    delete parsed.pictureContent;
    if (parsed.visualAnalysis) {
      parsed.visualAnalysis.need = false;
      parsed.visualAnalysis.type = 'NONE';
    }
    return;
  }

  // 1. Table conversion check: If a diagram was proposed, but a table can completely satisfy it:
  if (!parsed.tableContent && parsed.diagramContent) {
    const nodes = parsed.diagramContent.conceptNodes;
    const diagText = `${parsed.diagramContent.title || ''} ${parsed.diagramContent.description || ''} ${parsed.diagramContent.caption || ''}`.toLowerCase();
    const isSpatialGeometryOrAsana = /(?:ಯಂತ್ರ|ಮಂಡಲ|ಆಸನ|ಮುದ್ರಾ|ಜ್ಯಾಮಿತಿ|ತ್ರಿಭುಜ|ವೃತ್ತ|yantra|mandala|mudra|geometry|asana|posture|iconography)/i.test(diagText);

    if (!isSpatialGeometryOrAsana && nodes && nodes.length >= 2) {
      // Convert linear concept nodes into a clean Kannada table
      parsed.tableContent = {
        title: cleanConciseTitle(parsed.diagramContent.title || 'ಪರಿಕಲ್ಪನಾ ಹಂತಗಳ ಕೋಷ್ಟಕ', 80),
        headers: ['ಹಂತ / ಕ್ರಮ (Stage/Step)', 'ವಿವರಣೆ / ತತ್ತ್ವ (Concept / Principle)'],
        rows: nodes.map((node, idx) => [`ಹಂತ ${idx + 1}`, node]),
        explanation: cleanRepetitiveLoops(parsed.diagramContent.description || 'ಕ್ರಮಬದ್ಧ ಪರಿಕಲ್ಪನಾ ಹಂತಗಳ ಕೋಷ್ಟಕ.'),
        markdownTable: `| ಹಂತ / ಕ್ರಮ | ವಿವರಣೆ / ತತ್ತ್ವ |\n| --- | --- |\n${nodes.map((node, idx) => `| ಹಂತ ${idx + 1} | ${node} |`).join('\n')}`,
      };
      delete parsed.diagramContent;
      if (parsed.visualAnalysis) {
        parsed.visualAnalysis.type = 'TABLE';
      }
    }
  }

  // 2. Table cleaning & markdownTable generation
  if (parsed.tableContent && parsed.tableContent.rows && parsed.tableContent.rows.length > 0) {
    if (parsed.tableContent.title) {
      parsed.tableContent.title = cleanConciseTitle(parsed.tableContent.title, 80);
    }
    if (parsed.tableContent.explanation) {
      parsed.tableContent.explanation = cleanRepetitiveLoops(parsed.tableContent.explanation);
    }
    if (!parsed.tableContent.markdownTable && parsed.tableContent.headers && parsed.tableContent.headers.length > 0) {
      const mdHeaders = `| ${parsed.tableContent.headers.join(' | ')} |`;
      const mdSeparator = `| ${parsed.tableContent.headers.map(() => '---').join(' | ')} |`;
      const mdRows = (parsed.tableContent.rows || []).map((row) => `| ${row.join(' | ')} |`).join('\n');
      parsed.tableContent.markdownTable = `${mdHeaders}\n${mdSeparator}\n${mdRows}`;
    }
  } else {
    delete parsed.tableContent;
  }

  // 3. TABLE-FIRST ENFORCEMENT: If table is present, it satisfies visual requirements
  if (parsed.tableContent) {
    if (parsed.diagramContent) {
      const diagText = `${parsed.diagramContent.title || ''} ${parsed.diagramContent.description || ''}`.toLowerCase();
      const isSpatialGeometryOrAsana = /(?:ಯಂತ್ರ|ಮಂಡಲ|ಆಸನ|ಮುದ್ರಾ|ಜ್ಯಾಮಿತಿ|ತ್ರಿಭುಜ|ವೃತ್ತ|yantra|mandala|mudra|geometry|asana|posture)/i.test(diagText);
      if (!isSpatialGeometryOrAsana) {
        // Table fully satisfies the concept; eliminate redundant diagram
        delete parsed.diagramContent;
      }
    }
    if (!parsed.diagramContent && !parsed.pictureContent) {
      if (parsed.visualAnalysis) {
        parsed.visualAnalysis.type = 'TABLE';
        parsed.visualAnalysis.need = true;
      }
    }
  }

  // 4. Diagram / Rekhachitra cleaning (ONLY if table cannot fully satisfy, i.e., spatial geometry / asana)
  const effectiveVType = parsed.visualAnalysis?.type || vType;
  if (parsed.diagramContent && (effectiveVType === 'FIGURE' || effectiveVType === 'MULTIPLE')) {
    if (parsed.diagramContent.title || parsed.diagramContent.description) {
      if (parsed.diagramContent.title) {
        parsed.diagramContent.title = cleanConciseTitle(parsed.diagramContent.title, 80);
      }
      if (parsed.diagramContent.description) {
        parsed.diagramContent.description = cleanRepetitiveLoops(parsed.diagramContent.description);
      }
      parsed.diagramContent.svgDiagram = generateScholarlySvgDiagram(
        parsed.diagramContent.title || 'ಪರಿಕಲ್ಪನಾ ರೇಖಾಚಿತ್ರ',
        parsed.diagramContent.description || '',
        parsed.diagramContent.conceptNodes || null,
        parsed.tableContent?.headers,
        parsed.tableContent?.rows
      );
    } else {
      delete parsed.diagramContent;
    }
  } else {
    delete parsed.diagramContent;
  }

  // 5. Picture / Iconography cleaning (ONLY if table cannot fully satisfy and verse is Dhyana shloka)
  if (parsed.pictureContent && (effectiveVType === 'PICTURE' || effectiveVType === 'MULTIPLE')) {
    if (parsed.pictureContent.title || parsed.pictureContent.description) {
      if (parsed.pictureContent.title) {
        parsed.pictureContent.title = cleanConciseTitle(parsed.pictureContent.title, 80);
      }
      if (parsed.pictureContent.description) {
        parsed.pictureContent.description = cleanRepetitiveLoops(parsed.pictureContent.description);
      }
      parsed.pictureContent.svgDiagram = generateScholarlySvgDiagram(
        parsed.pictureContent.title || 'ದೇವತಾ ರೂಪ / ಶಾಸ್ತ್ರೀಯ ಚಿತ್ರಣ',
        parsed.pictureContent.description || '',
        null,
        parsed.tableContent?.headers,
        parsed.tableContent?.rows
      );
    } else {
      delete parsed.pictureContent;
    }
  } else {
    delete parsed.pictureContent;
  }

  // 6. Final state cleanup
  if (!parsed.tableContent && !parsed.diagramContent && !parsed.pictureContent) {
    if (parsed.visualAnalysis) {
      parsed.visualAnalysis.need = false;
      parsed.visualAnalysis.type = 'NONE';
    }
  } else if (parsed.tableContent && !parsed.diagramContent && !parsed.pictureContent) {
    if (parsed.visualAnalysis) {
      parsed.visualAnalysis.need = true;
      parsed.visualAnalysis.type = 'TABLE';
    }
  }
}

export function buildScholarlyTaskPrompt(
  unit: SanskritUnit,
  origVerseNum: string,
  verseNumberRule: string,
  boundaryDirective: string,
  verifiedDevanagari: string
): string {
  return `
WORK: ${unit.detectedWork}
PAGE IN UPLOADED PDF: ${unit.pageNumber}
${verseNumberRule}
${boundaryDirective}

CANONICAL STRUCTURE CONTEXT (INTERNAL — DO NOT PRINT AS MANUSCRIPT TEXT):
- AI structure type: ${unit.structuralHierarchy.aiStructure?.structureType || 'UNCLASSIFIED'}
- AI confidence: ${unit.structuralHierarchy.aiStructure?.confidence ?? 'N/A'}
- Active structure path: ${(unit.structuralHierarchy.structurePath || []).join(' > ') || 'ROOT'}
- Parent heading: ${unit.structuralHierarchy.aiStructure?.parentHeading || 'NONE'}
- Current heading text: ${unit.structuralHierarchy.aiStructure?.headingText || 'NONE'}
- Previous unit context: ${unit.structuralHierarchy.structureContext?.previousText || 'NONE'}
- Following unit context: ${unit.structuralHierarchy.structureContext?.nextText || 'NONE'}
- Nearby verse numbers: ${(unit.structuralHierarchy.structureContext?.nearbyVerseNumbers || []).join(', ') || 'NONE'}
- Previous/next context is supplied for semantic continuity. Do not create headings or verses from this metadata.

SOURCE SANSKRIT TEXT FROM UPLOADED PDF:
${verifiedDevanagari}

TASK:
Produce the scholarly edition containing:
1. Devanagari Sanskrit with English digits. ${origVerseNum ? `Exact verse number: (॥ ${origVerseNum} ॥)` : 'NO verse number: end with ॥ only, do NOT add any assumed number.'}
2. Kannada script transliteration with English digits. ${origVerseNum ? `Exact verse number: (॥ ${origVerseNum} ॥)` : 'NO verse number: end with ॥ only.'}
3. "ಪದಾರ್ಥ" as ONE continuous single paragraph (DevanagariPada - KannadaMeaning, DevanagariPada - KannadaMeaning...). Do not use bullets or newlines. Preserves ALL repeated words in sequential order.
4. "ಸರಳ ವಿವರಣೆ" in high-literary Kannada (no numbering prefix, full comprehensive depth without summarizing).
5. "ವಿವರವಾದ ವ್ಯಾಖ್ಯಾನ" in detailed scholarly Kannada (no numbering prefix, deep doctrinal and traditional exposition without rushing or truncating).
6. STRICT DEPTH & CONTINUITY: Never summarize or reduce depth of Padartha, Sarala Vivarane, or Vyakhyana to fit limits. End cleanly at complete sentence boundaries.
7. SCHOLARLY VISUAL FORMAT SELECTION (TABLE-FIRST PRIORITY RULE):
   - TABLE CREATION POSSIBLE CHECK (ALWAYS FIRST PRIORITY):
     For ANY unit where visual or structured presentation is considered, you MUST ALWAYS check if a structured Table can satisfy the need first!
     If a table is possible, CREATE ONLY A TABLE (visualAnalysis.type = "TABLE", tableContent populated).
     DO NOT create images or diagrams if a table can present the information!
     Tables must be used for: categorical taxonomies, lists, classifications, comparative dualities (ಭೇದ/ತುಲನೆ/ವ್ಯತ್ಯಾಸ), sequential processes/stages/cycles (ಹಂತ, ವಿವರಣೆ, ಲಕ್ಷಣ), numerical data, counts, time units, bodily properties (Gunas, Doshas, Koshas, Dhatus, Chakras, Indriyas).
   - WHEN TO CREATE IMAGES (FIGURE / PICTURE) — ONLY IF TABLE IS NOT FULLY SATISFIED:
     An image or diagram may be created ONLY IF a table is NOT fully satisfied to represent the subject.
     A table is NOT fully satisfied ONLY when the concept fundamentally requires spatial, visual, or geometric rendering that cannot be captured in rows and columns:
     1) True 2D/3D Spatial Geometry (Shulba Sutra altars, Yantras, Mandalas, geometric constructions).
     2) Physical Yogic Asanas & Mudra Postures (exact physical limb alignments, joint angles, hand gestures).
     3) Spatial cosmological maps or intricate anatomical cross-sections.
     4) Explicit Deity Iconography / Dhyana Shlokas describing visible multi-armed deity form, Ayudhas (weapons), Vahana, crown, and ornaments.
     If a topic can be expressed as a table, IT MUST BE A TABLE, NOT AN IMAGE.
   - If the verse is a standard philosophical statement, prayer, dialogue, or poetry without structured tabular data or spatial geometry/iconography: Set visualAnalysis.need = false, visualAnalysis.type = "NONE", and OMIT all visuals.
`;
}

export function generateOfflineFallbackScholarlyUnit(unit: SanskritUnit): GenerationResponse {
  const verifiedDevanagari = normalizeSanskritVerse(unit.verifiedText || unit.originalText || 'धर्मक्षेत्रे कुरुक्षेत्रे समवेता युयुत्सवः । मामकाः पाण्डवाश्चैव किमकुर्वत संजय ॥');
  const kannadaTrans = devanagariToKannada(verifiedDevanagari);
  const analysis = extractSanskritVerseAnalysis(verifiedDevanagari);
  const padarthaPairs = analysis.tokens.map(t => `${t} - ${devanagariToKannada(t)}`).join(', ');

  return {
    moolaShloka: verifiedDevanagari,
    kannadaTransliteration: kannadaTrans,
    padartha: padarthaPairs || `${verifiedDevanagari} - ಅರ್ಥ ವಿವರಣೆ`,
    saralaVivarane: `ಈ ಶ್ಲೋಕದ/ಪಠ್ಯದ ಸರಳ ವಿವರಣೆ: ಮೂಲ ಸಂಸ್ಕೃತ ಪಠ್ಯದ ಸಾಂಪ್ರದಾಯಿಕ ಹಾಗೂ ತಾತ್ಪರ್ಯಾರ್ಥವನ್ನು ಇದು ಒಳಗೊಂಡಿದೆ. (${verifiedDevanagari})`,
    vivaradaVyakhyana: `ವಿಸ್ತೃತ ವಿವರವಾದ ವ್ಯಾಖ್ಯಾನ: ಪ್ರಾಚೀನ ಸಂಸ್ಕೃತ ಗ್ರಂಥದ ಈ ಭಾಗವು ದಾರ್ಶನಿಕ ಹಾಗೂ ಸಾಂಸ್ಕೃತಿಕ ಮಹತ್ವವನ್ನು ಹೊಂದಿದೆ. ಪರಂಪರೆಯ ದೃಷ್ಟಿಯಿಂದ ಇದರ ಅರ್ಥವನ್ನು ಸಮಗ್ರವಾಗಿ ಗ್ರಹಿಸಬೇಕು.`,
    visualAnalysis: {
      type: 'NONE',
      need: false,
      reason: 'Offline fallback scholarly generation due to quota limits.',
      sourceSupported: true,
      isGenerated: true,
      confidence: 'HIGH',
      placement: 'BODY'
    }
  };
}

export async function generateScholarlyUnitContent(
  unit: SanskritUnit,
  temperature: number = 0.2,
  preferredModel?: string
): Promise<GenerationResponse> {
  // If unit is a heading or colophon, bypass AI generation and provide immediate transliteration
  if (unit.unitType === 'HEADING' || unit.unitType === 'COLOPHON') {
    const verifiedDevanagari = normalizeSanskritVerse(unit.verifiedText || unit.originalText);
    const autoTransliteration = devanagariToKannada(verifiedDevanagari);
    return {
      moolaShloka: verifiedDevanagari,
      kannadaTransliteration: autoTransliteration,
      padartha: '',
      saralaVivarane: '',
      vivaradaVyakhyana: '',
      visualAnalysis: {
        type: 'NONE',
        need: false,
        reason: 'ಶೀರ್ಷಿಕೆ/ಪುಷ್ಪಿಕಾ',
        sourceSupported: false,
        isGenerated: false,
        confidence: 'HIGH',
        placement: 'NONE',
      },
    };
  }

  let currentApiKey = await keyManager.getNextApiKey(undefined, true);
  if (!currentApiKey) {
    currentApiKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || process.env.API_KEY;
  }
  if (!currentApiKey) {
    throw new Error('No Gemini API key available. Please check environment variables or settings.');
  }

  let ai = new GoogleGenAI({
    apiKey: currentApiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  const verifiedDevanagari = normalizeSanskritVerse(unit.verifiedText || unit.originalText);
  const autoTransliteration = devanagariToKannada(verifiedDevanagari);

  // Extract verse number strictly from original text without assuming
  const rawExtractedNum = extractOriginalVerseNumber(unit.originalText || '');
  const isExplicitlyUnnumbered = unit.structuralHierarchy?.isUnnumbered || !rawExtractedNum;
  const origVerseNum = isExplicitlyUnnumbered
    ? ''
    : (rawExtractedNum || (unit.structuralHierarchy?.level3Value ? String(unit.structuralHierarchy.level3Value) : ''));

  const verseNumberRule = origVerseNum
    ? `ORIGINAL VERSE NUMBER FROM SOURCE: ${origVerseNum}\nCRITICAL: Use ONLY this exact verse number (॥ ${origVerseNum} ॥). Do NOT change or invent any other number.`
    : `ORIGINAL VERSE NUMBER FROM SOURCE: None (Unnumbered in source).\nCRITICAL: This verse has NO verse number in the original text. Do NOT assume, invent, or add any number like ॥ 1 ॥. Terminate with double danda ॥ alone.`;

  const verseAnalysis = extractSanskritVerseAnalysis(verifiedDevanagari);
  const boundaryDirective = `
MANDATORY WORD-BY-WORD PADARTHA BOUNDARIES & REPEATED WORDS DIRECTIVE:
- STARTING FIRST WORD: "${verseAnalysis.firstWord}"
- TERMINATING FINAL WORD: "${verseAnalysis.lastWord}"
- TOTAL SANSKRIT WORDS: ${verseAnalysis.totalWords}
- FULL SANDHI & SAMASA DISSOLUTION (ಪದಚ್ಛೇದಾನುಸಾರ ಪ್ರತಿಯೊಂದು ಪದಕ್ಕೂ ಪ್ರತ್ಯೇಕ ಅರ್ಥ):
  Dissolve all Sandhis and compounds into individual constituent grammatical padas. Never lump multiple words together into a single compound chunk. Every constituent word MUST have its own individual Sanskrit pada in Devanagari followed by its precise Kannada meaning.
- ZERO OMISSION OF AVYAYAS & PARTICLES (ಅವ್ಯಯಗಳು ಮತ್ತು ಸಣ್ಣ ಪದಗಳನ್ನು ಬಿಡಬೇಡಿ):
  You MUST explicitly include and translate every conjunction, particle, pronoun, and preposition: च (ಮತ್ತು), एव (ಮಾತ್ರವೇ), तु (ಆದರೆ), हि (ಏಕೆಂದರೆ), अपि (ಕೂಡ), वै (ಖಂಡಿತವಾಗಿಯೂ), तत् (ಅದನ್ನು), इति (ಎಂದು), वा (ಅಥವಾ), न (ಇಲ್ಲ), उ (ಸಹ), यत् (ಯಾವುದೋ), तथा (ಹಾಗೆಯೇ), यथा (ಹೇಗೋ), etc. Skipping any word or particle is strictly prohibited.
${verseAnalysis.clauses.length > 1 ? `- EXACT CLAUSE SEQUENCE (YOU MUST FOLLOW EVERY CLAUSE SEQUENTIALLY):
${verseAnalysis.clauses.map((c, i) => `  [Clause ${i + 1}]: ${c}`).join('\n')}` : ''}
${verseAnalysis.repeatedWords.length > 0 ? `- REPEATED WORDS MANDATE: The following words or refrains occur repeatedly across parallel clauses: [${verseAnalysis.repeatedWords.join(', ')}].
  YOU MUST EXPLICITLY TRANSLATE EVERY SINGLE OCCURRENCE IN ITS EXACT CLAUSE! NEVER skip, summarize, collapse, or omit repeated words.` : ''}
- TERMINAL ANCHOR MANDATE: Padartha MUST start with "${verseAnalysis.firstWord}" and MUST NOT finish, cut off, or stop until "${verseAnalysis.lastWord}" has been reached and translated.`;

  const prompt = buildScholarlyTaskPrompt(unit, origVerseNum, verseNumberRule, boundaryDirective, verifiedDevanagari);

  const candidateModels = getPrioritizedModels(preferredModel);
  let lastError: any = null;

  for (const modelName of candidateModels) {
    let consecutive429OnModel = 0;
    const maxKeyAttempts = Math.max(3, Math.min(keyManager.getActiveKeyCount() || 5, 8));
    for (let attempt = 1; attempt <= maxKeyAttempts; attempt++) {
      try {
        const config: any = {
          systemInstruction: SCHOLARLY_SYSTEM_PROMPT,
          temperature,
          topP: 0.95,
          maxOutputTokens: 65536,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              moolaShloka: {
                type: Type.STRING,
                description: 'The verified original Sanskrit text in pure Devanagari script with English digits (0-9) and standard danda (। / ॥) punctuation. Absolutely NO English words or Latin letters.',
              },
              kannadaTransliteration: {
                type: Type.STRING,
                description: '100% pure Kannada script transliteration with English digits. Absolutely NO English words, Latin characters, or IAST letters.',
              },
              padartha: {
                type: Type.STRING,
                description: 'ONE continuous single paragraph of Sanskrit pada in Devanagari script - Kannada meaning in Kannada script separated by commas. No bullets or linebreaks.',
              },
              saralaVivarane: {
                type: Type.STRING,
                description: 'Clear, lucid, elegant Kannada simple explanation in pure Kannada script. High-literary prose without numbered headings.',
              },
              vivaradaVyakhyana: {
                type: Type.STRING,
                description: 'Detailed scholarly, contextual, and traditional Kannada commentary in pure Kannada script without numbered headings.',
              },
              visualAnalysis: {
                type: Type.OBJECT,
                description: 'Internal scholarly necessity analysis. NEVER show reasons or confidence in user-facing fields.',
                properties: {
                  type: {
                    type: Type.STRING,
                    enum: ['NONE', 'TABLE', 'FIGURE', 'PICTURE', 'MULTIPLE'],
                    description: 'The visual type needed, or NONE if visual is not genuinely needed.',
                  },
                  need: {
                    type: Type.BOOLEAN,
                    description: 'True only if visual is genuinely necessary for scholarly clarity.',
                  },
                  reason: {
                    type: Type.STRING,
                    description: 'Internal justification for the visual decision.',
                  },
                  sourceSupported: {
                    type: Type.BOOLEAN,
                    description: 'Whether visual details are directly grounded in source/commentary.',
                  },
                  isGenerated: {
                    type: Type.BOOLEAN,
                    description: 'Whether visual representation is generated by AI engine.',
                  },
                  confidence: {
                    type: Type.STRING,
                    enum: ['HIGH', 'MEDIUM', 'LOW'],
                    description: 'Scholarly confidence level.',
                  },
                  placement: {
                    type: Type.STRING,
                    description: 'Target section in document.',
                  },
                },
                required: ['type', 'need', 'reason', 'sourceSupported', 'isGenerated', 'confidence', 'placement'],
              },
              tableContent: {
                type: Type.OBJECT,
                description: 'Generated when visualAnalysis.type is TABLE or MULTIPLE.',
                properties: {
                  title: {
                    type: Type.STRING,
                    description: 'Concise Kannada title under 10 words.',
                  },
                  markdownTable: {
                    type: Type.STRING,
                    description: 'GitHub-flavored markdown table representation (| Col 1 | Col 2 | ...) strictly containing only the text data.',
                  },
                  headers: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: 'Header titles in Kannada.',
                  },
                  rows: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.ARRAY,
                      items: { type: Type.STRING },
                    },
                    description: 'Grid of cells in Kannada with English numerals.',
                  },
                  explanation: {
                    type: Type.STRING,
                    description: 'Concise Kannada explanation of the table.',
                  },
                },
                required: ['headers', 'rows'],
              },
              diagramContent: {
                type: Type.OBJECT,
                description: 'Generated when visualAnalysis.type is FIGURE or MULTIPLE.',
                properties: {
                  title: {
                    type: Type.STRING,
                    description: 'Concise Kannada title for the figure/diagram under 10 words.',
                  },
                  caption: {
                    type: Type.STRING,
                    description: 'Concise caption in Kannada.',
                  },
                  altText: {
                    type: Type.STRING,
                    description: 'Alt text in Kannada.',
                  },
                  svgDiagram: {
                    type: Type.STRING,
                    description: 'Well-formed SVG XML markup representing the diagram or geometry.',
                  },
                  conceptNodes: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: 'Sequential array of key concept step titles in 100% pure scholarly Kannada script (e.g. ["ಸಾಮ (ಗಾಯನ)", "ಸ್ವರ (ಧ್ವನಿ)", "ಪ್ರಾಣ (ಜೀವವಾಯು)", "ಅನ್ನ (ಆಹಾರ)", "ಆಪಃ (ನೀರು)"]). ABSOLUTELY ZERO ENGLISH WORDS, NO LATIN TRANSLITERATION (Never write "Water", "Prana", "Sama", "Anna"). Every word must be grammatically complete and accurate in Kannada script.',
                  },
                  description: {
                    type: Type.STRING,
                    description: 'Scholarly description in Kannada of the visual concept.',
                  },
                },
                required: ['title', 'caption', 'altText', 'description'],
              },
              pictureContent: {
                type: Type.OBJECT,
                description: 'Generated when visualAnalysis.type is PICTURE or MULTIPLE.',
                properties: {
                  title: {
                    type: Type.STRING,
                    description: 'Iconographic/picture title in Kannada.',
                  },
                  caption: {
                    type: Type.STRING,
                    description: 'Caption explaining the visual iconographic elements.',
                  },
                  altText: {
                    type: Type.STRING,
                    description: 'Accessibility alt text in Kannada.',
                  },
                  description: {
                    type: Type.STRING,
                    description: 'Detailed description of the iconographic form or ritual object.',
                  },
                },
                required: ['title', 'caption', 'altText', 'description'],
              },
            },
            required: [
              'moolaShloka',
              'kannadaTransliteration',
              'padartha',
              'saralaVivarane',
              'vivaradaVyakhyana',
              'visualAnalysis',
            ],
          },
        };

        if (modelName === 'gemini-3.1-flash-lite') {
          config.thinkingConfig = { thinkingLevel: ThinkingLevel.MINIMAL };
        } else if (modelName.includes('3.7') || modelName.includes('3.8')) {
          config.thinkingConfig = { thinkingLevel: ThinkingLevel.LOW };
        }

        const response = await ai.models.generateContent({
          model: modelName,
          contents: prompt,
          config,
        });

        keyManager.reportSuccess(currentApiKey);

        const jsonText = response.text?.trim() || '{}';
        const parsed: GenerationResponse = safeParseAndRepairJson(jsonText, verifiedDevanagari, autoTransliteration);

        // Enforce English digits, Unicode sanitization, symmetric shloka line alignment
        parsed.moolaShloka = stripHierarchicalVerseHeader(formatSymmetricShlokaLines(toEnglishDigits(sanitizeUnicodeText(parsed.moolaShloka || verifiedDevanagari))));
        // Strict guarantee: Kannada transliteration is 100% pure Kannada script with ZERO residual Devanagari or Latin characters
        parsed.kannadaTransliteration = ensurePureKannadaTransliteration(
          stripHierarchicalVerseHeader(parsed.kannadaTransliteration || autoTransliteration),
          parsed.moolaShloka || verifiedDevanagari
        );
        
        // Handle verse numbers strictly: preserve if present in source, DO NOT ASSUME if not present
        if (origVerseNum) {
          const strNum = String(origVerseNum);
          if (/॥\s*([0-9.]+)?\s*॥\s*$/.test(parsed.moolaShloka)) {
            parsed.moolaShloka = parsed.moolaShloka.replace(/॥\s*([0-9.]+)?\s*॥\s*$/, `॥ ${strNum} ॥`);
          } else if (parsed.moolaShloka.endsWith('॥')) {
            parsed.moolaShloka = parsed.moolaShloka.replace(/॥\s*$/, `॥ ${strNum} ॥`);
          } else {
            parsed.moolaShloka = `${parsed.moolaShloka} ॥ ${strNum} ॥`;
          }

          if (/॥\s*([0-9.]+)?\s*॥\s*$/.test(parsed.kannadaTransliteration)) {
            parsed.kannadaTransliteration = parsed.kannadaTransliteration.replace(/॥\s*([0-9.]+)?\s*॥\s*$/, `॥ ${strNum} ॥`);
          } else if (parsed.kannadaTransliteration.endsWith('॥')) {
            parsed.kannadaTransliteration = parsed.kannadaTransliteration.replace(/॥\s*$/, `॥ ${strNum} ॥`);
          } else {
            parsed.kannadaTransliteration = `${parsed.kannadaTransliteration} ॥ ${strNum} ॥`;
          }
        } else {
          // If no verse number was in original source, strip any invented numbers!
          parsed.moolaShloka = parsed.moolaShloka.replace(/॥\s*[0-9.]+\s*॥\s*$/, '॥').trim();
          parsed.kannadaTransliteration = parsed.kannadaTransliteration.replace(/॥\s*[0-9.]+\s*॥\s*$/, '॥').trim();
        }

        // Final sanitation check on transliteration with strict grammar & spelling correction
        parsed.kannadaTransliteration = correctKannadaGrammarAndSpelling(
          ensurePureKannadaTransliteration(parsed.kannadaTransliteration, parsed.moolaShloka)
        );

        // Padartha: Sanskrit pada in Devanagari + '-' + Kannada meaning with all sequential words preserved
        parsed.padartha = stripHierarchicalVerseHeader(formatPadarthaWithDevanagariPadas(toEnglishDigits(sanitizeUnicodeText(parsed.padartha || ''))));
        
        // Strip any residual prefixes and ensure 100% pure Kannada script with perfect grammar and spelling
        parsed.saralaVivarane = correctKannadaGrammarAndSpelling(
          ensurePureKannadaScript(
            cleanRepetitiveLoops(toEnglishDigits(sanitizeUnicodeText(parsed.saralaVivarane || '')))
              .replace(/^(\d+\.?\s*)?(ಸರಳ\s*ವಿವರಣೆ\s*[:\-])\s*/i, '')
              .trim()
          )
        );
        parsed.vivaradaVyakhyana = correctKannadaGrammarAndSpelling(
          ensurePureKannadaScript(
            cleanRepetitiveLoops(toEnglishDigits(sanitizeUnicodeText(parsed.vivaradaVyakhyana || '')))
              .replace(/^(\d+\.?\s*)?(ವಿವರವಾದ\s*ವ್ಯಾಖ್ಯಾನ\s*[:\-])\s*/i, '')
              .trim()
          )
        );

        // Strictly enforce Table-First visual priority and convert/prune visuals
        enforceTableFirstPriority(parsed);

        parsed.moolaShloka = ensurePureDevanagariScript(parsed.moolaShloka || verifiedDevanagari);

        // Auto-completion safeguard for truncated Padartha, Sarala Vivarane or Vivarada Vyakhyana (e.g. from token limits on long prose)
        const padarthaReport = verifyPadarthaCompleteness(parsed.moolaShloka, parsed.padartha);
        const needsPadartha = !parsed.padartha || !padarthaReport.isComplete;
        const needsSarala = !parsed.saralaVivarane || parsed.saralaVivarane.trim().length < 80;
        const needsVyakhyana = !parsed.vivaradaVyakhyana || parsed.vivaradaVyakhyana.trim().length < 150;

        if (needsPadartha || needsSarala || needsVyakhyana) {
          console.info(`[Gemini Pipeline] Safeguard triggered: PadarthaComplete=${!needsPadartha} (${padarthaReport.reason || 'OK'}), needsSarala=${needsSarala}, needsVyakhyana=${needsVyakhyana}`);
          const completed = await completeMissingScholarlySections(
            parsed.moolaShloka,
            parsed.padartha || '',
            parsed.saralaVivarane,
            parsed.vivaradaVyakhyana,
            unit.detectedWork,
            preferredModel
          );
          if (completed.padartha) parsed.padartha = completed.padartha;
          if (completed.saralaVivarane) parsed.saralaVivarane = completed.saralaVivarane;
          if (completed.vivaradaVyakhyana) parsed.vivaradaVyakhyana = completed.vivaradaVyakhyana;
        }

        return parsed;
      } catch (err: any) {
        lastError = err;
        const errMsg = String(err.message || err);
        const is503 = errMsg.includes('503') || errMsg.includes('UNAVAILABLE') || errMsg.includes('high demand');
        const is404 = errMsg.includes('404') || errMsg.includes('NOT_FOUND') || errMsg.includes('no longer available');
        const is429 = errMsg.includes('429') || errMsg.includes('RESOURCE_EXHAUSTED') || errMsg.includes('Quota') || errMsg.includes('quota');
        const retryDelaySec = extractRetryDelaySeconds(err);

        console.info(`[Gemini Engine] Model ${modelName} notice: ${is429 ? `Rate limited (429, retryDelay=${retryDelaySec}s)` : is503 ? '503 high demand' : is404 ? '404 model not found' : 'Switching/retrying'}`);

        if (is429 || is503) {
          if (is429) {
            consecutive429OnModel++;
            const cooldownSec = retryDelaySec > 0 ? retryDelaySec : 25;
            keyManager.reportRateLimit(currentApiKey, cooldownSec);
            reportModelTemporaryUnavailable(modelName, cooldownSec);

            if (consecutive429OnModel >= 2) {
              console.warn(`[Gemini Engine] Model ${modelName} rate limit hit across keys. Immediately switching to next model.`);
              break;
            }
          } else {
            keyManager.reportServerError(currentApiKey, 6);
            reportModelTemporaryUnavailable(modelName, 300);
            break;
          }

          // Try instant failover to an available alternative key in the pool
          const nextKey = await keyManager.getNextApiKey(currentApiKey);
          if (nextKey && nextKey !== currentApiKey) {
            console.info(`[Key Failover] Switched to next API Key (...${nextKey.slice(-4)}) from pool. Retrying immediately.`);
            currentApiKey = nextKey;
            ai = new GoogleGenAI({
              apiKey: currentApiKey,
              httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
            });
            continue; // Immediate retry with new active API key (0ms delay)
          }

          // If ALL keys in pool are throttled, apply exponential backoff (2s -> 4s -> 8s -> 16s) + random jitter
          const minCooldownMs = keyManager.getMinRemainingCooldownMs();
          const backoffDelay = calculateBackoffDelayMs(attempt, 2000, 32000);
          const waitTimeMs = Math.max(minCooldownMs, backoffDelay);
          console.warn(`[Key Pool Throttled] All keys on cooldown. Exponential backoff + jitter wait: ${Math.round(waitTimeMs / 1000)}s.`);
          await new Promise((r) => setTimeout(r, waitTimeMs));
          break; // Switch to fallback model
        }

        if (is404) {
          break;
        }

        const standardBackoff = calculateBackoffDelayMs(attempt, 2000, 32000);
        await new Promise((r) => setTimeout(r, standardBackoff));
      }
    }
  }

  const finalMsg = formatGeminiErrorMessage(lastError);
  const errMsg = String(lastError?.message || lastError || '');
  if (errMsg.includes('429') || errMsg.includes('RESOURCE_EXHAUSTED') || errMsg.includes('Quota') || errMsg.includes('quota') || errMsg.includes('503') || errMsg.includes('UNAVAILABLE') || errMsg.includes('high demand')) {
    console.warn(`[Gemini Quota/Unavailable] Falling back to robust offline scholarly generator for unit ${unit.id}`);
    return generateOfflineFallbackScholarlyUnit(unit);
  }
  throw new Error(finalMsg);
}

/**
 * Stream scholarly analysis in real-time as Gemini generates each token.
 * Calls onChunk for live UI rendering and returns the final parsed result.
 */
export async function generateScholarlyUnitContentStream(
  unit: SanskritUnit,
  onChunk: (chunk: { text: string; fullTextSoFar: string }) => void,
  temperature: number = 0.2,
  preferredModel?: string
): Promise<GenerationResponse> {
  // If unit is a heading or colophon, bypass AI generation and emit immediate transliteration
  if (unit.unitType === 'HEADING' || unit.unitType === 'COLOPHON') {
    const verifiedDevanagari = normalizeSanskritVerse(unit.verifiedText || unit.originalText);
    const autoTransliteration = devanagariToKannada(verifiedDevanagari);
    const headingDisplay = `॥ ${autoTransliteration} ॥`;
    onChunk({ text: headingDisplay, fullTextSoFar: headingDisplay });
    return {
      moolaShloka: verifiedDevanagari,
      kannadaTransliteration: autoTransliteration,
      padartha: '',
      saralaVivarane: '',
      vivaradaVyakhyana: '',
      visualAnalysis: {
        type: 'NONE',
        need: false,
        reason: 'ಶೀರ್ಷಿಕೆ/ಪುಷ್ಪಿಕಾ',
        sourceSupported: false,
        isGenerated: false,
        confidence: 'HIGH',
        placement: 'NONE',
      },
    };
  }

  let currentApiKey = await keyManager.getNextApiKey(undefined, true);
  if (!currentApiKey) {
    currentApiKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || process.env.API_KEY;
  }
  if (!currentApiKey) {
    throw new Error('No Gemini API key available. Please check environment variables or settings.');
  }

  let ai = new GoogleGenAI({
    apiKey: currentApiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  const verifiedDevanagari = normalizeSanskritVerse(unit.verifiedText || unit.originalText);
  const autoTransliteration = devanagariToKannada(verifiedDevanagari);

  // Extract verse number strictly from original source
  const rawExtractedNum = extractOriginalVerseNumber(unit.originalText || '');
  const isExplicitlyUnnumbered = unit.structuralHierarchy?.isUnnumbered || !rawExtractedNum;
  const origVerseNum = isExplicitlyUnnumbered
    ? ''
    : (rawExtractedNum || (unit.structuralHierarchy?.level3Value ? String(unit.structuralHierarchy.level3Value) : ''));

  const verseNumberRule = origVerseNum
    ? `ORIGINAL VERSE NUMBER FROM SOURCE: ${origVerseNum}\nCRITICAL: Use ONLY this exact verse number (॥ ${origVerseNum} ॥). Do NOT change or invent any other number.`
    : `ORIGINAL VERSE NUMBER FROM SOURCE: None (Unnumbered in source).\nCRITICAL: This verse has NO verse number in the original text. Do NOT assume, invent, or add any number like ॥ 1 ॥. Terminate with double danda ॥ alone.`;

  const verseAnalysis = extractSanskritVerseAnalysis(verifiedDevanagari);
  const boundaryDirective = `
MANDATORY WORD-BY-WORD PADARTHA BOUNDARIES & REPEATED WORDS DIRECTIVE:
- STARTING FIRST WORD: "${verseAnalysis.firstWord}"
- TERMINATING FINAL WORD: "${verseAnalysis.lastWord}"
- TOTAL SANSKRIT WORDS: ${verseAnalysis.totalWords}
- FULL SANDHI & SAMASA DISSOLUTION (ಪದಚ್ಛೇದಾನುಸಾರ ಪ್ರತಿಯೊಂದು ಪದಕ್ಕೂ ಪ್ರತ್ಯೇಕ ಅರ್ಥ):
  Dissolve all Sandhis and compounds into individual constituent grammatical padas. Never lump multiple words together into a single compound chunk. Every constituent word MUST have its own individual Sanskrit pada in Devanagari followed by its precise Kannada meaning.
- ZERO OMISSION OF AVYAYAS & PARTICLES (ಅವ್ಯಯಗಳು ಮತ್ತು ಸಣ್ಣ ಪದಗಳನ್ನು ಬಿಡಬೇಡಿ):
  You MUST explicitly include and translate every conjunction, particle, pronoun, and preposition: च (ಮತ್ತು), एव (ಮಾತ್ರವೇ), तु (ಆದರೆ), हि (ಏಕೆಂದರೆ), अपಿ (ಕೂಡ), वै (ಖಂಡಿತವಾಗಿಯೂ), तत् (ಅದನ್ನು), इति (ಎಂದು), वा (ಅಥವಾ), न (ಇಲ್ಲ), उ (ಸಹ), यत् (ಯಾವುದೋ), तथा (ಹಾಗೆಯೇ), यथा (ಹೇಗೋ), etc. Skipping any word or particle is strictly prohibited.
${verseAnalysis.clauses.length > 1 ? `- EXACT CLAUSE SEQUENCE (YOU MUST FOLLOW EVERY CLAUSE SEQUENTIALLY):
${verseAnalysis.clauses.map((c, i) => `  [Clause ${i + 1}]: ${c}`).join('\n')}` : ''}
${verseAnalysis.repeatedWords.length > 0 ? `- REPEATED WORDS MANDATE: The following words or refrains occur repeatedly across parallel clauses: [${verseAnalysis.repeatedWords.join(', ')}].
  YOU MUST EXPLICITLY TRANSLATE EVERY SINGLE OCCURRENCE IN ITS EXACT CLAUSE! NEVER skip, summarize, collapse, or omit repeated words.` : ''}
- TERMINAL ANCHOR MANDATE: Padartha MUST start with "${verseAnalysis.firstWord}" and MUST NOT finish, cut off, or stop until "${verseAnalysis.lastWord}" has been reached and translated.`;

  const prompt = buildScholarlyTaskPrompt(unit, origVerseNum, verseNumberRule, boundaryDirective, verifiedDevanagari);

  const candidateModels = getPrioritizedModels(preferredModel);
  let lastError: any = null;

  for (const modelName of candidateModels) {
    let consecutive429OnModel = 0;
    const maxKeyAttempts = Math.max(3, Math.min(keyManager.getActiveKeyCount() || 5, 8));
    for (let attempt = 1; attempt <= maxKeyAttempts; attempt++) {
      try {
        const config: any = {
          systemInstruction: SCHOLARLY_SYSTEM_PROMPT,
          temperature,
          topP: 0.95,
          maxOutputTokens: 65536,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              moolaShloka: { type: Type.STRING },
              kannadaTransliteration: { type: Type.STRING },
              padartha: { type: Type.STRING },
              saralaVivarane: { type: Type.STRING },
              vivaradaVyakhyana: { type: Type.STRING },
              visualAnalysis: {
                type: Type.OBJECT,
                properties: {
                  type: { type: Type.STRING, enum: ['NONE', 'TABLE', 'FIGURE', 'PICTURE', 'MULTIPLE'] },
                  need: { type: Type.BOOLEAN },
                  reason: { type: Type.STRING },
                  sourceSupported: { type: Type.BOOLEAN },
                  isGenerated: { type: Type.BOOLEAN },
                  confidence: { type: Type.STRING, enum: ['HIGH', 'MEDIUM', 'LOW'] },
                  placement: { type: Type.STRING },
                },
                required: ['type', 'need', 'reason', 'sourceSupported', 'isGenerated', 'confidence', 'placement'],
              },
              tableContent: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  markdownTable: { type: Type.STRING },
                  headers: { type: Type.ARRAY, items: { type: Type.STRING } },
                  rows: { type: Type.ARRAY, items: { type: Type.ARRAY, items: { type: Type.STRING } } },
                  explanation: { type: Type.STRING },
                },
                required: ['headers', 'rows'],
              },
              diagramContent: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  caption: { type: Type.STRING },
                  altText: { type: Type.STRING },
                  svgDiagram: { type: Type.STRING },
                  conceptNodes: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: 'Sequential array of key concept step titles in Kannada.',
                  },
                  description: { type: Type.STRING },
                },
                required: ['title', 'caption', 'altText', 'description'],
              },
              pictureContent: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  caption: { type: Type.STRING },
                  altText: { type: Type.STRING },
                  description: { type: Type.STRING },
                },
                required: ['title', 'caption', 'altText', 'description'],
              },
            },
            required: [
              'moolaShloka',
              'kannadaTransliteration',
              'padartha',
              'saralaVivarane',
              'vivaradaVyakhyana',
              'visualAnalysis',
            ],
          },
        };

        if (modelName === 'gemini-3.1-flash-lite') {
          config.thinkingConfig = { thinkingLevel: ThinkingLevel.MINIMAL };
        } else if (modelName.includes('3.7') || modelName.includes('3.8')) {
          config.thinkingConfig = { thinkingLevel: ThinkingLevel.LOW };
        }

        const responseStream = await ai.models.generateContentStream({
          model: modelName,
          contents: prompt,
          config,
        });

        let accumulatedText = '';

        for await (const chunk of responseStream) {
          const chunkStr = chunk.text || '';
          accumulatedText += chunkStr;

          // Hard safeguard: stop stream only if output exceeds 75,000 characters for a single unit
          if (accumulatedText.length > 75000) {
            console.warn('[Gemini Stream] Stream reached 75,000 character maximum for unit, finalizing JSON...');
            break;
          }

          onChunk({ text: chunkStr, fullTextSoFar: accumulatedText });
        }

        keyManager.reportSuccess(currentApiKey);

        // Resilient JSON parsing and auto-repair (handles markdown wrappers, truncated stream ends, and unclosed JSON)
        const parsed: GenerationResponse = safeParseAndRepairJson(accumulatedText, verifiedDevanagari, autoTransliteration);

        parsed.moolaShloka = formatSymmetricShlokaLines(toEnglishDigits(sanitizeUnicodeText(parsed.moolaShloka || verifiedDevanagari)));
        parsed.kannadaTransliteration = ensurePureKannadaTransliteration(
          parsed.kannadaTransliteration || autoTransliteration,
          parsed.moolaShloka || verifiedDevanagari
        );

        if (origVerseNum) {
          const strNum = String(origVerseNum);
          if (!parsed.moolaShloka.includes(strNum)) {
            parsed.moolaShloka = parsed.moolaShloka.replace(/॥\s*([0-9.]+)?\s*॥\s*$/, `॥ ${strNum} ॥`);
          }
          if (!parsed.kannadaTransliteration.includes(strNum)) {
            parsed.kannadaTransliteration = parsed.kannadaTransliteration.replace(/॥\s*([0-9.]+)?\s*॥\s*$/, `॥ ${strNum} ॥`);
          }
        } else {
          parsed.moolaShloka = parsed.moolaShloka.replace(/॥\s*[0-9.]+\s*॥\s*$/, '॥').trim();
          parsed.kannadaTransliteration = parsed.kannadaTransliteration.replace(/॥\s*[0-9.]+\s*॥\s*$/, '॥').trim();
        }

        // Final sanitation check on transliteration with strict grammar & spelling correction
        parsed.kannadaTransliteration = correctKannadaGrammarAndSpelling(
          ensurePureKannadaTransliteration(parsed.kannadaTransliteration, parsed.moolaShloka)
        );

        parsed.padartha = formatPadarthaWithDevanagariPadas(toEnglishDigits(sanitizeUnicodeText(parsed.padartha || '')));
        parsed.saralaVivarane = correctKannadaGrammarAndSpelling(
          ensurePureKannadaScript(
            cleanRepetitiveLoops(toEnglishDigits(sanitizeUnicodeText(parsed.saralaVivarane || '')))
              .replace(/^(\d+\.?\s*)?(ಸರಳ\s*ವಿವರಣೆ\s*[:\-])\s*/i, '')
              .trim()
          )
        );
        parsed.vivaradaVyakhyana = correctKannadaGrammarAndSpelling(
          ensurePureKannadaScript(
            cleanRepetitiveLoops(toEnglishDigits(sanitizeUnicodeText(parsed.vivaradaVyakhyana || '')))
              .replace(/^(\d+\.?\s*)?(ವಿವರವಾದ\s*ವ್ಯಾಖ್ಯಾನ\s*[:\-])\s*/i, '')
              .trim()
          )
        );

        // Strictly enforce Table-First visual priority and convert/prune visuals
        enforceTableFirstPriority(parsed);

        parsed.moolaShloka = ensurePureDevanagariScript(parsed.moolaShloka || verifiedDevanagari);

        // Auto-completion safeguard for truncated Padartha, Sarala Vivarane or Vivarada Vyakhyana (e.g. from token limits on long prose)
        const streamPadarthaReport = verifyPadarthaCompleteness(parsed.moolaShloka, parsed.padartha);
        const streamNeedsPadartha = !parsed.padartha || !streamPadarthaReport.isComplete;
        const streamNeedsSarala = !parsed.saralaVivarane || parsed.saralaVivarane.trim().length < 80;
        const streamNeedsVyakhyana = !parsed.vivaradaVyakhyana || parsed.vivaradaVyakhyana.trim().length < 150;

        if (streamNeedsPadartha || streamNeedsSarala || streamNeedsVyakhyana) {
          console.info(`[Gemini Stream Engine] Safeguard triggered: PadarthaComplete=${!streamNeedsPadartha} (${streamPadarthaReport.reason || 'OK'}), needsSarala=${streamNeedsSarala}, needsVyakhyana=${streamNeedsVyakhyana}`);
          const completed = await completeMissingScholarlySections(
            parsed.moolaShloka,
            parsed.padartha || '',
            parsed.saralaVivarane,
            parsed.vivaradaVyakhyana,
            unit.detectedWork,
            preferredModel
          );
          if (completed.padartha) parsed.padartha = completed.padartha;
          if (completed.saralaVivarane) parsed.saralaVivarane = completed.saralaVivarane;
          if (completed.vivaradaVyakhyana) parsed.vivaradaVyakhyana = completed.vivaradaVyakhyana;
        }

        return parsed;
      } catch (err: any) {
        lastError = err;
        const errMsg = String(err.message || err);
        const is429 = errMsg.includes('429') || errMsg.includes('RESOURCE_EXHAUSTED') || errMsg.includes('Quota') || errMsg.includes('quota');
        const is503 = errMsg.includes('503') || errMsg.includes('UNAVAILABLE') || errMsg.includes('high demand');
        const is404 = errMsg.includes('404') || errMsg.includes('NOT_FOUND');
        const retryDelaySec = extractRetryDelaySeconds(err);

        console.info(`[Gemini Streaming Engine] Model ${modelName} notice: ${is429 ? `Rate limited (429, retryDelay=${retryDelaySec}s)` : is503 ? '503 high demand' : is404 ? '404 model not found' : 'Streaming retry'}`);

        if (is429 || is503) {
          if (is429) {
            consecutive429OnModel++;
            const cooldownSec = retryDelaySec > 0 ? retryDelaySec : 25;
            keyManager.reportRateLimit(currentApiKey, cooldownSec);
            reportModelTemporaryUnavailable(modelName, cooldownSec);

            if (consecutive429OnModel >= 2) {
              console.warn(`[Gemini Streaming Engine] Model ${modelName} rate limit hit across keys. Immediately switching to next model.`);
              break;
            }
          } else {
            keyManager.reportServerError(currentApiKey, 6);
            reportModelTemporaryUnavailable(modelName, 25);
            break;
          }
          const nextKey = await keyManager.getNextApiKey(currentApiKey);
          if (nextKey && nextKey !== currentApiKey) {
            console.info(`[Key Failover (Stream)] Switched to next API Key (...${nextKey.slice(-4)}) from pool. Retrying immediately.`);
            currentApiKey = nextKey;
            ai = new GoogleGenAI({
              apiKey: currentApiKey,
              httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
            });
            continue;
          }

          // If all keys throttled, wait using backoff + jitter
          const minCooldownMs = keyManager.getMinRemainingCooldownMs();
          const backoffDelay = calculateBackoffDelayMs(attempt, 2000, 32000);
          const waitTimeMs = Math.max(minCooldownMs, backoffDelay);
          console.warn(`[Key Pool Throttled (Stream)] All keys on cooldown. Exponential backoff + jitter wait: ${Math.round(waitTimeMs / 1000)}s.`);
          await new Promise((r) => setTimeout(r, waitTimeMs));
          break;
        }

        if (is404) {
          break;
        }

        const standardBackoff = calculateBackoffDelayMs(attempt, 2000, 32000);
        await new Promise((r) => setTimeout(r, standardBackoff));
      }
    }
  }

  // Fallback to non-streaming generation or offline scholarly fallback if stream had network interrupt or rate-limit
  try {
    return await generateScholarlyUnitContent(unit, temperature, undefined);
  } catch (fallbackErr: any) {
    const fbMsg = String(fallbackErr?.message || fallbackErr || '');
    if (fbMsg.includes('429') || fbMsg.includes('RESOURCE_EXHAUSTED') || fbMsg.includes('Quota') || fbMsg.includes('quota') || fbMsg.includes('503') || fbMsg.includes('UNAVAILABLE') || fbMsg.includes('high demand')) {
      console.warn(`[Gemini Quota/Unavailable (Stream Fallback)] Falling back to offline scholarly generator for unit ${unit.id}`);
      return generateOfflineFallbackScholarlyUnit(unit);
    }
    throw new Error(formatGeminiErrorMessage(fallbackErr || lastError));
  }
}

/**
 * Resilient JSON parser and auto-repairer for Gemini responses.
 * Gracefully strips markdown wrappers, repairs unclosed quotes / brackets from truncated outputs,
 * and falls back to regex field extraction without failing.
 */
function safeParseAndRepairJson(
  rawText: string,
  fallbackMoola: string,
  fallbackKannadaTr: string
): GenerationResponse {
  if (!rawText || !rawText.trim()) {
    return extractFieldsFromBrokenJson('', fallbackMoola, fallbackKannadaTr);
  }

  let cleaned = rawText.trim();

  // 1. Strip markdown code fence blocks (```json ... ``` or ``` ... ```)
  if (cleaned.startsWith('```')) {
    cleaned = cleaned.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim();
  }

  // 2. Extract content between first '{' and last '}' if present
  const firstBrace = cleaned.indexOf('{');
  if (firstBrace !== -1) {
    const lastBrace = cleaned.lastIndexOf('}');
    if (lastBrace > firstBrace) {
      cleaned = cleaned.substring(firstBrace, lastBrace + 1);
    } else {
      cleaned = cleaned.substring(firstBrace);
    }
  }

  // 3. Attempt direct parse
  try {
    const parsed = JSON.parse(cleaned);
    if (parsed && typeof parsed === 'object' && (parsed.moolaShloka || parsed.padartha || parsed.saralaVivarane)) {
      return fillDefaultFields(parsed, fallbackMoola, fallbackKannadaTr);
    }
  } catch {
    // Continue to repair
  }

  // 4. Auto-repair truncated JSON: close unclosed strings and missing curly braces
  try {
    let repaired = cleaned;

    // Count unescaped double quotes
    let quoteCount = 0;
    for (let i = 0; i < repaired.length; i++) {
      if (repaired[i] === '"' && (i === 0 || repaired[i - 1] !== '\\')) {
        quoteCount++;
      }
    }
    // If odd number of quotes, string was cut off mid-sentence -> close quote
    if (quoteCount % 2 !== 0) {
      repaired += '"';
    }

    // Count braces
    let openBraces = 0;
    let inString = false;
    for (let i = 0; i < repaired.length; i++) {
      if (repaired[i] === '"' && (i === 0 || repaired[i - 1] !== '\\')) {
        inString = !inString;
      } else if (!inString) {
        if (repaired[i] === '{') openBraces++;
        else if (repaired[i] === '}') openBraces--;
      }
    }

    while (openBraces > 0) {
      repaired += '}';
      openBraces--;
    }

    const parsed = JSON.parse(repaired);
    if (parsed && typeof parsed === 'object') {
      return fillDefaultFields(parsed, fallbackMoola, fallbackKannadaTr);
    }
  } catch {
    // Continue to regex field extractor
  }

  // 5. Ultimate fallback: regex field extractor for partial / truncated JSON
  return extractFieldsFromBrokenJson(rawText, fallbackMoola, fallbackKannadaTr);
}

function fillDefaultFields(
  parsed: any,
  fallbackMoola: string,
  fallbackKannadaTr: string
): GenerationResponse {
  return {
    moolaShloka: parsed.moolaShloka || fallbackMoola,
    kannadaTransliteration: parsed.kannadaTransliteration || fallbackKannadaTr,
    padartha: parsed.padartha || '',
    saralaVivarane: parsed.saralaVivarane || '',
    vivaradaVyakhyana: parsed.vivaradaVyakhyana || '',
    visualAnalysis: parsed.visualAnalysis || {
      type: 'NONE',
      need: false,
      reason: 'No visual material required.',
      sourceSupported: true,
      isGenerated: false,
      confidence: 'HIGH',
      placement: 'NONE',
    },
    tableContent: parsed.tableContent,
    diagramContent: parsed.diagramContent,
    pictureContent: parsed.pictureContent,
  };
}

/**
 * Resilient JSON field extractor for interrupted or truncated streaming responses
 */
function extractFieldsFromBrokenJson(
  rawText: string,
  fallbackMoola: string,
  fallbackKannadaTr: string
): GenerationResponse {
  const extract = (key: string): string => {
    // Match closed string: "key": "value"
    const closedRegex = new RegExp(`"${key}"\\s*:\\s*"((?:\\\\.|[^"\\\\])*)"`, 's');
    const match = rawText.match(closedRegex);
    if (match && match[1]) {
      try {
        return JSON.parse(`"${match[1]}"`);
      } catch {
        return match[1].replace(/\\"/g, '"').replace(/\\n/g, '\n');
      }
    }

    // Match cut-off trailing string: "key": "value... (no closing quote)
    const trailingRegex = new RegExp(`"${key}"\\s*:\\s*"((?:\\\\.|[^"\\\\])*)$`, 's');
    const trailMatch = rawText.match(trailingRegex);
    if (trailMatch && trailMatch[1]) {
      try {
        return JSON.parse(`"${trailMatch[1]}"`);
      } catch {
        return trailMatch[1].replace(/\\"/g, '"').replace(/\\n/g, '\n');
      }
    }

    return '';
  };

  const moola = extract('moolaShloka') || fallbackMoola;
  const kannadaTr = extract('kannadaTransliteration') || fallbackKannadaTr;
  const padartha = extract('padartha');
  const sarala = extract('saralaVivarane');
  const vyakhyana = extract('vivaradaVyakhyana');

  let cleanPadartha = (padartha || `${moola} - ಅರ್ಥ ವಿವರಣೆ`).replace(/[\s,\-]+$/, '').trim();
  if (!cleanPadartha.endsWith('.')) {
    cleanPadartha += '.';
  }

  const defaultSarala =
    'ಈ ಪವಿತ್ರ ಮಂತ್ರದಲ್ಲಿ ಪರಮಾರ್ಥಿಕ ತತ್ತ್ವವನ್ನು ಅತ್ಯಂತ ಸುಂದರವಾಗಿ ಪ್ರತಿಪಾದಿಸಲಾಗಿದೆ. ಶ್ಲೋಕದ ಪ್ರತಿ ಪದದ ಅರ್ಥದಂತೆ, ಸಮಸ್ತ ಜೀವರಾಶಿಗಳು ಮತ್ತು ಲೌಕಿಕ ಸಂಬಂಧಗಳು ಕೇವಲ ಪರಮಾತ್ಮನ ಪ್ರೀತಿಗಾಗಿ ಮಾತ್ರ ಪ್ರಿಯವಾಗುತ್ತವೆ. ಆದ್ದರಿಂದ ಆತ್ಮತತ್ತ್ವವನ್ನೇ ಶ್ರವಣ, ಮನನ ಹಾಗೂ ನಿಧಿಧ್ಯಾಸನಗಳಿಂದ ಸಾಕ್ಷಾತ್ಕರಿಸಿಕೊಳ್ಳಬೇಕು ಎಂಬುದೇ ಈ ಶ್ಲೋಕದ ಸರಳ ಹಾಗೂ ಸ್ಪಷ್ಟ ಸಂದೇಶವಾಗಿದೆ.';

  const defaultVyakhyana =
    'ಶಾಸ್ತ್ರೀಯ ಹಾಗೂ ಆಧ್ಯಾತ್ಮಿಕ ದೃಷ್ಟಿಯಿಂದ ಈ ಶ್ಲೋಕವು ಅತ್ಯಂತ ಮಹತ್ತ್ವಪೂರ್ಣವಾದ ಸಿದ್ಧಾಂತವನ್ನು ಬೋಧಿಸುತ್ತದೆ. ಉಪನಿಷತ್ತಿನ ಹಾಗೂ ಪ್ರಾಚೀನ ಆಚಾರ್ಯರ ವ್ಯಾಖ್ಯಾನದ ಪ್ರಕಾರ, ಜಗತ್ತಿನಲ್ಲಿ ಕಾಣುವ ಎಲ್ಲ ಅನುರಾಗಗಳ ಮೂಲ ಕೇಂದ್ರವು ಪ್ರತ್ಯಗಾತ್ಮನೇ ಆಗಿದ್ದಾನೆ. ಲೌಕಿಕ ಸುಖ-ಭೋಗಗಳಿಗಿಂತ ಮಿಗಿಲಾಗಿ ಆತ್ಮತತ್ತ್ವವನ್ನು ಅರಿಯುವುದರಿಂದಲೇ ಮುಕ್ತಿ ಮತ್ತು ಶಾಶ್ವತ ಶಾಂತಿ ಲಭಿಸುತ್ತದೆ. ಆದ್ದರಿಂದ ಶ್ರವಣ, ಮನನ ಮತ್ತು ನಿರಂತರ ಧ್ಯಾನದ ಮೂಲಕ ಈ ಸರ್ವವ್ಯಾಪಿ ಚೈತನ್ಯವನ್ನು ಅನುಭವಿಸುವುದೇ ಪರಮ ಪುರುಷಾರ್ಥವಾಗಿದೆ.';

  return {
    moolaShloka: moola,
    kannadaTransliteration: kannadaTr,
    padartha: cleanPadartha,
    saralaVivarane: sarala && sarala.trim().length >= 25 ? sarala.trim() : defaultSarala,
    vivaradaVyakhyana: vyakhyana && vyakhyana.trim().length >= 40 ? vyakhyana.trim() : defaultVyakhyana,
    visualAnalysis: {
      type: 'NONE',
      need: false,
      reason: 'No visual material required for simple text.',
      sourceSupported: true,
      isGenerated: false,
      confidence: 'HIGH',
      placement: 'NONE',
    },
  };
}
