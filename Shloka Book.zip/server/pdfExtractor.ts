import * as pdfjsLib from 'pdfjs-dist/legacy/build/pdf.mjs';
import fs from 'fs';
import { sanitizeUnicodeText } from './transliteration';

export interface ExtractedPdfPage {
  pageNumber: number;
  text: string;
  charCount: number;
  hasDevanagari: boolean;
  isNativeText: boolean;
}

export interface PdfExtractionResult {
  fileName: string;
  totalPages: number;
  detectedType: 'NATIVE_PDF' | 'SCANNED_PDF' | 'MIXED_PDF' | 'TEXT_FILE';
  pages: ExtractedPdfPage[];
  fullText: string;
  extractionMethod: 'NATIVE_PDF_PARSE' | 'PLAINTEXT_READER' | 'OCR_FALLBACK_SIM';
  devanagariDensity: number;
}

/**
 * Robust extraction of PDF and text files, prioritizing native selectable Sanskrit text.
 */
export async function extractDocumentText(filePath: string, fileName: string): Promise<PdfExtractionResult> {
  const lowerName = fileName.toLowerCase();
  const isTxt = lowerName.endsWith('.txt') || lowerName.endsWith('.md') || lowerName.endsWith('.html');

  if (isTxt) {
    const raw = fs.readFileSync(filePath, 'utf-8');
    const pages = splitTextIntoPseudoPages(raw);
    const devanagariMatches = (raw.match(/[\u0900-\u097F]/g) || []).length;
    const density = raw.length > 0 ? devanagariMatches / raw.length : 0;

    return {
      fileName,
      totalPages: pages.length,
      detectedType: 'TEXT_FILE',
      pages: pages.map((text, idx) => ({
        pageNumber: idx + 1,
        text,
        charCount: text.length,
        hasDevanagari: /[\u0900-\u097F]/.test(text),
        isNativeText: true,
      })),
      fullText: raw,
      extractionMethod: 'PLAINTEXT_READER',
      devanagariDensity: density,
    };
  }

  // Handle PDF files with pdfjs-dist legacy (fast, native Node support)
  const dataBuffer = fs.readFileSync(filePath);
  const uint8Data = new Uint8Array(dataBuffer);

  try {
    const loadingTask = pdfjsLib.getDocument({
      data: uint8Data,
      useSystemFonts: true,
      disableFontFace: true,
      isEvalSupported: false,
    });

    const pdfDoc = await loadingTask.promise;
    const totalPages = pdfDoc.numPages || 1;
    const pages: ExtractedPdfPage[] = [];

    let totalChars = 0;
    let devanagariTotal = 0;
    let nativePageCount = 0;

    for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
      try {
        const page = await pdfDoc.getPage(pageNum);
        const textContent = await page.getTextContent();

        // Extract text items and order them by vertical (top-to-bottom) and horizontal coordinates
        const items = textContent.items as Array<{
          str: string;
          transform: number[];
          width?: number;
          height?: number;
          hasEOL?: boolean;
        }>;

        let pageText = '';
        if (items && items.length > 0) {
          // Robust line clustering: Group items whose Y positions are within 8 points into lines,
          // then sort lines top-to-bottom (Y descending), and items within each line left-to-right (X ascending).
          interface LineBucket {
            avgY: number;
            items: Array<{ str: string; x: number; y: number }>;
          }
          const lines: LineBucket[] = [];
          for (const it of items) {
            const str = it.str || '';
            if (!str) continue;
            const x = it.transform?.[4] ?? 0;
            const y = it.transform?.[5] ?? 0;

            let placed = false;
            for (const line of lines) {
              if (Math.abs(line.avgY - y) <= 8) {
                line.items.push({ str, x, y });
                line.avgY = line.items.reduce((acc, curr) => acc + curr.y, 0) / line.items.length;
                placed = true;
                break;
              }
            }
            if (!placed) {
              lines.push({ avgY: y, items: [{ str, x, y }] });
            }
          }

          // Sort lines from top of page to bottom (Y descending)
          lines.sort((a, b) => b.avgY - a.avgY);

          // For each line, sort items from left to right (X ascending)
          const lineTexts: string[] = [];
          for (const line of lines) {
            line.items.sort((a, b) => a.x - b.x);
            let curLine = '';
            for (const item of line.items) {
              if (curLine.length > 0 && !curLine.endsWith(' ') && !item.str.startsWith(' ')) {
                curLine += ' ' + item.str;
              } else {
                curLine += item.str;
              }
            }
            if (curLine.trim()) {
              lineTexts.push(curLine.trim());
            }
          }
          pageText = lineTexts.join('\n');
        }

        const sanitized = sanitizeUnicodeText(pageText.trim());
        const charCount = sanitized.length;
        totalChars += charCount;

        const devaMatches = (sanitized.match(/[\u0900-\u097F]/g) || []).length;
        devanagariTotal += devaMatches;

        const isNative = charCount > 10;
        if (isNative) nativePageCount++;

        pages.push({
          pageNumber: pageNum,
          text: sanitized,
          charCount,
          hasDevanagari: devaMatches > 0,
          isNativeText: isNative,
        });

        page.cleanup();
      } catch (pageErr) {
        console.warn(`Warning: failed to extract text from page ${pageNum}:`, pageErr);
        pages.push({
          pageNumber: pageNum,
          text: '',
          charCount: 0,
          hasDevanagari: false,
          isNativeText: false,
        });
      }
    }

    let detectedType: 'NATIVE_PDF' | 'SCANNED_PDF' | 'MIXED_PDF' = 'NATIVE_PDF';
    if (nativePageCount === 0 && totalPages > 0) {
      detectedType = 'SCANNED_PDF';
    } else if (nativePageCount < totalPages) {
      detectedType = 'MIXED_PDF';
    }

    const density = totalChars > 0 ? devanagariTotal / totalChars : 0;
    const fullText = pages.map((p) => p.text).filter(Boolean).join('\n\n');

    return {
      fileName,
      totalPages,
      detectedType,
      pages,
      fullText,
      extractionMethod: 'NATIVE_PDF_PARSE',
      devanagariDensity: density,
    };
  } catch (err: any) {
    console.error('PDF parsing error:', err);
    throw new Error(`Failed to extract text from ${fileName}: ${err.message || 'Corrupted or unreadable PDF'}`);
  }
}

/**
 * Split plain text into ~4000 character pseudo-pages if multi-page plain text is uploaded.
 */
function splitTextIntoPseudoPages(fullText: string): string[] {
  if (fullText.length <= 4000) return [fullText];
  const pages: string[] = [];
  const lines = fullText.split('\n');
  let current = '';

  for (const line of lines) {
    if (current.length + line.length > 3500 && current.trim().length > 0) {
      pages.push(current.trim());
      current = line + '\n';
    } else {
      current += line + '\n';
    }
  }

  if (current.trim().length > 0) {
    pages.push(current.trim());
  }

  return pages.length > 0 ? pages : [fullText];
}
