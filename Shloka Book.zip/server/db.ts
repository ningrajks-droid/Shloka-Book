import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';
import { SanskritUnit, GranthaProject, GranthaDocument, EngineSettings } from '../src/types';

const DATA_DIR = path.join(process.cwd(), 'grantha_data');
const DB_FILE = path.join(DATA_DIR, 'grantha_engine.sqlite');
const BAK_FILE = path.join(DATA_DIR, 'grantha_engine.sqlite.bak');

let dbInstance: Database | null = null;
let dbInitPromise: Promise<Database> | null = null;

export const DEFAULT_SETTINGS: EngineSettings = {
  geminiModel: 'gemini-3.1-flash-lite',
  temperature: 0.1,
  maxOutputTokens: 8192,
  apiKeys: [],
  activeKeyIndex: 0,
  ocrFallback: false,
  sourceVerification: true,
  intelligentTables: true,
  intelligentDiagrams: true,
  confidenceThreshold: 0.85,
  batchSize: 5,
  maxRetries: 3,
  concurrency: 3,
  outputFontDevanagari: 'Noto Sans Devanagari',
  outputFontKannada: 'Noto Sans Kannada',
  fontSizePt: 11,
};

let isSaving = false;
let pendingSave = false;
let saveDebounceTimer: NodeJS.Timeout | null = null;

export async function getDb(): Promise<Database> {
  if (dbInstance) return dbInstance;
  if (dbInitPromise) return dbInitPromise;

  dbInitPromise = (async () => {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }

    // Clean up any stale .tmp files from previous sudden restarts
    try {
      const files = fs.readdirSync(DATA_DIR);
      for (const f of files) {
        if (f.startsWith('grantha_engine.tmp.')) {
          try {
            fs.unlinkSync(path.join(DATA_DIR, f));
          } catch {}
        }
      }
    } catch {}

    const SQL = await initSqlJs();

    // 1. Try loading primary DB file
    if (fs.existsSync(DB_FILE)) {
      try {
        const fileBuffer = fs.readFileSync(DB_FILE);
        if (fileBuffer.length >= 100) {
          const testDb = new SQL.Database(fileBuffer);
          testDb.exec('PRAGMA integrity_check;');
          initSchema(testDb);
          dbInstance = testDb;
          return dbInstance;
        }
      } catch (err) {
        console.warn('Primary SQLite DB was damaged, attempting recovery from backup...');
        try {
          if (fs.existsSync(DB_FILE)) {
            const corruptBackup = path.join(DATA_DIR, `grantha_engine.corrupt.${Date.now()}`);
            fs.renameSync(DB_FILE, corruptBackup);
          }
        } catch {}
      }
    }

    // 2. Try loading backup file if primary failed
    if (fs.existsSync(BAK_FILE)) {
      try {
        const bakBuffer = fs.readFileSync(BAK_FILE);
        if (bakBuffer.length >= 100) {
          const bakDb = new SQL.Database(bakBuffer);
          bakDb.exec('PRAGMA integrity_check;');
          initSchema(bakDb);
          dbInstance = bakDb;
          saveDb(true);
          console.log('Successfully recovered Grantha engine database from verified backup.');
          return dbInstance;
        }
      } catch (bakErr) {
        console.warn('Backup DB was also unreadable, creating fresh DB:', bakErr);
      }
    }

    // 3. Initialize fresh healthy database
    const freshDb = new SQL.Database();
    initSchema(freshDb);
    dbInstance = freshDb;
    saveDb(true);
    return dbInstance;
  })();

  try {
    const db = await dbInitPromise;
    return db;
  } finally {
    dbInitPromise = null;
  }
}

function initSchema(db: Database) {
  db.run(`
    CREATE TABLE IF NOT EXISTS projects (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      description TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      status TEXT NOT NULL,
      detected_genre TEXT,
      detected_work TEXT,
      total_documents INTEGER DEFAULT 0,
      total_pages INTEGER DEFAULT 0,
      total_units INTEGER DEFAULT 0,
      completed_units INTEGER DEFAULT 0,
      failed_units INTEGER DEFAULT 0,
      review_required_units INTEGER DEFAULT 0,
      current_doc_name TEXT,
      current_page INTEGER,
      current_unit_number TEXT
    );

    CREATE TABLE IF NOT EXISTS documents (
      id TEXT PRIMARY KEY,
      project_id TEXT NOT NULL,
      file_name TEXT NOT NULL,
      file_size INTEGER NOT NULL,
      page_count INTEGER NOT NULL,
      detected_type TEXT NOT NULL,
      detected_work TEXT,
      structural_type TEXT,
      status TEXT NOT NULL,
      uploaded_at TEXT NOT NULL,
      FOREIGN KEY (project_id) REFERENCES projects(id)
    );

    CREATE TABLE IF NOT EXISTS units (
      id TEXT PRIMARY KEY,
      project_id TEXT NOT NULL,
      doc_id TEXT NOT NULL,
      file_name TEXT NOT NULL,
      page_number INTEGER NOT NULL,
      unit_index INTEGER NOT NULL,
      detected_work TEXT NOT NULL,
      structural_hierarchy TEXT NOT NULL,
      original_text TEXT NOT NULL,
      raw_extracted_text TEXT NOT NULL,
      verified_text TEXT NOT NULL,
      first_meaningful_word TEXT NOT NULL,
      output TEXT,
      status TEXT NOT NULL,
      confidence TEXT NOT NULL,
      validation_score REAL DEFAULT 0,
      validation_issues TEXT,
      source_verification TEXT,
      change_log TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      error_message TEXT,
      FOREIGN KEY (project_id) REFERENCES projects(id),
      FOREIGN KEY (doc_id) REFERENCES documents(id)
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS structure_state (
      project_id TEXT PRIMARY KEY,
      state_json TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (project_id) REFERENCES projects(id)
    );

    CREATE TABLE IF NOT EXISTS structure_audit (
      id TEXT PRIMARY KEY,
      project_id TEXT NOT NULL,
      unit_id TEXT NOT NULL,
      page_number INTEGER NOT NULL,
      chunk_id TEXT NOT NULL,
      offline_json TEXT,
      ai_json TEXT,
      final_json TEXT NOT NULL,
      validation_status TEXT NOT NULL,
      reason TEXT,
      confidence REAL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (project_id) REFERENCES projects(id),
      FOREIGN KEY (unit_id) REFERENCES units(id)
    );
  `);
}

export function saveDb(immediate = false) {
  if (!dbInstance) return;
  
  if (immediate) {
    if (saveDebounceTimer) {
      clearTimeout(saveDebounceTimer);
      saveDebounceTimer = null;
    }
    executeSave();
    return;
  }

  if (saveDebounceTimer) return;
  saveDebounceTimer = setTimeout(() => {
    saveDebounceTimer = null;
    executeSave();
  }, 120);
}

function executeSave() {
  if (!dbInstance) return;
  if (isSaving) {
    pendingSave = true;
    return;
  }

  isSaving = true;
  try {
    const data = dbInstance.export();
    const buffer = Buffer.from(data);
    
    if (buffer.length >= 100) {
      const tmpFile = path.join(
        DATA_DIR,
        `grantha_engine.tmp.${Date.now()}_${Math.random().toString(36).substr(2, 4)}`
      );
      fs.writeFileSync(tmpFile, buffer);
      
      // Atomic rename
      fs.renameSync(tmpFile, DB_FILE);

      // Safe update backup
      try {
        fs.copyFileSync(DB_FILE, BAK_FILE);
      } catch {}
    }
  } catch (err) {
    console.error('Failed to atomically save SQLite DB:', err);
  } finally {
    isSaving = false;
    if (pendingSave) {
      pendingSave = false;
      setTimeout(executeSave, 40);
    }
  }
}


// ----------------- AI Structure State / Audit -----------------

export interface PersistedStructureState {
  documentType?: string;
  structurePath: string[];
  currentHeadings: Array<{ level: number; text: string; type: string }>;
  lastUnitId?: string;
  lastPage?: number;
  updatedAt?: string;
}

export async function getStructureState(projectId: string): Promise<PersistedStructureState | null> {
  const db = await getDb();
  const stmt = db.prepare(`SELECT state_json FROM structure_state WHERE project_id = ?`);
  stmt.bind([projectId]);
  if (!stmt.step()) {
    stmt.free();
    return null;
  }
  const row = stmt.getAsObject();
  stmt.free();
  try { return JSON.parse(String(row.state_json)); } catch { return null; }
}

export async function saveStructureState(projectId: string, state: PersistedStructureState): Promise<void> {
  const db = await getDb();
  const now = new Date().toISOString();
  const json = JSON.stringify({ ...state, updatedAt: now });
  db.run(
    `INSERT OR REPLACE INTO structure_state (project_id, state_json, updated_at) VALUES (?, ?, ?)`,
    [projectId, json, now]
  );
  saveDb();
}

export async function saveStructureAudit(entry: {
  projectId: string;
  unitId: string;
  pageNumber: number;
  chunkId: string;
  offline: unknown;
  ai: unknown;
  final: unknown;
  validationStatus: string;
  reason?: string;
  confidence?: number;
}): Promise<void> {
  const db = await getDb();
  db.run(
    `INSERT OR REPLACE INTO structure_audit
      (id, project_id, unit_id, page_number, chunk_id, offline_json, ai_json, final_json,
       validation_status, reason, confidence, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      `sa_${entry.unitId}_${Date.now()}`,
      entry.projectId,
      entry.unitId,
      entry.pageNumber,
      entry.chunkId,
      JSON.stringify(entry.offline ?? null),
      JSON.stringify(entry.ai ?? null),
      JSON.stringify(entry.final ?? {}),
      entry.validationStatus,
      entry.reason || '',
      entry.confidence ?? 0,
      new Date().toISOString(),
    ]
  );
  saveDb();
}

// ----------------- Project Operations -----------------

export async function createProject(name: string, description: string = ''): Promise<GranthaProject> {
  const db = await getDb();
  const id = 'proj_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
  const now = new Date().toISOString();

  const project: GranthaProject = {
    id,
    name,
    description,
    createdAt: now,
    updatedAt: now,
    status: 'IDLE',
    totalDocuments: 0,
    totalPages: 0,
    totalUnits: 0,
    completedUnits: 0,
    failedUnits: 0,
    reviewRequiredUnits: 0,
  };

  db.run(
    `INSERT INTO projects (id, name, description, created_at, updated_at, status, total_documents, total_pages, total_units, completed_units, failed_units, review_required_units)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      project.id,
      project.name,
      project.description,
      project.createdAt,
      project.updatedAt,
      project.status,
      0, 0, 0, 0, 0, 0
    ]
  );
  saveDb();
  return project;
}

export async function getAllProjects(): Promise<GranthaProject[]> {
  const db = await getDb();
  const stmt = db.prepare(`SELECT * FROM projects ORDER BY updated_at DESC`);
  const projects: GranthaProject[] = [];

  while (stmt.step()) {
    const row = stmt.getAsObject();
    projects.push({
      id: String(row.id),
      name: String(row.name),
      description: String(row.description || ''),
      createdAt: String(row.created_at),
      updatedAt: String(row.updated_at),
      status: row.status as any,
      detectedGenre: row.detected_genre ? String(row.detected_genre) : undefined,
      detectedWork: row.detected_work ? String(row.detected_work) : undefined,
      totalDocuments: Number(row.total_documents || 0),
      totalPages: Number(row.total_pages || 0),
      totalUnits: Number(row.total_units || 0),
      completedUnits: Number(row.completed_units || 0),
      failedUnits: Number(row.failed_units || 0),
      reviewRequiredUnits: Number(row.review_required_units || 0),
      currentDocName: row.current_doc_name ? String(row.current_doc_name) : undefined,
      currentPage: row.current_page ? Number(row.current_page) : undefined,
      currentUnitNumber: row.current_unit_number ? String(row.current_unit_number) : undefined,
    });
  }
  stmt.free();
  return projects;
}

export async function getProjectById(id: string): Promise<GranthaProject | null> {
  const db = await getDb();
  const stmt = db.prepare(`SELECT * FROM projects WHERE id = ?`);
  stmt.bind([id]);
  if (!stmt.step()) {
    stmt.free();
    return null;
  }
  const row = stmt.getAsObject();
  stmt.free();

  return {
    id: String(row.id),
    name: String(row.name),
    description: String(row.description || ''),
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
    status: row.status as any,
    detectedGenre: row.detected_genre ? String(row.detected_genre) : undefined,
    detectedWork: row.detected_work ? String(row.detected_work) : undefined,
    totalDocuments: Number(row.total_documents || 0),
    totalPages: Number(row.total_pages || 0),
    totalUnits: Number(row.total_units || 0),
    completedUnits: Number(row.completed_units || 0),
    failedUnits: Number(row.failed_units || 0),
    reviewRequiredUnits: Number(row.review_required_units || 0),
    currentDocName: row.current_doc_name ? String(row.current_doc_name) : undefined,
    currentPage: row.current_page ? Number(row.current_page) : undefined,
    currentUnitNumber: row.current_unit_number ? String(row.current_unit_number) : undefined,
  };
}

export async function updateProject(project: Partial<GranthaProject> & { id: string }) {
  const db = await getDb();
  const now = new Date().toISOString();

  const updates: string[] = ['updated_at = ?'];
  const values: any[] = [now];

  if (project.name !== undefined) { updates.push('name = ?'); values.push(project.name); }
  if (project.description !== undefined) { updates.push('description = ?'); values.push(project.description); }
  if (project.status !== undefined) { updates.push('status = ?'); values.push(project.status); }
  if (project.detectedGenre !== undefined) { updates.push('detected_genre = ?'); values.push(project.detectedGenre); }
  if (project.detectedWork !== undefined) { updates.push('detected_work = ?'); values.push(project.detectedWork); }
  if (project.totalDocuments !== undefined) { updates.push('total_documents = ?'); values.push(project.totalDocuments); }
  if (project.totalPages !== undefined) { updates.push('total_pages = ?'); values.push(project.totalPages); }
  if (project.totalUnits !== undefined) { updates.push('total_units = ?'); values.push(project.totalUnits); }
  if (project.completedUnits !== undefined) { updates.push('completed_units = ?'); values.push(project.completedUnits); }
  if (project.failedUnits !== undefined) { updates.push('failed_units = ?'); values.push(project.failedUnits); }
  if (project.reviewRequiredUnits !== undefined) { updates.push('review_required_units = ?'); values.push(project.reviewRequiredUnits); }
  if (project.currentDocName !== undefined) { updates.push('current_doc_name = ?'); values.push(project.currentDocName); }
  if (project.currentPage !== undefined) { updates.push('current_page = ?'); values.push(project.currentPage); }
  if (project.currentUnitNumber !== undefined) { updates.push('current_unit_number = ?'); values.push(project.currentUnitNumber); }

  values.push(project.id);
  db.run(`UPDATE projects SET ${updates.join(', ')} WHERE id = ?`, values);
  saveDb();
}

export async function clearAllProjectsAndUnits() {
  const db = await getDb();
  db.run(`DELETE FROM structure_audit;`);
  db.run(`DELETE FROM structure_state;`);
  db.run(`DELETE FROM units;`);
  db.run(`DELETE FROM documents;`);
  db.run(`DELETE FROM projects;`);
  saveDb();
}

export async function deleteProject(id: string) {
  const db = await getDb();
  db.run(`DELETE FROM structure_audit WHERE project_id = ?`, [id]);
  db.run(`DELETE FROM structure_state WHERE project_id = ?`, [id]);
  db.run(`DELETE FROM units WHERE project_id = ?`, [id]);
  db.run(`DELETE FROM documents WHERE project_id = ?`, [id]);
  db.run(`DELETE FROM projects WHERE id = ?`, [id]);
  saveDb();
}

// ----------------- Document Operations -----------------

export async function addDocument(doc: GranthaDocument) {
  const db = await getDb();
  db.run(
    `INSERT OR REPLACE INTO documents (id, project_id, file_name, file_size, page_count, detected_type, detected_work, structural_type, status, uploaded_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      doc.id,
      doc.projectId,
      doc.fileName,
      doc.fileSize,
      doc.pageCount,
      doc.detectedType,
      doc.detectedWork || '',
      doc.structuralType || '',
      doc.status,
      doc.uploadedAt,
    ]
  );
  saveDb();
}

export async function getDocumentsByProjectId(projectId: string): Promise<GranthaDocument[]> {
  const db = await getDb();
  const stmt = db.prepare(`SELECT * FROM documents WHERE project_id = ? ORDER BY uploaded_at ASC`);
  stmt.bind([projectId]);
  const docs: GranthaDocument[] = [];
  while (stmt.step()) {
    const row = stmt.getAsObject();
    docs.push({
      id: String(row.id),
      projectId: String(row.project_id),
      fileName: String(row.file_name),
      fileSize: Number(row.file_size),
      pageCount: Number(row.page_count),
      detectedType: row.detected_type as any,
      detectedWork: String(row.detected_work || ''),
      structuralType: String(row.structural_type || ''),
      status: row.status as any,
      uploadedAt: String(row.uploaded_at),
    });
  }
  stmt.free();
  return docs;
}

export async function deleteDocument(projectId: string, docId: string) {
  const db = await getDb();
  db.run(`DELETE FROM structure_audit WHERE project_id = ? AND unit_id IN (SELECT id FROM units WHERE project_id = ? AND doc_id = ?)`, [projectId, projectId, docId]);
  db.run(`DELETE FROM units WHERE project_id = ? AND doc_id = ?`, [projectId, docId]);
  db.run(`DELETE FROM documents WHERE id = ? AND project_id = ?`, [docId, projectId]);

  // Recalculate project totals
  const existingDocs = await getDocumentsByProjectId(projectId);
  const existingUnits = await getUnitsByProjectId(projectId);
  const completed = existingUnits.filter(u => u.status === 'COMPLETED').length;
  const failed = existingUnits.filter(u => u.status === 'FAILED').length;
  const reviewReq = existingUnits.filter(u => u.status === 'REVIEW_REQUIRED').length;

  const detectedWork = existingDocs.length > 0 ? (existingDocs[0].detectedWork || '') : '';
  const detectedGenre = existingDocs.length > 0 ? (existingDocs[0].detectedType || '') : '';

  await updateProject({
    id: projectId,
    totalDocuments: existingDocs.length,
    totalPages: existingDocs.reduce((acc, d) => acc + d.pageCount, 0),
    totalUnits: existingUnits.length,
    completedUnits: completed,
    failedUnits: failed,
    reviewRequiredUnits: reviewReq,
    detectedWork: detectedWork,
    detectedGenre: detectedGenre,
    status: existingUnits.length === 0 ? 'IDLE' : undefined,
    currentDocName: '',
    currentPage: 0,
    currentUnitNumber: '',
  });

  saveDb();
}

export async function deleteAllDocumentsInProject(projectId: string) {
  const db = await getDb();
  db.run(`DELETE FROM structure_audit WHERE project_id = ?`, [projectId]);
  db.run(`DELETE FROM structure_state WHERE project_id = ?`, [projectId]);
  db.run(`DELETE FROM units WHERE project_id = ?`, [projectId]);
  db.run(`DELETE FROM documents WHERE project_id = ?`, [projectId]);

  await updateProject({
    id: projectId,
    totalDocuments: 0,
    totalPages: 0,
    totalUnits: 0,
    completedUnits: 0,
    failedUnits: 0,
    reviewRequiredUnits: 0,
    detectedWork: '',
    detectedGenre: '',
    status: 'IDLE',
    currentDocName: '',
    currentPage: 0,
    currentUnitNumber: '',
  });

  saveDb();
}

export async function resetProjectData(projectId: string) {
  const db = await getDb();
  db.run(`DELETE FROM structure_audit WHERE project_id = ?`, [projectId]);
  db.run(`DELETE FROM structure_state WHERE project_id = ?`, [projectId]);
  db.run(`DELETE FROM units WHERE project_id = ?`, [projectId]);
  db.run(`DELETE FROM documents WHERE project_id = ?`, [projectId]);

  await updateProject({
    id: projectId,
    totalDocuments: 0,
    totalPages: 0,
    totalUnits: 0,
    completedUnits: 0,
    failedUnits: 0,
    reviewRequiredUnits: 0,
    detectedWork: '',
    detectedGenre: '',
    status: 'IDLE',
    currentDocName: '',
    currentPage: 0,
    currentUnitNumber: '',
  });

  saveDb();
}

// ----------------- Unit Operations (Checkpoints) -----------------

export async function saveUnit(unit: SanskritUnit) {
  const db = await getDb();
  const stmt = db.prepare(`SELECT id FROM units WHERE id = ?`);
  stmt.bind([unit.id]);
  const exists = stmt.step();
  stmt.free();

  const outputJson = unit.output ? JSON.stringify(unit.output) : null;
  const hierarchyJson = JSON.stringify(unit.structuralHierarchy);
  const valIssuesJson = JSON.stringify(unit.validationIssues || []);
  const srcVerJson = unit.sourceVerification ? JSON.stringify(unit.sourceVerification) : null;
  const changeLogJson = unit.changeLog ? JSON.stringify(unit.changeLog) : null;

  if (exists) {
    db.run(
      `UPDATE units SET
        verified_text = ?,
        output = ?,
        status = ?,
        confidence = ?,
        validation_score = ?,
        validation_issues = ?,
        source_verification = ?,
        change_log = ?,
        updated_at = ?,
        error_message = ?
       WHERE id = ?`,
      [
        unit.verifiedText,
        outputJson,
        unit.status,
        unit.confidence,
        unit.validationScore,
        valIssuesJson,
        srcVerJson,
        changeLogJson,
        new Date().toISOString(),
        unit.errorMessage || null,
        unit.id,
      ]
    );
  } else {
    db.run(
      `INSERT INTO units (
        id, project_id, doc_id, file_name, page_number, unit_index, detected_work,
        structural_hierarchy, original_text, raw_extracted_text, verified_text,
        first_meaningful_word, output, status, confidence, validation_score,
        validation_issues, source_verification, change_log, created_at, updated_at, error_message
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        unit.id,
        unit.projectId,
        unit.docId,
        unit.fileName,
        unit.pageNumber,
        unit.unitIndex,
        unit.detectedWork,
        hierarchyJson,
        unit.originalText,
        unit.rawExtractedText,
        unit.verifiedText,
        unit.firstMeaningfulWord,
        outputJson,
        unit.status,
        unit.confidence,
        unit.validationScore,
        valIssuesJson,
        srcVerJson,
        changeLogJson,
        unit.timestamps.created,
        unit.timestamps.updated,
        unit.errorMessage || null,
      ]
    );
  }
  saveDb();
}

export async function getUnitsByProjectId(projectId: string): Promise<SanskritUnit[]> {
  const db = await getDb();
  const stmt = db.prepare(`SELECT * FROM units WHERE project_id = ? ORDER BY page_number ASC, unit_index ASC`);
  stmt.bind([projectId]);
  const units: SanskritUnit[] = [];

  while (stmt.step()) {
    const row = stmt.getAsObject();
    units.push({
      id: String(row.id),
      projectId: String(row.project_id),
      docId: String(row.doc_id),
      fileName: String(row.file_name),
      pageNumber: Number(row.page_number),
      unitIndex: Number(row.unit_index),
      detectedWork: String(row.detected_work),
      structuralHierarchy: row.structural_hierarchy ? JSON.parse(String(row.structural_hierarchy)) : { level1Name: 'ಅಧ್ಯಾಯ', level1Value: 1, formattedNumber: '|| 1.1 ||' },
      originalText: String(row.original_text),
      rawExtractedText: String(row.raw_extracted_text),
      verifiedText: String(row.verified_text),
      firstMeaningfulWord: String(row.first_meaningful_word),
      output: row.output ? JSON.parse(String(row.output)) : undefined,
      status: row.status as any,
      confidence: row.confidence as any,
      validationScore: Number(row.validation_score || 0),
      validationIssues: row.validation_issues ? JSON.parse(String(row.validation_issues)) : [],
      sourceVerification: row.source_verification ? JSON.parse(String(row.source_verification)) : undefined,
      changeLog: row.change_log ? JSON.parse(String(row.change_log)) : [],
      timestamps: {
        created: String(row.created_at),
        updated: String(row.updated_at),
      },
      errorMessage: row.error_message ? String(row.error_message) : undefined,
    });
  }
  stmt.free();
  return units;
}

export async function getUnitById(id: string): Promise<SanskritUnit | null> {
  const db = await getDb();
  const stmt = db.prepare(`SELECT * FROM units WHERE id = ?`);
  stmt.bind([id]);
  if (!stmt.step()) {
    stmt.free();
    return null;
  }
  const row = stmt.getAsObject();
  stmt.free();

  return {
    id: String(row.id),
    projectId: String(row.project_id),
    docId: String(row.doc_id),
    fileName: String(row.file_name),
    pageNumber: Number(row.page_number),
    unitIndex: Number(row.unit_index),
    detectedWork: String(row.detected_work),
    structuralHierarchy: row.structural_hierarchy ? JSON.parse(String(row.structural_hierarchy)) : { level1Name: 'ಅಧ್ಯಾಯ', level1Value: 1, formattedNumber: '|| 1.1 ||' },
    originalText: String(row.original_text),
    rawExtractedText: String(row.raw_extracted_text),
    verifiedText: String(row.verified_text),
    firstMeaningfulWord: String(row.first_meaningful_word),
    output: row.output ? JSON.parse(String(row.output)) : undefined,
    status: row.status as any,
    confidence: row.confidence as any,
    validationScore: Number(row.validation_score || 0),
    validationIssues: row.validation_issues ? JSON.parse(String(row.validation_issues)) : [],
    sourceVerification: row.source_verification ? JSON.parse(String(row.source_verification)) : undefined,
    changeLog: row.change_log ? JSON.parse(String(row.change_log)) : [],
    timestamps: {
      created: String(row.created_at),
      updated: String(row.updated_at),
    },
    errorMessage: row.error_message ? String(row.error_message) : undefined,
  };
}

export async function deleteUnit(id: string) {
  const db = await getDb();
  const unit = await getUnitById(id);
  if (!unit) return;
  const projectId = unit.projectId;
  db.run(`DELETE FROM units WHERE id = ?`, [id]);

  if (projectId) {
    const existingUnits = await getUnitsByProjectId(projectId);
    const completed = existingUnits.filter(u => u.status === 'COMPLETED').length;
    const failed = existingUnits.filter(u => u.status === 'FAILED').length;
    const reviewReq = existingUnits.filter(u => u.status === 'REVIEW_REQUIRED').length;

    await updateProject({
      id: projectId,
      totalUnits: existingUnits.length,
      completedUnits: completed,
      failedUnits: failed,
      reviewRequiredUnits: reviewReq,
      status: existingUnits.length === 0 ? 'IDLE' : undefined,
    });
  }

  saveDb();
}

// ----------------- Settings Operations -----------------

const VALID_MODELS = ['gemini-3.8-flash', 'gemini-3.1-flash-lite', 'gemini-flash-latest', 'gemini-3.7-flash'];

export async function getSettings(): Promise<EngineSettings> {
  const db = await getDb();
  const stmt = db.prepare(`SELECT value FROM settings WHERE key = 'engine_config'`);
  if (!stmt.step()) {
    stmt.free();
    return { ...DEFAULT_SETTINGS };
  }
  const row = stmt.getAsObject();
  stmt.free();
  try {
    const parsed = JSON.parse(String(row.value));
    const merged = { ...DEFAULT_SETTINGS, ...parsed };
    if (!VALID_MODELS.includes(merged.geminiModel)) {
      merged.geminiModel = 'gemini-3.1-flash-lite';
    }
    return merged;
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

export async function saveSettings(settings: Partial<EngineSettings>): Promise<EngineSettings> {
  const current = await getSettings();
  const updated = { ...current, ...settings };
  const db = await getDb();
  db.run(`INSERT OR REPLACE INTO settings (key, value) VALUES ('engine_config', ?)`, [JSON.stringify(updated)]);
  saveDb();
  return updated;
}
