/**
 * Visual Intelligence, SVG Diagram Synthesizer & High-Res PNG Renderer
 * for Scholarly Sanskrit-Kannada Grantha Editions
 * 
 * Supports:
 * 1. Yoga & Asanas (ಪದ್ಮಾಸನ, ಸಿದ್ಧಾಸನ, ವಜ್ರಾಸನ, ಸ್ವಸ್ತಿಕಾಸನ, ಧ್ಯಾನಾಸನ, ಸುಖಾಸನ)
 * 2. Astronomy & Grahas (ಖಗೋಳ, ಸೂರ್ಯಮಂಡಲ, ನವಗ್ರಹಗಳು, ರಾಶಿ ಮಂಡಲ, ನಕ್ಷತ್ರಗಳು)
 * 3. Mathematics & Geometry (ವೃತ್ತ, ತ್ರಿಭುಜ, ಕೋನ, ಶುಲ್ಬಸೂತ್ರ, ಜ್ಯಾಮಿತಿ, ಯಂತ್ರ, ಛಂದಸ್ಸು)
 * 4. Philosophy & Concepts (ಪೂರ್ಣತ್ವ, ಬ್ರಹ್ಮ-ಜಗತ್, ಕಾರಣ-ಕಾರ್ಯ, ಸೃಷ್ಟಿ ಕ್ರಮ, ಪಂಚಕೋಶ)
 * 5. Scientific Taxonomies, Comparisons & Sequential Flows
 */

import { Resvg } from '@resvg/resvg-js';
import sharp from 'sharp';
import path from 'path';
import fs from 'fs';

export interface DiagramConfig {
  type?: 'FLOW' | 'COMPARISON' | 'COUNT_TAXONOMY' | 'CONCENTRIC' | 'ASANA' | 'ASTRONOMY' | 'GEOMETRY' | 'PURNATVA' | 'BRAHMA_JAGAT';
  title?: string;
  description?: string;
  conceptNodes?: string[] | null;
  tableHeaders?: string[];
  tableRows?: string[][];
  asanaName?: string;
}

/**
 * Get all available Indic / Kannada / Latin font file paths
 */
export function getAvailableFontFiles(): string[] {
  const candidateDirs = [
    path.resolve(process.cwd(), 'server/fonts'),
    path.resolve(process.cwd(), 'public/fonts'),
    path.resolve(process.cwd(), 'dist/fonts'),
    path.resolve(process.env.HOME || '/root', '.fonts'),
    '/usr/share/fonts/truetype',
    '/usr/share/fonts/opentype',
  ];

  const fontFiles: string[] = [];
  for (const dir of candidateDirs) {
    if (fs.existsSync(dir)) {
      try {
        const files = fs.readdirSync(dir);
        for (const file of files) {
          if (/\.(ttf|otf)$/i.test(file)) {
            const fullPath = path.join(dir, file);
            if (!fontFiles.includes(fullPath)) {
              fontFiles.push(fullPath);
            }
          }
        }
      } catch {
        // Skip inaccessible dirs
      }
    }
  }

  return fontFiles;
}

/**
 * Render SVG string directly to high-resolution PNG Buffer for DOCX ImageRun embedding
 */
export function sanitizeSvgForXml(rawSvg: string): string {
  if (!rawSvg) return '';

  let svg = rawSvg.trim();

  // Strip Markdown code fences if present (e.g. ```xml or ```svg)
  svg = svg.replace(/^```(?:svg|xml)?\s*/i, '').replace(/\s*```$/, '').trim();

  // Ensure svg wrapper
  if (!svg.startsWith('<svg')) {
    const svgStartIdx = svg.indexOf('<svg');
    if (svgStartIdx !== -1) {
      svg = svg.slice(svgStartIdx);
    } else {
      svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 720 340" width="720" height="340">${svg}</svg>`;
    }
  }

  // Ensure closing tag
  if (!svg.includes('</svg>')) {
    svg += '</svg>';
  }

  // Ensure xmlns attribute
  if (!svg.includes('xmlns=')) {
    svg = svg.replace('<svg', '<svg xmlns="http://www.w3.org/2000/svg"');
  }

  // Inject font style definition if not already present
  if (!svg.includes('Noto Sans Kannada')) {
    const styleBlock = `<style>
      *, text, tspan {
        font-family: 'Noto Sans Kannada', 'Noto Sans Devanagari', 'Noto Sans', sans-serif;
      }
    </style>`;
    svg = svg.replace(/(<svg[^>]*>)/i, `$1\n${styleBlock}\n`);
  }

  // Replace HTML tag wrappers with SVG compliant ones
  svg = svg
    .replace(/<strong>(.*?)<\/strong>/gi, '<tspan font-weight="bold">$1</tspan>')
    .replace(/<b>(.*?)<\/b>/gi, '<tspan font-weight="bold">$1</tspan>')
    .replace(/<em>(.*?)<\/em>/gi, '<tspan font-style="italic">$1</tspan>')
    .replace(/<i>(.*?)<\/i>/gi, '<tspan font-style="italic">$1</tspan>')
    .replace(/<br\s*\/?>/gi, ' ');

  // Replace all unescaped ampersands with &amp;
  // Look for & that is NOT followed by a valid XML entity name or numeric char reference
  svg = svg.replace(/&(?!(?:amp|lt|gt|quot|apos|#\d+|#x[0-9a-fA-F]+);)/g, '&amp;');

  return svg;
}

/**
 * Smart Word-boundary Text Wrapping for Indic & Multilingual Strings
 * Wraps text into lines that do not exceed maxCharsPerLine without slicing words or Indic conjuncts.
 * If text exceeds maxLines, it safely terminates at a word boundary and appends overflowSuffix (' ಮುಂತಾದವು', '…', or ' ಇತ್ಯಾದಿ').
 */
export function wrapScholarlyText(
  text: string,
  maxCharsPerLine: number,
  maxLines: number = 3,
  overflowSuffix: string = ' ಮುಂತಾದವು'
): string[] {
  if (!text) return [];
  const clean = text.replace(/[<>&"]/g, '').trim();
  if (!clean) return [];

  // Split by whitespace while preserving words
  const words = clean.split(/\s+/).filter(Boolean);
  if (words.length === 0) return [];

  const lines: string[] = [];
  let currentLine = '';

  for (let i = 0; i < words.length; i++) {
    const word = words[i];
    const testLine = currentLine ? `${currentLine} ${word}` : word;

    if (testLine.length <= maxCharsPerLine) {
      currentLine = testLine;
    } else {
      if (currentLine) {
        lines.push(currentLine);
        currentLine = word;
      } else {
        // Single word exceeds line threshold, keep word intact
        lines.push(word);
        currentLine = '';
      }

      if (lines.length === maxLines - 1) {
        // We are on the last allowed line, gather remaining words cleanly
        const remainingWords = words.slice(i + (currentLine ? 0 : 1));
        if (remainingWords.length > 0) {
          let lastLine = currentLine;
          let addedCount = 0;
          for (const remWord of remainingWords) {
            const testLast = lastLine ? `${lastLine} ${remWord}` : remWord;
            const neededSuffix = remainingWords.length > addedCount + 1 ? overflowSuffix : '';
            if ((testLast + neededSuffix).length <= maxCharsPerLine) {
              lastLine = testLast;
              addedCount++;
            } else {
              break;
            }
          }
          if (addedCount < remainingWords.length) {
            // Trim trailing punctuation like comma before adding suffix
            lastLine = lastLine.replace(/[,;.\-—]+$/, '');
            lastLine = (lastLine ? `${lastLine}${overflowSuffix}` : overflowSuffix).trim();
          }
          if (lastLine) lines.push(lastLine);
          currentLine = '';
          break;
        }
      }
    }
  }

  if (currentLine && lines.length < maxLines) {
    lines.push(currentLine);
  }

  return lines;
}

/**
 * Render multi-line SVG <text> element with <tspan> lines
 */
export function renderSvgWrappedText(
  lines: string[],
  x: number,
  startY: number,
  lineHeight: number = 14,
  attributes: {
    fontSize?: number;
    fontWeight?: string;
    fill?: string;
    textAnchor?: 'start' | 'middle' | 'end';
    fontStyle?: 'normal' | 'italic';
  } = {}
): string {
  if (!lines || lines.length === 0) return '';
  const {
    fontSize = 10,
    fontWeight = 'normal',
    fill = '#1F1916',
    textAnchor = 'start',
    fontStyle = 'normal'
  } = attributes;

  if (lines.length === 1) {
    return `<text x="${x}" y="${startY}" text-anchor="${textAnchor}" font-size="${fontSize}" font-weight="${fontWeight}" font-style="${fontStyle}" fill="${fill}">${lines[0]}</text>`;
  }

  let res = `<text x="${x}" y="${startY}" text-anchor="${textAnchor}" font-size="${fontSize}" font-weight="${fontWeight}" font-style="${fontStyle}" fill="${fill}">`;
  lines.forEach((line, idx) => {
    if (idx === 0) {
      res += `<tspan x="${x}">${line}</tspan>`;
    } else {
      res += `<tspan x="${x}" dy="${lineHeight}">${line}</tspan>`;
    }
  });
  res += `</text>`;
  return res;
}

export async function renderSvgToPngBuffer(svgString: string, targetWidth = 1400): Promise<Buffer> {
  const cleanSvg = sanitizeSvgForXml(svgString);

  // 1. Primary engine: Resvg with bundled TrueType Kannada, Devanagari & Latin fonts
  // This directly loads the TrueType glyph tables and uses HarfBuzz/USV for Kannada sub-base
  // consonants, completely preventing missing glyph boxes (tofu) and ensuring razor-sharp rendering.
  try {
    const fontFiles = getAvailableFontFiles();
    const resvg = new Resvg(cleanSvg, {
      fitTo: { mode: 'width', value: targetWidth },
      font: {
        loadSystemFonts: true,
        fontFiles: fontFiles.length > 0 ? fontFiles : undefined,
        defaultFontFamily: 'Noto Sans Kannada',
        sansSerifFamily: 'Noto Sans Kannada',
        serifFamily: 'Noto Sans Kannada',
      },
    });
    const pngData = resvg.render();
    const resvgBuffer = Buffer.from(pngData.asPng());
    if (resvgBuffer && resvgBuffer.length > 500) {
      try {
        const trimmed = await sharp(resvgBuffer)
          .trim({ background: '#FAF7F2', threshold: 10 })
          .extend({ top: 16, bottom: 16, left: 16, right: 16, background: '#FAF7F2' })
          .png({ quality: 95 })
          .toBuffer();
        if (trimmed && trimmed.length > 500) {
          return trimmed;
        }
      } catch {
        // Return untrimmed
      }
      return resvgBuffer;
    }
  } catch (resvgErr) {
    console.warn('Resvg primary rasterization error, attempting secondary engine:', resvgErr);
  }

  // 2. Secondary engine: Sharp
  try {
    const rawRaster = await sharp(Buffer.from(cleanSvg), { density: 200 })
      .resize({ width: targetWidth, withoutEnlargement: false })
      .png({ quality: 95 })
      .toBuffer();
    if (rawRaster && rawRaster.length > 500) {
      return rawRaster;
    }
  } catch (sharpErr) {
    console.warn('Sharp vector rasterization fallback failed:', sharpErr);
  }

  // 3. Fallback clean canvas bitmap
  return await sharp({
    create: {
      width: targetWidth,
      height: Math.round(targetWidth * 0.45),
      channels: 4,
      background: { r: 250, g: 247, b: 242, alpha: 1 },
    },
  })
    .png()
    .toBuffer();
}

const KANNADA_DIGITS = ['೦', '೧', '೨', '೩', '೪', '೫', '೬', '೭', '೮', '೯'];

export function toKannadaDigits(n: number | string): string {
  return String(n).replace(/[0-9]/g, (d) => KANNADA_DIGITS[parseInt(d, 10)] || d);
}

// Canonical Sanskrit/Kannada corrections for common truncations or misspellings in Vedic contexts
const CANONICAL_VEDIC_TERMS: Record<string, { primary: string; detail?: string }> = {
  'ಪ್ರಾ': { primary: 'ಪ್ರಾಣ', detail: 'ಜೀವವಾಯು / ಜೀವಶಕ್ತಿ' },
  'ಪ್ರಾಣ': { primary: 'ಪ್ರಾಣ', detail: 'ಜೀವವಾಯು / ಜೀವಶಕ್ತಿ' },
  'ಸಾಮ': { primary: 'ಸಾಮ', detail: 'ಗಾಯನ / ನಾದ' },
  'ಸ್ವರ': { primary: 'ಸ್ವರ', detail: 'ಧ್ವನಿ / ನಾದ' },
  'ಅನ್ನ': { primary: 'ಅನ್ನ', detail: 'ಆಹಾರ / ಪೃಥ್ವಿ' },
  'ಆಪಃ': { primary: 'ಆಪಃ', detail: 'ನೀರು / ಉದಕ' },
  'ಆಪ': { primary: 'ಆಪಃ', detail: 'ನೀರು / ಉದಕ' },
  'ವಾಕ್': { primary: 'ವಾಕ್', detail: 'ಋಕ್ / ವಾಣಿ' },
  'ವಾ': { primary: 'ವಾಕ್', detail: 'ಋಕ್ / ವಾಣಿ' },
  'ಓಷಧಿ': { primary: 'ಓಷಧಿಗಳು', detail: 'ವನಸ್ಪತಿ / ಸಸ್ಯ' },
  'ಓಷಧಿಗಳು': { primary: 'ಓಷಧಿಗಳು', detail: 'ವನಸ್ಪತಿ / ಸಸ್ಯ' },
  'ಭೂಮಿ': { primary: 'ಭೂಮಿ', detail: 'ಪೃಥ್ವಿ / ಆಧಾರ' },
  'ಪೃಥ್ವಿ': { primary: 'ಪೃಥ್ವಿ', detail: 'ಭೂಮಂಡಲ / ಆಧಾರ' },
  'ಉದ್ಗೀಥ': { primary: 'ಉದ್ಗೀಥ', detail: 'ಓಂಕಾರ / ಪ್ರಣವ' },
  'ಓಂ': { primary: 'ಓಂಕಾರ', detail: 'ಪರಬ್ರಹ್ಮ ಪ್ರಣವ' },
  'ಓಂಕಾರ': { primary: 'ಓಂಕಾರ', detail: 'ಪರಬ್ರಹ್ಮ ಪ್ರಣವ' },
  'ಪುರುಷ': { primary: 'ಪುರುಷ', detail: 'ಚೇತನ / ಜೀವ' },
};

/**
 * Master dispatcher for Scholarly Visual Diagrams
 */
export function generateScholarlySvgDiagram(
  title: string,
  description: string,
  conceptNodes?: string[] | null,
  tableHeaders?: string[],
  tableRows?: string[][]
): string {
  const safeTitle = (title || 'ಶಾಸ್ತ್ರೀಯ ಪರಿಕಲ್ಪನಾ ರೇಖಾಚಿತ್ರ').replace(/[<>&"]/g, '');
  const corpus = ((description || '') + ' ' + safeTitle + ' ' + (conceptNodes || []).join(' ')).toLowerCase();

  // 1. Purnatva Concept (ಪೂರ್ಣತ್ವ)
  if (
    corpus.includes('ಪೂರ್ಣ') ||
    corpus.includes('ಪೂರ್ಣತ್ವ') ||
    corpus.includes('purna') ||
    corpus.includes('ಪೂರ್ಣಮದಃ') ||
    corpus.includes('ಪೂರ್ಣಮಿದಂ')
  ) {
    return generatePurnatvaConceptSvg(safeTitle, description);
  }

  // 2. Brahma - Jagat & Karana-Karya Concept (ಬ್ರಹ್ಮ–ಜಗತ್ / ಕಾರಣ-ಕಾರ್ಯ)
  if (
    (corpus.includes('ಬ್ರಹ್ಮ') && (corpus.includes('ಜಗತ್') || corpus.includes('ಪ್ರಪಂಚ') || corpus.includes('ಸೃಷ್ಟಿ'))) ||
    (corpus.includes('ಕಾರಣ') && corpus.includes('ಕಾರ್ಯ')) ||
    corpus.includes('ಅದ್ವೈತ') ||
    corpus.includes('ಮಾಯಾ')
  ) {
    return generateBrahmaJagatConceptSvg(safeTitle, description);
  }

  // 3. Yoga & Asanas (ಪದ್ಮಾಸನ, ಸಿದ್ಧಾಸನ, ವಜ್ರಾಸನ, ಸ್ವಸ್ತಿಕಾಸನ, ಧ್ಯಾನಾಸನ, ಸುಖಾಸನ)
  if (
    corpus.includes('ಆಸನ') ||
    corpus.includes('ಪದ್ಮಾಸನ') ||
    corpus.includes('ಸಿದ್ಧಾಸನ') ||
    corpus.includes('ವಜ್ರಾಸನ') ||
    corpus.includes('ಸ್ವಸ್ತಿಕಾಸನ') ||
    corpus.includes('ಧ್ಯಾನಾಸನ') ||
    corpus.includes('ಸುಖಾಸನ') ||
    corpus.includes('ಯೋಗಾಸನ') ||
    corpus.includes('ಪ್ರಾಣಾಯಾಮ') ||
    corpus.includes('ಮುದ್ರಾ')
  ) {
    let asanaName = 'ಪದ್ಮಾಸನ (ಧ್ಯಾನಾಸನ)';
    if (corpus.includes('ಸಿದ್ಧಾಸನ')) asanaName = 'ಸಿದ್ಧಾಸನ (ಧ್ಯಾನಾಸನ)';
    else if (corpus.includes('ವಜ್ರಾಸನ')) asanaName = 'ವಜ್ರಾಸನ (ಸ್ಥಿರಾಸನ)';
    else if (corpus.includes('ಸ್ವಸ್ತಿಕಾಸನ')) asanaName = 'ಸ್ವಸ್ತಿಕಾಸನ (ಮಂಗಲಾಸನ)';
    else if (corpus.includes('ಸುಖಾಸನ')) asanaName = 'ಸುಖಾಸನ (ಸರಳಾಸನ)';
    else if (corpus.includes('ಪದ್ಮಾಸನ')) asanaName = 'ಪದ್ಮಾಸನ (ಕಮಲಾಸನ)';
    return generateAsanaIllustrationSvg(asanaName, safeTitle, description);
  }

  // 4. Pancha Mahabhootas & Sharira Tattvas (ಪಂಚಭೂತ, ಪಂಚಮಹಾಭೂತ, ಇಂದ್ರಿಯ, ದೇಹಧಾರಣೆ)
  const isPanchaBhoota =
    corpus.includes('ಪಂಚಭೂತ') ||
    corpus.includes('ಪಂಚಮಹಾಭೂತ') ||
    (corpus.includes('ಪೃಥ್ವಿ') && (corpus.includes('ಅಪ್ಪು') || corpus.includes('ಜಲ') || corpus.includes('ಧಾರಣ'))) ||
    (corpus.includes('ಪೃಥಿವೀ') && corpus.includes('ತೇಜ')) ||
    (corpus.includes('ಧಾರಣೇ') && corpus.includes('ಪಿಂಡೀಕರಣೇ')) ||
    (corpus.includes('ಇಂದ್ರಿಯ') && (corpus.includes('ವಿಷಯ') || corpus.includes('ಕಾರ್ಯ') || corpus.includes('ಭೂತ')));

  if (isPanchaBhoota) {
    return generatePanchabhootaShariraSvg(safeTitle, description);
  }

  // 5. Astronomy / Solar System / Grahas (ಖಗೋಳ, ಸೌರಮಂಡಲ, ನವಗ್ರಹ)
  // STRICT GUARD: Must NOT trigger on sensory perception (ಗ್ರಹಿಸು/ಗ್ರಹಣ), body tissue, or Garbhopanishad!
  const isBiologicalOrSensory =
    corpus.includes('ಗರ್ಭ') ||
    corpus.includes('ಭ್ರೂಣ') ||
    corpus.includes('ಶರೀರ') ||
    corpus.includes('ದೇಹ') ||
    corpus.includes('ಇಂದ್ರಿಯ') ||
    corpus.includes('ಧಾತು') ||
    corpus.includes('ಭೂತ');

  const isGenuineAstronomy =
    !isBiologicalOrSensory &&
    (corpus.includes('ಖಗೋಳ') ||
      corpus.includes('ಸೌರಮಂಡಲ') ||
      corpus.includes('ಗ್ರಹಮಂಡಲ') ||
      corpus.includes('ನವಗ್ರಹ') ||
      corpus.includes('ದ್ವಾದಶರಾಶಿ') ||
      corpus.includes('ಜ್ಯೋತಿಷ್ಯ') ||
      corpus.includes('ಖಗೋಳಶಾಸ್ತ್ರ'));

  if (isGenuineAstronomy) {
    return generateAstronomyDiagramSvg(safeTitle, description);
  }

  // 6. Mathematics & Geometry (ಗಣಿತ, ಜ್ಯಾಮಿತಿ, ವೃತ್ತ, ತ್ರಿಭುಜ, ಕೋನ, ಶುಲ್ಬಸೂತ್ರ, ಯಂತ್ರ)
  if (
    corpus.includes('ಗಣಿತ') ||
    corpus.includes('ಜ್ಯಾಮಿತಿ') ||
    corpus.includes('ವೃತ್ತ') ||
    corpus.includes('ತ್ರಿಭುಜ') ||
    corpus.includes('ಕೋನ') ||
    corpus.includes('ಪ್ರಮಾಣ') ||
    corpus.includes('ಅನುಪಾತ') ||
    corpus.includes('ಶುಲ್ಬ') ||
    corpus.includes('ಯಂತ್ರ') ||
    corpus.includes('ಜ್ಯಾ') ||
    corpus.includes('ವಿಸ್ತೀರ್ಣ')
  ) {
    return generateGeometryMathDiagramSvg(safeTitle, description);
  }

  // 7. Pancha Koshas / Concentric Layers (ಪಂಚಕೋಶ)
  if (corpus.includes('ಕೋಶ') || corpus.includes('ಅನ್ನಮಯ') || corpus.includes('ಪ್ರಾಣಮಯ') || corpus.includes('ಆನಂದಮಯ')) {
    return generateConcentricKoshaSvg(safeTitle, description);
  }

  // 8. Comparison Matrix (ವ್ಯತ್ಯಾಸ / ತುಲನೆ / ಹಂತಗಳು)
  const isComparison =
    corpus.includes('ವ್ಯತ್ಯಾಸ') ||
    corpus.includes('ತುಲನೆ') ||
    corpus.includes('ಭೇದ') ||
    corpus.includes('vs') ||
    (tableHeaders && tableHeaders.length === 2) ||
    (tableHeaders && tableHeaders.length === 3 && (tableHeaders[0].includes('ವಿಷಯ') || tableHeaders[0].includes('ಅಂಶ') || tableHeaders[0].includes('ಕ್ರಮ') || tableHeaders[0].includes('ಹಂತ')));

  if (isComparison && tableRows && tableRows.length >= 2) {
    return generateComparisonSvg(safeTitle, description, tableHeaders, tableRows);
  }

  // 9. Counts & Taxonomies (ಸಂಖ್ಯೆ, ಸಪ್ತಧಾತು, ತ್ರಿದೋಷ, ಚತುರ್ವಿಧಾಹಾರ, ಷಡಾಶ್ರಯ, ಅಷ್ಟಾಂಗ)
  const isMathOrCount =
    corpus.includes('ಸಂಖ್ಯೆ') ||
    corpus.includes('ಗಣನೆ') ||
    corpus.includes('ಭೂತ') ||
    corpus.includes('ದೋಷ') ||
    corpus.includes('ಧಾತು') ||
    corpus.includes('ಸಪ್ತಧಾತು') ||
    corpus.includes('ಗುಣ') ||
    corpus.includes('ಆಹಾರ') ||
    corpus.includes('ಆಶ್ರಯ') ||
    (tableRows && tableRows.length >= 2);

  if (isMathOrCount && tableRows && tableRows.length >= 2) {
    return generateTaxonomyCountSvg(safeTitle, description, tableHeaders, tableRows);
  }

  // Default: Flow Sequence Diagram
  return generateFlowSequenceSvg(safeTitle, description, conceptNodes, tableHeaders, tableRows);
}

/**
 * 1. Purnatva Concept Diagram (ಪೂರ್ಣತ್ವ ತತ್ತ್ವ ನಕ್ಷೆ)
 */
export function generatePurnatvaConceptSvg(safeTitle: string, description: string): string {
  const width = 720;
  const height = 340;
  const safeDesc = (description || 'ಪೂರ್ಣ ಪರಬ್ರಹ್ಮನಿಂದ ಪೂರ್ಣ ಜಗತ್ತು ಪ್ರಕಟವಾದರೂ, ಮೂಲ ಪೂರ್ಣತ್ವವು ಎಂದಿಗೂ ಅಖಂಡವಾಗಿರುತ್ತದೆ.').replace(/[<>&"]/g, '');

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="100%" height="100%" style="font-family:'Noto Sans Kannada', 'Noto Sans Devanagari', 'Noto Sans', sans-serif; background:#FAF7F2; border-radius:12px; border:1px solid #E8DEC8;">
  <defs>
    <linearGradient id="purnaGold" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#C2410C" />
      <stop offset="50%" stop-color="#8B1E0F" />
      <stop offset="100%" stop-color="#4A0D06" />
    </linearGradient>
    <linearGradient id="jagatBlue" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#1E40AF" />
      <stop offset="100%" stop-color="#1E293B" />
    </linearGradient>
    <linearGradient id="bgHeaderPurna" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#F5ECE0" />
      <stop offset="50%" stop-color="#EADDCB" />
      <stop offset="100%" stop-color="#F5ECE0" />
    </linearGradient>
    <filter id="purnaGlow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="3" stdDeviation="4" flood-color="#8B1E0F" flood-opacity="0.25" />
    </filter>
    <marker id="purnaArrow" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
      <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#C2410C" />
    </marker>
    <marker id="returnArrow" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
      <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#0F766E" />
    </marker>
  </defs>

  <!-- Card Header -->
  <rect x="0" y="0" width="${width}" height="46" fill="url(#bgHeaderPurna)" />
  <line x1="0" y1="46" x2="${width}" y2="46" stroke="#DCCBB5" stroke-width="1.5" />
  <text x="${width / 2}" y="28" text-anchor="middle" font-size="14" font-weight="bold" fill="#8B1E0F">
    ॥ ${safeTitle} - ಪೂರ್ಣತ್ವದ ಶಾಸ್ತ್ರೀಯ ತತ್ತ್ವ ಸರಣಿ ॥
  </text>

  <!-- Left Sphere: Parabrahma (Purna 1) -->
  <g filter="url(#purnaGlow)">
    <circle cx="150" cy="155" r="75" fill="url(#purnaGold)" stroke="#FBD38D" stroke-width="3" />
    <circle cx="150" cy="155" r="62" fill="none" stroke="#FDE68A" stroke-width="1.2" stroke-dasharray="4,3" />
    <text x="150" y="132" text-anchor="middle" font-size="11" font-weight="bold" fill="#FDE68A">ಅವ್ಯಕ್ತ ಕಾರಣ</text>
    <text x="150" y="156" text-anchor="middle" font-size="15" font-weight="bold" fill="#FFFFFF">ಪೂರ್ಣಂ ಅದಃ</text>
    <text x="150" y="176" text-anchor="middle" font-size="10.5" fill="#FEF08A">ಪರಬ್ರಹ್ಮ (ಅನಂತ)</text>
    <text x="150" y="194" text-anchor="middle" font-size="9.5" fill="#FFFFFF" opacity="0.9">[ ∞ (Infinity) ]</text>
  </g>

  <!-- Center Transformation / Srishti Flow -->
  <g>
    <!-- Forward Srishti Flow -->
    <path d="M 235 135 Q 360 95 475 135" fill="none" stroke="#C2410C" stroke-width="3" marker-end="url(#purnaArrow)" />
    <rect x="295" y="92" width="130" height="24" rx="12" fill="#8B1E0F" />
    <text x="360" y="108" text-anchor="middle" font-size="10" font-weight="bold" fill="#FFFFFF">ಸೃಷ್ಟಿ ವಿಕಾಸ (ಪ್ರಕಟಣೆ)</text>

    <!-- Mathematical Formula Core -->
    <rect x="260" y="145" width="200" height="42" rx="8" fill="#FFFFFF" stroke="#8B1E0F" stroke-width="1.5" />
    <text x="360" y="163" text-anchor="middle" font-size="11" font-weight="bold" fill="#8B1E0F">ಪೂರ್ಣಸ್ಯ ಪೂರ್ಣಮಾದಾಯ</text>
    <text x="360" y="179" text-anchor="middle" font-size="10.5" font-weight="bold" fill="#1E40AF">∞ - ∞ = ∞ (ಪೂರ್ಣಮೇವಾವಶಿಷ್ಯತೇ)</text>

    <!-- Return Laya / Jnana Flow -->
    <path d="M 475 185 Q 360 225 235 185" fill="none" stroke="#0F766E" stroke-width="3" marker-end="url(#returnArrow)" />
    <rect x="295" y="200" width="130" height="24" rx="12" fill="#0F766E" />
    <text x="360" y="216" text-anchor="middle" font-size="10" font-weight="bold" fill="#FFFFFF">ಲಯ / ಅಖಂಡ ಜ್ಞಾನ</text>
  </g>

  <!-- Right Sphere: Jagat (Purna 2) -->
  <g filter="url(#purnaGlow)">
    <circle cx="570" cy="155" r="75" fill="url(#jagatBlue)" stroke="#93C5FD" stroke-width="3" />
    <circle cx="570" cy="155" r="62" fill="none" stroke="#BFDBFE" stroke-width="1.2" stroke-dasharray="4,3" />
    <text x="570" y="132" text-anchor="middle" font-size="11" font-weight="bold" fill="#93C5FD">ವ್ಯಕ್ತ ಕಾರ್ಯ</text>
    <text x="570" y="156" text-anchor="middle" font-size="15" font-weight="bold" fill="#FFFFFF">ಪೂರ್ಣಂ ಇದಂ</text>
    <text x="570" y="176" text-anchor="middle" font-size="10.5" fill="#BFDBFE">ಜಗತ್ತು (ನಾಮ-ರೂಪ)</text>
    <text x="570" y="194" text-anchor="middle" font-size="9.5" fill="#FFFFFF" opacity="0.9">[ ∞ (ಪೂರ್ಣ ಸೃಷ್ಟಿ) ]</text>
  </g>

  <!-- Footer Explanation -->
  <rect x="20" y="268" width="${width - 40}" height="56" rx="8" fill="#FFFFFF" stroke="#E2D8C7" />
  <text x="35" y="288" font-size="11" font-weight="bold" fill="#8B1E0F">ಶಾಸ್ತ್ರೀಯ ತತ್ತ್ವ ಸಾರಾಂಶ:</text>
  ${renderSvgWrappedText(wrapScholarlyText(safeDesc, 82, 2, ' ಮುಂತಾದವು'), 35, 305, 14, { fontSize: 10, fill: '#2D3748' })}
</svg>`;
}

/**
 * 2. Brahma - Jagat & Karana-Karya Ontological Map (ಬ್ರಹ್ಮ–ಜಗತ್ ತತ್ತ್ವ ನಕ್ಷೆ)
 */
export function generateBrahmaJagatConceptSvg(safeTitle: string, description: string): string {
  const width = 720;
  const height = 320;
  const safeDesc = (description || 'ಬ್ರಹ್ಮವು ಜಗತ್ತಿಗೆ ಅಭಿನ್ನ-ನಿಮಿತ್ತೋಪಾದಾನ ಕಾರಣ (ಮಣ್ಣು-ಮಡಕೆ, ಚಿನ್ನ-ಆಭರಣಗಳಂತೆ).').replace(/[<>&"]/g, '');

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="100%" height="100%" style="font-family:'Noto Sans Kannada', 'Noto Sans Devanagari', 'Noto Sans', sans-serif; background:#FAF7F2; border-radius:12px; border:1px solid #E8DEC8;">
  <defs>
    <linearGradient id="brahmaGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#8B1E0F" />
      <stop offset="100%" stop-color="#5B1008" />
    </linearGradient>
    <linearGradient id="mayaGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0F766E" />
      <stop offset="100%" stop-color="#115E59" />
    </linearGradient>
    <linearGradient id="jagatGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#1E40AF" />
      <stop offset="100%" stop-color="#1E3A8A" />
    </linearGradient>
    <marker id="bjArrow" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
      <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#8B1E0F" />
    </marker>
  </defs>

  <!-- Header -->
  <rect x="0" y="0" width="${width}" height="44" fill="#F4EADB" />
  <line x1="0" y1="44" x2="${width}" y2="44" stroke="#DBC8B0" stroke-width="1.5" />
  <text x="${width / 2}" y="27" text-anchor="middle" font-size="14" font-weight="bold" fill="#8B1E0F">
    ॥ ${safeTitle} - ಬ್ರಹ್ಮ–ಜಗತ್ ಸಂಬಂಧ ಹಾಗೂ ಕಾರಣ–ಕಾರ್ಯ ನಕ್ಷೆ ॥
  </text>

  <!-- 3 Major Vertical Pillars -->
  <!-- Pillar 1: Brahma (Karana) -->
  <g transform="translate(30, 60)">
    <rect x="0" y="0" width="200" height="185" rx="10" fill="url(#brahmaGrad)" stroke="#FBD38D" stroke-width="2" />
    <rect x="12" y="12" width="176" height="26" rx="4" fill="#6B1408" />
    <text x="100" y="30" text-anchor="middle" font-size="12" font-weight="bold" fill="#FDE68A">೧. ಮೂಲ ಸತ್ಯ (ಅಧಿಷ್ಠಾನ)</text>
    <text x="100" y="65" text-anchor="middle" font-size="16" font-weight="bold" fill="#FFFFFF">ಪರಬ್ರಹ್ಮ</text>
    <text x="100" y="86" text-anchor="middle" font-size="10.5" fill="#FEF08A">ಸಚ್ಚಿದಾನಂದ ಸ್ವರೂಪ</text>
    
    <line x1="15" y1="100" x2="185" y2="100" stroke="#FDE68A" stroke-width="0.8" opacity="0.6" />
    <text x="25" y="120" font-size="10" fill="#FFFFFF">• ನಿತ್ಯ ಶುದ್ಧ ಬುದ್ಧ ಮುಕ್ತ</text>
    <text x="25" y="140" font-size="10" fill="#FFFFFF">• ಉಪಾದಾನ + ನಿಮಿತ್ತ ಕಾರಣ</text>
    <text x="25" y="160" font-size="10" fill="#FFFFFF">• ಅವಿಕಾರ್ಯ, ಸರ್ವವ್ಯಾಪಿ</text>
  </g>

  <!-- Arrow 1 -> 2 -->
  <path d="M 235 150 L 265 150" stroke="#8B1E0F" stroke-width="3" marker-end="url(#bjArrow)" />

  <!-- Pillar 2: Maya / Prakriti (Upadhi) -->
  <g transform="translate(260, 60)">
    <rect x="0" y="0" width="200" height="185" rx="10" fill="url(#mayaGrad)" stroke="#99F6E4" stroke-width="2" />
    <rect x="12" y="12" width="176" height="26" rx="4" fill="#0D5E57" />
    <text x="100" y="30" text-anchor="middle" font-size="12" font-weight="bold" fill="#99F6E4">೨. ಪರಿಣಾಮಕ ಶಕ್ತಿ</text>
    <text x="100" y="65" text-anchor="middle" font-size="16" font-weight="bold" fill="#FFFFFF">ಮಾಯಾ / ಪ್ರಕೃತಿ</text>
    <text x="100" y="86" text-anchor="middle" font-size="10.5" fill="#CCFBF1">ತ್ರಿಗುಣಾತ್ಮಕ ಶಕ್ತಿ</text>
    
    <line x1="15" y1="100" x2="185" y2="100" stroke="#99F6E4" stroke-width="0.8" opacity="0.6" />
    <text x="25" y="120" font-size="10" fill="#FFFFFF">• ಸತ್ತ್ವ, ರಜಸ್, ತಮಸ್</text>
    <text x="25" y="140" font-size="10" fill="#FFFFFF">• ಆವರಣ ಮತ್ತು ವಿಕ್ಷೇಪ ಶಕ್ತಿ</text>
    <text x="25" y="160" font-size="10" fill="#FFFFFF">• ಜಗನ್ನಿರ್ಮಾಣದ ಉಪಾಧಿ</text>
  </g>

  <!-- Arrow 2 -> 3 -->
  <path d="M 465 150 L 495 150" stroke="#8B1E0F" stroke-width="3" marker-end="url(#bjArrow)" />

  <!-- Pillar 3: Jagat (Karya) -->
  <g transform="translate(490, 60)">
    <rect x="0" y="0" width="200" height="185" rx="10" fill="url(#jagatGrad)" stroke="#BFDBFE" stroke-width="2" />
    <rect x="12" y="12" width="176" height="26" rx="4" fill="#172554" />
    <text x="100" y="30" text-anchor="middle" font-size="12" font-weight="bold" fill="#BFDBFE">೩. ವ್ಯಕ್ತ ಪ್ರಪಂಚ</text>
    <text x="100" y="65" text-anchor="middle" font-size="16" font-weight="bold" fill="#FFFFFF">ಜಗತ್ತು / ಪ್ರಪಂಚ</text>
    <text x="100" y="86" text-anchor="middle" font-size="10.5" fill="#DBEAFE">ನಾಮ-ರೂಪ-ಕ್ರಿಯೆ</text>
    
    <line x1="15" y1="100" x2="185" y2="100" stroke="#BFDBFE" stroke-width="0.8" opacity="0.6" />
    <text x="25" y="120" font-size="10" fill="#FFFFFF">• ಪಂಚಭೂತಗಳು, ಜೀವಿಗಳು</text>
    <text x="25" y="140" font-size="10" fill="#FFFFFF">• ಕಾರ್ಯ ಸ್ವರೂಪ (ವಿಕಾರ)</text>
    <text x="25" y="160" font-size="10" fill="#FFFFFF">• ವ್ಯವಹಾರಿಕ ಸತ್ಯ</text>
  </g>

  <!-- Footer Analogies -->
  <rect x="30" y="258" width="${width - 60}" height="48" rx="8" fill="#FFFFFF" stroke="#E2D8C7" />
  <text x="45" y="278" font-size="10.5" font-weight="bold" fill="#8B1E0F">ಶಾಸ್ತ್ರೀಯ ದೃಷ್ಟಾಂತಗಳು (Analogies):</text>
  <text x="45" y="296" font-size="10" fill="#2D3748">ಸುವರ್ಣ-ಕುಂಡಲ (ಚಿನ್ನ ಮತ್ತು ಒಡವೆ), ಮೃತ್ತಿಕಾ-ಘಟ (ಮಣ್ಣು ಮತ್ತು ಮಡಕೆ), ಸಮುದ್ರ-ತರಂಗ (ಸಮುದ್ರ ಮತ್ತು ಅಲೆಗಳು).</text>
</svg>`;
}

/**
 * 3. Asana Educational Schematic Diagram (ಯೋಗ / ಪದ್ಮಾಸನ / ಧ್ಯಾನಾಸನ ಚಿತ್ರ)
 */
export function generateAsanaIllustrationSvg(asanaName: string, safeTitle: string, description: string): string {
  const width = 720;
  const height = 360;
  const safeDesc = (description || 'ಮೇರುದಂಡವನ್ನು (ಬೆನ್ನುಹುರಿ) ನೆಟ್ಟಗೆ ಇರಿಸಿ, ಪಾದಗಳನ್ನು ತೊಡೆಗಳ ಮೇಲಿಟ್ಟು ಚಿನ್ಮುದ್ರೆಯಲ್ಲಿ ಧ್ಯಾನಸ್ಥಿತಿಯನ್ನು ಹೊಂದುವುದು.').replace(/[<>&"]/g, '');

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="100%" height="100%" style="font-family:'Noto Sans Kannada', 'Noto Sans Devanagari', 'Noto Sans', sans-serif; background:#FAF7F2; border-radius:12px; border:1px solid #E8DEC8;">
  <defs>
    <linearGradient id="asanaHeaderGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#F5ECE0" />
      <stop offset="50%" stop-color="#E8DAC7" />
      <stop offset="100%" stop-color="#F5ECE0" />
    </linearGradient>
    <linearGradient id="bodyGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#C2410C" />
      <stop offset="100%" stop-color="#8B1E0F" />
    </linearGradient>
    <filter id="chakraGlow" x="-30%" y="-30%" width="160%" height="160%">
      <feDropShadow dx="0" dy="0" stdDeviation="3" flood-color="#F59E0B" flood-opacity="0.6" />
    </filter>
  </defs>

  <!-- Header -->
  <rect x="0" y="0" width="${width}" height="46" fill="url(#asanaHeaderGrad)" />
  <line x1="0" y1="46" x2="${width}" y2="46" stroke="#DBC8B0" stroke-width="1.5" />
  <text x="${width / 2}" y="28" text-anchor="middle" font-size="14" font-weight="bold" fill="#8B1E0F">
    ॥ ${safeTitle} - ${asanaName} ಶಾಸ್ತ್ರೀಯ ರೇಖಾಚಿತ್ರ ॥
  </text>

  <!-- Left: Yoga Posture Schematic Figure (Padmasana / Dhyanasana) -->
  <g transform="translate(40, 60)">
    <!-- Base Mat / Asana Peetha -->
    <ellipse cx="140" cy="225" rx="120" ry="24" fill="#E2D5C3" stroke="#8B1E0F" stroke-width="1.5" />
    <ellipse cx="140" cy="225" rx="100" ry="16" fill="#F5EFE6" />

    <!-- Vertical Sushumna Axis (Spine Alignment Line) -->
    <line x1="140" y1="20" x2="140" y2="220" stroke="#EF4444" stroke-width="2" stroke-dasharray="4,3" />
    
    <!-- Human Body Silhouette Outline (Stylized Meditative Figure) -->
    <!-- Head -->
    <circle cx="140" cy="45" r="22" fill="url(#bodyGrad)" stroke="#FBD38D" stroke-width="2" />
    <circle cx="140" cy="24" r="5" fill="#F59E0B" filter="url(#chakraGlow)" /> <!-- Sahasrara -->
    
    <!-- Neck & Torso -->
    <path d="M 134 67 L 146 67 L 165 110 L 155 175 L 125 175 L 115 110 Z" fill="url(#bodyGrad)" stroke="#FBD38D" stroke-width="1.5" />

    <!-- Chakras on Spine -->
    <circle cx="140" cy="45" r="3.5" fill="#60A5FA" /> <!-- Ajna -->
    <circle cx="140" cy="78" r="3.5" fill="#38BDF8" /> <!-- Vishuddha -->
    <circle cx="140" cy="115" r="4" fill="#34D399" /> <!-- Anahata -->
    <circle cx="140" cy="145" r="4" fill="#FBBF24" /> <!-- Manipura -->
    <circle cx="140" cy="175" r="4" fill="#FB923C" /> <!-- Svadhisthana -->
    <circle cx="140" cy="205" r="4" fill="#EF4444" /> <!-- Muladhara -->

    <!-- Arms & Hands in Jnana Mudra resting on knees -->
    <!-- Left Arm -->
    <path d="M 120 95 Q 70 140 60 190 Q 75 195 90 190 Q 95 160 125 125" fill="url(#bodyGrad)" opacity="0.95" />
    <circle cx="60" cy="190" r="8" fill="#FDE68A" stroke="#8B1E0F" stroke-width="1.5" /> <!-- Mudra -->
    
    <!-- Right Arm -->
    <path d="M 160 95 Q 210 140 220 190 Q 205 195 190 190 Q 185 160 155 125" fill="url(#bodyGrad)" opacity="0.95" />
    <circle cx="220" cy="190" r="8" fill="#FDE68A" stroke="#8B1E0F" stroke-width="1.5" /> <!-- Mudra -->

    <!-- Crossed Legs / Lotus Lock (Padma Bandha) -->
    <path d="M 125 170 Q 70 180 55 205 Q 140 235 225 205 Q 210 180 155 170 Z" fill="url(#bodyGrad)" stroke="#FBD38D" stroke-width="1.5" />
    <ellipse cx="100" cy="205" rx="20" ry="10" fill="#FDE68A" stroke="#8B1E0F" /> <!-- Left Foot over right thigh -->
    <ellipse cx="180" cy="205" rx="20" ry="10" fill="#FDE68A" stroke="#8B1E0F" /> <!-- Right Foot over left thigh -->
  </g>

  <!-- Right: Detailed Anatomical Key & Alignment Rules -->
  <g transform="translate(340, 60)">
    <rect x="0" y="0" width="340" height="235" rx="8" fill="#FFFFFF" stroke="#E2D8C7" />
    
    <rect x="10" y="10" width="320" height="24" rx="4" fill="#8B1E0F" />
    <text x="170" y="26" text-anchor="middle" font-size="11" font-weight="bold" fill="#FFFFFF">ಆಸನ ಲಕ್ಷಣಗಳು ಮತ್ತು ವಿಜ್ಞಾನ ವಿಧಿ</text>

    <text x="20" y="55" font-size="11" font-weight="bold" fill="#C2410C">೧. ಮೇರುದಂಡ (Spine Alignment):</text>
    <text x="35" y="72" font-size="10" fill="#2D3748">ಕಾಯಶಿರೋಗ್ರೀವಂ ಸಮಂ ಕಾಯಂ (ಬೆನ್ನುಹುರಿ, ಕುತ್ತಿಗೆ, ತಲೆ ನೇರ)</text>

    <text x="20" y="95" font-size="11" font-weight="bold" fill="#C2410C">೨. ಪಾದಬಂಧನ (Leg Lock):</text>
    <text x="35" y="112" font-size="10" fill="#2D3748">ಉಭಯ ಪಾದಗಳನ್ನು ವಿರುದ್ಧ ತೊಡೆಗಳ ಮೇಲೆ ಭದ್ರವಾಗಿರಿಸುವುದು</text>

    <text x="20" y="135" font-size="11" font-weight="bold" fill="#C2410C">೩. ಜ್ಞಾನಮುದ್ರಾ (Hand Mudra):</text>
    <text x="35" y="152" font-size="10" fill="#2D3748">ಹೆಬ್ಬೆರಳು-ತೋರುಬೆರಳುಗಳ ಸಂಯೋಗ, ಅಂಗೈ ಮೇಲ್ಮುಖ</text>

    <text x="20" y="175" font-size="11" font-weight="bold" fill="#C2410C">೪. ದೃಷ್ಟಿಸ್ಥಾನ ಮತ್ತು ಪ್ರಾಣಾಯಾಮ (Focus and Breath):</text>
    <text x="35" y="192" font-size="10" fill="#2D3748">ನಾಸಾಗ್ರ ದೃಷ್ಟಿ ಅಥವಾ ಭ್ರೂಮಧ್ಯ ದೃಷ್ಟಿ, ಸಮ ಶ್ವಾಸ-ಪ್ರಶ್ವಾಸ</text>

    <text x="20" y="215" font-size="10.5" font-style="italic" fill="#0F766E">ಸಿದ್ಧಿ ಫಲ: ಮನಸ್ಸಿನ ಏಕಾಗ್ರತೆ, ಷಟ್ಚಕ್ರ ಜಾಗೃತಿ, ಕುಂಡಲಿನೀ ಪ್ರಬೋಧ.</text>
  </g>

  <!-- Footer -->
  <rect x="20" y="306" width="${width - 40}" height="42" rx="6" fill="#F4EADB" />
  <text x="35" y="331" font-size="10" fill="#4A0D06"><strong>ಶಾಸ್ತ್ರೀಯ ಸೂತ್ರ:</strong> "ಸ್ಥಿರಸುಖಮಾಸನಮ್" (ಪಾತಂಜಲ ಯೋಗಸೂತ್ರ ೨.೪೬) - ಸ್ಥಿರತೆ ಮತ್ತು ಸುಖವೇ ಆಸನದ ಮುಖ್ಯ ಲಕ್ಷಣ.</text>
</svg>`;
}

/**
 * 4. Astronomy / Solar System / Grahas Diagram (ಖಗೋಳ / ಸೂರ್ಯಮಂಡಲ / ಗ್ರಹ ನಕ್ಷೆ)
 */
export function generateAstronomyDiagramSvg(safeTitle: string, description: string): string {
  const width = 720;
  const height = 360;
  const safeDesc = (description || 'ಸೂರ್ಯಕೇಂದ್ರಿತ ಸೌರಮಂಡಲದಲ್ಲಿ ನವಗ್ರಹಗಳ ಕಕ್ಷೆಗಳು ಹಾಗೂ ದ್ವಾದಶ ರಾಶಿಗಳ ಶಾಸ್ತ್ರೀಯ ವಿಭಾಗ.').replace(/[<>&"]/g, '');

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="100%" height="100%" style="font-family:'Noto Sans Kannada', 'Noto Sans Devanagari', 'Noto Sans', sans-serif; background:#0B132B; border-radius:12px; border:1px solid #1C2541;">
  <defs>
    <radialGradient id="sunGrad" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#FEF08A" />
      <stop offset="50%" stop-color="#F59E0B" />
      <stop offset="100%" stop-color="#DC2626" />
    </radialGradient>
    <filter id="sunGlow" x="-50%" y="-50%" width="200%" height="200%">
      <feDropShadow dx="0" dy="0" stdDeviation="8" flood-color="#F59E0B" flood-opacity="0.8" />
    </filter>
  </defs>

  <!-- Header -->
  <rect x="0" y="0" width="${width}" height="44" fill="#1C2541" />
  <line x1="0" y1="44" x2="${width}" y2="44" stroke="#3A506B" stroke-width="1.5" />
  <text x="${width / 2}" y="27" text-anchor="middle" font-size="14" font-weight="bold" fill="#FDE047">
    ॥ ${safeTitle} - ಖಗೋಳ ಮತ್ತು ಸೂರ್ಯಮಂಡಲ ಗ್ರಹ ಸ್ಥಾನ ನಕ್ಷೆ ॥
  </text>

  <!-- Left: Solar System with Concentric Orbits -->
  <g transform="translate(190, 200)">
    <!-- Orbits -->
    <circle cx="0" cy="0" r="35" fill="none" stroke="#3A506B" stroke-width="1" stroke-dasharray="3,3" />
    <circle cx="0" cy="0" r="60" fill="none" stroke="#3A506B" stroke-width="1" stroke-dasharray="3,3" />
    <circle cx="0" cy="0" r="90" fill="none" stroke="#3A506B" stroke-width="1" stroke-dasharray="3,3" />
    <circle cx="0" cy="0" r="120" fill="none" stroke="#3A506B" stroke-width="1" stroke-dasharray="3,3" />
    <circle cx="0" cy="0" r="150" fill="none" stroke="#3A506B" stroke-width="1" stroke-dasharray="3,3" />

    <!-- Central Sun (Surya) -->
    <circle cx="0" cy="0" r="22" fill="url(#sunGrad)" filter="url(#sunGlow)" />
    <text x="0" y="4" text-anchor="middle" font-size="9" font-weight="bold" fill="#450A0A">ಸೂರ್ಯ</text>

    <!-- Budha (Mercury) -->
    <circle cx="28" cy="-20" r="5" fill="#94A3B8" />
    <text x="32" y="-28" font-size="8" fill="#E2E8F0">ಬುಧ</text>

    <!-- Shukra (Venus) -->
    <circle cx="-50" cy="30" r="7" fill="#FDE047" />
    <text x="-75" y="42" font-size="8" fill="#E2E8F0">ಶುಕ್ರ</text>

    <!-- Prithvi & Chandra (Earth & Moon) -->
    <circle cx="75" cy="45" r="8" fill="#38BDF8" />
    <circle cx="86" cy="38" r="3" fill="#E2E8F0" />
    <text x="70" y="65" font-size="8" fill="#38BDF8">ಭೂಮಿ/ಚಂದ್ರ</text>

    <!-- Mangala (Mars) -->
    <circle cx="-100" cy="-60" r="7" fill="#EF4444" />
    <text x="-125" y="-70" font-size="8" fill="#FCA5A5">ಮಂಗಳ</text>

    <!-- Guru (Jupiter) -->
    <circle cx="125" cy="-75" r="13" fill="#F59E0B" />
    <text x="142" y="-72" font-size="8.5" font-weight="bold" fill="#FDE68A">ಗುರು</text>

    <!-- Shani (Saturn with Rings) -->
    <circle cx="-135" cy="65" r="10" fill="#CA8A04" />
    <ellipse cx="-135" cy="65" rx="18" ry="4" fill="none" stroke="#EAB308" stroke-width="1.5" />
    <text x="-155" y="85" font-size="8.5" fill="#FEF08A">ಶನಿ</text>
  </g>

  <!-- Right: Navagraha & Astronomical Coordinates Card -->
  <g transform="translate(410, 60)">
    <rect x="0" y="0" width="280" height="235" rx="8" fill="#1C2541" stroke="#3A506B" />
    
    <rect x="10" y="10" width="260" height="24" rx="4" fill="#3A506B" />
    <text x="140" y="26" text-anchor="middle" font-size="11" font-weight="bold" fill="#FDE047">ಶಾಸ್ತ್ರೀಯ ಖಗೋಳ ವಿಭಾಗ</text>

    <text x="20" y="55" font-size="10.5" font-weight="bold" fill="#93C5FD">೧. ಕೇಂದ್ರ ಬಿಂದು (Center):</text>
    <text x="35" y="70" font-size="9.5" fill="#E2E8F0">ಸೂರ್ಯ (ರವಿ) - ಆತ್ಮಕಾರಕ, ಪ್ರಾಣಮಂಡಲ ಕೇಂದ್ರ</text>

    <text x="20" y="92" font-size="10.5" font-weight="bold" fill="#93C5FD">೨. ಗ್ರಹ ಮಂಡಲ (Planets):</text>
    <text x="35" y="107" font-size="9.5" fill="#E2E8F0">ಬುಧ, ಶುಕ್ರ, ಭೂಮಿ, ಮಂಗಳ, ಗುರು, ಶನಿ</text>

    <text x="20" y="129" font-size="10.5" font-weight="bold" fill="#93C5FD">೩. ಛಾಯಾ ಗ್ರಹಗಳು (Nodal Points):</text>
    <text x="35" y="144" font-size="9.5" fill="#E2E8F0">ರಾಹು (ಉತ್ತರ ನೋಡ್) ಮತ್ತು ಕೇತು (ದಕ್ಷಿಣ ನೋಡ್)</text>

    <text x="20" y="166" font-size="10.5" font-weight="bold" fill="#93C5FD">೪. ದ್ವಾದಶ ರಾಶಿ ಚಕ್ರ (12 Zodiacs):</text>
    <text x="35" y="181" font-size="9.5" fill="#E2E8F0">ಮೇಷ, ವೃಷಭ, ಮಿಥುನ... ೩೬೦° ಕ್ರಾಂತಿ ವೃತ್ತ</text>

    <text x="20" y="203" font-size="10.5" font-weight="bold" fill="#93C5FD">೫. ಸಪ್ತವಿಂಶತಿ ನಕ್ಷತ್ರಗಳು:</text>
    <text x="35" y="218" font-size="9.5" fill="#E2E8F0">೨೭ ನಕ್ಷತ್ರಗಳು, ಪ್ರತಿ ನಕ್ಷತ್ರಕ್ಕೆ ೪ ಪಾದಗಳು (೧೦೮)</text>
  </g>

  <!-- Footer -->
  <rect x="20" y="306" width="${width - 40}" height="42" rx="6" fill="#1C2541" stroke="#3A506B" />
  <text x="35" y="331" font-size="9.5" fill="#94A3B8"><tspan font-weight="bold">ವಿಜ್ಞಾನ ಸಮನ್ವಯ:</tspan> ಪ್ರಾಚೀನ ಸೂರ್ಯಸಿದ್ಧಾಂತ ಮತ್ತು ಆಧುನಿಕ ಖಗೋಳಶಾಸ್ತ್ರ ಎರಡೂ ಗ್ರಹಗಳ ಕಕ್ಷಾ ಪರಿಭ್ರಮಣೆಯನ್ನು ನಿಖರವಾಗಿ ಸಮರ್ಥಿಸುತ್ತವೆ.</text>
</svg>`;
}

/**
 * 5. Mathematics & Geometry Diagram (ಗಣಿತ, ಜ್ಯಾಮಿತಿ, ವೃತ್ತ, ತ್ರಿಭುಜ, ಶುಲ್ಬಸೂತ್ರ)
 */
export function generateGeometryMathDiagramSvg(safeTitle: string, description: string): string {
  const width = 720;
  const height = 350;
  const safeDesc = (description || 'ವೃತ್ತ, ತ್ರಿಕೋನ, ಚತುರ್ಭುಜಗಳ ಜ್ಯಾಮಿತೀಯ ಪ್ರಮೇಯ ಹಾಗೂ ಶುಲ್ಬಸೂತ್ರಗಳ ನಿಖರ ಗಣಿತ ಸಂಬಂಧ.').replace(/[<>&"]/g, '');

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="100%" height="100%" style="font-family:'Noto Sans Kannada', 'Noto Sans Devanagari', 'Noto Sans', sans-serif; background:#FAF7F2; border-radius:12px; border:1px solid #E8DEC8;">
  <defs>
    <linearGradient id="mathHeaderGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#F5ECE0" />
      <stop offset="50%" stop-color="#E8DAC7" />
      <stop offset="100%" stop-color="#F5ECE0" />
    </linearGradient>
  </defs>

  <!-- Header -->
  <rect x="0" y="0" width="${width}" height="44" fill="url(#mathHeaderGrad)" />
  <line x1="0" y1="44" x2="${width}" y2="44" stroke="#DBC8B0" stroke-width="1.5" />
  <text x="${width / 2}" y="27" text-anchor="middle" font-size="14" font-weight="bold" fill="#8B1E0F">
    ॥ ${safeTitle} - ಶಾಸ್ತ್ರೀಯ ಗಣಿತ ಮತ್ತು ಜ್ಯಾಮಿತಿ ಪರಿಮಾಣ ರೇಖಾಚಿತ್ರ ॥
  </text>

  <!-- Left: Concentric Geometry & Geometric Forms (Vritta, Tribhuja, Shulba) -->
  <g transform="translate(40, 60)">
    <!-- Outer Square (Bhoopura) -->
    <rect x="10" y="10" width="220" height="220" fill="#FFFFFF" stroke="#8B1E0F" stroke-width="2" />
    
    <!-- Inscribed Circle (Vritta) -->
    <circle cx="120" cy="120" r="100" fill="#FFFBEB" stroke="#1E40AF" stroke-width="2" />
    
    <!-- Triangle 1 (Downward Prakriti) -->
    <polygon points="120,215 35,68 205,68" fill="none" stroke="#C2410C" stroke-width="2" />
    
    <!-- Triangle 2 (Upward Purusha - Star Formation) -->
    <polygon points="120,25 35,172 205,172" fill="none" stroke="#0F766E" stroke-width="2" />

    <!-- Center Bindu (Origin Point) -->
    <circle cx="120" cy="120" r="4.5" fill="#8B1E0F" />
    <text x="120" y="138" text-anchor="middle" font-size="9" font-weight="bold" fill="#8B1E0F">ಮಹಾಬಿಂದು</text>

    <!-- Dimension Annotations -->
    <line x1="120" y1="120" x2="220" y2="120" stroke="#1E40AF" stroke-width="1.5" stroke-dasharray="2,2" />
    <text x="165" y="114" text-anchor="middle" font-size="9" font-weight="bold" fill="#1E40AF">ತ್ರಿಜ್ಯ (r)</text>
  </g>

  <!-- Right: Mathematical Formulas & Geometric Theorems Card -->
  <g transform="translate(300, 60)">
    <rect x="0" y="0" width="380" height="225" rx="8" fill="#FFFFFF" stroke="#E2D8C7" />
    
    <rect x="10" y="10" width="360" height="24" rx="4" fill="#1E40AF" />
    <text x="190" y="26" text-anchor="middle" font-size="11" font-weight="bold" fill="#FFFFFF">ಜ್ಯಾಮಿತೀಯ ಪ್ರಮೇಯಗಳು ಮತ್ತು ಶುಲ್ಬ ಸೂತ್ರಗಳು</text>

    <text x="20" y="55" font-size="11" font-weight="bold" fill="#8B1E0F">೧. ವೃತ್ತ ಪರಿಮಾಣ (Circle Metrics):</text>
    <text x="35" y="72" font-size="10" fill="#2D3748">ಪರಿಧಿ (Circumference) = 2πr  |  ಕ್ಷೇತ್ರಫಲ (Area) = πr²</text>

    <text x="20" y="95" font-size="11" font-weight="bold" fill="#8B1E0F">೨. ಶುಲ್ಬ-ಬೋಧಾಯನ ಸಿದ್ಧಾಂತ (Pythagoras Theorem):</text>
    <text x="35" y="112" font-size="10" fill="#2D3748">ಕರ್ಣ² = ಬಾಹು₁² + ಬಾಹು₂² (a² + b² = c²)</text>

    <text x="20" y="135" font-size="11" font-weight="bold" fill="#8B1E0F">೩. ಸುವರ್ಣ ಅನುಪಾತ (Golden Ratio - Φ):</text>
    <text x="35" y="152" font-size="10" fill="#2D3748">ಯಂತ್ರ ರಚನೆಯಲ್ಲಿ 1 : 1.618 ನೈಸರ್ಗಿಕ ಸಮ್ಮಿತಿ ನಿಯಮ</text>

    <text x="20" y="175" font-size="11" font-weight="bold" fill="#8B1E0F">೪. ಛಂದಶ್ಶಾಸ್ತ್ರೀಯ ಮಾತ್ರಾಗಣನೆ (Metrical Math):</text>
    <text x="35" y="192" font-size="10" fill="#2D3748">ಲಘು (೧ ಮಾತ್ರಾ), ಗುರು (೨ ಮಾತ್ರಾ), ಪಿಂಗಳ ಛಂದಸ್ಸಿನ ೨ⁿ ಸಂಯೋಜನೆ</text>

    <text x="20" y="215" font-size="9.5" font-style="italic" fill="#0F766E">ಗಣಿತವು ವೇದಾಂಗ ಜ್ಯೋತಿಷ ಮತ್ತು ಶುಲ್ಬಶಾಸ್ತ್ರಗಳ ಆಧಾರ ಸ್ತಂಭವಾಗಿದೆ.</text>
  </g>

  <!-- Footer -->
  <rect x="20" y="296" width="${width - 40}" height="42" rx="6" fill="#F4EADB" />
  <text x="35" y="321" font-size="10" fill="#4A0D06"><tspan font-weight="bold">ವೇದ ಗಣಿತ ಸೂತ್ರ:</tspan> "ಯಥಾ ಶಿಖಾ ಮಯೂರಾಣಾಂ ನಾಗಾನಾಂ ಮಣಯೋ ಯಥಾ । ತದ್ವದ್ವೇದಾಂಗಶಾಸ್ತ್ರಾಣಾಂ ಗಣಿತಂ ಮೂರ್ಧ್ನಿ ವರ್ತತೇ ॥"</text>
</svg>`;
}

/**
 * 6. Pancha Koshas / Concentric Rings SVG
 */
export function generateConcentricKoshaSvg(safeTitle: string, description: string): string {
  const width = 720;
  const height = 340;
  const safeDesc = (description || 'ಆತ್ಮನನ್ನು ಆವರಿಸಿರುವ ಪಂಚಕೋಶಗಳು: ಅನ್ನಮಯ, ಪ್ರಾಣಮಯ, ಮನೋಮಯ, ವಿಜ್ಞಾನಮಯ ಮತ್ತು ಆನಂದಮಯ.').replace(/[<>&"]/g, '');

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="100%" height="100%" style="font-family:'Noto Sans Kannada', 'Noto Sans Devanagari', 'Noto Sans', sans-serif; background:#FAF7F2; border-radius:12px; border:1px solid #E8DEC8;">
  <!-- Header -->
  <rect x="0" y="0" width="${width}" height="44" fill="#F5ECE0" />
  <line x1="0" y1="44" x2="${width}" y2="44" stroke="#DBC8B0" stroke-width="1.5" />
  <text x="${width / 2}" y="27" text-anchor="middle" font-size="14" font-weight="bold" fill="#8B1E0F">
    ॥ ${safeTitle} - ಪಂಚಕೋಶ ತತ್ತ್ವ ಸರಣಿ ॥
  </text>

  <!-- Left: Concentric Koshas -->
  <g transform="translate(180, 185)">
    <!-- 1. Annamaya (Outermost) -->
    <circle cx="0" cy="0" r="115" fill="#FEE2E2" stroke="#EF4444" stroke-width="2" />
    <!-- 2. Pranamaya -->
    <circle cx="0" cy="0" r="92" fill="#FEF3C7" stroke="#F59E0B" stroke-width="2" />
    <!-- 3. Manomaya -->
    <circle cx="0" cy="0" r="70" fill="#D1FAE5" stroke="#10B981" stroke-width="2" />
    <!-- 4. Vijnanamaya -->
    <circle cx="0" cy="0" r="48" fill="#DBEAFE" stroke="#3B82F6" stroke-width="2" />
    <!-- 5. Anandamaya -->
    <circle cx="0" cy="0" r="28" fill="#EDE9FE" stroke="#8B5CF6" stroke-width="2" />
    <!-- Center: Atman -->
    <circle cx="0" cy="0" r="12" fill="#8B1E0F" />
    <text x="0" y="4" text-anchor="middle" font-size="8" font-weight="bold" fill="#FFFFFF">ಆತ್ಮ</text>
  </g>

  <!-- Right: Kosha Details List -->
  <g transform="translate(360, 60)">
    <rect x="0" y="0" width="330" height="225" rx="8" fill="#FFFFFF" stroke="#E2D8C7" />
    
    <text x="20" y="30" font-size="11" font-weight="bold" fill="#EF4444">೧. ಅನ್ನಮಯ ಕೋಶ (ಸ್ಥೂಲ ಶರೀರ):</text>
    <text x="35" y="45" font-size="9.5" fill="#4B5563">ಆಹಾರದಿಂದ ಪೋಷಿತವಾದ ಭೌತಿಕ ದೇಹ</text>

    <text x="20" y="70" font-size="11" font-weight="bold" fill="#D97706">೨. ಪ್ರಾಣಮಯ ಕೋಶ (ಸೂಕ್ಷ್ಮ ಶರೀರ):</text>
    <text x="35" y="85" font-size="9.5" fill="#4B5563">ಪಂಚ ಪ್ರಾಣಗಳು ಮತ್ತು ಕರ್ಮೇಂದ್ರಿಯಗಳು</text>

    <text x="20" y="110" font-size="11" font-weight="bold" fill="#059669">೩. ಮನೋಮಯ ಕೋಶ:</text>
    <text x="35" y="125" font-size="9.5" fill="#4B5563">ಮನಸ್ಸು, ಸಂಕಲ್ಪ-ವಿಕಲ್ಪ, ಜ್ಞಾನೇಂದ್ರಿಯಗಳು</text>

    <text x="20" y="150" font-size="11" font-weight="bold" fill="#2563EB">೪. ವಿಜ್ಞಾನಮಯ ಕೋಶ:</text>
    <text x="35" y="165" font-size="9.5" fill="#4B5563">ಬುದ್ಧಿ, ವಿವೇಕ, ಕರ್ತೃತ್ವ ಭಾವ</text>

    <text x="20" y="190" font-size="11" font-weight="bold" fill="#7C3AED">೫. ಆನಂದಮಯ ಕೋಶ (ಕಾರಣ ಶರೀರ):</text>
    <text x="35" y="205" font-size="9.5" fill="#4B5563">ಪ್ರಿಯ, ಮೋದ, ಪ್ರಮೋದಗಳಿಂದ ಕೂಡಿದ ಅಜ್ಞಾನಾವಸ್ಥೆ</text>
  </g>

  <!-- Footer -->
  <rect x="20" y="296" width="${width - 40}" height="36" rx="6" fill="#F4EADB" />
  <text x="35" y="318" font-size="10" fill="#4A0D06"><tspan font-weight="bold">ತೈತ್ತಿರೀಯ ಉಪನಿಷತ್:</tspan> ಈ ಐದು ಕೋಶಗಳನ್ನು ದಾಟಿದಾಗ ಶುದ್ಧ ಸಾಕ್ಷಿ ಚೈತನ್ಯವಾದ ಪರಮಾತ್ಮನ ಸಾಕ್ಷಾತ್ಕಾರವಾಗುತ್ತದೆ.</text>
</svg>`;
}

/**
 * 7. Sequential Flowchart SVG (High-Readability A4 Book Format with 2x2 Balanced Grid)
 */
function generateFlowSequenceSvg(
  safeTitle: string,
  description: string,
  conceptNodes?: string[] | null,
  _tableHeaders?: string[],
  tableRows?: string[][]
): string {
  // Clean safeTitle and format cleanly
  let cleanTitle = (safeTitle || 'ಅನುಕ್ರಮ ಪರಿಕಲ್ಪನಾ ನಕ್ಷೆ')
    .replace(/\([A-Za-z\s,-]+\)/g, '')
    .replace(/\s+/g, ' ')
    .trim();

  // Strip duplicate phrases if present
  cleanTitle = cleanTitle
    .replace(/-\s*ಅನುಕ್ರಮ\s*ಪರಿಕಲ್ಪನಾ\s*ನಕ್ಷೆ/gi, '')
    .replace(/-\s*ಪರಿಕಲ್ಪನಾ\s*ನಕ್ಷೆ/gi, '')
    .replace(/ಅನುಕ್ರಮ\s*ಪರಿಕಲ್ಪನಾ\s*ನಕ್ಷೆ/gi, 'ಅನುಕ್ರಮ ಪರಿಕಲ್ಪನಾ ನಕ್ಷೆ')
    .trim();

  let rawNodes: string[] = [];
  if (conceptNodes && conceptNodes.length > 0) {
    rawNodes = conceptNodes.map((n) => n.trim().replace(/^[0-9೧-೯]+\.\s*/, '')).filter(Boolean);
  } else if (tableRows && tableRows.length > 0) {
    rawNodes = tableRows.map((r) => r[0] || '').filter(Boolean);
  } else if (description) {
    const arrowParts = description.split(/\s*(?:->|→|—>|⇒|=>|>)\s*/);
    if (arrowParts.length >= 2) {
      rawNodes = arrowParts.map((p) => p.trim().replace(/[.,;:]/g, '').replace(/^[0-9೧-೯]+\.\s*/, '')).filter(Boolean);
    } else {
      const lineParts = description.split(/\n+/).map((l) => l.trim().replace(/^[0-9೧-೯]+\.\s*/, '')).filter((l) => l.length > 2 && l.length < 50);
      if (lineParts.length >= 2) {
        rawNodes = lineParts;
      } else {
        const commaParts = description.split(/[,;]/).map((p) => p.trim()).filter((p) => p.length > 2 && p.length < 40);
        if (commaParts.length >= 2) {
          rawNodes = commaParts;
        }
      }
    }
  }

  if (rawNodes.length < 2) {
    rawNodes = [
      'ಮೂಲ ಕಾರಣ / ಅವ್ಯಕ್ತ ಬೀಜ',
      'ಪ್ರಕೃತಿ / ಸೂಕ್ಷ್ಮ ವಿಕಾಸ',
      'ಸ್ಥೂಲ ಕಾರ್ಯ / ಸೃಷ್ಟಿ ಪ್ರಪಂಚ',
      'ಪರಮಾರ್ಥ ಜ್ಞಾನ / ಸಾಕ್ಷಾತ್ಕಾರ'
    ];
  }

  // Allow up to 8 distinct steps for maximum A4 clarity
  const allNodes = rawNodes.slice(0, 8);
  const totalCount = allNodes.length;

  // Process nodes into structured { primaryTitle, detailText } to render large primary titles + clear subtitles
  const processedItems = allNodes.map((node) => {
    let clean = (node || '').replace(/[<>&"]/g, '').trim();
    let primary = clean;
    let detail = '';

    const parenMatch = clean.match(/^(.*?)\s*[\(\[（](.*?)[\)\]）]\s*$/);
    if (parenMatch && parenMatch[1].trim()) {
      primary = parenMatch[1].trim();
      detail = parenMatch[2].trim();
    } else if (clean.includes(' / ')) {
      const parts = clean.split(' / ');
      primary = parts[0].trim();
      detail = parts.slice(1).join(' / ').trim();
    } else if (clean.includes(' - ')) {
      const parts = clean.split(' - ');
      primary = parts[0].trim();
      detail = parts.slice(1).join(' - ').trim();
    } else if (clean.includes(': ')) {
      const parts = clean.split(': ');
      primary = parts[0].trim();
      detail = parts.slice(1).join(': ').trim();
    }

    // 1. Check canonical corrections
    const canonical = CANONICAL_VEDIC_TERMS[primary];
    if (canonical) {
      primary = canonical.primary;
      if (!detail || /^[A-Za-z\s,\.\-–—()]+$/.test(detail)) {
        detail = canonical.detail || '';
      }
    }

    // 2. Strip any English transliteration from primary if mixed
    primary = primary.replace(/\([A-Za-z\s,-]+\)/g, '').replace(/[A-Za-z]/g, '').trim();

    // 3. If detail is purely English (e.g. "Prana", "Water", "Sama"), suppress or use canonical
    if (/^[A-Za-z\s,\.\-–—()]+$/.test(detail)) {
      const canonDetail = CANONICAL_VEDIC_TERMS[primary]?.detail;
      detail = canonDetail || '';
    } else {
      detail = detail.replace(/\([A-Za-z\s,-]+\)/g, '').replace(/[A-Za-z]/g, '').trim();
    }

    return {
      primaryTitle: primary || 'ತತ್ತ್ವ',
      detailText: detail,
    };
  });

  const width = 760;

  // 1. SPECIFIC 4-STEP LAYOUT: 2x2 Balanced Grid (Book-Format Aspect Ratio 1.8:1)
  if (totalCount === 4) {
    const height = 410;
    const cardW = 320;
    const cardH = 125;
    const col1X = 40;
    const col2X = 400;
    const row1Y = 70;
    const row2Y = 235;

    const cards = [
      { ...processedItems[0], x: col1X, y: row1Y, grad: 'flowGrad1', stroke: '#FBD38D', stepText: 'ಹಂತ ೧', badgeColor: '#FDE68A' },
      { ...processedItems[1], x: col2X, y: row1Y, grad: 'flowGrad2', stroke: '#FBD38D', stepText: 'ಹಂತ ೨', badgeColor: '#FDE68A' },
      { ...processedItems[2], x: col1X, y: row2Y, grad: 'flowGrad3', stroke: '#99F6E4', stepText: 'ಹಂತ ೩', badgeColor: '#99F6E4' },
      { ...processedItems[3], x: col2X, y: row2Y, grad: 'flowGrad4', stroke: '#BFDBFE', stepText: 'ಹಂತ ೪', badgeColor: '#BFDBFE' },
    ];

    let svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="100%" height="100%" style="font-family:'Noto Sans Kannada', 'Noto Sans Devanagari', 'Noto Sans', sans-serif; background:#FAF7F2; border-radius:12px; border:1px solid #E8DEC8;">
  <defs>
    <linearGradient id="flowGrad1" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#8B1E0F" />
      <stop offset="100%" stop-color="#5B1008" />
    </linearGradient>
    <linearGradient id="flowGrad2" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#9A3412" />
      <stop offset="100%" stop-color="#7C2D12" />
    </linearGradient>
    <linearGradient id="flowGrad3" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0F766E" />
      <stop offset="100%" stop-color="#115E59" />
    </linearGradient>
    <linearGradient id="flowGrad4" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#1E40AF" />
      <stop offset="100%" stop-color="#1E3A8A" />
    </linearGradient>
    <marker id="flowArrow" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
      <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#C2410C" />
    </marker>
    <filter id="cardShadow" x="-5%" y="-5%" width="110%" height="110%">
      <feDropShadow dx="0" dy="2" stdDeviation="3" flood-color="#000000" flood-opacity="0.16" />
    </filter>
  </defs>

  <!-- Header Banner -->
  <rect x="0" y="0" width="${width}" height="48" fill="#F4EADB" />
  <line x1="0" y1="48" x2="${width}" y2="48" stroke="#DBC8B0" stroke-width="1.5" />
  <text x="${width / 2}" y="31" text-anchor="middle" font-size="16" font-weight="bold" fill="#8B1E0F">
    ॥ ${cleanTitle} ॥
  </text>
`;

    // Render 4 Cards
    cards.forEach((c) => {
      const pLines = wrapScholarlyText(c.primaryTitle, 22, 2, '…');
      const dLines = c.detailText ? wrapScholarlyText(c.detailText, 26, 2, '…') : [];
      const titleY = c.y + 60;
      const detailY = titleY + pLines.length * 20;

      const titleSvg = renderSvgWrappedText(pLines, c.x + cardW / 2, titleY, 20, {
        fontSize: 18.5,
        fontWeight: 'bold',
        fill: '#FFFFFF',
        textAnchor: 'middle',
      });

      const detailSvg = dLines.length > 0 ? renderSvgWrappedText(dLines, c.x + cardW / 2, detailY, 16, {
        fontSize: 13.5,
        fontWeight: 'normal',
        fill: c.badgeColor,
        textAnchor: 'middle',
      }) : '';

      svg += `
  <g filter="url(#cardShadow)">
    <rect x="${c.x}" y="${c.y}" width="${cardW}" height="${cardH}" rx="10" fill="url(#${c.grad})" stroke="${c.stroke}" stroke-width="1.8" />
    <rect x="${c.x + 14}" y="${c.y + 10}" width="82" height="24" rx="5" fill="#000000" fill-opacity="0.32" />
    <text x="${c.x + 55}" y="${c.y + 27}" text-anchor="middle" font-size="12.5" font-weight="bold" fill="${c.badgeColor}">
      ${c.stepText}
    </text>
    ${titleSvg}
    ${detailSvg}
  </g>`;
    });

    // Arrow 1 -> 2 (Top Row)
    svg += `
  <line x1="362" y1="${row1Y + cardH / 2}" x2="394" y2="${row1Y + cardH / 2}" stroke="#C2410C" stroke-width="3.5" marker-end="url(#flowArrow)" />`;

    // Curve Step 2 -> Step 3
    svg += `
  <path d="M 560 ${row1Y + cardH} C 560 215, 200 190, 200 ${row2Y - 6}" fill="none" stroke="#C2410C" stroke-width="3" stroke-dasharray="6,3" marker-end="url(#flowArrow)" />`;

    // Arrow 3 -> 4 (Bottom Row)
    svg += `
  <line x1="362" y1="${row2Y + cardH / 2}" x2="394" y2="${row2Y + cardH / 2}" stroke="#C2410C" stroke-width="3.5" marker-end="url(#flowArrow)" />`;

    // Footer
    svg += `
  <text x="${width / 2}" y="${height - 14}" text-anchor="middle" font-size="12" fill="#64748B" font-style="italic">
    ಶಾಸ್ತ್ರೀಯ ತತ್ತ್ವ ಸರಣಿ ಹಾಗೂ ಅನುಕ್ರಮ ರೇಖಾಚಿತ್ರ (ಒಟ್ಟು ಹಂತಗಳು: ೪)
  </text>
</svg>`;

    return svg;
  }

  // 2. GENERAL DYNAMIC LAYOUT (For 2, 3, 5, 6, 7, 8 steps)
  let colsPerRow = 3;
  if (totalCount <= 2) colsPerRow = 2;
  else if (totalCount === 3) colsPerRow = 3;
  else if (totalCount <= 6) colsPerRow = 3;
  else colsPerRow = 4;

  const numRows = Math.ceil(totalCount / colsPerRow);
  const horizontalPadding = colsPerRow === 2 ? 40 : 28;
  const colGap = colsPerRow === 2 ? 36 : 22;
  const rowGap = 36;
  const cardWidth = Math.floor((width - horizontalPadding * 2 - (colsPerRow - 1) * colGap) / colsPerRow);

  const maxChars = colsPerRow === 2 ? 26 : (colsPerRow === 3 ? 20 : 16);
  const cardHeight = colsPerRow === 2 ? 140 : 120;
  const startY = 70;
  const totalGridHeight = numRows * cardHeight + (numRows - 1) * rowGap;
  const height = Math.max(270, startY + totalGridHeight + 48);

  let svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="100%" height="100%" style="font-family:'Noto Sans Kannada', 'Noto Sans Devanagari', 'Noto Sans', sans-serif; background:#FAF7F2; border-radius:12px; border:1px solid #E8DEC8;">
  <defs>
    <linearGradient id="flowNodeGradA" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#8B1E0F" />
      <stop offset="100%" stop-color="#5B1008" />
    </linearGradient>
    <linearGradient id="flowNodeGradB" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#9A3412" />
      <stop offset="100%" stop-color="#7C2D12" />
    </linearGradient>
    <marker id="flowArrow" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
      <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#C2410C" />
    </marker>
  </defs>

  <!-- Header Banner -->
  <rect x="0" y="0" width="${width}" height="48" fill="#F4EADB" />
  <line x1="0" y1="48" x2="${width}" y2="48" stroke="#DBC8B0" stroke-width="1.5" />
  <text x="${width / 2}" y="31" text-anchor="middle" font-size="16" font-weight="bold" fill="#8B1E0F">
    ॥ ${cleanTitle} ॥
  </text>
`;

  // Render Rows
  for (let r = 0; r < numRows; r++) {
    const startIndex = r * colsPerRow;
    const countInThisRow = Math.min(colsPerRow, totalCount - startIndex);
    const rowY = startY + r * (cardHeight + rowGap);
    
    const rowContentWidth = countInThisRow * cardWidth + (countInThisRow - 1) * colGap;
    const rowStartX = Math.floor((width - rowContentWidth) / 2);

    for (let c = 0; c < countInThisRow; c++) {
      const idx = startIndex + c;
      const item = processedItems[idx];
      const x = rowStartX + c * (cardWidth + colGap);
      const isEven = idx % 2 === 0;
      const gradId = isEven ? 'flowNodeGradA' : 'flowNodeGradB';

      const pLines = wrapScholarlyText(item.primaryTitle, maxChars, 2, '…');
      const dLines = item.detailText ? wrapScholarlyText(item.detailText, maxChars + 4, 2, '…') : [];

      const textStartY = rowY + (colsPerRow === 2 ? 66 : 58);
      const titleSvg = renderSvgWrappedText(pLines, x + cardWidth / 2, textStartY, 20, {
        fontSize: colsPerRow === 2 ? 18.5 : (colsPerRow === 3 ? 17 : 14.5),
        fontWeight: 'bold',
        fill: '#FFFFFF',
        textAnchor: 'middle',
      });

      const detailY = textStartY + pLines.length * 19;
      const detailSvg = dLines.length > 0 ? renderSvgWrappedText(dLines, x + cardWidth / 2, detailY, 15, {
        fontSize: colsPerRow === 2 ? 13.5 : 12.5,
        fontWeight: 'normal',
        fill: '#FEF08A',
        textAnchor: 'middle',
      }) : '';

      svgContent += `
  <g>
    <rect x="${x}" y="${rowY}" width="${cardWidth}" height="${cardHeight}" rx="10" fill="url(#${gradId})" stroke="#FBD38D" stroke-width="1.6" />
    <rect x="${x + 10}" y="${rowY + 8}" width="80" height="24" rx="5" fill="#000000" fill-opacity="0.32" />
    <text x="${x + 50}" y="${rowY + 25}" text-anchor="middle" font-size="12.5" font-weight="bold" fill="#FDE68A">
      ಹಂತ ${toKannadaDigits(idx + 1)}
    </text>
    ${titleSvg}
    ${detailSvg}
  </g>`;

      // Horizontal arrow to next card
      if (c < countInThisRow - 1 && idx < totalCount - 1) {
        const arrowStartX = x + cardWidth + 2;
        const arrowEndX = arrowStartX + colGap - 4;
        const arrowY = rowY + cardHeight / 2;
        svgContent += `
  <line x1="${arrowStartX}" y1="${arrowY}" x2="${arrowEndX}" y2="${arrowY}" stroke="#C2410C" stroke-width="3" marker-end="url(#flowArrow)" />`;
      }
    }

    // Row transition connector
    if (r < numRows - 1 && startIndex + countInThisRow < totalCount) {
      const lastX = rowStartX + (countInThisRow - 1) * (cardWidth + colGap) + cardWidth / 2;
      const lastY = rowY + cardHeight;
      const nextRowFirstCount = Math.min(colsPerRow, totalCount - (r + 1) * colsPerRow);
      const nextRowContentWidth = nextRowFirstCount * cardWidth + (nextRowFirstCount - 1) * colGap;
      const nextRowStartX = Math.floor((width - nextRowContentWidth) / 2) + cardWidth / 2;
      const nextRowY = startY + (r + 1) * (cardHeight + rowGap);

      const midY = (lastY + nextRowY) / 2;
      svgContent += `
  <path d="M ${lastX} ${lastY + 2} C ${lastX} ${midY + 12}, ${nextRowStartX} ${midY - 12}, ${nextRowStartX} ${nextRowY - 4}" fill="none" stroke="#C2410C" stroke-width="3" stroke-dasharray="5,3" marker-end="url(#flowArrow)" />`;
    }
  }

  // Footer label
  svgContent += `
  <text x="${width / 2}" y="${height - 14}" text-anchor="middle" font-size="12" fill="#64748B" font-style="italic">
    ಶಾಸ್ತ್ರೀಯ ತತ್ತ್ವ ಸರಣಿ ಹಾಗೂ ಅನುಕ್ರಮ ರೇಖಾಚಿತ್ರ (ಒಟ್ಟು ಹಂತಗಳು: ${toKannadaDigits(totalCount)})
  </text>
</svg>`;

  return svgContent;
}

/**
 * 4. Pancha Mahabhootas & Sharira Tattvas Diagram (ಪಂಚಮಹಾಭೂತ ಹಾಗೂ ಶರೀರ ತತ್ತ್ವ ನಕ್ಷೆ)
 */
export function generatePanchabhootaShariraSvg(safeTitle: string, description: string): string {
  const width = 720;
  const height = 370;

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="100%" height="100%" style="font-family:'Noto Sans Kannada', 'Noto Sans Devanagari', 'Noto Sans', sans-serif; background:#FAF7F2; border-radius:12px; border:1px solid #E8DEC8;">
  <defs>
    <linearGradient id="headerGradPb" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#F5ECE0" />
      <stop offset="100%" stop-color="#E8DEC8" />
    </linearGradient>
    <linearGradient id="prithviGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#92400E" />
      <stop offset="100%" stop-color="#78350F" />
    </linearGradient>
    <linearGradient id="jalaGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0284C7" />
      <stop offset="100%" stop-color="#0369A1" />
    </linearGradient>
    <linearGradient id="tejasGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#DC2626" />
      <stop offset="100%" stop-color="#B91C1C" />
    </linearGradient>
    <linearGradient id="vayuGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0D9488" />
      <stop offset="100%" stop-color="#0F766E" />
    </linearGradient>
    <linearGradient id="akashaGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#4F46E5" />
      <stop offset="100%" stop-color="#4338CA" />
    </linearGradient>
  </defs>

  <!-- Header -->
  <rect x="0" y="0" width="${width}" height="44" fill="url(#headerGradPb)" />
  <line x1="0" y1="44" x2="${width}" y2="44" stroke="#DBC8B0" stroke-width="1.5" />
  <text x="${width / 2}" y="27" text-anchor="middle" font-size="13.5" font-weight="bold" fill="#8B1E0F">
    ॥ ${safeTitle} - ಪಂಚಮಹಾಭೂತ ಹಾಗೂ ಶರೀರ ತತ್ತ್ವ ನಕ್ಷೆ ॥
  </text>

  <!-- Top 5 Bhoota Element Cards -->
  <!-- 1. Prithvi -->
  <g transform="translate(24, 58)">
    <rect x="0" y="0" width="124" height="135" rx="8" fill="#FFFFFF" stroke="#92400E" stroke-width="1.5" />
    <rect x="0" y="0" width="124" height="28" rx="8" fill="url(#prithviGrad)" />
    <text x="62" y="19" text-anchor="middle" font-size="11.5" font-weight="bold" fill="#FEF3C7">೧. ಪೃಥ್ವಿ (ಭೂಮಿ)</text>
    
    <text x="62" y="46" text-anchor="middle" font-size="10" font-weight="bold" fill="#78350F">ಕಾರ್ಯ: ಧಾರಣೆ</text>
    <line x1="12" y1="53" x2="112" y2="53" stroke="#FDE68A" stroke-width="1" />
    <text x="62" y="70" text-anchor="middle" font-size="9.5" fill="#451A03">ದೇಹದಲ್ಲಿ ಕಾಠಿಣ್ಯ</text>
    <text x="62" y="86" text-anchor="middle" font-size="9.5" fill="#451A03">ಅಸ್ಥಿ, ಮಾಂಸ, ಚರ್ಮ</text>
    <rect x="10" y="100" width="104" height="24" rx="4" fill="#FEF3C7" />
    <text x="62" y="116" text-anchor="middle" font-size="9" font-weight="bold" fill="#92400E">ನಾಸಿಕಾ / ಗಂಧ</text>
  </g>

  <!-- 2. Jala / Apah -->
  <g transform="translate(160, 58)">
    <rect x="0" y="0" width="124" height="135" rx="8" fill="#FFFFFF" stroke="#0284C7" stroke-width="1.5" />
    <rect x="0" y="0" width="124" height="28" rx="8" fill="url(#jalaGrad)" />
    <text x="62" y="19" text-anchor="middle" font-size="11.5" font-weight="bold" fill="#E0F2FE">೨. ಅಪ್ಪು (ಜಲ)</text>
    
    <text x="62" y="46" text-anchor="middle" font-size="10" font-weight="bold" fill="#0369A1">ಕಾರ್ಯ: ಪಿಂಡೀಕರಣ</text>
    <line x1="12" y1="53" x2="112" y2="53" stroke="#BAE6FD" stroke-width="1" />
    <text x="62" y="70" text-anchor="middle" font-size="9.5" fill="#0C4A6E">ದೇಹದಲ್ಲಿ ದ್ರವತ್ವ</text>
    <text x="62" y="86" text-anchor="middle" font-size="9.5" fill="#0C4A6E">ರಕ್ತ, ಲಾಲಾರಸ, ಮೂತ್ರ</text>
    <rect x="10" y="100" width="104" height="24" rx="4" fill="#E0F2FE" />
    <text x="62" y="116" text-anchor="middle" font-size="9" font-weight="bold" fill="#0284C7">ಜಿಹ್ವಾ / ರಸ</text>
  </g>

  <!-- 3. Tejas / Agni -->
  <g transform="translate(296, 58)">
    <rect x="0" y="0" width="124" height="135" rx="8" fill="#FFFFFF" stroke="#DC2626" stroke-width="1.5" />
    <rect x="0" y="0" width="124" height="28" rx="8" fill="url(#tejasGrad)" />
    <text x="62" y="19" text-anchor="middle" font-size="11.5" font-weight="bold" fill="#FEE2E2">೩. ತೇಜಸ್ಸು (ಅಗ್ನಿ)</text>
    
    <text x="62" y="46" text-anchor="middle" font-size="10" font-weight="bold" fill="#B91C1C">ಕಾರ್ಯ: ಪ್ರಕಾಶನ</text>
    <line x1="12" y1="53" x2="112" y2="53" stroke="#FECACA" stroke-width="1" />
    <text x="62" y="70" text-anchor="middle" font-size="9.5" fill="#7F1D1D">ದೇಹದಲ್ಲಿ ಉಷ್ಣತೆ</text>
    <text x="62" y="86" text-anchor="middle" font-size="9.5" fill="#7F1D1D">ಜಠರಾಗ್ನಿ, ವರ್ಣ, ಕಾಂತಿ</text>
    <rect x="10" y="100" width="104" height="24" rx="4" fill="#FEE2E2" />
    <text x="62" y="116" text-anchor="middle" font-size="9" font-weight="bold" fill="#DC2626">ಚಕ್ಷು / ರೂಪ</text>
  </g>

  <!-- 4. Vayu -->
  <g transform="translate(432, 58)">
    <rect x="0" y="0" width="124" height="135" rx="8" fill="#FFFFFF" stroke="#0D9488" stroke-width="1.5" />
    <rect x="0" y="0" width="124" height="28" rx="8" fill="url(#vayuGrad)" />
    <text x="62" y="19" text-anchor="middle" font-size="11.5" font-weight="bold" fill="#CCFBF1">೪. ವಾಯು (ಗಾಳಿ)</text>
    
    <text x="62" y="46" text-anchor="middle" font-size="10" font-weight="bold" fill="#0F766E">ಕಾರ್ಯ: ಗಮನ (ಚಲನೆ)</text>
    <line x1="12" y1="53" x2="112" y2="53" stroke="#99F6E4" stroke-width="1" />
    <text x="62" y="70" text-anchor="middle" font-size="9.5" fill="#134E4A">ದೇಹದಲ್ಲಿ ಚಲನಶೀಲತೆ</text>
    <text x="62" y="86" text-anchor="middle" font-size="9.5" fill="#134E4A">ಶ್ವಾಸ, ಪ್ರಾಣ, ಸ್ಪಂದನ</text>
    <rect x="10" y="100" width="104" height="24" rx="4" fill="#CCFBF1" />
    <text x="62" y="116" text-anchor="middle" font-size="9" font-weight="bold" fill="#0D9488">ತ್ವಕ್ / ಸ್ಪರ್ಶ</text>
  </g>

  <!-- 5. Akasha -->
  <g transform="translate(568, 58)">
    <rect x="0" y="0" width="124" height="135" rx="8" fill="#FFFFFF" stroke="#4F46E5" stroke-width="1.5" />
    <rect x="0" y="0" width="124" height="28" rx="8" fill="url(#akashaGrad)" />
    <text x="62" y="19" text-anchor="middle" font-size="11.5" font-weight="bold" fill="#E0E7FF">೫. ಆಕಾಶ (ಶೂನ್ಯ)</text>
    
    <text x="62" y="46" text-anchor="middle" font-size="10" font-weight="bold" fill="#4338CA">ಕಾರ್ಯ: ಅವಕಾಶದಾನ</text>
    <line x1="12" y1="53" x2="112" y2="53" stroke="#C7D2FE" stroke-width="1" />
    <text x="62" y="70" text-anchor="middle" font-size="9.5" fill="#312E81">ದೇಹದಲ್ಲಿ ರಂಧ್ರ/ಕುಹರ</text>
    <text x="62" y="86" text-anchor="middle" font-size="9.5" fill="#312E81">ಹೃದಯಾವಕಾಶ, ಶ್ರೋತ್ರ</text>
    <rect x="10" y="100" width="104" height="24" rx="4" fill="#E0E7FF" />
    <text x="62" y="116" text-anchor="middle" font-size="9" font-weight="bold" fill="#4F46E5">ಶ್ರೋತ್ರ / ಶಬ್ದ</text>
  </g>

  <!-- Bottom Synthesis Box: Sharira Integration -->
  <g transform="translate(24, 208)">
    <rect x="0" y="0" width="672" height="114" rx="8" fill="#FFFFFF" stroke="#8B1E0F" stroke-width="1.2" />
    <rect x="0" y="0" width="672" height="26" rx="8" fill="#F4EADB" />
    <text x="336" y="18" text-anchor="middle" font-size="11" font-weight="bold" fill="#8B1E0F">
      ಶಾಸ್ತ್ರೀಯ ಸಮನ್ವಯ: ಪಂಚೀಕೃತ ಪಂಚಮಹಾಭೂತಗಳಿಂದ ಶರೀರ ನಿರ್ಮಾಣ ಹಾಗೂ ಜ್ಞಾನೇಂದ್ರಿಯಗಳ ಗ್ರಹಣ ಶಕ್ತಿ
    </text>
    
    <text x="20" y="48" font-size="10" font-weight="bold" fill="#C2410C">೧. ಸ್ಥೂಲ ಶರೀರ ಧಾರಣೆ:</text>
    <text x="145" y="48" font-size="10" fill="#2D3748">ಪೃಥ್ವಿ ಕಾಠಿಣ್ಯವನ್ನು, ಜಲವು ದ್ರವ-ಸ್ನಿಗ್ಧತೆಯನ್ನು, ಅಗ್ನಿಯು ಜೀರ್ಣಶಕ್ತಿ-ರೂಪಜ್ಞಾನವನ್ನು ನೀಡುತ್ತವೆ.</text>
    
    <text x="20" y="70" font-size="10" font-weight="bold" fill="#C2410C">೨. ಸೂಕ್ಷ್ಮ ವ್ಯಾಪಾರಗಳು:</text>
    <text x="145" y="70" font-size="10" fill="#2D3748">ವಾಯುವು ಪ್ರಾಣಾಪಾನಾದಿ ಚಲನೆಯನ್ನು, ಆಕಾಶವು ನಾಡಿ-ಹೃದಯಾದಿಗಳಲ್ಲಿ ಅವಕಾಶವನ್ನು ಕಲ್ಪಿಸುತ್ತದೆ.</text>
    
    <text x="20" y="94" font-size="10" font-weight="bold" fill="#047857">೩. ಉಪನಿಷತ್ ಸಿದ್ಧಾಂತ:</text>
    <text x="145" y="94" font-size="10" fill="#065F46">ದೇಹವು ಕೇವಲ ಮಾಂಸಪಿಂಡವಲ್ಲ; ಪಂಚಮಹಾಭೂತಗಳ ಸೂಕ್ಷ್ಮ ಸಂಯೋಗ ಮತ್ತು ಬ್ರಹ್ಮಾಂಡದ ಸಜೀವ ಪ್ರತೀಕ.</text>
  </g>

  <!-- Footer Citation -->
  <text x="${width / 2}" y="${height - 12}" text-anchor="middle" font-size="10" fill="#718096" font-style="italic">
    ಗರ್ಭೋಪನಿಷತ್ - ಪಂಚಭೂತಾತ್ಮಕಂ ಪಂಚಸು ವರ್ತಮಾನಂ ಶರೀರಂ
  </text>
</svg>`;
}

/**
 * 8. Comparison Matrix SVG with Smart Multi-line Text Wrapping
 */
function generateComparisonSvg(
  safeTitle: string,
  _description: string,
  tableHeaders?: string[],
  tableRows?: string[][]
): string {
  const width = 760;
  const rows = (tableRows && tableRows.length > 0) ? tableRows.slice(0, 16) : [
    ['ಅಂಶ ೧', 'ಪಕ್ಷ ೧ ವಿವರಣೆ', 'ಪಕ್ಷ ೨ ವಿವರಣೆ'],
    ['ಅಂಶ ೨', 'ಪಕ್ಷ ೧ ವಿವರಣೆ', 'ಪಕ್ಷ ೨ ವಿವರಣೆ']
  ];

  const col1Title = (tableHeaders && tableHeaders[0]) || 'ಕ್ರಮ / ವಿಷಯ';
  const col2Title = (tableHeaders && tableHeaders[1]) || 'ಧಾತು / ಹಂತ';
  const col3Title = (tableHeaders && tableHeaders[2]) || 'ಉತ್ಪತ್ತಿ / ಲಕ್ಷಣ';

  const col1Width = 160;
  const col2Width = 265;
  const col3Width = 275;
  const col1X = 25;
  const col2X = col1X + col1Width + 10;
  const col3X = col2X + col2Width + 10;

  // Process rows with wrapping
  const processedRows = rows.map((row) => {
    const c1 = (row[0] || '').trim();
    const c2 = (row[1] || '').trim();
    const c3 = (row[2] || row[1] || '').trim();

    const c1Lines = wrapScholarlyText(c1, 18, 2, '…');
    const c2Lines = wrapScholarlyText(c2, 30, 4, ' ಮುಂತಾದವು');
    const c3Lines = wrapScholarlyText(c3, 32, 4, ' ಮುಂತಾದವು');
    const maxLines = Math.max(c1Lines.length, c2Lines.length, c3Lines.length, 1);
    const rowHeight = Math.max(42, 18 + maxLines * 18);

    return { c1Lines, c2Lines, c3Lines, rowHeight };
  });

  const startY = 90;
  const totalRowsHeight = processedRows.reduce((sum, r) => sum + r.rowHeight + 8, 0);
  const height = Math.max(260, startY + totalRowsHeight + 40);

  let svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="100%" height="100%" style="font-family:'Noto Sans Kannada', 'Noto Sans Devanagari', 'Noto Sans', sans-serif; background:#FAF7F2; border-radius:12px; border:1px solid #E8DEC8;">
  <rect x="0" y="0" width="${width}" height="46" fill="#F4EADB" />
  <line x1="0" y1="46" x2="${width}" y2="46" stroke="#DBC8B0" stroke-width="1.5" />
  <text x="${width / 2}" y="29" text-anchor="middle" font-size="15" font-weight="bold" fill="#8B1E0F">
    ॥ ${safeTitle} - ತುಲನಾತ್ಮಕ ರೇಖಾಚಿತ್ರ ॥
  </text>

  <!-- Headers -->
  <rect x="${col1X}" y="54" width="${col1Width}" height="30" rx="5" fill="#6B1408" />
  <text x="${col1X + col1Width / 2}" y="74" text-anchor="middle" font-size="12.5" font-weight="bold" fill="#FFFFFF">${col1Title.replace(/[<>&"]/g, '')}</text>

  <rect x="${col2X}" y="54" width="${col2Width}" height="30" rx="5" fill="#8B1E0F" />
  <text x="${col2X + col2Width / 2}" y="74" text-anchor="middle" font-size="12.5" font-weight="bold" fill="#FFFFFF">${col2Title.replace(/[<>&"]/g, '')}</text>

  <rect x="${col3X}" y="54" width="${col3Width}" height="30" rx="5" fill="#1E40AF" />
  <text x="${col3X + col3Width / 2}" y="74" text-anchor="middle" font-size="12.5" font-weight="bold" fill="#FFFFFF">${col3Title.replace(/[<>&"]/g, '')}</text>
`;

  let currentY = startY;
  processedRows.forEach((r, i) => {
    const bgFill = i % 2 === 0 ? '#FFFFFF' : '#F7F3EE';
    const textStartY = currentY + 22;

    const c1Svg = renderSvgWrappedText(r.c1Lines, col1X + 12, textStartY, 18, {
      fontSize: 12,
      fontWeight: 'bold',
      fill: '#8B1E0F'
    });
    const c2Svg = renderSvgWrappedText(r.c2Lines, col2X + 12, textStartY, 18, {
      fontSize: 12,
      fontWeight: 'normal',
      fill: '#1F1916'
    });
    const c3Svg = renderSvgWrappedText(r.c3Lines, col3X + 12, textStartY, 18, {
      fontSize: 12,
      fontWeight: 'normal',
      fill: '#1F1916'
    });

    svgContent += `
  <rect x="${col1X}" y="${currentY}" width="${col1Width}" height="${r.rowHeight}" rx="5" fill="${bgFill}" stroke="#EADBCE" stroke-width="1.2" />
  ${c1Svg}

  <rect x="${col2X}" y="${currentY}" width="${col2Width}" height="${r.rowHeight}" rx="5" fill="${bgFill}" stroke="#EADBCE" stroke-width="1.2" />
  ${c2Svg}

  <rect x="${col3X}" y="${currentY}" width="${col3Width}" height="${r.rowHeight}" rx="5" fill="${bgFill}" stroke="#EADBCE" stroke-width="1.2" />
  ${c3Svg}
`;
    currentY += r.rowHeight + 8;
  });

  svgContent += `
  <text x="${width / 2}" y="${height - 12}" text-anchor="middle" font-size="11.5" fill="#718096" font-style="italic">
    ಶಾಸ್ತ್ರೀಯ ಭೇದ-ವ್ಯತ್ಯಾಸ ಹಾಗೂ ಲಕ್ಷಣಗಳ ತುಲನಾತ್ಮಕ ವಿಶ್ಲೇಷಣೆ
  </text>
</svg>`;

  return svgContent;
}

/**
 * 9. Taxonomy Counts SVG (Dynamic Grid for 2 to 24 Items with Smart Multi-line Wrapping)
 */
function generateTaxonomyCountSvg(
  safeTitle: string,
  _description: string,
  _tableHeaders?: string[],
  tableRows?: string[][]
): string {
  const width = 760;
  // DYNAMIC: Take ALL rows (up to 24) without arbitrary truncation!
  const items = (tableRows && tableRows.length > 0) ? tableRows.slice(0, 24) : [
    ['ಅಂಶ ೧', 'ವಿವರಣೆ ೧'],
    ['ಅಂಶ ೨', 'ವಿವರಣೆ ೨'],
    ['ಅಂಶ ೩', 'ವಿವರಣೆ ೩'],
    ['ಅಂಶ ೪', 'ವಿವರಣೆ ೪']
  ];
  const count = items.length;
  
  // Compute optimal column count based on item count
  let cols = 3;
  if (count <= 2) cols = 2;
  else if (count === 4) cols = 2; // 2x2 grid gives wide cards for 4 items
  else if (count === 7 || count === 8 || count === 12 || count === 16 || count >= 10) cols = 4;
  else cols = 3;

  const rowsCount = Math.ceil(count / cols);
  const horizontalPadding = cols === 2 ? 40 : (cols === 4 ? 24 : 32);
  const gap = cols === 2 ? 18 : 12;
  const cardWidth = Math.floor((width - horizontalPadding * 2 - (cols - 1) * gap) / cols);

  // Character allowances based on cardWidth
  const maxTitleChars = cols === 2 ? 32 : (cols === 3 ? 22 : 16);
  const maxSubChars = cols === 2 ? 36 : (cols === 3 ? 24 : 18);
  const maxSubLines = cols === 2 ? 3 : 2;

  // Process all cards with smart wrapping
  const processedCards = items.map((row, i) => {
    const rawTitle = (row[0] || `ಅಂಶ ${i + 1}`).trim();
    let rawSub = '';
    if (row[1] && row[1] !== row[0]) {
      rawSub = row[1].trim();
      if (row[2] && row[2] !== row[1] && row[2] !== row[0]) {
        rawSub += ` (${row[2].trim()})`;
      }
    } else if (row[2]) {
      rawSub = row[2].trim();
    }

    const titleLines = wrapScholarlyText(rawTitle, maxTitleChars, 2, '…');
    const subLines = wrapScholarlyText(rawSub, maxSubChars, maxSubLines, ' ಮುಂತಾದವು');
    return { titleLines, subLines };
  });

  const maxTitleLines = Math.max(1, ...processedCards.map((c) => c.titleLines.length));
  const maxSubLinesFound = Math.max(1, ...processedCards.map((c) => c.subLines.length));
  
  // Calculate dynamic card height to give comfortable padding
  const titleBlockHeight = (maxTitleLines - 1) * 16;
  const subBlockHeight = maxSubLinesFound * 15;
  const cardHeight = Math.max(cols === 2 ? 88 : 74, 30 + titleBlockHeight + subBlockHeight + 14);
  const startY = 70;
  const height = Math.max(240, startY + rowsCount * (cardHeight + gap) + 40);

  let svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="100%" height="100%" style="font-family:'Noto Sans Kannada', 'Noto Sans Devanagari', 'Noto Sans', sans-serif; background:#FAF7F2; border-radius:12px; border:1px solid #E8DEC8;">
  <rect x="0" y="0" width="${width}" height="48" fill="#F4EADB" />
  <line x1="0" y1="48" x2="${width}" y2="48" stroke="#DBC8B0" stroke-width="1.5" />
  <text x="${width / 2}" y="31" text-anchor="middle" font-size="15" font-weight="bold" fill="#8B1E0F">
    ॥ ${safeTitle} - ಸಂಖ್ಯಾತ್ಮಕ ಮತ್ತು ಶಾಸ್ತ್ರೀಯ ವರ್ಗೀಕರಣ ॥
  </text>
`;

  processedCards.forEach((card, i) => {
    const colIndex = i % cols;
    const rowIndex = Math.floor(i / cols);
    const x = horizontalPadding + colIndex * (cardWidth + gap);
    const y = startY + rowIndex * (cardHeight + gap);
    
    const circleRadius = 13;
    const circleX = x + 22;
    const circleY = y + cardHeight / 2;
    const textStartX = x + 44;
    const titleStartY = y + 22;
    const subStartY = titleStartY + card.titleLines.length * 16;

    const titleSvg = renderSvgWrappedText(card.titleLines, textStartX, titleStartY, 16, {
      fontSize: cols === 4 ? 11.5 : 13,
      fontWeight: 'bold',
      fill: '#8B1E0F'
    });

    const subSvg = renderSvgWrappedText(card.subLines, textStartX, subStartY, 15, {
      fontSize: cols === 4 ? 10.5 : 12,
      fontWeight: 'normal',
      fill: '#374151'
    });

    svgContent += `
  <g>
    <rect x="${x}" y="${y}" width="${cardWidth}" height="${cardHeight}" rx="8" fill="#FFFFFF" stroke="#8B1E0F" stroke-width="1.3" />
    <circle cx="${circleX}" cy="${circleY}" r="${circleRadius}" fill="#8B1E0F" />
    <text x="${circleX}" y="${circleY + 4}" text-anchor="middle" font-size="11.5" font-weight="bold" fill="#FFFFFF">${i + 1}</text>
    ${titleSvg}
    ${subSvg}
  </g>`;
  });

  svgContent += `
  <text x="${width / 2}" y="${height - 14}" text-anchor="middle" font-size="11.5" fill="#64748B" font-style="italic">
    ಶಾಸ್ತ್ರೀಯ ಗಣಿತ, ಸಂಖ್ಯಾಗಣನೆ ಹಾಗೂ ತತ್ತ್ವ ಪರಿಮಾಣ ನಕ್ಷೆ (ಒಟ್ಟು ಅಂಶಗಳು: ${count})
  </text>
</svg>`;

  return svgContent;
}
