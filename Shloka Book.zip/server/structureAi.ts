import { GoogleGenAI, Type } from '@google/genai';
import { keyManager } from './keyManager';
import { SanskritUnit } from '../src/types';

export interface StructureClassification {
  unitId: string;
  documentType?: string;
  structureType: string;
  isTitle: boolean;
  isMajorHeading: boolean;
  isSubHeading: boolean;
  isChapter: boolean;
  isSection: boolean;
  isVerse: boolean;
  isProse: boolean;
  isMetadata: boolean;
  isPageNoise: boolean;
  isOcrCorruption: boolean;
  headingLevel?: number;
  headingText?: string;
  parentHeading?: string;
  structurePath?: string[];
  confidence: number;
  reason: string;
}

export interface StructureState {
  documentType: string;
  structurePath: string[];
  currentHeadings: Array<{ level: number; text: string; type: string }>;
  lastUnitId?: string;
  lastPage?: number;
}

function clampConfidence(v: unknown): number {
  const n = Number(v);
  return Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : 0;
}

function band(c: number): 'HIGH' | 'MEDIUM' | 'LOW' {
  return c >= 0.85 ? 'HIGH' : c >= 0.60 ? 'MEDIUM' : 'LOW';
}

function explicitStructuralSignal(text: string): boolean {
  return /(?:॥\s*)?(?:अथ\s+)?(?:प्रथम|द्वितीय|तृतीय|चतुर्थ|पञ्चम|षष्ठ|सप्तम|अष्टम|नवम|दशम|एकादश|द्वादश|त्रयोदश|चतुर्दश|पञ्चदश|षोडश|सप्तदश|अष्टादश|एकोनविंश|विंश)[ःोीम्]?\s*(?:अध्याय|खण्ड|काण्ड|पर्व|सर्ग|वल्ली|प्रपाठक|मण्डल|प्रश्न|पाद|स्कन्ध|अंश|प्रकरण|परिच्छेद|अनुवाक|ब्राह्मण|सूक्त)|(?:इति|अथ)\s+[^\n]{2,80}/i.test(text)
    || /(?:अध्याय|खण्ड|काण्ड|पर्व|सर्ग|वल्ली|प्रपाठक|मण्डल|प्रश्न|पाद|स्कन्ध|अंश|प्रकरण|परिच्छेद|अनुवाक|ब्राह्मण|सूक्त)[ःः]?\s*[0-9०-९]+/i.test(text);
}

function explicitVerseSignal(text: string): boolean {
  return /(?:॥\s*[0-9०-९]+(?:\.[0-9०-९]+)*\s*॥|॥\s*[0-9०-९]+\s*$)/.test(text);
}

function mapTypeToUnitType(c: StructureClassification, fallback: SanskritUnit['unitType']): SanskritUnit['unitType'] {
  if (c.isVerse) return 'SHLOKA';
  if (c.structureType === 'MANTRA') return 'MANTRA';
  if (c.structureType === 'SHANTI_MANTRA') return 'SHANTI_MANTRA';
  if (c.structureType === 'QUOTATION') return 'QUOTATION';
  if (c.structureType === 'COLOPHON') return 'COLOPHON';
  if (c.isTitle || c.isMajorHeading || c.isSubHeading || c.isChapter || c.isSection ||
      ['HEADING', 'TITLE', 'SUBHEADING', 'CHAPTER', 'SECTION'].includes(c.structureType)) return 'HEADING';
  if (c.isProse) return 'GADYA';
  return fallback || 'GADYA';
}

function normalizeClassification(raw: any, unitId: string): StructureClassification {
  const confidence = clampConfidence(raw?.confidence);
  const structureType = String(raw?.structureType || 'PROSE').toUpperCase();
  return {
    unitId,
    documentType: raw?.documentType ? String(raw.documentType) : undefined,
    structureType,
    isTitle: Boolean(raw?.isTitle),
    isMajorHeading: Boolean(raw?.isMajorHeading),
    isSubHeading: Boolean(raw?.isSubHeading),
    isChapter: Boolean(raw?.isChapter),
    isSection: Boolean(raw?.isSection),
    isVerse: Boolean(raw?.isVerse),
    isProse: Boolean(raw?.isProse),
    isMetadata: Boolean(raw?.isMetadata),
    isPageNoise: Boolean(raw?.isPageNoise),
    isOcrCorruption: Boolean(raw?.isOcrCorruption),
    headingLevel: Number.isFinite(Number(raw?.headingLevel)) ? Number(raw.headingLevel) : undefined,
    headingText: raw?.headingText ? String(raw.headingText) : undefined,
    parentHeading: raw?.parentHeading ? String(raw.parentHeading) : undefined,
    structurePath: Array.isArray(raw?.structurePath) ? raw.structurePath.map(String) : undefined,
    confidence,
    reason: String(raw?.reason || 'No reason supplied.'),
  };
}

async function callStructureModel(
  prompt: string,
  preferredModel?: string,
  maxRetries = 3
): Promise<StructureClassification[]> {
  const models = Array.from(new Set([
    preferredModel,
    'gemini-3.1-flash-lite',
    'gemini-flash-latest',
  ].filter(Boolean))) as string[];

  let lastError: any;
  for (const model of models) {
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      const key = await keyManager.getNextApiKey(undefined, true);
      if (!key) throw new Error('No Gemini API key available for AI structure analysis.');
      try {
        const ai = new GoogleGenAI({ apiKey: key, httpOptions: { headers: { 'User-Agent': 'aistudio-build' } } });
        const response = await ai.models.generateContent({
          model,
          contents: prompt,
          config: {
            temperature: 0.05,
            topP: 0.9,
            maxOutputTokens: 8192,
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                documentType: { type: Type.STRING },
                classifications: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      unitId: { type: Type.STRING },
                      documentType: { type: Type.STRING },
                      structureType: { type: Type.STRING },
                      isTitle: { type: Type.BOOLEAN },
                      isMajorHeading: { type: Type.BOOLEAN },
                      isSubHeading: { type: Type.BOOLEAN },
                      isChapter: { type: Type.BOOLEAN },
                      isSection: { type: Type.BOOLEAN },
                      isVerse: { type: Type.BOOLEAN },
                      isProse: { type: Type.BOOLEAN },
                      isMetadata: { type: Type.BOOLEAN },
                      isPageNoise: { type: Type.BOOLEAN },
                      isOcrCorruption: { type: Type.BOOLEAN },
                      headingLevel: { type: Type.NUMBER },
                      headingText: { type: Type.STRING },
                      parentHeading: { type: Type.STRING },
                      structurePath: { type: Type.ARRAY, items: { type: Type.STRING } },
                      confidence: { type: Type.NUMBER },
                      reason: { type: Type.STRING },
                    },
                    required: ['unitId', 'structureType', 'isTitle', 'isMajorHeading', 'isSubHeading', 'isChapter', 'isSection', 'isVerse', 'isProse', 'isMetadata', 'isPageNoise', 'isOcrCorruption', 'confidence', 'reason'],
                  },
                },
              },
              required: ['documentType', 'classifications'],
            },
          },
        });
        keyManager.reportSuccess(key);
        const parsed = JSON.parse(response.text || '{}');
        const rows = Array.isArray(parsed.classifications) ? parsed.classifications : [];
        return rows.map((r: any) => normalizeClassification(r, String(r.unitId)));
      } catch (err: any) {
        lastError = err;
        const msg = String(err?.message || err);
        if (/429|quota|RESOURCE_EXHAUSTED/i.test(msg)) {
          keyManager.reportRateLimit(key, 10);
          await new Promise(r => setTimeout(r, Math.min(8000, attempt * 1800)));
        } else if (/503|UNAVAILABLE|500/i.test(msg)) {
          keyManager.reportServerError(key, 6);
          await new Promise(r => setTimeout(r, Math.min(5000, attempt * 1200)));
        } else {
          break;
        }
      }
    }
  }
  throw lastError || new Error('AI structure classification failed.');
}

export function reconcileStructure(
  unit: SanskritUnit,
  ai: StructureClassification | undefined,
  state: StructureState
): { unit: SanskritUnit; final: StructureClassification; state: StructureState } {
  const offline: StructureClassification = {
    unitId: unit.id,
    structureType: unit.unitType || 'PROSE',
    isTitle: unit.unitType === 'HEADING',
    isMajorHeading: unit.unitType === 'HEADING',
    isSubHeading: false,
    isChapter: Boolean(unit.structuralHierarchy.level1Name && /ಅಧ್ಯಾಯ|काण्ड|पर्व|प्रपाठक|मण्डल|स्कन्ध/i.test(unit.structuralHierarchy.level1Name)),
    isSection: Boolean(unit.structuralHierarchy.sectionName),
    isVerse: ['SHLOKA', 'UNNUMBERED_SHLOKA', 'MANTRA', 'SHANTI_MANTRA'].includes(unit.unitType || ''),
    isProse: unit.unitType === 'GADYA',
    isMetadata: false,
    isPageNoise: false,
    isOcrCorruption: false,
    headingLevel: unit.unitType === 'HEADING' ? 2 : undefined,
    headingText: unit.unitType === 'HEADING' ? unit.originalText : undefined,
    parentHeading: undefined,
    structurePath: unit.structuralHierarchy.sectionName ? [unit.structuralHierarchy.sectionName] : state.structurePath,
    confidence: unit.confidence === 'HIGH' ? 0.90 : unit.confidence === 'MEDIUM' ? 0.70 : 0.45,
    reason: 'Offline structural candidate.',
  };

  const sourceText = unit.originalText || unit.rawExtractedText || '';
  const explicitHeading = explicitStructuralSignal(sourceText);
  const explicitVerse = explicitVerseSignal(sourceText);

  let final = ai || offline;
  if (!ai) {
    final = offline;
  } else if (explicitHeading && !ai.isVerse && ai.confidence < 0.85) {
    final = { ...ai, isMajorHeading: true, isSection: true, isTitle: false, isVerse: false, structureType: 'HEADING', confidence: Math.max(ai.confidence, 0.88), reason: 'Explicit structural marker preserved over low-confidence AI disagreement.' };
  } else if (explicitVerse && (ai.isTitle || ai.isMajorHeading || ai.isSubHeading || ai.isChapter || ai.isSection) && ai.confidence < 0.98) {
    final = { ...ai, isTitle: false, isMajorHeading: false, isSubHeading: false, isChapter: false, isSection: false, isVerse: true, isProse: false, structureType: 'SHLOKA', confidence: Math.max(ai.confidence, 0.90), reason: 'Explicit source verse numbering prevented a false heading.' };
  }

  // High-confidence semantic AI can correct an offline candidate.
  if (ai && ai.confidence >= 0.85 && !explicitHeading) {
    final = ai;
  }

  const mappedType = mapTypeToUnitType(final, unit.unitType);
  unit.unitType = mappedType;
  unit.structuralHierarchy = {
    ...unit.structuralHierarchy,
    aiStructure: {
      ...final,
      confidenceBand: band(final.confidence),
      source: ai ? 'RECONCILED' : 'OFFLINE',
      validationStatus: final.confidence >= 0.85 ? 'ACCEPTED' : 'FLAGGED',
    },
    structurePath: final.structurePath || state.structurePath,
    sectionName: final.headingText || unit.structuralHierarchy.sectionName,
  };

  if (final.headingText && final.headingLevel) {
    const nextHeads = state.currentHeadings.filter(h => h.level < final.headingLevel);
    nextHeads.push({ level: final.headingLevel, text: final.headingText, type: final.structureType });
    state.currentHeadings = nextHeads;
    state.structurePath = final.structurePath?.length ? final.structurePath : nextHeads.map(h => h.text);
  } else if (final.structurePath?.length) {
    state.structurePath = final.structurePath;
  }
  state.documentType = final.documentType || state.documentType || 'SANSKRIT_BOOK';
  state.lastUnitId = unit.id;
  state.lastPage = unit.pageNumber;

  return { unit, final, state };
}

export async function analyzeStructureBatch(
  units: SanskritUnit[],
  state: StructureState,
  preferredModel?: string
): Promise<{ units: SanskritUnit[]; classifications: StructureClassification[]; state: StructureState; aiUsed: boolean; error?: string }> {
  if (!units.length) return { units, classifications: [], state, aiUsed: false };

  const records = units.map((u, i) => {
    const previous = i > 0 ? units[i - 1].originalText : '';
    const next = i + 1 < units.length ? units[i + 1].originalText : '';
    return {
      unitId: u.id,
      page: u.pageNumber,
      position: u.unitIndex,
      currentText: u.originalText,
      previousContext: previous,
      nextContext: next,
      offlineCandidate: {
        unitType: u.unitType,
        hierarchy: u.structuralHierarchy,
      },
      structuralState: state,
    };
  });

  const prompt = `You are the semantic structure analyst for a universal Sanskrit scholarly document engine.
Classify the supplied units using surrounding context. Do NOT rewrite source text and do NOT invent headings.
The engine supports arbitrary Sanskrit works: Veda, Upanishad, Gita, Itihasa, Purana, Darshana, Sutra, Bhashya, Kavya, scientific works, mixed prose/verse, and nested hierarchies.

Evidence priority:
1. explicit document structure and unmistakable numbering
2. strong semantic/contextual understanding
3. existing structural state
4. offline candidate
5. typography/layout hints

The offline candidate is only a hint and may be wrong. A short Sanskrit sentence is NOT automatically a heading.
Distinguish title, major heading, subheading, chapter, section, verse, mantra, prose, commentary heading, explanatory heading, metadata, page noise and OCR corruption.
Use the previous/current/following context. Maintain hierarchy across units.
If a heading is split across units, use context and return the same logical heading only when justified.
For headingText, return the exact source heading text when it is actually present; never paraphrase it.
For structurePath, return the active path after processing the unit.
Confidence is 0..1.

INPUT:
${JSON.stringify(records, null, 2)}

Return JSON only.`;

  try {
    const classifications = await callStructureModel(prompt, preferredModel);
    const byId = new Map(classifications.map(c => [c.unitId, c]));
    const out: SanskritUnit[] = [];
    let workingState = { ...state, currentHeadings: [...state.currentHeadings], structurePath: [...state.structurePath] };

    for (const unit of units) {
      const result = reconcileStructure(unit, byId.get(unit.id), workingState);
      out.push(result.unit);
      workingState = result.state;
    }
    return { units: out, classifications, state: workingState, aiUsed: classifications.length > 0 };
  } catch (err: any) {
    // Safe degradation: offline candidates remain valid candidates; they are never presented as AI-confirmed.
    return {
      units,
      classifications: [],
      state,
      aiUsed: false,
      error: String(err?.message || err),
    };
  }
}
