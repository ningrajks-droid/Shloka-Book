#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
HIGH-PERFORMANCE SCHOLARLY GRANTHA DESKTOP PROCESSOR
Universal Sanskrit -> Kannada Scholarly Book Production System
==============================================================================

Features:
1. Fast PDF Parsing with PyMuPDF (fitz)
2. Smart Batching (25-30 shlokas per batch -> cuts 1000+ API calls down to ~35)
3. Concurrent / Parallel ThreadPool Execution for ultra-fast throughput
4. Robust 429 Rate Limit Handling with Exponential Backoff & Jitter
5. Incremental & Atomic .docx Generation with Beautiful Styling & Tables
6. Real-time Progress Tracking with Pause (Virama) / Resume Support
7. Anti-Repetition Loop Cleaner & Pure Kannada Script Sanitization
==============================================================================
"""

import os
import re
import sys
import time
import json
import random
import threading
from typing import List, Dict, Any, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed

try:
    import fitz  # PyMuPDF
except ImportError:
    print("PyMuPDF (fitz) is required. Please install it using: pip install pymupdf")
    sys.exit(1)

try:
    from docx import Document
    from docx.shared import Pt, Inches, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
    from docx.oxml import OxmlElement, parse_xml
    from docx.oxml.ns import nsdecls, qn
except ImportError:
    print("python-docx is required. Please install it using: pip install python-docx")
    sys.exit(1)

try:
    from google import genai
    from google.genai import types
except ImportError:
    print("google-genai is required. Please install it using: pip install google-genai")
    sys.exit(1)

try:
    from tqdm import tqdm
except ImportError:
    tqdm = None


# ============================================================================
# CONSTANTS & STYLING
# ============================================================================
FONT_KANNADA = "Tunga"
FONT_DEVANAGARI = "Noto Serif Devanagari"
COLOR_PRIMARY_MAROON = RGBColor(139, 30, 15)   # #8B1E0F
COLOR_CHARCOAL = RGBColor(31, 25, 22)          # #1F1916
COLOR_SLATE = RGBColor(90, 80, 75)             # #5A504B
COLOR_GOLD_ACCENT = RGBColor(180, 130, 40)

HEX_MAROON = "8B1E0F"
HEX_LIGHT_BEIGE = "FAF7F2"
HEX_BORDER = "E8E2D9"

# Pause/Virama Event Controller
PAUSE_EVENT = threading.Event()
PAUSE_EVENT.set()  # Default: Running (not paused)

DOCX_LOCK = threading.Lock()


# ============================================================================
# API KEY POOL & ROTATION ENGINE
# ============================================================================
class ApiKeyPool:
    """Thread-safe Gemini API key pool with automatic round-robin, in-flight tracking, and instant rate-limit cooldown failover."""
    def __init__(self, keys: Optional[List[str]] = None):
        self.lock = threading.Lock()
        self.keys_state: List[Dict[str, Any]] = []
        self.current_idx = 0
        self._clients: Dict[str, genai.Client] = {}
        
        discovered = self._discover_keys(keys)
        for k in discovered:
            self.keys_state.append({
                "key": k,
                "name": f"Key (...{k[-4:]})" if len(k) >= 8 else "Key",
                "rate_limited_until": 0.0,
                "error_count": 0,
                "in_flight": 0,
            })
        
        if self.keys_state:
            print(f"🔑 [API Key Pool] Loaded {len(self.keys_state)} active Gemini API key(s) for high-speed multi-key rotation!")

    def _discover_keys(self, user_keys: Optional[List[str]]) -> List[str]:
        found = set()
        if user_keys:
            for item in user_keys:
                if item:
                    for k in re.split(r'[,;\s]+', item):
                        k = k.strip()
                        if k and len(k) > 10:
                            found.add(k)
        
        # Check environment variables
        for env_var in ["GEMINI_API_KEYS", "GEMINI_API_KEY", "GOOGLE_API_KEY", "VITE_GEMINI_API_KEY"]:
            val = os.environ.get(env_var, "").strip()
            if val:
                for k in re.split(r'[,;\s]+', val):
                    k = k.strip()
                    if k and len(k) > 10:
                        found.add(k)
        
        # Check local text and env files
        for fname in ["gemini_api_keys.txt", "gemini_api_key.txt", "api_keys.txt", ".env"]:
            if os.path.isfile(fname):
                try:
                    with open(fname, "r", encoding="utf-8") as f:
                        for line in f:
                            line = line.strip()
                            if line.startswith("#") or not line:
                                continue
                            if "=" in line:
                                line = line.split("=", 1)[1].strip().strip('"').strip("'")
                            if line and len(line) > 10 and not line.startswith("http"):
                                found.add(line)
                except Exception:
                    pass
        return list(found)

    def get_key(self, exclude_key: Optional[str] = None) -> Optional[str]:
        with self.lock:
            if not self.keys_state:
                return None
            now = time.time()
            available = [k for k in self.keys_state if k["rate_limited_until"] <= now]
            
            if not available:
                # If all rate-limited, pick the one expiring soonest
                sorted_by_exp = sorted(self.keys_state, key=lambda x: x["rate_limited_until"])
                target = sorted_by_exp[0]
            else:
                candidates = [k for k in available if k["key"] != exclude_key] or available
                candidates.sort(key=lambda x: (x["in_flight"], x["error_count"]))
                target = candidates[0]

            target["in_flight"] += 1
            return target["key"]

    def release_key(self, key_str: str):
        with self.lock:
            for k in self.keys_state:
                if k["key"] == key_str:
                    k["in_flight"] = max(0, k["in_flight"] - 1)

    def report_rate_limit(self, key_str: str, cooldown_sec: float = 12.0):
        with self.lock:
            now = time.time()
            for k in self.keys_state:
                if k["key"] == key_str:
                    k["rate_limited_until"] = now + max(5.0, cooldown_sec)
                    k["error_count"] += 1
                    k["in_flight"] = max(0, k["in_flight"] - 1)

    def report_success(self, key_str: str):
        with self.lock:
            for k in self.keys_state:
                if k["key"] == key_str:
                    k["error_count"] = max(0, k["error_count"] - 1)
                    k["in_flight"] = max(0, k["in_flight"] - 1)

    def get_client(self, key_str: str) -> genai.Client:
        with self.lock:
            if key_str not in self._clients:
                self._clients[key_str] = genai.Client(api_key=key_str)
            return self._clients[key_str]

    @property
    def has_keys(self) -> bool:
        return len(self.keys_state) > 0


# ============================================================================
# 1. TEXT SANITIZATION & ANTI-REPETITION LOOP DESTROYER (ReDoS-SAFE)
# ============================================================================
DEVA_TO_KAN_MAP = {
    'अ': 'ಅ', 'आ': 'ಆ', 'इ': 'ಇ', 'ई': 'ಈ', 'उ': 'ಉ', 'ऊ': 'ಊ', 'ऋ': 'ಋ', 'ॠ': 'ೠ',
    'ऌ': 'ಌ', 'ॡ': 'ೡ', 'ए': 'ಏ', 'ऐ': 'ಐ', 'ओ': 'ಓ', 'औ': 'ಔ',
    'ा': 'ಾ', 'ि': 'ಿ', 'ी': 'ೀ', 'ु': 'ು', 'ू': 'ೂ', 'ृ': 'ೃ', 'ॄ': 'ೄ',
    'ॢ': 'ೢ', 'ॣ': 'ೣ', 'े': 'ೇ', 'ै': 'ೈ', 'ो': 'ೋ', 'ौ': 'ೌ',
    '्': '್', 'ं': 'ಂ', 'ः': 'ಃ', 'ँ': 'ँ', 'ऽ': 'ಽ',
    'क': 'ಕ', 'ख': 'ಖ', 'ग': 'ಗ', 'घ': 'ಘ', 'ङ': 'ಙ',
    'च': 'ಚ', 'छ': 'ಛ', 'ज': 'ಜ', 'झ': 'ಝ', 'ञ': 'ಞ',
    'ट': 'ಟ', 'ठ': 'ಠ', 'ड': 'ಡ', 'ढ': 'ಢ', 'ण': 'ಣ',
    'त': 'ತ', 'थ': 'ಥ', 'द': 'ದ', 'ध': 'ಧ', 'न': 'ನ',
    'प': 'ಪ', 'फ': 'ಫ', 'ब': 'ಬ', 'भ': 'ಭ', 'म': 'ಮ',
    'य': 'ಯ', 'र': 'ರ', 'ल': 'ಲ', 'व': 'ವ',
    'श': 'ಶ', 'ष': 'ಷ', 'स': 'ಸ', 'ह': 'ಹ', 'ळ': 'ಳ',
    '।': ' । ', '॥': ' ॥ ', '०': '0', '१': '1', '२': '2', '३': '3', '४': '4',
    '५': '5', '६': '6', '७': '7', '८': '8', '९': '9',
}


def devanagari_to_kannada(text: str) -> str:
    """Accurately transliterates Devanagari Sanskrit into 100% pure Kannada script."""
    if not text:
        return ""
    result = []
    i = 0
    length = len(text)
    while i < length:
        if i + 1 < length and text[i:i + 2] in ('||', '//'):
            result.append(' ॥ ')
            i += 2
            continue
        char = text[i]
        if char == '|':
            result.append(' । ')
            i += 1
            continue
        if char in DEVA_TO_KAN_MAP:
            result.append(DEVA_TO_KAN_MAP[char])
        elif re.match(r'[A-Za-z]', char):
            pass  # strip Latin noise
        else:
            result.append(char)
        i += 1
    return "".join(result).strip()


def to_english_digits(text: str) -> str:
    """Converts Kannada and Devanagari numerals to English digits."""
    if not text:
        return ""
    dev_kannada_digits = {
        '०': '0', '१': '1', '२': '2', '३': '3', '४': '4', '५': '5', '६': '6', '७': '7', '८': '8', '९': '9',
        '೦': '0', '೧': '1', '೨': '2', '೩': '3', '೪': '4', '೫': '5', '೬': '6', '೭': '7', '೮': '8', '೯': '9',
    }
    for k, v in dev_kannada_digits.items():
        text = text.replace(k, v)
    return text


def clean_repetitive_loops(text: str) -> str:
    """
    High-Performance, ReDoS-Safe Anti-Repetition and Loop Destroyer:
    Detects and collapses runaway repetitive phrases, looping clauses, or repeated sentences in linear time.
    """
    if not text:
        return ""
    str_val = text.strip()
    if len(str_val) > 25000:
        str_val = str_val[:25000]

    # 1. Word-level n-gram loop deduplication (O(N) linear scan)
    str_val = collapse_repeating_word_sequences(str_val)

    # 2. Sentence-level deduplication
    sentences = re.split(r'(?<=[.।॥!?\n])\s+', str_val)
    if len(sentences) > 1:
        deduped = []
        seen_sentences = {}
        last_norm = ""
        for s in sentences:
            trimmed = s.strip()
            if not trimmed:
                continue
            norm = re.sub(r'[\s\W]+', ' ', trimmed).strip().lower()
            if not norm:
                continue
            if norm == last_norm:
                continue
            count = seen_sentences.get(norm, 0)
            if count >= 2:
                continue
            seen_sentences[norm] = count + 1
            last_norm = norm
            deduped.append(trimmed)
        str_val = " ".join(deduped)

    # 3. Substring sliding-window loop detector
    str_val = collapse_repeating_substrings(str_val)

    return str_val.strip()


def collapse_repeating_word_sequences(text: str) -> str:
    """Collapses repeating n-word patterns in linear time without regex backtracking."""
    words = text.split()
    if len(words) < 6:
        return text

    result_words = []
    i = 0
    while i < len(words):
        match_found = False
        max_pattern_len = min(15, (len(words) - i) // 2)
        for length in range(max_pattern_len, 1, -1):
            if words[i:i + length] == words[i + length:i + 2 * length]:
                # Count consecutive repetitions
                repeat_count = 2
                while (i + (repeat_count + 1) * length <= len(words) and
                       words[i:i + length] == words[i + repeat_count * length:i + (repeat_count + 1) * length]):
                    repeat_count += 1
                result_words.extend(words[i:i + length])
                i += repeat_count * length
                match_found = True
                break

        if not match_found:
            result_words.append(words[i])
            i += 1

    return " ".join(result_words)


def collapse_repeating_substrings(text: str) -> str:
    """Collapses repeating character chunks in linear time without regex."""
    if len(text) < 20:
        return text

    current = text
    for chunk_len in [20, 30, 40, 60, 80, 120]:
        if len(current) < chunk_len * 2:
            continue
        i = 0
        modified = []
        while i < len(current):
            if i + chunk_len * 2 <= len(current):
                chunk1 = current[i:i + chunk_len]
                chunk2 = current[i + chunk_len:i + chunk_len * 2]
                if chunk1 == chunk2:
                    end_idx = i + chunk_len * 2
                    while end_idx + chunk_len <= len(current) and current[end_idx:end_idx + chunk_len] == chunk1:
                        end_idx += chunk_len
                    modified.append(chunk1)
                    i = end_idx
                    continue
            modified.append(current[i])
            i += 1
        current = "".join(modified)
    return current


def clean_concise_title(title: str, max_length: int = 75) -> str:
    """Sanitizes table / diagram titles to be crisp single phrases."""
    if not title:
        return ""
    cleaned = clean_repetitive_loops(title)
    if ":" in cleaned:
        parts = cleaned.split(":")
        first = parts[0].strip()
        second = parts[1].strip() if len(parts) > 1 else ""
        if first and 8 <= len(first) <= max_length:
            cleaned = first
        elif second and len(second) <= max_length:
            cleaned = f"{first}: {second}"

    if len(cleaned) > max_length:
        truncated = cleaned[:max_length]
        cleaned = re.sub(r'[\s,;:–—]+[^\s]*$', '', truncated).strip()
    return cleaned


def format_padartha_strictly(raw_padartha: str) -> str:
    """
    Guarantees strict separation in Padartha:
    - Sanskrit Pada in pure Devanagari script ONLY
    - Kannada Meaning in pure Kannada script ONLY
    - Strips any mixed Kannada from the Sanskrit pada and any Sanskrit from the Kannada meaning.
    """
    if not raw_padartha:
        return ""
    
    cleaned = clean_repetitive_loops(to_english_digits(raw_padartha))
    cleaned = re.sub(r'^(\d+\.?\s*)?(ಪದಾರ್ಥ\s*[:\-])\s*', '', cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r'^[•\-\*\d+\.]\s+', '', cleaned, flags=re.MULTILINE).strip()

    items = re.split(r'[,;\n\r]+', cleaned)
    formatted = []

    for item in items:
        item_str = item.strip()
        if not item_str:
            continue

        match = re.match(r'^([^-=:—–>]+)\s*[-=:—–>]+\s*(.+)$', item_str)
        if match:
            pada = match.group(1).strip()
            artha = match.group(2).strip()

            # Clean bullet numbers or parentheses from pada
            pada = re.sub(r'^[•\-\*\d+\.)\]\s]+', '', pada).strip()

            # If pada has Devanagari, strip any Kannada script or brackets leaking into it
            if re.search(r'[\u0900-\u097F]', pada):
                pada = re.sub(r'[\(（\[\{][\u0C80-\u0CFF\s\d\-_,.]+[\)）\]\}]', '', pada)
                pada = re.sub(r'[\u0C80-\u0CFF]+', '', pada)
                pada = re.sub(r'^[\/\-–—:,\s]+|[\/\-–—:,\s]+$', '', pada).strip()

            # Clean English letters from Sanskrit pada
            pada = re.sub(r'[A-Za-z]', '', pada).strip()

            # Clean Sanskrit Devanagari word repetition from Kannada artha
            if re.search(r'[\u0900-\u097F]', artha) and re.search(r'[\u0C80-\u0CFF]', artha):
                artha = re.sub(r'[\(（\[\{][\u0900-\u097F\s\d\-_,.]+[\)）\]\}]', '', artha)
                artha = re.sub(r'^[\u0900-\u097F\s\d।॥\-_–—:=]+\s*[-=—–:]*\s*', '', artha)

            pada = re.sub(r'^[.,;:!?\s]+|[.,;:!?\s]+$', '', pada).strip()
            artha = re.sub(r'^[\/\-–—:=,\s]+|[\/\-–—:=,\s]+$', '', artha).strip()

            if pada and artha:
                formatted.append(f"{pada} - {artha}")
            elif item_str:
                formatted.append(item_str)
        else:
            formatted.append(item_str)

    return ", ".join(formatted)


HEADING_TYPE_SPECS = [
    # (regex, type_key, kannada_label, level) — major heads first
    (r"अध्याय|ಅಧ್ಯಾಯ|\bAdhyaya\b|\bChapter\b", "adhyaya", "ಅಧ್ಯಾಯ", 1),
    (r"वल्ली|वल्लिः?|ವಲ್ಲಿ|\bValli\b", "valli", "ವಲ್ಲಿ", 1),
    (r"काण्ड|कांड|ಕಾಂಡ|\bKanda\b", "kanda", "ಕಾಂಡ", 1),
    (r"स्कन्ध|स्कंध|ಸ್ಕಂಧ|\bSkandha\b", "skandha", "ಸ್ಕಂಧ", 1),
    (r"खण्ड|खंड|ಖಂಡ|\bKhanda\b|\bSection\b", "khanda", "ಖಂಡ", 2),
    (r"सर्गः?|ಸರ್ಗ|\bSarga\b", "sarga", "ಸರ್ಗ", 2),
    (r"प्रकरणम्?|ಪ್ರಕರಣ|\bPrakarana\b", "prakarana", "ಪ್ರಕರಣ", 2),
    (r"अनुवाकः?|ಅನುವಾಕ|\bAnuvaka\b", "anuvaka", "ಅನುವಾಕ", 2),
    (r"पटलः?|ಪಟಲ|\bPatala\b", "patala", "ಪಟಲ", 2),
    (r"परिच्छेदः?|ಪರಿಚ್ಛೇದ", "pariccheda", "ಪರಿಚ್ಛೇದ", 2),
    (r"उल्लासः?|ಉಲ್ಲಾಸ", "ullasa", "ಉಲ್ಲಾಸ", 2),
    (r"ब्राह्मणम्?|ಬ್ರಾಹ್ಮಣ", "brahmana", "ಬ್ರಾಹ್ಮಣ", 2),
    (r"भूमिका|ಭೂಮಿಕೆ", "bhumika", "ಭೂಮಿಕೆ", 3),
    (r"प्रस्तावना|ಪ್ರಸ್ತಾವನೆ", "prastavana", "ಪ್ರಸ್ತಾವನೆ", 3),
    (r"उपसंहारः?|ಉಪಸಂಹಾರ", "upasanhara", "ಉಪಸಂಹಾರ", 3),
    (r"पीठिका|ಪೀಠಿಕೆ", "pithika", "ಪೀಠಿಕೆ", 3),
    (r"उपोद्घातः?", "upodghata", "ಉಪೋದ್ಘಾತ", 3),
    (r"विषयानुक्रमणिका|ವಿಷಯಾನುಕ್ರಮಣಿಕೆ", "anukramanika", "ವಿಷಯಾನುಕ್ರಮಣಿಕೆ", 3),
]


def detect_structural_heading(line: str) -> Optional[Dict[str, Any]]:
    """
    Detects grantha heads / sub-heads (ಅಧ್ಯಾಯ, ವಲ್ಲಿ, ಖಂಡ, ...).
    Short title lines are headings — NOT shlokas. Long verses that merely
    mention these words are ignored.
    """
    trimmed = re.sub(r"\s+", " ", (line or "").strip())
    if not trimmed or len(trimmed) > 140:
        return None
    if len(trimmed.split()) > 20:
        return None

    matched: Optional[Dict[str, Any]] = None
    for pattern, kind, label, level in HEADING_TYPE_SPECS:
        if re.search(pattern, trimmed, re.I):
            matched = {
                "kind": "heading",
                "headingType": kind,
                "headingLabel": label,
                "headingLevel": level,
                "originalText": trimmed,
            }
            break
    if not matched:
        return None

    verse_no = detect_explicit_verse_number(trimmed)
    if verse_no and len(trimmed) > 80:
        return None
    return matched


def format_heading_kannada(unit: Dict[str, Any]) -> str:
    """Renders a heading as a single Kannada title line (no 5-step commentary)."""
    raw = to_english_digits(unit.get("originalText", "") or "")
    kannada = to_english_digits(devanagari_to_kannada(raw))
    kannada = re.sub(r"\s+", " ", kannada).strip(" :-–—")
    label = unit.get("headingLabel") or ""
    if label and label not in kannada:
        kannada = f"{label}: {kannada}" if kannada else label
    if not kannada:
        return f"॥ {label or 'ಶೀರ್ಷಿಕೆ'} ॥"
    if "॥" not in kannada:
        kannada = f"॥ {kannada} ॥"
    return kannada


def is_heading_unit(unit: Dict[str, Any]) -> bool:
    return unit.get("kind") == "heading"


def chunk_units_for_batches(units: List[Dict[str, Any]], batch_size: int) -> List[List[Dict[str, Any]]]:
    """Groups shlokas into API batches while keeping intervening headings in document order."""
    chunks: List[List[Dict[str, Any]]] = []
    current: List[Dict[str, Any]] = []
    shloka_count = 0
    for u in units:
        if is_heading_unit(u):
            current.append(u)
            continue
        if shloka_count >= batch_size:
            chunks.append(current)
            current = []
            shloka_count = 0
        current.append(u)
        shloka_count += 1
    if current:
        chunks.append(current)
    return chunks


def detect_explicit_verse_number(line: str) -> Optional[str]:
    norm = to_english_digits(line.strip())
    if not norm:
        return None
    m = re.search(r'(?:॥|\|\||//|/|\\|।|\|)\s*(\d+(?:[.-]\d+)*)\s*(?:॥|\|\||//|/|\\|।|\|)', norm)
    if m:
        return m.group(1).strip()
    m = re.search(r'(?:॥|\|\||।|\|)\s*(\d+(?:[.-]\d+)*)\s*$', norm)
    if m:
        return m.group(1).strip()
    m = re.search(r'(?:\(|\[|【)\s*(\d+(?:[.-]\d+)*)\s*(?:\)|\]|】)\s*(?:॥|\|\|)?$', norm)
    if m:
        return m.group(1).strip()
    m = re.search(r'^(?:(?:श्लोक|ಶ್ಲೋಕ|verse|shloka|मंत्र|ಮಂತ್ರ)\s*)?(\d+(?:[.-]\d+)*)\s*[:.-]', norm, re.I)
    if m:
        return m.group(1).strip()
    return None

def detect_definitive_end_sign(line: str) -> bool:
    norm = line.strip()
    if not norm:
        return False
    if re.search(r'^इति\s+[\u0900-\u097F\s]+(?:समाप्त|सम्पूर्ण|ಸಮಾಪ್ತ|ಸಂಪೂರ್ಣ|ಅಧ್ಯಾಯ|अध्याय|खण्ड|ಖಂಡ)', norm, re.I):
        return True
    if re.search(r'(?:समाप्तम्|समाप्तः|सम्पूर्णम्|ಸಮಾಪ್ತವಾಯಿತು|ಸಂಪೂರ್ಣ|ಸಮಾಪ್ತಃ|समाप्ता)\s*(?:॥|\|\|)?$', norm, re.I):
        return True
    if re.search(r'शान्ति[ः|:\s]+शान्ति[ः|:\s]+शान्ति[ः|:\s]*(?:॥|\|\|)?$', norm, re.I):
        return True
    return False

def is_line_ending_properly(line: str, next_is_blank: bool) -> bool:
    trimmed = line.strip()
    if not trimmed:
        return False
    if next_is_blank:
        return True
    return bool(re.search(r'(?:[।॥.!?]|//|\\\\|/|\\|\|\||II)\s*$', trimmed, re.I))

# ============================================================================
# 2. FAST PDF PARSER WITH PyMuPDF (fitz)
# ============================================================================
def extract_shlokas_from_pdf(pdf_path: str) -> List[Dict[str, Any]]:
    """
    Rapidly extracts Sanskrit text, structural headings, and individual Shlokas from a PDF.
    Headings (ಅಧ್ಯಾಯ, ವಲ್ಲಿ, ಖಂಡ, ...) are stored as heading units — not as shlokas.
    Strictly follows:
    1. Do NOT split immediately on //, \\, /, \, or II.
    2. Read continuously to form 10-15 line logical blocks.
    3. Break only at proper endings (full stop, end of paragraph, or separator).
    4. STOP RULE: Process immediately upon explicit shloka number or definitive end sign.
    """
    if not os.path.exists(pdf_path):
        raise FileNotFoundError(f"PDF file not found: {pdf_path}")

    print(f"📖 Fast parsing PDF using PyMuPDF: {os.path.basename(pdf_path)}...")
    doc = fitz.open(pdf_path)
    all_pages_text = []

    for page_num in range(len(doc)):
        page = doc[page_num]
        blocks = page.get_text("blocks")
        blocks.sort(key=lambda b: (b[1], b[0]))
        page_text = "\n".join([b[4].strip() for b in blocks if b[4].strip()])
        if page_text:
            all_pages_text.append(page_text)

    full_text = "\n\n".join(all_pages_text)
    full_text = to_english_digits(full_text)

    raw_lines = full_text.splitlines()
    units: List[Dict[str, Any]] = []
    current_verse_lines: List[str] = []
    meaningful_line_count = 0
    current_chapter = "ಪ್ರಥಮ ಭಾಗ (Section 1)"
    current_khanda = "ಪ್ರಥಮ ಖಂಡ (Khanda 1)"
    verse_counter = 1

    def flush_verse(min_len: int = 10, verse_number: str = "") -> None:
        nonlocal current_verse_lines, meaningful_line_count, verse_counter
        verse_text = "\n".join(current_verse_lines).strip()
        if len(verse_text) >= min_len:
            units.append({
                "id": f"shloka_{verse_counter}",
                "kind": "shloka",
                "verseNumber": verse_number,
                "chapter": current_chapter,
                "khanda": current_khanda,
                "originalText": verse_text,
            })
            verse_counter += 1
        current_verse_lines = []
        meaningful_line_count = 0

    def emit_heading(heading: Dict[str, Any]) -> None:
        nonlocal current_chapter, current_khanda
        heading_kn = format_heading_kannada(heading)
        htype = heading.get("headingType", "")
        if htype in ("adhyaya", "valli", "kanda", "skandha"):
            current_chapter = heading_kn
        if htype in ("khanda", "sarga", "prakarana", "anuvaka", "patala"):
            current_khanda = heading_kn
        heading["id"] = f"heading_{len(units) + 1}"
        heading["verseNumber"] = ""
        heading["chapter"] = current_chapter
        heading["khanda"] = current_khanda
        units.append(heading)

    for i, raw_l in enumerate(raw_lines):
        line_str = raw_l.strip()
        if not line_str:
            if current_verse_lines and meaningful_line_count >= 10:
                flush_verse(min_len=10)
            continue

        heading = detect_structural_heading(line_str)
        if heading:
            if current_verse_lines:
                flush_verse(min_len=6)
            emit_heading(heading)
            continue

        # 1. STOP RULE: explicit shloka number or definitive end sign
        explicit_num = detect_explicit_verse_number(line_str)
        is_def_end = detect_definitive_end_sign(line_str)

        if explicit_num or is_def_end:
            current_verse_lines.append(line_str)
            flush_verse(min_len=1, verse_number=explicit_num or "")
            continue

        # 2. Continuous accumulation (Immunity to //, \\, /, \, II):
        current_verse_lines.append(line_str)
        meaningful_line_count += 1

        # 3. Check 10-15 line block splitting:
        if meaningful_line_count >= 10:
            next_line = raw_lines[i + 1].strip() if i + 1 < len(raw_lines) else ""
            next_is_blank = not next_line
            ends_properly = is_line_ending_properly(line_str, next_is_blank)

            if ends_properly or meaningful_line_count >= 15:
                flush_verse(min_len=10)

    # Flush remaining text
    if current_verse_lines:
        flush_verse(min_len=6)

    n_head = sum(1 for u in units if is_heading_unit(u))
    n_shloka = len(units) - n_head
    print(f"✅ Fast extraction completed: Found {n_shloka} shlokas and {n_head} headings (ಅಧ್ಯಾಯ/ವಲ್ಲಿ/ಖಂಡ).")
    return units


# ============================================================================
# 3. GEMINI API BATCH SCHOLARLY EXPLANATION GENERATOR
# ============================================================================
BATCH_PROMPT_SYSTEM = """You are an expert Vedic scholar, Kannada literary researcher, and master book author/editor.
You will receive a BATCH of Sanskrit verses/mantras (25 to 30 verses).
For EVERY single verse in the batch, generate the complete mandatory sections in high-quality publishing Kannada:

1. "moolaShloka": Sanskrit verse in Devanagari script with English digits.
2. "kannadaTransliteration": 100% pure Kannada script transliteration with English digits (NO English/Latin characters).
3. "padartha": Word-by-word meaning in a single continuous paragraph formatted strictly as:
   "DevanagariPada - KannadaMeaning, DevanagariPada - KannadaMeaning, ..."
   (Devanagari for Sanskrit words, Kannada script for meanings. No English, no bullet points).
4. "saralaVivarane": Lucid, clear Kannada explanation of the verse in pure Kannada prose.
5. "vivaradaVyakhyana": Deep scholarly and philosophical commentary in Kannada.
6. "tableNeeded": (BOOLEAN) Set to true ONLY IF the text explicitly provides numerical data, structured lists, classifications, mathematical variables, or categorical attributes. Organize strictly using only the provided text data without outside additions.
7. "tableTitle": Very short concise Kannada title under 10 words (e.g. "ಗರ್ಭಸ್ಥ ಶಿಶುವಿನ ಮಾಸಿಕ ವಿಕಾಸ ಕ್ರಮ" or "ಪಂಚಭೂತಗಳ ವಿಂಗಡಣೆ").
8. "tableHeaders": Array of column header strings in Kannada.
9. "tableRows": 2D array of strings representing table cell contents in Kannada with English digits.
10. "tableExplanation": Brief 1-2 sentence Kannada explanation of the table.
11. "diagramNeeded": (BOOLEAN) Set to true ONLY IF the shloka or explanation explicitly describes a visible process, geometric figure, anatomical structure, or cosmological map. ZERO-ASSUMPTION RULE: The visual must exclusively reflect what is written in the text without external metaphors. If text lacks concrete structural layout, set to false. Absolute prohibition of generic graphics!
12. "diagramTitle": Very short concise Kannada title for the diagram under 10 words.
13. "diagramCaption": Concise caption in Kannada explaining the visual illustration.
14. "diagramDescription": Detailed description of the diagram, posture alignment, or geometry principles strictly from the text.

STRICT RULES:
- NEVER skip any verse in the batch.
- If a verse has an explicit verse number in source, preserve that exact number.
- If a verse has NO verse number in source (e.g. Shanti Mantras, unnumbered verses), DO NOT invent, assume, or add any verse number. Leave it ending with standard double danda ॥ without numbers.
- tableTitle and diagramTitle must be short and NEVER repeat phrases in a loop.
- All numbers must be English digits (0-9).
- Return a JSON object containing a "results" array of objects corresponding to each verse in order.
"""

def call_gemini_batch_with_retry(
    key_pool: ApiKeyPool,
    batch_units: List[Dict[str, Any]],
    model_name: str = "gemini-2.5-flash",
    max_retries: int = 6
) -> List[Dict[str, Any]]:
    """
    Calls Gemini API with smart batching (25-30 verses) and multi-key rotation on 429/quota rate limits.
    """
    # Build batch payload
    batch_input = []
    for u in batch_units:
        batch_input.append({
            "verseNumber": u["verseNumber"],
            "originalText": u["originalText"],
            "chapter": u.get("chapter", ""),
            "khanda": u.get("khanda", "")
        })

    prompt = f"Process this batch of Sanskrit verses:\n{json.dumps(batch_input, ensure_ascii=False, indent=2)}"
    current_key = key_pool.get_key()
    if not current_key:
        raise RuntimeError("No Gemini API key available in Key Pool.")

    for attempt in range(max_retries):
        # Handle Pause / Virama
        PAUSE_EVENT.wait()

        client = key_pool.get_client(current_key)

        try:
            response = client.models.generate_content(
                model=model_name,
                contents=prompt,
                config=types.GenerateContentConfig(
                    system_instruction=BATCH_PROMPT_SYSTEM,
                    temperature=0.2,
                    response_mime_type="application/json",
                ),
            )

            key_pool.report_success(current_key)

            raw_text = response.text or "{}"
            parsed = json.loads(raw_text)

            results = parsed.get("results", [])
            if not results and isinstance(parsed, list):
                results = parsed

            # Post-process & sanitize all results
            sanitized_results = []
            for item in results:
                moola = to_english_digits(item.get("moolaShloka", ""))
                kannada_tr = to_english_digits(item.get("kannadaTransliteration", ""))
                padartha = format_padartha_strictly(item.get("padartha", ""))
                sarala = clean_repetitive_loops(to_english_digits(item.get("saralaVivarane", "")))
                vyakhyana = clean_repetitive_loops(to_english_digits(item.get("vivaradaVyakhyana", "")))
                table_title = clean_concise_title(item.get("tableTitle", ""), 75)
                table_needed = bool(item.get("tableNeeded", False)) and bool(item.get("tableHeaders"))

                sanitized_results.append({
                    "moolaShloka": moola,
                    "kannadaTransliteration": kannada_tr,
                    "padartha": padartha,
                    "saralaVivarane": sarala,
                    "vivaradaVyakhyana": vyakhyana,
                    "tableNeeded": table_needed,
                    "tableTitle": table_title,
                    "tableHeaders": item.get("tableHeaders", []),
                    "tableRows": item.get("tableRows", []),
                    "tableExplanation": clean_repetitive_loops(item.get("tableExplanation", "")),
                    "diagramNeeded": bool(item.get("diagramNeeded", False)),
                    "diagramTitle": clean_concise_title(item.get("diagramTitle", ""), 75),
                    "diagramCaption": item.get("diagramCaption", ""),
                    "diagramDescription": clean_repetitive_loops(item.get("diagramDescription", "")),
                })

            return sanitized_results

        except Exception as e:
            err_str = str(e)
            is_rate_limit = "429" in err_str or "RESOURCE_EXHAUSTED" in err_str or "quota" in err_str.lower()
            
            # Extract retry delay if present in error message
            delay_match = re.search(r'retry in (\d+(?:\.\d+)?)s', err_str, re.IGNORECASE)
            delay_sec = float(delay_match.group(1)) if delay_match else 12.0

            if is_rate_limit:
                key_pool.report_rate_limit(current_key, delay_sec)
                # Seamless Key Failover: Pick next active key in pool
                next_key = key_pool.get_key(exclude_key=current_key)
                if next_key and next_key != current_key:
                    print(f"🔄 [Key Failover] Switched from Key (...{current_key[-4:]}) to Key (...{next_key[-4:]}). Retrying immediately.")
                    current_key = next_key
                    continue

                sleep_time = delay_sec + 1.0
                print(f"⚠️ [Rate Limit 429] All keys busy. Backing off for {sleep_time:.1f}s (Attempt {attempt + 1}/{max_retries})...")
            else:
                sleep_time = (2 ** attempt) * 2 + random.uniform(0.5, 2.0)
                print(f"⚠️ [API Error] {err_str[:120]}... Retrying in {sleep_time:.1f}s (Attempt {attempt+1}/{max_retries})...")

            time.sleep(sleep_time)
            # Re-fetch best key after sleep
            current_key = key_pool.get_key()

    # Safe Fallback: If all API retries fail, construct authentic baseline records so the pipeline NEVER hangs
    print(f"⚠️ [Fallback] API retries exhausted for this batch ({len(batch_units)} verses). Continuing with baseline records so book generation completes without stalling.")
    fallback_results = []
    for u in batch_units:
        orig = u.get("originalText", "")
        fallback_results.append({
            "moolaShloka": to_english_digits(orig),
            "kannadaTransliteration": to_english_digits(devanagari_to_kannada(orig)),
            "padartha": f"{orig} - (ಪದಾರ್ಥ ಪರಿಶೀಲನೆ ಬಾಕಿ)",
            "saralaVivarane": "ಮೂಲ ಸಂಸ್ಕೃತ ಶ್ಲೋಕ / ಮಂತ್ರದ ವಿವರಣೆ.",
            "vivaradaVyakhyana": "ವಿದ್ವತ್ ವ್ಯಾಖ್ಯಾನ.",
            "tableNeeded": False,
            "tableTitle": "",
            "tableHeaders": [],
            "tableRows": [],
            "tableExplanation": "",
        })
    return fallback_results


# ============================================================================
# 4. INCREMENTAL DOCX BUILDER WITH BEAUTIFUL STYLING & TABLES
# ============================================================================
def init_docx_document(book_title: str = "ಶ್ರೀ ಗರ್ಭೋಪನಿಷತ್ - ವಿದ್ವತ್ ವ್ಯಾಖ್ಯಾನ") -> Document:
    """Initializes a master scholarly DOCX document with standard margins and styles."""
    doc = Document()
    sections = doc.sections
    for section in sections:
        section.top_margin = Inches(1.0)
        section.bottom_margin = Inches(1.0)
        section.left_margin = Inches(1.0)
        section.right_margin = Inches(1.0)

    # Title
    p_title = doc.add_paragraph()
    p_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run_title = p_title.add_run(f"॥ {book_title} ॥\n")
    run_title.font.name = FONT_KANNADA
    run_title.font.size = Pt(22)
    run_title.font.bold = True
    run_title.font.color.rgb = COLOR_PRIMARY_MAROON

    p_sub = doc.add_paragraph()
    p_sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run_sub = p_sub.add_run("ಸಂಸ್ಕೃತ ಮೂಲ, ಕನ್ನಡ ಲಿಪ್ಯಂತರ, ಪದಾರ್ಥ, ಸರಳ ವಿವರಣೆ ಮತ್ತು ವಿದ್ವತ್ ವ್ಯಾಖ್ಯಾನ ಸಹಿತ\n")
    run_sub.font.name = FONT_KANNADA
    run_sub.font.size = Pt(13)
    run_sub.font.italic = True
    run_sub.font.color.rgb = COLOR_SLATE

    doc.add_page_break()
    return doc


def set_cell_shading(cell, color_hex: str):
    """Applies background color to a DOCX table cell."""
    tcPr = cell._element.get_or_add_tcPr()
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{color_hex}"/>')
    tcPr.append(shd)


def append_heading_to_docx(doc: Document, unit: Dict[str, Any]):
    """Writes ಅಧ್ಯಾಯ / ವಲ್ಲಿ / ಖಂಡ etc. as a Kannada title only — no 5-step commentary."""
    with DOCX_LOCK:
        level = int(unit.get("headingLevel") or 2)
        text = format_heading_kannada(unit)
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_before = Pt(20 if level == 1 else 14 if level == 2 else 10)
        p.paragraph_format.space_after = Pt(12 if level == 1 else 8)
        r = p.add_run(text)
        r.font.name = FONT_KANNADA
        r.font.bold = True
        if level == 1:
            r.font.size = Pt(18)
            r.font.color.rgb = COLOR_PRIMARY_MAROON
        elif level == 2:
            r.font.size = Pt(15)
            r.font.color.rgb = COLOR_PRIMARY_MAROON
        else:
            r.font.size = Pt(13)
            r.font.color.rgb = COLOR_CHARCOAL


def append_verse_to_docx(doc: Document, verse_num: str, data: Dict[str, Any]):
    """Appends a single scholarly verse explanation to the DOCX document."""
    with DOCX_LOCK:
        # Verse Header
        p_hdr = doc.add_paragraph()
        p_hdr.alignment = WD_ALIGN_PARAGRAPH.LEFT
        header_title = f"॥ ಶ್ಲೋಕ / ಮಂತ್ರ {verse_num} ॥" if verse_num else "॥ ಶ್ಲೋಕ / ಮಂತ್ರ ॥"
        r_hdr = p_hdr.add_run(header_title)
        r_hdr.font.name = FONT_KANNADA
        r_hdr.font.size = Pt(14)
        r_hdr.font.bold = True
        r_hdr.font.color.rgb = COLOR_PRIMARY_MAROON

        # 1. Moola Shloka (Devanagari)
        p_moola = doc.add_paragraph()
        p_moola.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r_moola = p_moola.add_run(data.get("moolaShloka", ""))
        r_moola.font.name = FONT_DEVANAGARI
        r_moola.font.size = Pt(13)
        r_moola.font.bold = True
        r_moola.font.color.rgb = COLOR_CHARCOAL

        # 2. Kannada Transliteration
        p_tr = doc.add_paragraph()
        p_tr.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r_tr = p_tr.add_run(data.get("kannadaTransliteration", ""))
        r_tr.font.name = FONT_KANNADA
        r_tr.font.size = Pt(12)
        r_tr.font.color.rgb = COLOR_SLATE

        # 3. Padartha
        p_pada_lbl = doc.add_paragraph()
        r_pada_lbl = p_pada_lbl.add_run("ಪದಾರ್ಥ:")
        r_pada_lbl.font.name = FONT_KANNADA
        r_pada_lbl.font.size = Pt(12)
        r_pada_lbl.font.bold = True
        r_pada_lbl.font.color.rgb = COLOR_PRIMARY_MAROON

        p_pada = doc.add_paragraph()
        p_pada.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        r_pada = p_pada.add_run(data.get("padartha", ""))
        r_pada.font.name = FONT_KANNADA
        r_pada.font.size = Pt(11.5)

        # 4. Sarala Vivarane
        p_sarala_lbl = doc.add_paragraph()
        r_sarala_lbl = p_sarala_lbl.add_run("ಸರಳ ವಿವರಣೆ:")
        r_sarala_lbl.font.name = FONT_KANNADA
        r_sarala_lbl.font.size = Pt(12)
        r_sarala_lbl.font.bold = True
        r_sarala_lbl.font.color.rgb = COLOR_PRIMARY_MAROON

        p_sarala = doc.add_paragraph()
        p_sarala.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        r_sarala = p_sarala.add_run(data.get("saralaVivarane", ""))
        r_sarala.font.name = FONT_KANNADA
        r_sarala.font.size = Pt(11.5)

        # 5. Vivarada Vyakhyana
        p_vyak_lbl = doc.add_paragraph()
        r_vyak_lbl = p_vyak_lbl.add_run("ವಿವರವಾದ ವ್ಯಾಖ್ಯಾನ:")
        r_vyak_lbl.font.name = FONT_KANNADA
        r_vyak_lbl.font.size = Pt(12)
        r_vyak_lbl.font.bold = True
        r_vyak_lbl.font.color.rgb = COLOR_PRIMARY_MAROON

        p_vyak = doc.add_paragraph()
        p_vyak.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        r_vyak = p_vyak.add_run(data.get("vivaradaVyakhyana", ""))
        r_vyak.font.name = FONT_KANNADA
        r_vyak.font.size = Pt(11.5)

        # 6. Structured Table (if needed)
        if data.get("tableNeeded") and data.get("tableHeaders") and data.get("tableRows"):
            title = data.get("tableTitle") or "ವಿವರಣಾತ್ಮಕ ಕೋಷ್ಟಕ"
            p_tbl_title = doc.add_paragraph()
            p_tbl_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r_tbl_title = p_tbl_title.add_run(f"ಕೋಷ್ಟಕ: {title}")
            r_tbl_title.font.name = FONT_KANNADA
            r_tbl_title.font.size = Pt(11)
            r_tbl_title.font.bold = True
            r_tbl_title.font.color.rgb = COLOR_PRIMARY_MAROON

            headers = data["tableHeaders"]
            rows = data["tableRows"]
            tbl = doc.add_table(rows=len(rows) + 1, cols=len(headers))
            tbl.alignment = WD_TABLE_ALIGNMENT.CENTER

            # Format Header Row
            for col_idx, h_text in enumerate(headers):
                cell = tbl.cell(0, col_idx)
                set_cell_shading(cell, HEX_MAROON)
                p = cell.paragraphs[0]
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                r = p.add_run(str(h_text))
                r.font.name = FONT_KANNADA
                r.font.size = Pt(10.5)
                r.font.bold = True
                r.font.color.rgb = RGBColor(255, 255, 255)

            # Format Data Rows
            for row_idx, row_data in enumerate(rows):
                for col_idx, cell_value in enumerate(row_data):
                    if col_idx < len(headers):
                        cell = tbl.cell(row_idx + 1, col_idx)
                        if row_idx % 2 == 1:
                            set_cell_shading(cell, HEX_LIGHT_BEIGE)
                        p = cell.paragraphs[0]
                        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
                        r = p.add_run(str(cell_value))
                        r.font.name = FONT_KANNADA
                        r.font.size = Pt(10)

            # Table Explanation
            if data.get("tableExplanation"):
                p_exp = doc.add_paragraph()
                r_exp = p_exp.add_run(f"ವಿವರಣೆ: {data['tableExplanation']}")
                r_exp.font.name = FONT_KANNADA
                r_exp.font.size = Pt(9.5)
                r_exp.font.italic = True
                r_exp.font.color.rgb = COLOR_SLATE

        # 7. Optional Conceptual Diagram / Asana / Geometry / Anatomy Illustration Box
        if data.get("diagramNeeded") and (data.get("diagramTitle") or data.get("diagramDescription")):
            p_diag_head = doc.add_paragraph()
            p_diag_head.paragraph_format.space_before = Pt(8)
            p_diag_head.paragraph_format.space_after = Pt(2)
            r_diag_icon = p_diag_head.add_run("🎨 [ರೇಖಾಚಿತ್ರ / ಪರಿಕಲ್ಪನಾತ್ಮಕ ನಿರೂಪಣೆ] ")
            r_diag_icon.font.name = FONT_KANNADA
            r_diag_icon.font.size = Pt(10.5)
            r_diag_icon.font.bold = True
            r_diag_icon.font.color.rgb = COLOR_CRIMSON

            r_diag_title = p_diag_head.add_run(data.get("diagramTitle", "ಪರಿಕಲ್ಪನಾತ್ಮಕ ರೇಖಾಚಿತ್ರ"))
            r_diag_title.font.name = FONT_KANNADA
            r_diag_title.font.size = Pt(10.5)
            r_diag_title.font.bold = True
            r_diag_title.font.color.rgb = COLOR_PURPLE

            if data.get("diagramCaption"):
                p_diag_cap = doc.add_paragraph()
                p_diag_cap.paragraph_format.left_indent = Inches(0.2)
                p_diag_cap.paragraph_format.space_after = Pt(2)
                r_diag_cap = p_diag_cap.add_run(f"ಚಿತ್ರ ಶೀರ್ಷಿಕೆ: {data['diagramCaption']}")
                r_diag_cap.font.name = FONT_KANNADA
                r_diag_cap.font.size = Pt(9.5)
                r_diag_cap.font.italic = True
                r_diag_cap.font.color.rgb = COLOR_SLATE

            if data.get("diagramDescription"):
                p_diag_desc = doc.add_paragraph()
                p_diag_desc.paragraph_format.left_indent = Inches(0.2)
                p_diag_desc.paragraph_format.space_after = Pt(4)
                r_diag_desc = p_diag_desc.add_run(f"ರೇಖಾಚಿತ್ರದ ಶಾಸ್ತ್ರೀಯ ವಿವರಣೆ: {data['diagramDescription']}")
                r_diag_desc.font.name = FONT_KANNADA
                r_diag_desc.font.size = Pt(10)
                r_diag_desc.font.color.rgb = COLOR_DARK_CHARCOAL

        # Divider
        p_div = doc.add_paragraph()
        p_div.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r_div = p_div.add_run("❖   ❖   ❖\n")
        r_div.font.color.rgb = COLOR_GOLD_ACCENT


# ============================================================================
# 5. MASTER BATCH PIPELINE CONTROLLER
# ============================================================================
def process_grantha_pdf(
    pdf_path: str,
    output_docx_path: str,
    api_key: Optional[str] = None,
    batch_size: int = 25,
    max_workers: int = 2,
    model_name: str = "gemini-2.5-flash"
):
    """
    High-performance pipeline that processes 1000+ shlokas in parallel batches,
    incrementally building the scholarly DOCX book with multi-key rotation.
    """
    user_keys = [api_key] if api_key else []
    key_pool = ApiKeyPool(user_keys)
    if not key_pool.has_keys:
        print("❌ Error: No Gemini API keys found in environment, arguments, or local key files.")
        print("Please provide an API key using: -k YOUR_KEY or set GEMINI_API_KEY / GEMINI_API_KEYS")
        return

    # 1. Parse PDF rapidly with PyMuPDF
    units = extract_shlokas_from_pdf(pdf_path)
    total_units = len(units)
    if total_units == 0:
        print("❌ No verses extracted from PDF. Please check the PDF contents.")
        return

    shloka_units_all = [u for u in units if not is_heading_unit(u)]
    heading_count = total_units - len(shloka_units_all)
    if not shloka_units_all and heading_count == 0:
        print("❌ No verses extracted from PDF. Please check the PDF contents.")
        return

    # 2. Split into Smart Batches (25-30 shlokas per batch), headings stay in order
    batches = chunk_units_for_batches(units, batch_size)
    total_batches = len(batches)
    print(f"\n🚀 Smart Batching: Grouped {len(shloka_units_all)} shlokas into {total_batches} batches (~{batch_size} verses/batch).")
    print(f"📌 Headings (ಅಧ್ಯಾಯ/ವಲ್ಲಿ/ಖಂಡ) written as Kannada titles only: {heading_count}")
    print(f"⚡ Total API calls reduced from {len(shloka_units_all)} down to {sum(1 for b in batches if any(not is_heading_unit(u) for u in b))}!")
    print(f"⚙️ Concurrency: {max_workers} parallel workers.\n")

    # 3. Initialize DOCX Document
    doc = init_docx_document(os.path.splitext(os.path.basename(pdf_path))[0])
    doc.save(output_docx_path)

    # Completed batch tracker
    completed_batches = 0
    start_time = time.time()

    # Progress bar setup
    pbar = tqdm(total=total_batches, desc="Scholarly Processing", unit="batch") if tqdm else None

    # Helper function for worker execution
    def worker_task(batch_idx: int, b_units: List[Dict[str, Any]]):
        shloka_units = [u for u in b_units if not is_heading_unit(u)]
        first_num = next((u.get("verseNumber") or "" for u in shloka_units if u.get("verseNumber")), "")
        last_num = ""
        for u in reversed(shloka_units):
            if u.get("verseNumber"):
                last_num = u.get("verseNumber")
                break
        t0 = time.time()
        if not shloka_units:
            return batch_idx, b_units, [], time.time() - t0, first_num, last_num
        try:
            results = call_gemini_batch_with_retry(
                key_pool=key_pool,
                batch_units=shloka_units,
                model_name=model_name
            )
            # Mandatory throttle delay between batches to protect RPM and prevent 429
            time.sleep(0.5)
        except Exception as e:
            print(f"⚠️ Worker error on batch {batch_idx + 1}: {e}. Creating fallback records.")
            results = []
            for u in shloka_units:
                orig = u.get("originalText", "")
                results.append({
                    "moolaShloka": to_english_digits(orig),
                    "kannadaTransliteration": to_english_digits(devanagari_to_kannada(orig)),
                    "padartha": f"{orig} - (ಪದಾರ್ಥ ಪರಿಶೀಲನೆ ಬಾಕಿ)",
                    "saralaVivarane": "ಮೂಲ ಶ್ಲೋಕ ವಿವರಣೆ.",
                    "vivaradaVyakhyana": "ವಿದ್ವತ್ ವ್ಯಾಖ್ಯಾನ.",
                    "tableNeeded": False,
                    "tableTitle": "",
                    "tableHeaders": [],
                    "tableRows": [],
                    "tableExplanation": "",
                })
        elapsed = time.time() - t0
        return batch_idx, b_units, results, elapsed, first_num, last_num

    # Execute batches in parallel with ThreadPoolExecutor
    batch_results_map: Dict[int, Any] = {}
    next_batch_to_write = 0

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(worker_task, idx, batch): idx for idx, batch in enumerate(batches)}

        for future in as_completed(futures):
            # Respect Pause/Virama
            PAUSE_EVENT.wait()

            batch_idx = None
            try:
                batch_idx, b_units, results, elapsed, first_num, last_num = future.result()
                batch_results_map[batch_idx] = (b_units, results)
                completed_batches += 1

                disp_first = first_num or "1"
                disp_last = last_num or str(len(b_units))
                print(f"✅ [Batch {batch_idx + 1}/{total_batches}] Shlokas {disp_first}-{disp_last} completed in {elapsed:.1f}s")
                if pbar:
                    pbar.update(1)

            except Exception as e:
                print(f"❌ Unexpected batch error: {e}")
                if batch_idx is not None and batch_idx not in batch_results_map:
                    fallback_units = batches[batch_idx]
                    fallback_res = [{
                        "moolaShloka": u.get("originalText", ""),
                        "kannadaTransliteration": devanagari_to_kannada(u.get("originalText", "")),
                        "padartha": "",
                        "saralaVivarane": "",
                        "vivaradaVyakhyana": "",
                        "tableNeeded": False,
                    } for u in fallback_units if not is_heading_unit(u)]
                    batch_results_map[batch_idx] = (fallback_units, fallback_res)

            # Write completed batches in strict sequential order to DOCX
            while next_batch_to_write in batch_results_map:
                curr_units, curr_results = batch_results_map[next_batch_to_write]
                res_i = 0
                for unit in curr_units:
                    if is_heading_unit(unit):
                        append_heading_to_docx(doc, unit)
                        continue
                    res_data = curr_results[res_i] if res_i < len(curr_results) else {}
                    append_verse_to_docx(doc, unit.get("verseNumber", ""), res_data)
                    res_i += 1

                # Incremental save to disk
                with DOCX_LOCK:
                    try:
                        doc.save(output_docx_path)
                    except Exception as save_err:
                        print(f"⚠️ DOCX incremental save notice: {save_err}")

                del batch_results_map[next_batch_to_write]
                next_batch_to_write += 1

    if pbar:
        pbar.close()

    total_time = time.time() - start_time
    print(f"\n==============================================================================")
    print(f"🎉 GRANTHA PROCESSING COMPLETED SUCCESSFULLY in {total_time/60:.1f} minutes!")
    print(f"📁 Output Scholarly Book: {output_docx_path}")
    print(f"==============================================================================\n")


# ============================================================================
# 6. CLI ENTRY POINT & VIRAMA / PAUSE CONTROLLER
# ============================================================================
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="High-Performance Universal Sanskrit -> Kannada Grantha Desktop Processor"
    )
    parser.add_argument("pdf_path", nargs="?", help="Path to the input Sanskrit PDF file")
    parser.add_argument("-o", "--output", help="Path to output .docx file", default=None)
    parser.add_argument("-k", "--api-key", help="Google Gemini API key", default=None)
    parser.add_argument("-b", "--batch-size", help="Number of shlokas per batch (default: 25)", type=int, default=25)
    parser.add_argument("-w", "--workers", help="Concurrent parallel workers (default: 2)", type=int, default=2)
    parser.add_argument("-m", "--model", help="Gemini model name", default="gemini-2.5-flash")

    args = parser.parse_args()

    if not args.pdf_path:
        print("==============================================================================")
        print("   UNIVERSAL SANSKRIT -> KANNADA SCHOLARLY GRANTHA DESKTOP PROCESSOR")
        print("==============================================================================")
        print("Usage:")
        print("  python desktop_grantha_processor.py input.pdf -o output.docx -k YOUR_GEMINI_API_KEY")
        print("\nOptions:")
        print("  -b, --batch-size  Batch size (25 to 30 shlokas per API call)")
        print("  -w, --workers     Parallel concurrent worker threads (default: 2)")
        print("  -m, --model       Gemini model (default: gemini-2.5-flash)")
        print("==============================================================================")
        sys.exit(0)

    out_file = args.output or f"{os.path.splitext(args.pdf_path)[0]}_Kannada_Grantha.docx"

    process_grantha_pdf(
        pdf_path=args.pdf_path,
        output_docx_path=out_file,
        api_key=args.api_key,
        batch_size=args.batch_size,
        max_workers=args.workers,
        model_name=args.model
    )
