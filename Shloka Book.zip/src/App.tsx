import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  BookOpen,
  Plus,
  Search,
  Filter,
  Layers,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Sparkles,
  RefreshCw,
  FolderPlus,
  Trash2,
  Key,
  Heading1,
  AlignLeft,
} from 'lucide-react';
import { GranthaProject, GranthaDocument, SanskritUnit } from './types';
import { safeFetchJson } from './utils/apiClient';
import { Navbar } from './components/Navbar';
import { ProjectDashboard } from './components/ProjectDashboard';
import { LiveProcessMonitor } from './components/LiveProcessMonitor';
import { FileUploadSection } from './components/FileUploadSection';
import { UnitViewer } from './components/UnitViewer';
import { ReviewModal } from './components/ReviewModal';
import { ExportModal } from './components/ExportModal';
import { SettingsModal } from './components/SettingsModal';
import { WindowsPackagingGuide } from './components/WindowsPackagingGuide';
import { ProjectManagerModal } from './components/ProjectManagerModal';
import { MasterIndexModal } from './components/MasterIndexModal';
import { AcademicProjectIntro } from './components/AcademicProjectIntro';

export function App() {
  const [projects, setProjects] = useState<GranthaProject[]>([]);
  const [currentProject, setCurrentProject] = useState<GranthaProject | null>(null);
  const [documents, setDocuments] = useState<GranthaDocument[]>([]);
  const [units, setUnits] = useState<SanskritUnit[]>([]);
  const [selectedUnitId, setSelectedUnitId] = useState<string | null>(null);
  const [changingUnitTypeId, setChangingUnitTypeId] = useState<string | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  // Modals
  const [showNewProjectModal, setShowNewProjectModal] = useState<boolean>(false);
  const [showSettingsModal, setShowSettingsModal] = useState<boolean>(false);
  const [showWindowsGuide, setShowWindowsGuide] = useState<boolean>(false);
  const [showExportModal, setShowExportModal] = useState<boolean>(false);
  const [showMasterIndexModal, setShowMasterIndexModal] = useState<boolean>(false);
  const [reviewingUnit, setReviewingUnit] = useState<SanskritUnit | null>(null);
  const [keyStatus, setKeyStatus] = useState<{ total: number; active: number; rateLimited: number; hasAnyKey: boolean } | null>(null);

  const checkKeyStatus = useCallback(() => {
    safeFetchJson<{ total: number; active: number; rateLimited: number; hasAnyKey: boolean }>('/api/key-status').then(res => {
      if (res.ok && res.data) {
        setKeyStatus(res.data);
      }
    });
  }, []);

  useEffect(() => {
    checkKeyStatus();
  }, [checkKeyStatus]);

  const isPollingRef = useRef<boolean>(false);
  const currentProjectId = currentProject?.id;

  // Load a single project & its units safely
  const loadProject = useCallback(async (id: string) => {
    try {
      const projRes = await safeFetchJson<GranthaProject>(`/api/projects/${id}`);
      if (!projRes.ok || !projRes.data) {
        console.warn(`Could not load project ${id}:`, projRes.error);
        return;
      }

      setCurrentProject(projRes.data);
      setIsProcessing(projRes.data.isRunning || false);
      setDocuments(projRes.data.documents || []);

      // Load units
      const unitsRes = await safeFetchJson<SanskritUnit[]>(`/api/projects/${id}/units`);
      if (unitsRes.ok && Array.isArray(unitsRes.data)) {
        setUnits(unitsRes.data);
        setSelectedUnitId((prev) => {
          if (prev && unitsRes.data!.some((u) => u.id === prev)) return prev;
          return unitsRes.data!.length > 0 ? unitsRes.data![0].id : null;
        });
      }
    } catch (err) {
      console.error(`Error loading project ${id}:`, err);
    }
  }, []);

  // Fetch all projects safely
  const fetchProjects = useCallback(async (selectId?: string) => {
    try {
      const res = await safeFetchJson<GranthaProject[]>('/api/projects');
      if (!res.ok || !res.data) {
        console.warn('Error fetching projects:', res.error);
        return;
      }

      const data = res.data;
      setProjects(data);

      if (selectId) {
        loadProject(selectId);
      } else if (data.length > 0) {
        if (!currentProjectId || !data.some((p) => p.id === currentProjectId)) {
          loadProject(data[0].id);
        }
      } else if (data.length === 0) {
        createInitialProject();
      }
    } catch (err) {
      console.error('Error fetching projects:', err);
    }
  }, [currentProjectId, loadProject]);

  useEffect(() => {
    fetchProjects();
  }, []);

  const createInitialProject = async () => {
    try {
      const res = await safeFetchJson<GranthaProject>('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: 'ನನ್ನ ಸಂಸ್ಕೃತ ಗ್ರಂಥ ಪ್ರಕಲ್ಪ (My Sanskrit Grantha Project)',
          description: 'ನಿಮ್ಮ ಸಂಸ್ಕೃತ PDF ಕಡತಗಳನ್ನು ಅಪ್ಲೋಡ್ ಮಾಡಿ ವಿದ್ವತ್ ಗ್ರಂಥ ಪ್ರಕಾಶನವನ್ನು ಪ್ರಾರಂಭಿಸಿ.',
        }),
      });
      if (res.ok && res.data) {
        await fetchProjects(res.data.id);
      }
    } catch (err) {
      console.error('Error creating initial project:', err);
    }
  };

  // Robust poll project status if running with rate limit backoff
  useEffect(() => {
    if (!currentProjectId || !isProcessing) return;

    let isMounted = true;
    let pollTimer: any = null;
    let pollDelay = 3000;

    const poll = async () => {
      if (!isMounted || isPollingRef.current) return;
      isPollingRef.current = true;

      try {
        const res = await safeFetchJson<GranthaProject>(`/api/projects/${currentProjectId}`);

        if (res.isRateLimited) {
          // Back off to 8s if server / proxy is rate limiting
          pollDelay = 8000;
        } else if (res.ok && res.data && isMounted) {
          pollDelay = 3000;
          setCurrentProject(res.data);
          const running = res.data.isRunning || false;
          setIsProcessing(running);

          const unitsRes = await safeFetchJson<SanskritUnit[]>(`/api/projects/${currentProjectId}/units`);
          if (unitsRes.ok && Array.isArray(unitsRes.data) && isMounted) {
            setUnits(unitsRes.data);
          }

          if (!running) {
            isPollingRef.current = false;
            return;
          }
        }
      } catch (err) {
        console.warn('Poll status check note:', err);
      } finally {
        isPollingRef.current = false;
        if (isMounted && isProcessing) {
          pollTimer = setTimeout(poll, pollDelay);
        }
      }
    };

    pollTimer = setTimeout(poll, 1500);

    return () => {
      isMounted = false;
      if (pollTimer) clearTimeout(pollTimer);
      isPollingRef.current = false;
    };
  }, [currentProjectId, isProcessing]);

  // Handle Project Creation
  const handleCreateProject = async (name: string, description: string) => {
    try {
      const res = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          description: description.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to create project');
      await fetchProjects(data.id);
    } catch (err: any) {
      alert(`ಪ್ರಕಲ್ಪ ರಚನೆ ದೋಷ: ${err.message}`);
      throw err;
    }
  };

  // Handle Project Deletion
  const handleDeleteProject = async (projectId: string) => {
    try {
      const res = await fetch(`/api/projects/${projectId}`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to delete project');

      // Check remaining projects
      const updatedProjects = projects.filter((p) => p.id !== projectId);
      setProjects(updatedProjects);

      if (currentProject?.id === projectId) {
        if (updatedProjects.length > 0) {
          loadProject(updatedProjects[0].id);
        } else {
          await createInitialProject();
        }
      }
      await fetchProjects();
    } catch (err: any) {
      alert(`ಪ್ರಕಲ್ಪ ಅಳಿಸುವಿಕೆ ದೋಷ: ${err.message}`);
      throw err;
    }
  };

  // Processing Actions
  const handleStartProcessing = async () => {
    if (!currentProject) return;
    setIsProcessing(true);
    try {
      const res = await fetch(`/api/projects/${currentProject.id}/start`, { method: 'POST' });
      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'ಸಂಸ್ಕರಣೆ ಆರಂಭಿಸಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ');
      }
      await loadProject(currentProject.id);
    } catch (err: any) {
      alert(`ಸಂಸ್ಕರಣೆ ಆರಂಭ ದೋಷ: ${err.message}`);
      setIsProcessing(false);
      await loadProject(currentProject.id);
    }
  };

  const handlePauseProcessing = async () => {
    if (!currentProject) return;
    try {
      const res = await fetch(`/api/projects/${currentProject.id}/pause`, { method: 'POST' });
      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'ವಿರಾಮಗೊಳಿಸಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ');
      }
      setIsProcessing(false);
      await loadProject(currentProject.id);
    } catch (err: any) {
      console.error(err);
      setIsProcessing(false);
      await loadProject(currentProject.id);
    }
  };

  const handleCancelProcessing = async () => {
    if (!currentProject) return;
    try {
      const res = await fetch(`/api/projects/${currentProject.id}/cancel`, { method: 'POST' });
      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'ರದ್ದುಗೊಳಿಸಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ');
      }
      setIsProcessing(false);
      await loadProject(currentProject.id);
    } catch (err: any) {
      console.error(err);
      setIsProcessing(false);
      await loadProject(currentProject.id);
    }
  };

  // Reprocess Single Unit
  const handleReprocessUnit = async (unitId: string) => {
    const res = await fetch(`/api/units/${unitId}/reprocess`, { method: 'POST' });
    const updated = await res.json();
    if (!res.ok) throw new Error(updated.error || 'Reprocess failed');

    setUnits((prev) => prev.map((u) => (u.id === unitId ? updated : u)));
    if (currentProject) {
      loadProject(currentProject.id);
    }
  };

  // Save Unit Edit / Accept
  const handleSaveUnit = async (updatedData: Partial<SanskritUnit> & { id: string; action?: 'ACCEPT' | 'REJECT' }) => {
    const res = await fetch(`/api/units/${updatedData.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updatedData),
    });
    const updated = await res.json();
    if (!res.ok) throw new Error(updated.error || 'Update failed');

    setUnits((prev) => prev.map((u) => (u.id === updatedData.id ? updated : u)));
    if (currentProject) {
      loadProject(currentProject.id);
    }
  };

  // Manually mark a unit as HEADING or SHLOKA directly from the Verse Index list.
  // HEADING -> heading-only output (mula text + transliteration, no padartha/sarala
  // vivarane/vyakhyana). SHLOKA -> forces the full 5-section generation pipeline so
  // all 5 mandatory output fields get (re)generated, even if the unit was previously
  // a HEADING/COLOPHON/GADYA.
  const handleChangeUnitType = async (e: React.MouseEvent, unitId: string, manualUnitType: 'HEADING' | 'SHLOKA') => {
    e.stopPropagation();
    if (changingUnitTypeId) return;
    setChangingUnitTypeId(unitId);
    try {
      const res = await fetch(`/api/units/${unitId}/reprocess`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ manualUnitType }),
      });
      const updated = await res.json();
      if (!res.ok) throw new Error(updated.error || 'Failed to change unit type');
      setUnits((prev) => prev.map((u) => (u.id === unitId ? updated : u)));
      if (currentProject) {
        loadProject(currentProject.id);
      }
    } catch (err: any) {
      console.error('Failed to change unit type', err);
    } finally {
      setChangingUnitTypeId(null);
    }
  };

  const handleDeleteUnit = async (e: React.MouseEvent, unitId: string) => {
    e.stopPropagation();
    try {
      const res = await fetch(`/api/units/${unitId}`, { method: 'DELETE' });
      if (res.ok) {
        setUnits((prev) => prev.filter((u) => u.id !== unitId));
        if (selectedUnitId === unitId) {
          const remaining = units.filter((u) => u.id !== unitId);
          setSelectedUnitId(remaining.length > 0 ? remaining[0].id : null);
        }
        if (currentProject) {
          loadProject(currentProject.id);
        }
      }
    } catch (err) {
      console.error('Failed to delete unit', err);
    }
  };

  // Filter and Search Units
  const filteredUnits = units.filter((u) => {
    if (filterStatus !== 'ALL') {
      if (filterStatus === 'COMPLETED' && u.status !== 'COMPLETED') return false;
      if (filterStatus === 'REVIEW_REQUIRED' && u.status !== 'REVIEW_REQUIRED' && u.status !== 'FAILED' && u.confidence !== 'LOW') return false;
      if (filterStatus === 'PENDING' && (u.status === 'COMPLETED' || u.status === 'REVIEW_REQUIRED')) return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchText = (u.originalText || '').toLowerCase();
      const matchNum = (u.structuralHierarchy.formattedNumber || '').toLowerCase();
      const matchKannada = (u.output?.kannadaTransliteration || '').toLowerCase();
      const matchFirstWord = (u.firstMeaningfulWord || '').toLowerCase();
      if (!matchText.includes(q) && !matchNum.includes(q) && !matchKannada.includes(q) && !matchFirstWord.includes(q)) {
        return false;
      }
    }
    return true;
  });

  const selectedUnit = units.find((u) => u.id === selectedUnitId) || units[0] || null;

  return (
    <div className="min-h-screen bg-[#F7F4EF] text-[#1F1916] flex flex-col font-sans selection:bg-[#8B1E0F]/20 selection:text-[#8B1E0F]">
      {/* Top Navbar */}
      <Navbar
        projects={projects}
        currentProject={currentProject}
        onSelectProject={(id) => loadProject(id)}
        onNewProject={() => setShowNewProjectModal(true)}
        onOpenMasterIndex={() => setShowMasterIndexModal(true)}
        onOpenSettings={() => setShowSettingsModal(true)}
        onOpenWindowsGuide={() => setShowWindowsGuide(true)}
        onOpenExport={() => setShowExportModal(true)}
      />

      {/* Main Content Workspace */}
      <main className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6 flex-1">
        {keyStatus && !keyStatus.hasAnyKey && (
          <div className="p-4 rounded-xl bg-amber-50 border border-amber-300 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs shadow-xs">
            <div className="flex items-center space-x-3 text-amber-900">
              <AlertTriangle className="w-5 h-5 text-amber-700 flex-shrink-0" />
              <div>
                <span className="font-bold font-kannada text-sm">
                  ⚠️ ಡೆಸ್ಕ್‌ಟಾಪ್ / ಸ್ಥಳೀಯ ಆವೃತ್ತಿ ಸೂಚನೆ: Gemini API Key ಲಭ್ಯವಿಲ್ಲ (API Key Required)
                </span>
                <p className="text-[11px] text-amber-800 font-kannada mt-0.5">
                  ಸಂಸ್ಕೃತ ಶ್ಲೋಕಗಳ ಸ್ವಯಂಚಾಲಿತ AI ವಿಶ್ಲೇಷಣೆ, ಪದಾರ್ಥ ಹಾಗೂ ತಾತ್ಪರ್ಯ ರಚನೆಗೆ Gemini API Key ಅಗತ್ಯವಿದೆ. ಸೆಟ್ಟಿಂಗ್ಸ್‌ನಲ್ಲಿ ಕೀ ಸೇರಿಸಿ ಅಥವಾ <code>.env</code> ಕಡತ ಬಳಸಿ.
                </p>
              </div>
            </div>
            <button
              onClick={() => setShowSettingsModal(true)}
              className="px-4 py-2 rounded-lg bg-[#8B1E0F] hover:bg-[#A32312] text-white font-bold text-xs flex items-center space-x-1.5 flex-shrink-0 shadow-sm transition-all"
            >
              <Key className="w-3.5 h-3.5" />
              <span>API Key ಸೇರಿಸಿ (Add Key)</span>
            </button>
          </div>
        )}

        {/* Academic Project Presentation & Creator Intro */}
        <AcademicProjectIntro />

        {currentProject ? (
          <>
            {/* Dashboard & Processing Control */}
            <ProjectDashboard
              project={currentProject}
              units={units}
              isProcessing={isProcessing}
              onStart={handleStartProcessing}
              onPause={handlePauseProcessing}
              onCancel={handleCancelProcessing}
              onOpenExport={() => setShowExportModal(true)}
              onOpenMasterIndex={() => setShowMasterIndexModal(true)}
              onOpenReview={() => {
                setFilterStatus('REVIEW_REQUIRED');
                const firstReview = units.find((u) => u.status === 'REVIEW_REQUIRED' || u.status === 'FAILED' || u.confidence === 'LOW');
                if (firstReview) {
                  setSelectedUnitId(firstReview.id);
                  setReviewingUnit(firstReview);
                }
              }}
              onFilterStatus={(s) => setFilterStatus(s)}
              onDeleteProject={() => handleDeleteProject(currentProject.id)}
              currentFilter={filterStatus}
            />

            {/* Live Process & Scholarly Engine Monitor */}
            <LiveProcessMonitor
              project={currentProject}
              units={units}
              isProcessing={isProcessing}
              onStart={handleStartProcessing}
              onPause={handlePauseProcessing}
              onCancel={handleCancelProcessing}
              onOpenExport={() => setShowExportModal(true)}
              onSelectUnit={(unitId) => setSelectedUnitId(unitId)}
            />

            {/* Source Documents Upload Section */}
            <FileUploadSection
              projectId={currentProject.id}
              documents={documents}
              onFilesUploaded={() => {
                fetchProjects();
                loadProject(currentProject.id);
              }}
              onStartProcessing={handleStartProcessing}
            />

            {/* Split Screen Workspace: Left Verse Index & Right Verse Scholarly Viewer */}
            {units.length > 0 && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                {/* Left Column: Verse Navigator (4 cols) */}
                <div className="lg:col-span-4 bg-white border border-[#E8E2D9] rounded-xl p-4 shadow-sm flex flex-col max-h-[800px]">
                  <div className="flex items-center justify-between pb-3 border-b border-[#EAE4DC] mb-3">
                    <h3 className="font-serif text-sm font-bold text-[#1F1916] flex items-center">
                      <Layers className="w-4 h-4 mr-1.5 text-[#8B1E0F]" />
                      ಶ್ಲೋಕಾನುಕ್ರಮಣಿಕಾ (Verse Index)
                    </h3>
                    <span className="text-xs font-mono text-[#7A695D]">
                      {filteredUnits.length} / {units.length}
                    </span>
                  </div>

                  {/* Search Bar */}
                  <div className="relative mb-3">
                    <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-[#A39286]" />
                    <input
                      type="text"
                      placeholder="ಹುಡುಕಿ (Search Sanskrit text, verse #)..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-[#DDD5C9] text-xs bg-[#FAF8F5] focus:outline-none focus:border-[#8B1E0F]"
                    />
                  </div>

                  {/* Filter Pills */}
                  <div className="flex space-x-1 mb-3 overflow-x-auto pb-1 text-[11px]">
                    {['ALL', 'COMPLETED', 'REVIEW_REQUIRED', 'PENDING'].map((status) => (
                      <button
                        key={status}
                        onClick={() => setFilterStatus(status)}
                        className={`px-2.5 py-1 rounded-full whitespace-nowrap transition-colors ${
                          filterStatus === status
                            ? 'bg-[#8B1E0F] text-white font-semibold'
                            : 'bg-[#F4EDE5] text-[#634E42] hover:bg-[#EADBCE]'
                        }`}
                      >
                        {status === 'ALL'
                          ? 'ಎಲ್ಲವೂ (All)'
                          : status === 'COMPLETED'
                          ? 'ಪೂರ್ಣ'
                          : status === 'REVIEW_REQUIRED'
                          ? 'ಪರಿಶೀಲನೆ'
                          : 'ಬಾಕಿ'}
                      </button>
                    ))}
                  </div>

                  {/* Unit Items List */}
                  <div className="overflow-y-auto space-y-2 flex-1 pr-1">
                    {filteredUnits.map((u) => {
                      const isSelected = selectedUnit?.id === u.id;
                      return (
                        <div
                          key={u.id}
                          id={`verse-list-item-${u.id}`}
                          onClick={() => setSelectedUnitId(u.id)}
                          className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                            isSelected
                              ? 'bg-[#FAF2EF] border-[#8B1E0F] shadow-sm ring-1 ring-[#8B1E0F]'
                              : 'bg-[#FAF8F5] border-[#EAE4DC] hover:bg-[#F3ECE4]'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-mono text-xs font-bold text-[#8B1E0F]">
                              {u.structuralHierarchy.formattedNumber}
                            </span>
                            <div className="flex items-center space-x-1.5">
                              <span
                                className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                                  u.status === 'COMPLETED'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : u.status === 'REVIEW_REQUIRED'
                                    ? 'bg-amber-100 text-amber-900'
                                    : 'bg-stone-200 text-stone-700'
                                }`}
                              >
                                {u.status}
                              </span>
                              {/* Manual type override: click directly to mark this unit as
                                  Heading (heading-only output) or Shloka (full 5-section output) */}
                              <div className="flex items-center rounded border border-[#EADBCE] overflow-hidden">
                                <button
                                  onClick={(e) => handleChangeUnitType(e, u.id, 'HEADING')}
                                  disabled={changingUnitTypeId === u.id}
                                  title="ಶೀರ್ಷಿಕೆಯಾಗಿ ಗುರುತಿಸಿ (Mark as Heading — heading-only output)"
                                  className={`p-1 transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${
                                    u.unitType === 'HEADING' || u.unitType === 'COLOPHON'
                                      ? 'bg-indigo-600 text-white'
                                      : 'text-[#857468] hover:text-[#8B1E0F] hover:bg-[#EADBCE]'
                                  }`}
                                >
                                  <Heading1 className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={(e) => handleChangeUnitType(e, u.id, 'SHLOKA')}
                                  disabled={changingUnitTypeId === u.id}
                                  title="ಶ್ಲೋಕವಾಗಿ ಗುರುತಿಸಿ (Mark as Shloka — generates all 5 sections)"
                                  className={`p-1 border-l border-[#EADBCE] transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${
                                    u.unitType && u.unitType !== 'HEADING' && u.unitType !== 'COLOPHON'
                                      ? 'bg-emerald-600 text-white'
                                      : 'text-[#857468] hover:text-[#8B1E0F] hover:bg-[#EADBCE]'
                                  }`}
                                >
                                  {changingUnitTypeId === u.id ? (
                                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                                  ) : (
                                    <AlignLeft className="w-3.5 h-3.5" />
                                  )}
                                </button>
                              </div>
                              <button
                                onClick={(e) => handleDeleteUnit(e, u.id)}
                                title="ಅಳಿಸಿಹಾಕು (Delete)"
                                className="p-1 text-[#857468] hover:text-[#8B1E0F] hover:bg-[#EADBCE] rounded transition-colors"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>

                          <p className="font-devanagari text-xs text-[#2A231E] line-clamp-2 leading-relaxed">
                            {u.originalText}
                          </p>

                          <div className="mt-2 pt-1.5 border-t border-[#EAE4DC]/60 flex items-center justify-between text-[10px] text-[#857468]">
                            <span>ಪುಟ {u.pageNumber}</span>
                            <span className="font-mono">{u.confidence} CONF</span>
                          </div>
                        </div>
                      );
                    })}

                    {filteredUnits.length === 0 && (
                      <p className="text-center py-8 text-xs text-[#857468]">
                        ಯಾವುದೇ ಶ್ಲೋಕಗಳು ಕಂಡುಬಂದಿಲ್ಲ.
                      </p>
                    )}
                  </div>
                </div>

                {/* Right Column: Active Verse Scholarly Editor & Viewer (8 cols) */}
                <div className="lg:col-span-8">
                  {selectedUnit ? (
                    <UnitViewer
                      unit={selectedUnit}
                      onReprocess={handleReprocessUnit}
                      onOpenEdit={(unitToEdit) => setReviewingUnit(unitToEdit)}
                      onUnitUpdated={(updatedUnit) => {
                        setUnits((prev) =>
                          prev.map((u) => (u.id === updatedUnit.id ? updatedUnit : u))
                        );
                      }}
                    />
                  ) : (
                    <div className="bg-white border border-[#E8E2D9] rounded-xl p-12 text-center text-[#857468]">
                      <BookOpen className="w-12 h-12 text-[#DDD5C9] mx-auto mb-3" />
                      <p className="text-sm font-semibold">ಶ್ಲೋಕವನ್ನು ಆಯ್ಕೆಮಾಡಿ</p>
                      <p className="text-xs mt-1">ಎಡಭಾಗದ ಪಟ್ಟಿಯಿಂದ ಶ್ಲೋಕವನ್ನು ಕ್ಲಿಕ್ ಮಾಡಿ.</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="bg-white border border-[#E8E2D9] rounded-2xl p-12 text-center shadow-sm max-w-xl mx-auto my-12">
            <BookOpen className="w-16 h-16 text-[#8B1E0F] mx-auto mb-4" />
            <h2 className="font-serif text-2xl font-bold text-[#1F1916]">
              ಸರ್ವ ಸಂಸ್ಕೃತ-ಕನ್ನಡ ವಿದ್ವತ್ ಗ್ರಂಥ ಪ್ರಕಲ್ಪ
            </h2>
            <p className="text-sm text-[#7A695D] mt-2 mb-6 font-kannada leading-relaxed">
              ಮೂಲ ಸಂಸ್ಕೃತ ಹಸ್ತಪ್ರತಿಗಳನ್ನು ಅಪ್ಲೋಡ್ ಮಾಡಿ, 5 ಕಡ್ಡಾಯ ವಿಭಾಗಗಳೊಂದಿಗೆ ಅತ್ಯುನ್ನತ ಗುಣಮಟ್ಟದ ಗ್ರಂಥಗಳನ್ನು ಸಿದ್ಧಪಡಿಸಿ.
            </p>
            <button
              onClick={() => setShowNewProjectModal(true)}
              className="px-6 py-3 rounded-xl bg-[#8B1E0F] hover:bg-[#A32312] text-white font-semibold text-sm shadow-md transition-colors"
            >
              ಹೊಸ ಗ್ರಂಥ ಪ್ರಕಲ್ಪವನ್ನು ರಚಿಸಿ (Create Project)
            </button>
          </div>
        )}
      </main>

      {/* Review Modal */}
      {reviewingUnit && (
        <ReviewModal
          unit={reviewingUnit}
          onClose={() => setReviewingUnit(null)}
          onSaveUnit={handleSaveUnit}
          onReprocess={handleReprocessUnit}
        />
      )}

      {/* Export Modal */}
      {showExportModal && (
        <ExportModal
          project={currentProject}
          units={units}
          onClose={() => setShowExportModal(false)}
        />
      )}

      {/* Settings Modal */}
      {showSettingsModal && (
        <SettingsModal onClose={() => setShowSettingsModal(false)} />
      )}

      {/* Windows Packaging Guide */}
      {showWindowsGuide && (
        <WindowsPackagingGuide onClose={() => setShowWindowsGuide(false)} />
      )}

      {/* Grantha Project Manager Modal (New Project & Delete Old Projects) */}
      <ProjectManagerModal
        isOpen={showNewProjectModal}
        onClose={() => setShowNewProjectModal(false)}
        projects={projects}
        currentProjectId={currentProject?.id || null}
        onSelectProject={(id) => loadProject(id)}
        onCreateProject={handleCreateProject}
        onDeleteProject={handleDeleteProject}
      />

      {/* Master Index & Head/Sub-head Hierarchy Modal */}
      {showMasterIndexModal && currentProject && (
        <MasterIndexModal
          project={currentProject}
          units={units}
          onClose={() => setShowMasterIndexModal(false)}
          onProjectUpdated={() => {
            loadProject(currentProject.id);
            fetchProjects();
          }}
          onSelectUnit={(unitId) => {
            setSelectedUnitId(unitId);
          }}
          onStartProcessing={() => {
            handleStartProcessing();
          }}
        />
      )}

      {/* Footer */}
      <footer className="bg-[#1C1613] text-[#AFA39B] border-t border-[#3D2E27] py-6 text-xs text-center">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="font-kannada">
            ಸರ್ವ ಸಂಸ್ಕೃತ-ಕನ್ನಡ ಗ್ರಂಥ ವಿದ್ವತ್ ಪ್ರಕಾಶನ ಯಂತ್ರ • Universal Sanskrit → Kannada Scholarly Grantha Engine
          </p>
          <p className="font-mono text-[11px] text-[#786960]">
            Devanagari Sanskrit • 5 Strict Sections • Zero Padaccheda • English Digits
          </p>
        </div>
      </footer>
    </div>
  );
}
export default App;
