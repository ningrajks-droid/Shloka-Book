export interface TableOfContentsEntry {
  slNo: number;
  level1Name: string;
  level1Value: string | number;
  level2Name?: string;
  level2Value?: string | number;
  subheadSummary?: string;
  sectionName?: string;
  subsectionName?: string;
  topic?: string;
  whatItTeaches?: string;
  firstWords?: string;
  unitType?: string;
  isUnnumbered?: boolean;
  pageStart: number;
  pageEnd: number;
  pageRange: string;
  unitIds: string[];
}

export interface StructuralSummaryStats {
  totalBooksCount: number;
  totalChaptersCount: number;
  totalVallisCount: number;
  totalKhandasCount: number;
  totalSectionsCount: number;
  totalNumberedShlokasCount: number;
  totalUnnumberedShlokasCount: number;
  totalMantrasCount: number;
  totalShantiMantrasCount: number;
  totalGadyaCount: number;
  totalQuotationsCount: number;
  totalReviewRequiredCount: number;
}

export interface GranthaTableOfContents {
  bookTitle: string;
  isFlatVerseList: boolean;
  columns: string[];
  hasLevel1: boolean;
  level1Name: string;
  hasLevel2: boolean;
  level2Name?: string;
  hasSection: boolean;
  totalUnitsCount: number;
  totalNumberedCount: number;
  totalUnnumberedCount: number;
  totalMantraCount: number;
  totalShantiMantraCount: number;
  totalGadyaCount: number;
  totalOtherCount: number;
  pageStart: number;
  pageEnd: number;
  pageRange: string;
  summaryStats: StructuralSummaryStats;
  entries: TableOfContentsEntry[];
}

export interface SanskritUnit {
  id: string;
  projectId: string;
  docId: string;
  fileName: string;
  pageNumber: number;
  unitIndex: number;
  detectedWork: string;
  unitType?: 'SHLOKA' | 'UNNUMBERED_SHLOKA' | 'MANTRA' | 'SHANTI_MANTRA' | 'GADYA' | 'QUOTATION' | 'COLOPHON' | 'HEADING';
  structuralHierarchy: {
    level1Name: string; // e.g. "ಕಾಂಡ", "ಪರ್ವ", "ಅಧ್ಯಾಯ", "ಮಂಡಲ", "ವಲ್ಲಿ"
    level1Value: string | number;
    level2Name?: string; // e.g. "ಸರ್ಗ", "ಅಧ್ಯಾಯ", "ಸೂಕ್ತ", "ಖಂಡ"
    level2Value?: string | number;
    level3Name?: string; // e.g. "ಶ್ಲೋಕ", "ಋಕ್", "ಮಂತ್ರ", "ಗದ್ಯ ಭಾಗ"
    level3Value?: string | number;
    sectionName?: string; // e.g. "ಮಂಗಳಾಚರಣ", "ಧ್ಯಾನ ಶ್ಲೋಕ", "ಫಲಶ್ರುತಿ", "ಶಾಂತಿ ಪಾಠ"
    subsectionName?: string;
    formattedNumber: string; // e.g. "|| 1.2.14 ||"
    isUnnumbered?: boolean;
    // AI/context-aware structural understanding (internal; never rendered as Word heading styles)
    aiStructure?: {
      documentType?: string;
      structureType?: string;
      isTitle?: boolean;
      isMajorHeading?: boolean;
      isSubHeading?: boolean;
      isChapter?: boolean;
      isSection?: boolean;
      isVerse?: boolean;
      isProse?: boolean;
      isMetadata?: boolean;
      isPageNoise?: boolean;
      isOcrCorruption?: boolean;
      headingLevel?: number;
      headingText?: string;
      parentHeading?: string;
      structurePath?: string[];
      confidence?: number;
      confidenceBand?: 'HIGH' | 'MEDIUM' | 'LOW';
      reason?: string;
      source?: 'AI' | 'OFFLINE' | 'RECONCILED';
      validationStatus?: 'ACCEPTED' | 'FLAGGED' | 'REJECTED';
    };
    structurePath?: string[];
    structureContext?: {
      previousUnitId?: string;
      previousText?: string;
      nextUnitId?: string;
      nextText?: string;
      activePath?: string[];
      nearbyVerseNumbers?: string[];
    };
  };
  originalText: string;
  rawExtractedText: string;
  verifiedText: string;
  firstMeaningfulWord: string;
  
  // The 5 mandatory sections
  output?: {
    moolaShloka: string;         // 1. Devanagari Sanskrit with English digits
    kannadaTransliteration: string; // 2. Kannada script transliteration
    padartha: string;             // 3. 1. ಪದಾರ್ಥ (Continuous single paragraph)
    saralaVivarane: string;       // 4. 2. ಸರಳ ವಿವರಣೆ (Simple Kannada explanation)
    vivaradaVyakhyana: string;    // 5. 3. ವಿವರವಾದ ವ್ಯಾಖ್ಯಾನ (Detailed scholarly commentary)
    tableContent?: {
      title?: string;
      markdownTable?: string;
      headers: string[];
      rows: string[][];
      explanation?: string;
    };
    diagramContent?: {
      title: string;
      caption: string;
      altText: string;
      conceptNodes?: string[];
      svgDiagram?: string;
      imageUrl?: string;
      description: string;
    };
    pictureContent?: {
      title: string;
      caption: string;
      altText: string;
      imageUrl?: string;
      svgDiagram?: string;
      description: string;
      source?: 'ORIGINAL_EXTRACTED' | 'SCHOLARLY_GENERATED';
    };
    visualAnalysis?: {
      type: 'NONE' | 'TABLE' | 'FIGURE' | 'PICTURE' | 'MULTIPLE';
      need: boolean;
      reason: string;
      sourceSupported: boolean;
      isGenerated: boolean;
      confidence: 'HIGH' | 'MEDIUM' | 'LOW';
      placement: string;
    };
  };

  status: 'PENDING' | 'EXTRACTING' | 'VERIFYING' | 'GENERATING' | 'VALIDATING' | 'COMPLETED' | 'FAILED' | 'REVIEW_REQUIRED';
  confidence: 'HIGH' | 'MEDIUM' | 'LOW';
  validationScore: number;
  validationIssues: string[];
  
  sourceVerification?: {
    referenceSource: string;
    matchedWork: string;
    matchedVerseNum: string;
    confidenceScore: number;
    notes: string;
    diffFound: boolean;
  };

  changeLog?: {
    category: string;
    originalText: string;
    correctedText: string;
    reason: string;
    source: string;
    confidence: 'HIGH' | 'MEDIUM' | 'LOW';
    method: 'AUTO' | 'SOURCE_VERIFIED' | 'AI_VERIFIED' | 'MANUAL_REVIEW';
    timestamp: string;
  }[];

  timestamps: {
    created: string;
    updated: string;
  };
  errorMessage?: string;
}

export interface GranthaProject {
  id: string;
  name: string;
  description: string;
  createdAt: string;
  updatedAt: string;
  status: 'IDLE' | 'PROCESSING' | 'PAUSED' | 'COMPLETED' | 'ERROR';
  detectedGenre?: string;
  detectedWork?: string;
  totalDocuments: number;
  totalPages: number;
  totalUnits: number;
  completedUnits: number;
  failedUnits: number;
  reviewRequiredUnits: number;
  currentDocName?: string;
  currentPage?: number;
  currentUnitNumber?: string;
  documents?: GranthaDocument[];
  isRunning?: boolean;
}

export interface GranthaDocument {
  id: string;
  projectId: string;
  fileName: string;
  fileSize: number;
  pageCount: number;
  detectedType: 'NATIVE_PDF' | 'SCANNED_PDF' | 'MIXED_PDF' | 'TEXT_FILE';
  detectedWork: string;
  structuralType: string;
  status: 'UPLOADED' | 'EXTRACTED' | 'PARSED' | 'PROCESSED';
  uploadedAt: string;
}

export interface EngineSettings {
  geminiModel: string;
  temperature: number;
  maxOutputTokens: number;
  apiKeys: string[];
  activeKeyIndex: number;
  ocrFallback: boolean;
  sourceVerification: boolean;
  intelligentTables: boolean;
  intelligentDiagrams: boolean;
  confidenceThreshold: number; // e.g. 0.85
  batchSize: number;
  maxRetries: number;
  concurrency: number;
  outputFontDevanagari: string;
  outputFontKannada: string;
  fontSizePt: number;
}

export interface EngineStats {
  totalProjects: number;
  totalUnitsProcessed: number;
  highConfidenceCount: number;
  reviewRequiredCount: number;
  autoCorrectedCount: number;
  uptimeSeconds: number;
}

export interface ProjectLogEntry {
  id: string;
  timestamp: string;
  level: 'info' | 'success' | 'warn' | 'error';
  message: string;
  verseNumber?: string;
  stage?: string;
}
