import React, { useState, useEffect } from 'react';
import {
  X,
  Settings,
  Key,
  Plus,
  Trash2,
  CheckCircle,
  Sparkles,
  Sliders,
  Shield,
  Type,
  Zap,
} from 'lucide-react';
import { EngineSettings } from '../types';
import { safeFetchJson } from '../utils/apiClient';

interface SettingsModalProps {
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ onClose }) => {
  const [settings, setSettings] = useState<EngineSettings | null>(null);
  const [newKey, setNewKey] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const [keyStatus, setKeyStatus] = useState<{ total: number; active: number; rateLimited: number; hasAnyKey: boolean } | null>(null);
  const [testingKey, setTestingKey] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);

  const fetchKeyStatus = () => {
    safeFetchJson<{ total: number; active: number; rateLimited: number; hasAnyKey: boolean }>('/api/key-status').then(res => {
      if (res.ok && res.data) {
        setKeyStatus(res.data);
      }
    });
  };

  useEffect(() => {
    safeFetchJson<EngineSettings>('/api/settings').then(res => {
      if (res.ok && res.data) {
        setSettings(res.data);
      }
    });
    fetchKeyStatus();
  }, []);

  const handleTestKey = async () => {
    setTestingKey(true);
    setTestResult(null);
    try {
      const res = await fetch('/api/test-key', { method: 'POST' });
      const data = await res.json();
      if (res.ok && data.success) {
        setTestResult({ success: true, message: 'Gemini AI ಸಂಪರ್ಕ ಯಶಸ್ವಿಯಾಗಿದೆ! (Connected successfully)' });
      } else {
        setTestResult({ success: false, message: `ದೋಷ: ${data.error || 'ಕೀ ಮಾನ್ಯವಾಗಿಲ್ಲ'}` });
      }
    } catch (err: any) {
      setTestResult({ success: false, message: `ಸಂಪರ್ಕ ವಿಫಲವಾಗಿದೆ: ${err.message}` });
    } finally {
      setTestingKey(false);
      fetchKeyStatus();
    }
  };

  const handleAddKey = () => {
    if (!newKey.trim() || !settings) return;
    const updatedKeys = [...(settings.apiKeys || []), newKey.trim()];
    setSettings({ ...settings, apiKeys: updatedKeys });
    setNewKey('');
  };

  const handleRemoveKey = (index: number) => {
    if (!settings) return;
    const updatedKeys = settings.apiKeys.filter((_, i) => i !== index);
    setSettings({ ...settings, apiKeys: updatedKeys });
  };

  const handleSave = async () => {
    if (!settings) return;
    setIsSaving(true);
    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      });
      if (!res.ok) throw new Error('Failed to save settings');
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err: any) {
      alert(`ದೋಷ: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  if (!settings) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-2xl border border-[#E8E2D9] max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-5 bg-[#FAF7F2] border-b border-[#E8DFC9] flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#8B1E0F] text-white flex items-center justify-center">
              <Settings className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-serif font-bold text-base text-[#1F1916]">
                ಗ್ರಂಥ ಯಂತ್ರ ಸಂರಚನೆ (Grantha Engine Settings)
              </h3>
              <p className="text-xs text-[#7A695D]">
                Multi API Key Rotation • AI Parameters • Verification Policies
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-[#EADBCE] text-[#7A695D] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-xs">
          {/* 1. Multi API Key Pool & Desktop Setup */}
          <div className="p-4 rounded-xl bg-[#FAF8F5] border border-[#EAE4DC] space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-serif font-bold text-xs text-[#1F1916] flex items-center">
                <Key className="w-4 h-4 mr-1.5 text-[#8B1E0F]" />
                Gemini API Key Pool (Multi-Key Rotation & Desktop)
              </h4>
              <div className="flex items-center space-x-2">
                {keyStatus && (
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                      keyStatus.hasAnyKey
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                        : 'bg-rose-100 text-rose-800 border border-rose-300'
                    }`}
                  >
                    {keyStatus.hasAnyKey
                      ? `ಸಕ್ರಿಯ ಕೀಗಳು: ${keyStatus.total}`
                      : '⚠️ API Key ಅಲಭ್ಯ (No Key Found)'}
                  </span>
                )}
              </div>
            </div>

            {/* Desktop / Standalone Offline Notice */}
            <div className="p-3 rounded-lg bg-[#FAF0E6] border border-[#E8DFC9] text-[11px] text-[#5C4D43] leading-relaxed">
              <strong className="text-[#8B1E0F] block mb-1">💻 ಡೆಸ್ಕ್‌ಟಾಪ್ / ಸ್ಥಳೀಯ ಆವೃತ್ತಿ ಬಳಕೆದಾರರಿಗೆ:</strong>
              ಡೆಸ್ಕ್‌ಟಾಪ್‌ನಲ್ಲಿ ಚಲಾಯಿಸುವಾಗ API Key ಲಭ್ಯವಿಲ್ಲದಿದ್ದರೆ, ನಿಮ್ಮ <strong>Google Gemini API Key</strong> ಅನ್ನು ಕೆಳಗಿನ ಬಾಕ್ಸ್‌ನಲ್ಲಿ ಸೇರಿಸಿ <strong>'ಉಳಿಸಿ' (Save)</strong> ಒತ್ತಿರಿ. ಇದು ನಿಮ್ಮ ಕಂಪ್ಯೂಟರ್‌ನ SQLite ಡೇಟಾಬೇಸ್‌ನಲ್ಲಿ ಸುರಕ್ಷಿತವಾಗಿ ಉಳಿಯುತ್ತದೆ. ಅಥವಾ ನಿಮ್ಮ ಪ್ರಾಜೆಕ್ಟ್ ಫೋಲ್ಡರ್‌ನ <code>.env</code> ಕಡತದಲ್ಲಿ <code>GEMINI_API_KEY=your_key</code> ಎಂದು ನಮೂದಿಸಬಹುದು.
            </div>

            {/* Key List */}
            <div className="space-y-2">
              {(settings.apiKeys || []).map((k, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-2 rounded bg-white border border-[#DDD5C9]"
                >
                  <span className="font-mono text-xs text-[#4A3B31]">
                    Key #{idx + 1}: ••••••••••••{k.slice(-4)}
                  </span>
                  <button
                    onClick={() => handleRemoveKey(idx)}
                    className="text-rose-600 hover:text-rose-800 p-1"
                    title="Remove key"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
              {(settings.apiKeys || []).length === 0 && (
                <p className="text-[11px] text-stone-500 italic">
                  {keyStatus?.hasAnyKey
                    ? 'ಪರಿಸರ (Environment) ಕೀ ಸಕ್ರಿಯವಾಗಿದೆ (Server env GEMINI_API_KEY is active).'
                    : 'ಯಾವುದೇ ಕೀ ಕಂಡುಬಂದಿಲ್ಲ. ದಯವಿಟ್ಟು ಕೆಳಗೆ ನಿಮ್ಮ Gemini API Key ಸೇರಿಸಿ.'}
                </p>
              )}
            </div>

            {/* Add Key Input */}
            <div className="flex space-x-2">
              <input
                type="password"
                placeholder="Paste new Gemini API Key (e.g. AIzaSy...)..."
                value={newKey}
                onChange={(e) => setNewKey(e.target.value)}
                className="flex-1 p-2 rounded-lg border border-[#DDD5C9] text-xs font-mono bg-white focus:outline-none focus:border-[#8B1E0F]"
              />
              <button
                onClick={handleAddKey}
                disabled={!newKey.trim()}
                className="px-3 py-2 rounded-lg bg-[#8B1E0F] hover:bg-[#A32312] text-white text-xs font-semibold flex items-center space-x-1 disabled:opacity-50"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>ಸೇರಿಸಿ</span>
              </button>
            </div>

            {/* Test Connection Button */}
            <div className="pt-2 flex items-center justify-between">
              <button
                type="button"
                onClick={handleTestKey}
                disabled={testingKey}
                className="px-3 py-1.5 rounded-lg bg-stone-100 hover:bg-stone-200 border border-stone-300 text-stone-700 text-xs font-semibold flex items-center space-x-1.5 disabled:opacity-50"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#8B1E0F]" />
                <span>{testingKey ? 'ಪರೀಕ್ಷಿಸಲಾಗುತ್ತಿದೆ...' : 'API Key ಸಂಪರ್ಕ ಪರೀಕ್ಷಿಸಿ (Test Key)'}</span>
              </button>
              {testResult && (
                <span
                  className={`text-[11px] font-semibold ${
                    testResult.success ? 'text-emerald-700' : 'text-rose-700'
                  }`}
                >
                  {testResult.message}
                </span>
              )}
            </div>
          </div>

          {/* 2. AI Model & Editorial Parameters */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-[#1F1916] mb-1">
                AI ಮಾದರಿ (Model):
              </label>
              <select
                value={settings.geminiModel}
                onChange={(e) => setSettings({ ...settings, geminiModel: e.target.value })}
                className="w-full p-2 rounded-lg border border-[#DDD5C9] text-xs bg-[#FAF8F5] focus:outline-none focus:border-[#8B1E0F]"
              >
                <option value="gemini-3.8-flash">gemini-3.8-flash (Gemini 3.8 Flash - Recommended & High Throughput)</option>
                <option value="gemini-3.1-flash-lite">gemini-3.1-flash-lite (Flash Lite - Ultra-Fast & High Availability)</option>
                <option value="gemini-flash-latest">gemini-flash-latest (Gemini Flash Latest)</option>
                <option value="gemini-3.7-flash">gemini-3.7-flash (Gemini 3.7 Flash)</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-[#1F1916] mb-1">
                ತಾಪಮಾನ (Temperature): {settings.temperature}
              </label>
              <input
                type="range"
                min="0.0"
                max="0.5"
                step="0.05"
                value={settings.temperature}
                onChange={(e) => setSettings({ ...settings, temperature: parseFloat(e.target.value) })}
                className="w-full accent-[#8B1E0F]"
              />
              <span className="text-[10px] text-[#7A695D]">
                ಕಟ್ಟುನಿಟ್ಟಾದ ವಿದ್ವತ್ಪೂರ್ಣ ನಿಖರತೆಗೆ 0.1 ಶಿಫಾರಸು ಮಾಡಲಾಗಿದೆ
              </span>
            </div>
          </div>

          {/* 2.5 High-Speed Concurrency & Batch Workers */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-[#FFFBF7] to-[#FAF4ED] border border-[#E8DFC9] space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Zap className="w-4 h-4 text-[#8B1E0F]" />
                <h4 className="font-serif font-bold text-xs text-[#1F1916]">
                  ಸಮಾನಾಂತರ ಬ್ಯಾಚ್ ವರ್ಕರ್ಸ್ & ವೇಗ ವರ್ಧನೆ (High-Speed Batch Engine)
                </h4>
              </div>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#8B1E0F]/10 text-[#8B1E0F] border border-[#8B1E0F]/20">
                {settings.concurrency || 3}x ಸಮಾನಾಂತರ ವರ್ಕರ್‌ಗಳು
              </span>
            </div>

            <p className="text-[11px] text-[#5C4D43] leading-relaxed">
              ಏಕಕಾಲದಲ್ಲಿ ಹಲವು ಶ್ಲೋಕಗಳನ್ನು ಸಮಾನಾಂತರವಾಗಿ ಸಂಸ್ಕರಿಸಿ <strong>1 ನಿಮಿಷದಲ್ಲಿ 8 ರಿಂದ 15+ ಶ್ಲೋಕಗಳನ್ನು</strong> ಅತಿ ವೇಗವಾಗಿ ರಚಿಸುತ್ತದೆ. ನಿಮ್ಮ Key Pool ನಲ್ಲಿ ಹಲವು ಕೀಗಳಿದ್ದರೆ ಅವುಗಳ ನಡುವೆ ಸ್ವಯಂಚಾಲಿತ ಲೋಡ್ ಬ್ಯಾಲೆನ್ಸಿಂಗ್ ನಡೆಯುತ್ತದೆ.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
              {[
                { val: 1, label: '1x ಏಕಮುಖ', desc: '~3-5 ಶ್ಲೋಕ/ನಿ' },
                { val: 2, label: '2x ವೇಗ', desc: '~6-8 ಶ್ಲೋಕ/ನಿ' },
                { val: 3, label: '3x ಹೈ-ಸ್ಪೀಡ್', desc: '~8-12 ಶ್ಲೋಕ/ನಿ (ಶಿಫಾರಸು)' },
                { val: 4, label: '4x ಸೂಪರ್-ಸ್ಪೀಡ್', desc: '~12-16+ ಶ್ಲೋಕ/ನಿ' },
              ].map((lvl) => {
                const isSelected = (settings.concurrency || 3) === lvl.val;
                return (
                  <button
                    key={lvl.val}
                    type="button"
                    onClick={() => setSettings({ ...settings, concurrency: lvl.val })}
                    className={`p-2 rounded-lg text-left transition-all border ${
                      isSelected
                        ? 'bg-[#8B1E0F] text-white border-[#8B1E0F] shadow-sm'
                        : 'bg-white text-[#4A3B31] border-[#DDD5C9] hover:bg-[#FAF0E6]'
                    }`}
                  >
                    <div className="font-bold text-xs">{lvl.label}</div>
                    <div className={`text-[10px] ${isSelected ? 'text-amber-200' : 'text-[#7A695D]'}`}>
                      {lvl.desc}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 3. Feature Toggles */}
          <div className="p-4 rounded-xl bg-white border border-[#EAE4DC] space-y-3">
            <h4 className="font-serif font-bold text-xs text-[#1F1916]">
              ಕಾರ್ಯನೀತಿ ನಿಯಮಗಳು (Policy & Quality Gates)
            </h4>

            <label className="flex items-center justify-between cursor-pointer">
              <div>
                <span className="font-semibold text-[#1F1916]">
                  ಸಂಸ್ಕೃತ ಆಕರ ದೃಢೀಕರಣ (Sanskrit Canonical Source Verification)
                </span>
                <p className="text-[10px] text-[#7A695D]">
                  SanskritDocuments.org ಹಾಗೂ ಅಧಿಕೃತ ಶಾಸ್ತ್ರೀಯ ಕೋಶಗಳೊಂದಿಗೆ ಪರಿಶೀಲನೆ
                </p>
              </div>
              <input
                type="checkbox"
                checked={settings.sourceVerification}
                onChange={(e) => setSettings({ ...settings, sourceVerification: e.target.checked })}
                className="w-4 h-4 accent-[#8B1E0F]"
              />
            </label>

            <label className="flex items-center justify-between cursor-pointer">
              <div>
                <span className="font-semibold text-[#1F1916]">
                  ಬುದ್ಧಿವಂತ ಕೋಷ್ಟಕ ರಚನೆ (Intelligent Table Generation)
                </span>
                <p className="text-[10px] text-[#7A695D]">
                  ಅಗತ್ಯವಿದ್ದಾಗ ಮಾತ್ರ ವರ್ಗೀಕರಣ/ಹೋಲಿಕೆ ಕೋಷ್ಟಕ ರಚನೆ (1. ಪದಾರ್ಥದಲ್ಲಿ ನಿಷೇಧಿಸಲಾಗಿದೆ)
                </p>
              </div>
              <input
                type="checkbox"
                checked={settings.intelligentTables}
                onChange={(e) => setSettings({ ...settings, intelligentTables: e.target.checked })}
                className="w-4 h-4 accent-[#8B1E0F]"
              />
            </label>

            <label className="flex items-center justify-between cursor-pointer">
              <div>
                <span className="font-semibold text-[#1F1916]">
                  ಪರಿಕಲ್ಪನಾತ್ಮಕ ರೇಖಾಚಿತ್ರ ರಚನೆ (Intelligent SVG Diagrams)
                </span>
                <p className="text-[10px] text-[#7A695D]">
                  ತತ್ವ ಶ್ರೇಣಿ ಅಥವಾ ಕಾಸ್ಮಾಲಾಜಿಕಲ್ ರಚನೆಗೆ ಉಪಯುಕ್ತ ರೇಖಾಚಿತ್ರ ರಚನೆ
                </p>
              </div>
              <input
                type="checkbox"
                checked={settings.intelligentDiagrams}
                onChange={(e) => setSettings({ ...settings, intelligentDiagrams: e.target.checked })}
                className="w-4 h-4 accent-[#8B1E0F]"
              />
            </label>

            <label className="flex items-center justify-between cursor-pointer">
              <div>
                <span className="font-semibold text-[#1F1916]">
                  OCR ಆಪತ್ಕಾಲೀನ ಪರ್ಯಾಯ (OCR Fallback Mode)
                </span>
                <p className="text-[10px] text-[#7A695D]">
                  ನೇರ ಪಠ್ಯ ಅಲಭ್ಯವಿದ್ದಾಗ ಮಾತ್ರ OCR ಬಳಸಿ (ಡೀಫಾಲ್ಟ್: OFF)
                </p>
              </div>
              <input
                type="checkbox"
                checked={settings.ocrFallback}
                onChange={(e) => setSettings({ ...settings, ocrFallback: e.target.checked })}
                className="w-4 h-4 accent-[#8B1E0F]"
              />
            </label>
          </div>

          {/* 4. Output Formatting & Fonts */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-[#1F1916] mb-1">
                ಕನ್ನಡ ಫಾಂಟ್ (Kannada Font in DOCX):
              </label>
              <input
                type="text"
                value={settings.outputFontKannada}
                onChange={(e) => setSettings({ ...settings, outputFontKannada: e.target.value })}
                className="w-full p-2 rounded-lg border border-[#DDD5C9] text-xs bg-white"
              />
            </div>
            <div>
              <label className="block font-bold text-[#1F1916] mb-1">
                ದೇವನಾಗರಿ ಫಾಂಟ್ (Devanagari Font in DOCX):
              </label>
              <input
                type="text"
                value={settings.outputFontDevanagari}
                onChange={(e) => setSettings({ ...settings, outputFontDevanagari: e.target.value })}
                className="w-full p-2 rounded-lg border border-[#DDD5C9] text-xs bg-white"
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#FAF7F2] border-t border-[#E8DFC9] flex items-center justify-between">
          <div>
            {saveSuccess && (
              <span className="text-xs text-emerald-700 font-semibold flex items-center">
                <CheckCircle className="w-4 h-4 mr-1" />
                ಸಂರಚನೆಗಳನ್ನು ಯಶಸ್ವಿಯಾಗಿ ಉಳಿಸಲಾಗಿದೆ!
              </span>
            )}
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg border border-[#DDD5C9] hover:bg-[#EADBCE] text-xs font-semibold text-[#5A4B41] transition-colors"
            >
              ಮುಚ್ಚಿ (Close)
            </button>
            <button
              id="btn-save-settings"
              onClick={handleSave}
              disabled={isSaving}
              className="px-5 py-2 rounded-lg bg-[#8B1E0F] hover:bg-[#A32312] text-white text-xs font-semibold shadow-sm transition-colors"
            >
              {isSaving ? 'ಉಳಿಸಲಾಗುತ್ತಿದೆ...' : 'ಉಳಿಸಿ (Save Changes)'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
