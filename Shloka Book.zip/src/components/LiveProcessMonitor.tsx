import React, { useState, useEffect, useRef } from 'react';
import {
  Activity,
  Play,
  Pause,
  Square,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Terminal,
  Layers,
  Sparkles,
  ChevronDown,
  ChevronUp,
  Download,
  ArrowRight,
  Zap,
  BookOpen,
} from 'lucide-react';
import { GranthaProject, SanskritUnit, ProjectLogEntry } from '../types';
import { safeFetchJson } from '../utils/apiClient';

interface LiveProcessMonitorProps {
  project: GranthaProject;
  units: SanskritUnit[];
  isProcessing: boolean;
  onStart: () => void;
  onPause: () => void;
  onCancel: () => void;
  onOpenExport: () => void;
  onSelectUnit?: (unitId: string) => void;
}

// Helper to parse incomplete JSON stream in real time into scholarly sections
function parsePartialStreamJson(raw: string) {
  if (!raw) return null;
  const extractField = (fieldName: string) => {
    const regex = new RegExp(`"${fieldName}"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)`, 's');
    const m = raw.match(regex);
    if (m && m[1]) {
      return m[1]
        .replace(/\\n/g, '\n')
        .replace(/\\"/g, '"')
        .replace(/\\\\/g, '\\')
        .replace(/\\t/g, '\t');
    }
    return '';
  };

  const moolaShloka = extractField('moolaShloka');
  const kannadaTransliteration = extractField('kannadaTransliteration');
  const padartha = extractField('padartha');
  const saralaVivarane = extractField('saralaVivarane');
  const vivaradaVyakhyana = extractField('vivaradaVyakhyana');

  const hasAny = Boolean(moolaShloka || kannadaTransliteration || padartha || saralaVivarane || vivaradaVyakhyana);
  if (!hasAny) return null;
  return {
    moolaShloka,
    kannadaTransliteration,
    padartha,
    saralaVivarane,
    vivaradaVyakhyana,
  };
}

export const LiveProcessMonitor: React.FC<LiveProcessMonitorProps> = ({
  project,
  units,
  isProcessing,
  onStart,
  onPause,
  onCancel,
  onOpenExport,
  onSelectUnit,
}) => {
  const [logs, setLogs] = useState<ProjectLogEntry[]>([]);
  const [showLogs, setShowLogs] = useState(true);
  const [autoScrollLogs, setAutoScrollLogs] = useState(true);
  const logsContainerRef = useRef<HTMLDivElement>(null);

  // Real-time live typewriter stream state
  const [liveStreamText, setLiveStreamText] = useState<string>('');
  const [liveStreamVerse, setLiveStreamVerse] = useState<string>('');
  const [liveStreamCharCount, setLiveStreamCharCount] = useState<number>(0);
  const [showLiveStream, setShowLiveStream] = useState<boolean>(true);
  const [autoScrollLiveStream, setAutoScrollLiveStream] = useState<boolean>(true);
  const [streamViewMode, setStreamViewMode] = useState<'formatted' | 'raw'>('formatted');
  const streamContainerRef = useRef<HTMLDivElement>(null);
  const eventSourceRef = useRef<EventSource | null>(null);

  const total = units.length;
  const completed = units.filter((u) => u.status === 'COMPLETED').length;
  const reviewReq = units.filter((u) => u.status === 'REVIEW_REQUIRED').length;
  const failed = units.filter((u) => u.status === 'FAILED').length;
  const percentComplete = total > 0 ? Math.round(((completed + reviewReq) / total) * 100) : 0;

  const activeUnit =
    units.find((u) => u.status === 'GENERATING' || u.status === 'VERIFYING' || u.status === 'VALIDATING') ||
    (isProcessing && units.find((u) => u.status === 'PENDING')) ||
    null;

  // Auto-open live stream when processing starts
  useEffect(() => {
    if (isProcessing) {
      setShowLiveStream(true);
    }
  }, [isProcessing]);

  // Initial state fetch so live monitor is never blank on mount or tab return
  useEffect(() => {
    if (!project?.id) return;
    const fetchLiveState = async () => {
      try {
        const res = await safeFetchJson<any>(`/api/projects/${project.id}/live-state`);
        if (res.ok && res.data) {
          if (res.data.accumulatedText) {
            setLiveStreamText(res.data.accumulatedText);
            setLiveStreamCharCount(res.data.charCount || res.data.accumulatedText.length);
          }
          if (res.data.currentVerse) {
            setLiveStreamVerse(res.data.currentVerse);
          }
        }
      } catch {
        // Ignore
      }
    };
    fetchLiveState();
  }, [project?.id]);

  // Fetch standard logs periodically
  const fetchLogs = React.useCallback(async () => {
    if (!project?.id) return;
    try {
      const res = await safeFetchJson<ProjectLogEntry[]>(`/api/projects/${project.id}/logs`);
      if (res.ok && res.data) {
        setLogs(res.data);
      }
    } catch {
      // Ignore
    }
  }, [project?.id]);

  useEffect(() => {
    fetchLogs();
    const interval = setInterval(fetchLogs, isProcessing ? 2000 : 8000);
    return () => {
      clearInterval(interval);
    };
  }, [fetchLogs, isProcessing]);

  // Connect to SSE stream for real-time live letter-by-letter / token-by-token generation
  useEffect(() => {
    if (!project?.id) return;

    if (eventSourceRef.current) {
      eventSourceRef.current.close();
      eventSourceRef.current = null;
    }

    // Only establish live streaming connection when processing is actively running
    if (!isProcessing) {
      return;
    }

    const es = new EventSource(`/api/projects/${project.id}/live-stream`);
    eventSourceRef.current = es;

    es.addEventListener('state', (e: any) => {
      try {
        const data = JSON.parse(e.data);
        if (data.accumulatedText) {
          setLiveStreamText(data.accumulatedText);
          setLiveStreamCharCount(data.charCount || data.accumulatedText.length);
        }
        if (data.currentVerse) {
          setLiveStreamVerse(data.currentVerse);
        }
      } catch {
        // Ignore
      }
    });

    es.addEventListener('unit_start', (e: any) => {
      try {
        const data = JSON.parse(e.data);
        setLiveStreamText('');
        setLiveStreamCharCount(0);
        if (data.verseNumber) {
          setLiveStreamVerse(data.verseNumber);
        }
      } catch {
        // Ignore
      }
    });

    es.addEventListener('chunk', (e: any) => {
      try {
        const data = JSON.parse(e.data);
        if (data.fullTextSoFar) {
          setLiveStreamText(data.fullTextSoFar);
          setLiveStreamCharCount(data.charCount || data.fullTextSoFar.length);
        } else if (data.chunk) {
          setLiveStreamText((prev) => {
            const next = prev + data.chunk;
            setLiveStreamCharCount(next.length);
            return next;
          });
        }
        if (data.verseNumber) {
          setLiveStreamVerse(data.verseNumber);
        }
      } catch {
        // Ignore
      }
    });

    es.addEventListener('unit_complete', (e: any) => {
      fetchLogs();
    });

    es.addEventListener('unit_failed', (e: any) => {
      fetchLogs();
    });

    return () => {
      es.close();
      eventSourceRef.current = null;
    };
  }, [project?.id, isProcessing]);

  useEffect(() => {
    if (autoScrollLogs && logsContainerRef.current) {
      logsContainerRef.current.scrollTop = logsContainerRef.current.scrollHeight;
    }
  }, [logs, autoScrollLogs]);

  // Safe container-only scrolling - NEVER scroll whole window/page
  useEffect(() => {
    if (autoScrollLiveStream && streamContainerRef.current) {
      streamContainerRef.current.scrollTop = streamContainerRef.current.scrollHeight;
    }
  }, [liveStreamText, autoScrollLiveStream]);

  const hasPendingOrFailed = units.some(
    (u) => u.status === 'PENDING' || u.status === 'FAILED' || u.status === 'VERIFYING' || u.status === 'GENERATING'
  );
  const isExtractDone = total > 0;
  const isVerifyActive = isProcessing && activeUnit?.status === 'VERIFYING';
  const isGenActive = isProcessing && (activeUnit?.status === 'GENERATING' || !activeUnit?.status || activeUnit?.status === 'PENDING');
  const isValActive = isProcessing && activeUnit?.status === 'VALIDATING';
  const isAllDone = total > 0 && completed + reviewReq >= total && !isProcessing;

  return (
    <div className="bg-[#FFFFFF] border border-[#E8E2D9] rounded-xl shadow-sm overflow-hidden mb-6 transition-all">
      {/* Header Bar */}
      <div className="bg-[#FAF7F2] px-5 py-3.5 border-b border-[#E8DFC9] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-2.5">
          <div className="p-1.5 rounded-lg bg-[#8B1E0F]/10 text-[#8B1E0F]">
            <Activity className={`w-5 h-5 ${isProcessing ? 'animate-pulse' : ''}`} />
          </div>
          <div>
            <h2 className="font-serif text-base font-bold text-[#1F1916] flex items-center gap-2 flex-wrap">
              <span>ಲೈವ್ ಪ್ರಕ್ರಿಯೆ & ಹಂತಗಳ ಪರಿವೀಕ್ಷಕ (Live Process Monitor)</span>
              {isProcessing && (
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-amber-100 text-amber-900 border border-amber-300 animate-pulse">
                  <RefreshCw className="w-3 h-3 mr-1 animate-spin" />
                  ಸಂಸ್ಕರಣೆ ಚಾಲನೆಯಲ್ಲಿದೆ
                </span>
              )}
              {project?.status === 'PAUSED' && !isProcessing && (
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-amber-50 text-amber-800 border border-amber-300">
                  <Pause className="w-3 h-3 mr-1 text-amber-600" />
                  ವಿರಾಮಗೊಳಿಸಲಾಗಿದೆ (Paused)
                </span>
              )}
              {isAllDone && (
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-100 text-emerald-900 border border-emerald-300">
                  <CheckCircle2 className="w-3 h-3 mr-1" />
                  ಸಂಪೂರ್ಣಗೊಂಡಿದೆ
                </span>
              )}
              {!isProcessing && !isAllDone && total > 0 && project?.status !== 'PAUSED' && (
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium bg-stone-100 text-stone-700 border border-stone-300">
                  <Clock className="w-3 h-3 mr-1" />
                  ಸಂಸ್ಕರಣೆಗೆ ಸಿದ್ಧವಾಗಿದೆ
                </span>
              )}
            </h2>
            <p className="text-xs text-[#736357] font-kannada">
              {isProcessing
                ? 'ಸಂಸ್ಕೃತ ಮೂಲ ಪಠ್ಯ ಪರಿಶೀಲನೆ, ಕನ್ನಡ ಲಿಪ್ಯಂತರ, ಪದಾರ್ಥ ಹಾಗೂ ವಿದ್ವತ್ ವ್ಯಾಖ್ಯಾನ ರಚನೆ ಲೈವ್ ಆಗಿ ನಡೆಯುತ್ತಿದೆ.'
                : total > 0
                ? 'ಕಡತದ ಶ್ಲೋಕಗಳು ಸಿದ್ಧವಾಗಿವೆ. ಕೆಳಗಿನ "ಸಂಸ್ಕರಣೆ ಆರಂಭಿಸಿ" ಅಥವಾ "ಮುಂದುವರಿಸಿ" ಬಟನ್ ಒತ್ತಿ ಪ್ರಕ್ರಿಯೆಯನ್ನು ಪ್ರಾರಂಭಿಸಿ.'
                : 'PDF ಕಡತವನ್ನು ಅಪ್ಲೋಡ್ ಮಾಡಿದ ತಕ್ಷಣ ಶ್ಲೋಕಗಳ ಪಟ್ಟಿ ಮತ್ತು ಲೈವ್ ಪ್ರಕ್ರಿಯೆ ಇಲ್ಲಿ ಕಾಣಿಸುತ್ತದೆ.'}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center space-x-2 flex-wrap gap-y-1">
          {!isProcessing ? (
            <button
              id="btn-monitor-start"
              onClick={onStart}
              disabled={total === 0}
              className="flex items-center space-x-2 px-4 py-2 rounded-lg bg-[#8B1E0F] hover:bg-[#A32312] text-white font-medium text-xs shadow-sm transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 fill-white" />
              <span>
                {completed > 0 && hasPendingOrFailed
                  ? 'ಮುಂದುವರಿಸಿ (Resume)'
                  : !hasPendingOrFailed && total > 0
                  ? 'ಮರು-ಸಂಸ್ಕರಣೆ (Reprocess)'
                  : 'ಸಂಸ್ಕರಣೆ ಆರಂಭಿಸಿ (Start)'}
              </span>
            </button>
          ) : (
            <>
              <button
                id="btn-monitor-pause"
                onClick={onPause}
                className="flex items-center space-x-1.5 px-3 py-2 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-medium text-xs transition-colors cursor-pointer"
              >
                <Pause className="w-3.5 h-3.5" />
                <span>ವಿರಾಮ (Pause)</span>
              </button>
              <button
                id="btn-monitor-cancel"
                onClick={onCancel}
                className="flex items-center space-x-1.5 px-3 py-2 rounded-lg bg-stone-700 hover:bg-stone-800 text-white font-medium text-xs transition-colors cursor-pointer"
              >
                <Square className="w-3.5 h-3.5" />
                <span>ರದ್ದು (Cancel)</span>
              </button>
            </>
          )}

          {isAllDone && (
            <button
              id="btn-monitor-export"
              onClick={onOpenExport}
              className="flex items-center space-x-1.5 px-3.5 py-2 rounded-lg bg-[#2E231D] hover:bg-[#42332A] text-white font-medium text-xs transition-colors shadow-sm"
            >
              <Download className="w-3.5 h-3.5 text-amber-300" />
              <span>ರಫ್ತು ಮಾಡಿ (Export)</span>
            </button>
          )}

          <button
            onClick={() => setShowLiveStream(!showLiveStream)}
            className={`flex items-center space-x-1 px-2.5 py-2 rounded-lg border text-xs transition-colors ${
              showLiveStream
                ? 'bg-amber-50 border-amber-400 text-amber-900 font-bold'
                : 'border-[#DDD5C9] hover:bg-[#F4EDE5] text-[#634E42]'
            }`}
            title="ಲೈವ್ ಅಕ್ಷರ ಸ್ಟ್ರೀಮ್ ವೀಕ್ಷಣೆ / ಮುಚ್ಚಿ"
          >
            <Zap className={`w-3.5 h-3.5 ${isProcessing ? 'text-amber-600 animate-pulse' : 'text-[#7A695D]'}`} />
            <span>ಲೈವ್ ಸ್ಟ್ರೀಮ್ {isProcessing && liveStreamText ? '🔴' : ''}</span>
            {showLiveStream ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>

          <button
            onClick={() => setShowLogs(!showLogs)}
            className="flex items-center space-x-1 px-2.5 py-2 rounded-lg border border-[#DDD5C9] hover:bg-[#F4EDE5] text-[#634E42] text-xs transition-colors"
            title="ಚಟುವಟಿಕೆ ಲಾಗ್ ವೀಕ್ಷಣೆ / ಮುಚ್ಚಿ"
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>ಲಾಗ್ ({logs.length})</span>
            {showLogs ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      <div className="p-5 space-y-5">
        {/* Next Step Workflow Banner */}
        {!isProcessing && total > 0 && completed === 0 && (
          <div className="p-4 rounded-xl bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-2xs">
            <div className="flex items-start space-x-3">
              <div className="p-2 rounded-lg bg-amber-500 text-white mt-0.5">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-amber-950 font-serif">
                  ಕಡತ ಅಪ್ಲೋಡ್ ಪೂರ್ಣಗೊಂಡಿದೆ! ಮುಂದಿನ ಹಂತ:
                </h4>
                <p className="text-xs text-amber-900 mt-1 font-kannada leading-relaxed">
                  ನಿಮ್ಮ PDF ನಿಂದ ಒಟ್ಟು <strong className="font-bold text-[#8B1E0F]">{total} ಸಂಸ್ಕೃತ ಶ್ಲೋಕಗಳನ್ನು</strong> ಗುರುತಿಸಲಾಗಿದೆ.
                  ಈಗ <strong>"ವಿದ್ವತ್ ಸಂಸ್ಕರಣೆ ಆರಂಭಿಸಿ"</strong> ಕ್ಲಿಕ್ ಮಾಡಿ ಕನ್ನಡ ಲಿಪ್ಯಂತರ, ಪ್ರತಿಪದಾರ್ಥ, ಸರಳ ವಿವರಣೆ ಹಾಗೂ ವಿದ್ವತ್ ವ್ಯಾಖ್ಯಾನಗಳನ್ನು ಪಡೆಯಿರಿ.
                </p>
              </div>
            </div>
            <button
              onClick={onStart}
              className="flex items-center justify-center space-x-2 px-5 py-2.5 rounded-lg bg-[#8B1E0F] hover:bg-[#A32312] text-white font-bold text-sm shadow-md transition-all whitespace-nowrap transform hover:scale-[1.02] active:scale-[0.98]"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>ವಿದ್ವತ್ ಸಂಸ್ಕರಣೆ ಆರಂಭಿಸಿ (Start Now)</span>
            </button>
          </div>
        )}

        {/* 6-Stage Visual Pipeline */}
        <div>
          <h4 className="text-xs font-bold text-[#736357] uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-[#8B1E0F]" />
            <span>ಶಾಸ್ತ್ರೀಯ ಸಂಸ್ಕರಣಾ ಹಂತಗಳು (Scholarly Pipeline Stages)</span>
          </h4>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2.5">
            <div className={`p-3 rounded-lg border text-left transition-all ${isExtractDone ? 'bg-emerald-50/70 border-emerald-300 text-emerald-950' : 'bg-stone-50 border-stone-200 text-stone-500'}`}>
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] font-mono font-bold">ಹಂತ ೧</span>
                {isExtractDone ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Clock className="w-3.5 h-3.5 text-stone-400" />}
              </div>
              <p className="text-xs font-bold">PDF / OCR ಪಠ್ಯ</p>
              <p className="text-[10px] opacity-80 mt-0.5">{total > 0 ? `${total} ಶ್ಲೋಕಗಳು` : 'ಕಡತ ಅಪ್ಲೋಡ್'}</p>
            </div>

            <div className={`p-3 rounded-lg border text-left transition-all ${isVerifyActive ? 'bg-amber-50 border-amber-400 text-amber-950 ring-1 ring-amber-400 animate-pulse' : completed > 0 ? 'bg-emerald-50/70 border-emerald-300 text-emerald-950' : 'bg-stone-50 border-stone-200 text-stone-500'}`}>
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] font-mono font-bold">ಹಂತ ೨</span>
                {isVerifyActive ? <RefreshCw className="w-3.5 h-3.5 text-amber-600 animate-spin" /> : completed > 0 ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Clock className="w-3.5 h-3.5 text-stone-400" />}
              </div>
              <p className="text-xs font-bold">ಮೂಲ ಪರಿಶೀಲನೆ</p>
              <p className="text-[10px] opacity-80 mt-0.5">ಆಕರ & ಶಾಸ್ತ್ರ ಹೋಲಿಕೆ</p>
            </div>

            <div className={`p-3 rounded-lg border text-left transition-all ${isGenActive ? 'bg-amber-50 border-amber-400 text-amber-950 ring-1 ring-amber-400 animate-pulse' : completed > 0 ? 'bg-emerald-50/70 border-emerald-300 text-emerald-950' : 'bg-stone-50 border-stone-200 text-stone-500'}`}>
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] font-mono font-bold">ಹಂತ ೩</span>
                {isGenActive ? <RefreshCw className="w-3.5 h-3.5 text-amber-600 animate-spin" /> : completed > 0 ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Clock className="w-3.5 h-3.5 text-stone-400" />}
              </div>
              <p className="text-xs font-bold">ಕನ್ನಡ ಲಿಪ್ಯಂತರ</p>
              <p className="text-[10px] opacity-80 mt-0.5">ಶುದ್ಧ ISO/ಶಾಸ್ತ್ರೀಯ</p>
            </div>

            <div className={`p-3 rounded-lg border text-left transition-all ${isGenActive ? 'bg-amber-50 border-amber-400 text-amber-950 ring-1 ring-amber-400 animate-pulse' : completed > 0 ? 'bg-emerald-50/70 border-emerald-300 text-emerald-950' : 'bg-stone-50 border-stone-200 text-stone-500'}`}>
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] font-mono font-bold">ಹಂತ ೪</span>
                {isGenActive ? <RefreshCw className="w-3.5 h-3.5 text-amber-600 animate-spin" /> : completed > 0 ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Clock className="w-3.5 h-3.5 text-stone-400" />}
              </div>
              <p className="text-xs font-bold">ಅಖಂಡ ಪದಾರ್ಥ</p>
              <p className="text-[10px] opacity-80 mt-0.5">ಪದವಿಭಾಗ & ಅರ್ಥಗಳು</p>
            </div>

            <div className={`p-3 rounded-lg border text-left transition-all ${isGenActive ? 'bg-amber-50 border-amber-400 text-amber-950 ring-1 ring-amber-400 animate-pulse' : completed > 0 ? 'bg-emerald-50/70 border-emerald-300 text-emerald-950' : 'bg-stone-50 border-stone-200 text-stone-500'}`}>
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] font-mono font-bold">ಹಂತ ೫</span>
                {isGenActive ? <RefreshCw className="w-3.5 h-3.5 text-amber-600 animate-spin" /> : completed > 0 ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Clock className="w-3.5 h-3.5 text-stone-400" />}
              </div>
              <p className="text-xs font-bold">ವಿದ್ವತ್ ವ್ಯಾಖ್ಯಾನ</p>
              <p className="text-[10px] opacity-80 mt-0.5">ಭಾಷ್ಯ & ಶಾಸ್ತ್ರ ಪ್ರಮಾಣ</p>
            </div>

            <div className={`p-3 rounded-lg border text-left transition-all ${isValActive ? 'bg-amber-50 border-amber-400 text-amber-950 ring-1 ring-amber-400 animate-pulse' : completed > 0 ? 'bg-emerald-50/70 border-emerald-300 text-emerald-950' : 'bg-stone-50 border-stone-200 text-stone-500'}`}>
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] font-mono font-bold">ಹಂತ ೬</span>
                {isValActive ? <RefreshCw className="w-3.5 h-3.5 text-amber-600 animate-spin" /> : completed > 0 ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Clock className="w-3.5 h-3.5 text-stone-400" />}
              </div>
              <p className="text-xs font-bold">ನಿಖರತೆ ಪರೀಕ್ಷೆ</p>
              <p className="text-[10px] opacity-80 mt-0.5">12-ಹಂತದ ತಪಾಸಣೆ</p>
            </div>
          </div>
        </div>

        {/* Live Active Processing Card & Progress */}
        {isProcessing && activeUnit && (
          <div className="p-4 rounded-xl bg-[#FAF5EE] border border-[#DECFBE] space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center space-x-2.5">
                <div className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-ping" />
                <span className="text-xs font-bold text-[#8B1E0F] uppercase tracking-wider">
                  ಪ್ರಸ್ತುತ ಪರಿಷ್ಕರಣೆ (Active Unit)
                </span>
                <span className="px-2 py-0.5 rounded bg-[#EADECE] text-[#4A382C] font-mono text-xs font-bold">
                  ಶ್ಲೋಕ {activeUnit.structuralHierarchy?.formattedNumber || `#${activeUnit.unitIndex}`}
                </span>
                <span className="text-xs text-[#7A695D]">
                  • ಪುಟ {activeUnit.pageNumber} ({activeUnit.fileName})
                </span>
              </div>
              {onSelectUnit && (
                <button
                  onClick={() => onSelectUnit(activeUnit.id)}
                  className="text-xs text-[#8B1E0F] hover:underline flex items-center font-medium self-start sm:self-auto"
                >
                  <span>ಸಂಪಾದಕದಲ್ಲಿ ವೀಕ್ಷಿಸಿ</span>
                  <ArrowRight className="w-3.5 h-3.5 ml-1" />
                </button>
              )}
            </div>

            <div className="p-3 rounded-lg bg-white border border-[#EAE4DC] font-devanagari text-sm text-[#2A231E] leading-relaxed shadow-2xs">
              {activeUnit.originalText}
            </div>

            <div className="flex items-center justify-between text-xs text-[#634E42]">
              <span className="flex items-center">
                <RefreshCw className="w-3 h-3 mr-1.5 text-[#8B1E0F] animate-spin" />
                {activeUnit.status === 'VERIFYING'
                  ? 'ಮೂಲ ಸಂಸ್ಕೃತ ಗ್ರಂಥಗಳೊಂದಿಗೆ ತಾಳೆ ನೋಡಲಾಗುತ್ತಿದೆ...'
                  : activeUnit.status === 'VALIDATING'
                  ? 'ವ್ಯಾಕರಣ, ಪದಾರ್ಥ ಹಾಗೂ ಲಿಪ್ಯಂತರ ನಿಖರತೆ ಪರೀಕ್ಷಿಸಲಾಗುತ್ತಿದೆ...'
                  : 'ಕನ್ನಡ ಲಿಪ್ಯಂತರ, ಪ್ರತಿಪದಾರ್ಥ, ಸರಳ ವಿವರಣೆ ಹಾಗೂ ವಿದ್ವತ್ ವ್ಯಾಖ್ಯಾನ ರಚಿಸಲಾಗುತ್ತಿದೆ...'}
              </span>
              <span className="font-mono text-[11px] font-semibold text-[#8B1E0F]">
                ಪ್ರಗತಿ: {completed} / {total} ({percentComplete}%)
              </span>
            </div>
          </div>
        )}

        {/* Real-time Live Letter Stream / Typewriter Box (Only shown when toggled on by user) */}
        {showLiveStream && (
          <div className="rounded-xl border border-amber-400/80 bg-[#14110F] text-[#F3EBE1] overflow-hidden shadow-lg font-mono text-xs animate-in fade-in duration-200">
            <div className="px-4 py-2.5 bg-[#241D19] border-b border-[#3B2F28] flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center space-x-2.5">
                <div className="p-1 rounded bg-amber-500/20 text-amber-400">
                  <Zap className={`w-3.5 h-3.5 ${isProcessing ? 'animate-bounce' : ''}`} />
                </div>
                <div className="flex items-center space-x-2">
                  <span className="font-bold text-amber-300 font-sans text-xs flex items-center gap-1.5">
                    <span>{isProcessing ? '🔴 ಲೈವ್ ಅಕ್ಷರ ಸ್ಟ್ರೀಮ್ (Live Typewriter Stream)' : '⏸️ ಲೈವ್ ಅಕ್ಷರ ಸ್ಟ್ರೀಮ್ (Live Stream)'}</span>
                    {isProcessing && (
                      <span className="px-1.5 py-0.2 text-[9px] bg-amber-400 text-black font-bold rounded-full animate-pulse">
                        LIVE
                      </span>
                    )}
                    {project.status === 'PAUSED' && (
                      <span className="px-1.5 py-0.2 text-[9px] bg-amber-600 text-white font-bold rounded-full">
                        ವಿರಾಮ (PAUSED)
                      </span>
                    )}
                  </span>
                  {liveStreamVerse && (
                    <span className="text-[10px] text-[#A8988B] bg-[#362B25] px-2 py-0.5 rounded">
                      ಶ್ಲೋಕ: {liveStreamVerse}
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center space-x-3 text-[11px] text-[#A8988B]">
                {/* View switcher between formatted structured blocks and raw json */}
                <div className="flex rounded bg-[#181412] p-0.5 border border-[#3D3128]">
                  <button
                    type="button"
                    onClick={() => setStreamViewMode('formatted')}
                    className={`px-2 py-0.5 rounded text-[10px] font-sans transition-colors ${
                      streamViewMode === 'formatted'
                        ? 'bg-amber-500 text-black font-bold'
                        : 'text-[#B0A296] hover:text-white'
                    }`}
                  >
                    ವಿಭಾಗಗಳು
                  </button>
                  <button
                    type="button"
                    onClick={() => setStreamViewMode('raw')}
                    className={`px-2 py-0.5 rounded text-[10px] font-sans transition-colors ${
                      streamViewMode === 'raw'
                        ? 'bg-amber-500 text-black font-bold'
                        : 'text-[#B0A296] hover:text-white'
                    }`}
                  >
                    Raw Stream
                  </button>
                </div>

                <label className="flex items-center space-x-1 text-[#C4B6A9] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={autoScrollLiveStream}
                    onChange={(e) => setAutoScrollLiveStream(e.target.checked)}
                    className="rounded border-[#55453A] text-[#8B1E0F] focus:ring-0"
                  />
                  <span>Auto-scroll</span>
                </label>
                <span className="font-mono text-amber-300/90 font-semibold">
                  {liveStreamCharCount} ಅಕ್ಷರಗಳು
                </span>
                <button
                  onClick={() => setShowLiveStream(false)}
                  className="px-2 py-0.5 rounded bg-[#362B25] hover:bg-[#4A3C33] text-[#D6CBC0] text-[10px] transition-colors"
                  title="ಸ್ಟ್ರೀಮ್ ವಿಂಡೋ ಮುಚ್ಚಿ"
                >
                  ಮುಚ್ಚಿ ✕
                </button>
              </div>
            </div>

            <div
              ref={streamContainerRef}
              className="p-4 max-h-72 overflow-y-auto bg-[#14110F] text-[#EFEBE4] leading-relaxed scrollbar-thin scrollbar-thumb-[#4A3C33] relative font-sans"
            >
              {liveStreamText ? (
                (() => {
                  const parsed = streamViewMode === 'formatted' ? parsePartialStreamJson(liveStreamText) : null;
                  if (parsed) {
                    return (
                      <div className="space-y-3 font-sans text-xs">
                        {parsed.moolaShloka && (
                          <div className="p-2.5 rounded bg-[#201A16] border border-[#3E3128]">
                            <div className="text-[10px] font-bold text-amber-400 uppercase tracking-wider mb-1">
                              📜 ಮೂಲ ಶ್ಲೋಕ (Sanskrit Devanagari)
                            </div>
                            <div className="font-devanagari text-sm text-[#FFF4E8] whitespace-pre-wrap leading-relaxed">
                              {parsed.moolaShloka}
                            </div>
                          </div>
                        )}
                        {parsed.kannadaTransliteration && (
                          <div className="p-2.5 rounded bg-[#201A16] border border-[#3E3128]">
                            <div className="text-[10px] font-bold text-amber-400 uppercase tracking-wider mb-1">
                              🔤 ಕನ್ನಡ ಲಿಪ್ಯಂತರ (Pure Kannada Script)
                            </div>
                            <div className="font-kannada text-xs text-[#EAE2D8] whitespace-pre-wrap leading-relaxed">
                              {parsed.kannadaTransliteration}
                            </div>
                          </div>
                        )}
                        {parsed.padartha && (
                          <div className="p-2.5 rounded bg-[#201A16] border border-[#3E3128]">
                            <div className="text-[10px] font-bold text-amber-400 uppercase tracking-wider mb-1">
                              📖 ಪ್ರತಿಪದಾರ್ಥ (Devanagari Pada - Kannada Meaning)
                            </div>
                            <div className="font-kannada text-xs text-[#DFD6CB] leading-relaxed">
                              {parsed.padartha}
                            </div>
                          </div>
                        )}
                        {parsed.saralaVivarane && (
                          <div className="p-2.5 rounded bg-[#201A16] border border-[#3E3128]">
                            <div className="text-[10px] font-bold text-amber-400 uppercase tracking-wider mb-1">
                              ✨ ಸರಳ ವಿವರಣೆ (Simple Kannada Meaning)
                            </div>
                            <div className="font-kannada text-xs text-[#EDE6DC] leading-relaxed">
                              {parsed.saralaVivarane}
                            </div>
                          </div>
                        )}
                        {parsed.vivaradaVyakhyana && (
                          <div className="p-2.5 rounded bg-[#201A16] border border-[#3E3128]">
                            <div className="text-[10px] font-bold text-amber-400 uppercase tracking-wider mb-1">
                              📚 ವಿದ್ವತ್ ವ್ಯಾಖ್ಯಾನ (Scholarly Exposition)
                            </div>
                            <div className="font-kannada text-xs text-[#E0D8CE] leading-relaxed">
                              {parsed.vivaradaVyakhyana}
                            </div>
                          </div>
                        )}
                        {isProcessing && (
                          <div className="flex items-center space-x-2 text-[11px] text-amber-300/80 pt-1">
                            <span className="inline-block w-2 h-3.5 bg-amber-400 animate-pulse" />
                            <span className="font-kannada">AI ಅಕ್ಷರಗಳನ್ನು ಲೈವ್ ಆಗಿ ರಚಿಸುತ್ತಿದೆ...</span>
                          </div>
                        )}
                      </div>
                    );
                  }

                  return (
                    <pre className="whitespace-pre-wrap font-mono text-xs text-[#EDE5DB] leading-relaxed select-text">
                      {liveStreamText}
                      {isProcessing && (
                        <span className="inline-block w-2 h-4 bg-amber-400 ml-1 animate-pulse align-middle" />
                      )}
                    </pre>
                  );
                })()
              ) : isProcessing ? (
                <div className="py-6 text-center text-[#8C7D72] flex flex-col items-center justify-center space-y-2">
                  <RefreshCw className="w-5 h-5 text-amber-400 animate-spin" />
                  <p className="text-xs font-kannada text-amber-300/90">
                    AI ಮಾದರಿಯಿಂದ ಲೈವ್ ಅಕ್ಷರಗಳು ಮತ್ತು ಪದಗಳು ಸ್ಟ್ರೀಮ್ ಆಗುವುದನ್ನು ಕಾಯಲಾಗುತ್ತಿದೆ...
                  </p>
                </div>
              ) : (
                <div className="py-4 text-center text-[#8C7D72] text-xs font-kannada">
                  ಸಂಸ್ಕರಣೆ ಆರಂಭವಾದಾಗ AI ರಚಿಸುವ ಪ್ರತಿಯೊಂದು ಅಕ್ಷರವೂ ಇಲ್ಲಿ ಲೈವ್ ಆಗಿ ಪ್ರದರ್ಶನಗೊಳ್ಳುತ್ತದೆ.
                </div>
              )}
            </div>
          </div>
        )}

        {/* Live Terminal / Activity Log */}
        {showLogs && (
          <div className="rounded-xl border border-[#D5C7B7] bg-[#1E1916] text-[#EFEBE4] overflow-hidden shadow-inner font-mono text-xs">
            <div className="px-4 py-2 bg-[#2A221E] border-b border-[#3D322B] flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-2.5 h-2.5 rounded-full bg-red-500" />
                <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                <span className="text-[11px] text-[#A8988B] ml-2">ಚಟುವಟಿಕೆ ಲಾಗ್ (Live Execution Stream)</span>
              </div>
              <div className="flex items-center space-x-3 text-[11px]">
                <label className="flex items-center space-x-1 text-[#C4B6A9] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={autoScrollLogs}
                    onChange={(e) => setAutoScrollLogs(e.target.checked)}
                    className="rounded border-[#55453A] text-[#8B1E0F] focus:ring-0"
                  />
                  <span>Auto-scroll</span>
                </label>
                <span className="text-[#87786C]">{logs.length} ಸಂದೇಶಗಳು</span>
              </div>
            </div>

            <div
              ref={logsContainerRef}
              className="p-3.5 max-h-56 overflow-y-auto space-y-1.5 scrollbar-thin scrollbar-thumb-[#4A3C33]"
            >
              {logs.length === 0 ? (
                <p className="text-[#7A6B60] italic py-2 text-center">
                  ಯಾವುದೇ ಹೊಸ ಲಾಗ್ ದಾಖಲಾಗಿಲ್ಲ. ಕಡತ ಅಪ್ಲೋಡ್ ಮಾಡಿ ಅಥವಾ ಸಂಸ್ಕರಣೆ ಆರಂಭಿಸಿ.
                </p>
              ) : (
                logs.map((log) => {
                  let colorClass = 'text-[#D6CBC0]';
                  let badge = 'INFO';
                  if (log.level === 'success') {
                    colorClass = 'text-emerald-400';
                    badge = 'SUCCESS';
                  } else if (log.level === 'warn') {
                    colorClass = 'text-amber-300';
                    badge = 'WARN';
                  } else if (log.level === 'error') {
                    colorClass = 'text-rose-400';
                    badge = 'ERROR';
                  }

                  return (
                    <div key={log.id} className="flex items-start space-x-2 leading-relaxed">
                      <span className="text-[#857468] select-none text-[10px] pt-0.5">[{log.timestamp}]</span>
                      <span
                        className={`text-[9px] font-bold px-1.5 py-0.2 rounded select-none ${
                          badge === 'SUCCESS'
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                            : badge === 'WARN'
                            ? 'bg-amber-950 text-amber-300 border border-amber-800'
                            : badge === 'ERROR'
                            ? 'bg-rose-950 text-rose-300 border border-rose-800'
                            : 'bg-stone-800 text-stone-300 border border-stone-700'
                        }`}
                      >
                        {badge}
                      </span>
                      <span className={`${colorClass} flex-1 font-kannada`}>{log.message}</span>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
