import React, { useState } from 'react';
import {
  BookOpen,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Edit3,
  Layers,
  Table as TableIcon,
  Image as ImageIcon,
  ShieldCheck,
  FileSearch,
  ExternalLink,
  ChevronRight,
  Copy,
  Check,
  Zap,
  Sparkles,
} from 'lucide-react';
import { SanskritUnit } from '../types';
import { LiveStreamDrawer } from './LiveStreamDrawer';

interface UnitViewerProps {
  unit: SanskritUnit;
  onReprocess: (unitId: string) => Promise<void>;
  onOpenEdit: (unit: SanskritUnit) => void;
  onUnitUpdated?: (unit: SanskritUnit) => void;
}

export const UnitViewer: React.FC<UnitViewerProps> = ({
  unit,
  onReprocess,
  onOpenEdit,
  onUnitUpdated,
}) => {
  const [activeTab, setActiveTab] = useState<'SCHOLARLY' | 'LAYERS' | 'AUDIT'>('SCHOLARLY');
  const [isReprocessing, setIsReprocessing] = useState(false);
  const [isRepairingSection, setIsRepairingSection] = useState<string | null>(null);
  const [isLiveStreamOpen, setIsLiveStreamOpen] = useState(false);
  const [copiedSection, setCopiedSection] = useState<string | null>(null);
  const [isApproving, setIsApproving] = useState(false);
  const [isAutoFixing, setIsAutoFixing] = useState(false);

  const handleApproveOk = async () => {
    setIsApproving(true);
    try {
      const res = await fetch(`/api/units/${unit.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'ACCEPT',
          status: 'COMPLETED',
          confidence: 'HIGH',
          validationIssues: [],
        }),
      });
      const updated = await res.json();
      if (onUnitUpdated) {
        onUnitUpdated(updated);
      }
    } catch (err: any) {
      alert(`ದೃಢೀಕರಣ ದೋಷ: ${err.message}`);
    } finally {
      setIsApproving(false);
    }
  };

  const handleAutoFix = async () => {
    setIsAutoFixing(true);
    try {
      const res = await fetch(`/api/units/${unit.id}/repair-section`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ section: 'all' }),
      });
      const data = await res.json();
      if (data.success && data.unit && onUnitUpdated) {
        onUnitUpdated(data.unit);
      }
    } catch (err: any) {
      alert(`ಸ್ವಯಂ ಸರಿಪಡಿಸುವಾಗ ದೋಷ: ${err.message}`);
    } finally {
      setIsAutoFixing(false);
    }
  };

  const handleRepairSection = async (section: 'padartha' | 'saralaVivarane' | 'vivaradaVyakhyana' | 'all') => {
    setIsRepairingSection(section);
    try {
      const res = await fetch(`/api/units/${unit.id}/repair-section`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ section }),
      });
      const data = await res.json();
      if (data.success && data.unit && onUnitUpdated) {
        onUnitUpdated(data.unit);
      }
    } catch (err: any) {
      alert(`ದೋಷ: ${err.message}`);
    } finally {
      setIsRepairingSection(null);
    }
  };

  const handleReprocessClick = async () => {
    setIsReprocessing(true);
    try {
      await onReprocess(unit.id);
    } catch (err: any) {
      alert(`ಪುನಃ ಸಂಸ್ಕರಣೆ ದೋಷ: ${err.message}`);
    } finally {
      setIsReprocessing(false);
    }
  };

  const copyToClipboard = (text: string, sectionKey: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(sectionKey);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const output = unit.output;

  // Live Parisheelane validation checks
  const liveIssues: string[] = [];
  if (output) {
    // 1. Moola Sanskrit check
    if (!output.moolaShloka || !/[\u0900-\u097F]/.test(output.moolaShloka)) {
      liveIssues.push('ಮೂಲ ಶ್ಲೋಕದಲ್ಲಿ ಸಂಸ್ಕೃತ ದೇವನಾಗರಿ ಅಕ್ಷರಗಳಿಲ್ಲ.');
    } else if (/[A-Za-z]/.test(output.moolaShloka)) {
      liveIssues.push('ಮೂಲ ಶ್ಲೋಕದಲ್ಲಿ ಇಂಗ್ಲಿಷ್ ಅಕ್ಷರಗಳಿವೆ (ದೇವನಾಗರಿ ಲಿಪಿ ಮಾತ್ರ ಇರಬೇಕು).');
    } else if (/[\u0C80-\u0CFF]/.test(output.moolaShloka)) {
      liveIssues.push('ಮೂಲ ಶ್ಲೋಕದಲ್ಲಿ ಕನ್ನಡ ಅಕ್ಷರಗಳು ಬೆರೆತಿವೆ (ದೇವನಾಗರಿ ಲಿಪಿ ಮಾತ್ರ ಇರಬೇಕು).');
    }

    // 2. Lipyantara pure Kannada check
    if (!output.kannadaTransliteration || !/[\u0C80-\u0CFF]/.test(output.kannadaTransliteration)) {
      liveIssues.push('ಕನ್ನಡ ಲಿಪ್ಯಂತರ ಲಭ್ಯವಿಲ್ಲ.');
    } else if (/[A-Za-z]/.test(output.kannadaTransliteration)) {
      liveIssues.push('ಕನ್ನಡ ಲಿಪ್ಯಂತರದಲ್ಲಿ ಇಂಗ್ಲಿಷ್ ಅಕ್ಷರಗಳಿವೆ (ಕೇವಲ ಶುದ್ಧ ಕನ್ನಡ ಲಿಪಿ ಮಾತ್ರ ಇರಬೇಕು).');
    } else if (/[\u0900-\u097F]/.test(output.kannadaTransliteration)) {
      liveIssues.push('ಕನ್ನಡ ಲಿಪ್ಯಂತರದಲ್ಲಿ ದೇವನಾಗರಿ ಅಕ್ಷರಗಳು ಬೆರೆತಿವೆ (ಕೇವಲ ಶುದ್ಧ ಕನ್ನಡ ಲಿಪಿ ಮಾತ್ರ ಇರಬೇಕು).');
    }

    // 3. Padartha, Sarala Vivarane & Vyakhyana check (Only for regular Shlokas/Mantras/Gadya, NOT for Headings or Colophons)
    if (unit.unitType !== 'HEADING' && unit.unitType !== 'COLOPHON') {
      if (!output.padartha || output.padartha.trim().length < 15) {
        liveIssues.push('ಪದಾರ್ಥ ವಿಭಾಗವು ಖಾಲಿಯಾಗಿದೆ ಅಥವಾ ಅಪೂರ್ಣವಾಗಿದೆ.');
      } else {
        if (!/[\u0900-\u097F]/.test(output.padartha)) {
          liveIssues.push('ಪದಾರ್ಥದಲ್ಲಿ ಸಂಸ್ಕೃತ ಪದಗಳು ದೇವನಾಗರಿ ಲಿಪಿಯಲ್ಲಿರಬೇಕು.');
        }
        if (!/[\u0C80-\u0CFF]/.test(output.padartha)) {
          liveIssues.push('ಪದಾರ್ಥದಲ್ಲಿ ಅರ್ಥಗಳು ಕನ್ನಡ ಲಿಪಿಯಲ್ಲಿರಬೇಕು.');
        }
        if (/[A-Za-z]/.test(output.padartha)) {
          liveIssues.push('ಪದಾರ್ಥದಲ್ಲಿ ಇಂಗ್ಲಿಷ್ ಅಕ್ಷರಗಳು ಕಂಡುಬಂದಿವೆ.');
        }
        const brokenMatches = output.padartha.match(/,\s*[\u093E-\u094F\u0901-\u0903][\u0900-\u097F]*/g);
        if (brokenMatches || output.padartha.trim().match(/^[\u093E-\u094F\u0901-\u0903]/)) {
          liveIssues.push('ಪದಾರ್ಥದಲ್ಲಿ ವಿಕೃತ/ತುಂಡಾದ ಪದ ಕಂಡುಬಂದಿದೆ (ಉದಾ: "ोन्यां" ಬದಲಿಗೆ "योन्यां" ಇರಬೇಕು).');
        }
        const firstMoolaWordMatch = (output.moolaShloka || unit.originalText).match(/[\u0900-\u097F]{2,}/);
        if (firstMoolaWordMatch) {
          const firstMoolaWord = firstMoolaWordMatch[0];
          const firstCleanWord = firstMoolaWord.replace(/[ःं\u0951\u0952]$/, '');
          if (!output.padartha.includes(firstCleanWord) && firstCleanWord.length >= 2) {
            liveIssues.push(`ಪದಾರ್ಥದಲ್ಲಿ ಮೊದಲ ಸಂಸ್ಕೃತ ಪದ '${firstMoolaWord}' ಬಿಟ್ಟುಹೋಗಿದೆ.`);
          }
        }
      }

      // 4. Sarala Vivarane & Vyakhyana check
      if (!output.saralaVivarane || output.saralaVivarane.trim().length < 25) {
        liveIssues.push('ಸರಳ ವಿವರಣೆ ಅಪೂರ್ಣವಾಗಿದೆ.');
      }
      if (!output.vivaradaVyakhyana || output.vivaradaVyakhyana.trim().length < 40) {
        liveIssues.push('ವಿವರವಾದ ವ್ಯಾಖ್ಯಾನ ಅಪೂರ್ಣವಾಗಿದೆ.');
      }
    }
  }

  const allIssues = Array.from(new Set([...(unit.validationIssues || []), ...liveIssues]));
  const hasMistakes = allIssues.length > 0 && unit.status !== 'COMPLETED';

  return (
    <div className="bg-white border border-[#E8E2D9] rounded-xl shadow-sm overflow-hidden">
      {/* Unit Header */}
      <div className="p-4 bg-[#FAF7F2] border-b border-[#E8DFC9] flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div className="flex items-center space-x-3">
          <span className="w-8 h-8 rounded-lg bg-[#8B1E0F] text-white flex items-center justify-center font-mono font-bold text-xs">
            {unit.unitIndex}
          </span>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-devanagari font-bold text-sm text-[#1F1916]">
                {unit.detectedWork}
              </span>
              {unit.unitType && unit.unitType !== 'SHLOKA' && (
                <span className="font-kannada text-xs font-bold px-2 py-0.5 rounded bg-indigo-50 text-indigo-800 border border-indigo-200">
                  {unit.unitType === 'HEADING' ? 'ಶೀರ್ಷಿಕೆ' :
                   unit.unitType === 'SHANTI_MANTRA' ? 'ಶಾಂತಿ ಮಂತ್ರ' :
                   unit.unitType === 'UNNUMBERED_SHLOKA' ? 'ಶ್ಲೋಕ' :
                   unit.unitType === 'MANTRA' ? 'ಮಂತ್ರ' :
                   unit.unitType === 'GADYA' ? 'ಗದ್ಯ ಭಾಗ' :
                   unit.unitType === 'COLOPHON' ? 'ಪುಷ್ಪಿಕಾ' : unit.unitType}
                </span>
              )}
              {unit.structuralHierarchy.formattedNumber && (
                <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-[#8B1E0F]/10 text-[#8B1E0F] border border-[#8B1E0F]/20">
                  {unit.unitType === 'SHANTI_MANTRA' || unit.unitType === 'COLOPHON' ? '' : 'ಸಂಖ್ಯೆ: '}{unit.structuralHierarchy.formattedNumber.replace(/\|\|/g, '').trim()}
                </span>
              )}
              <span className="text-xs text-[#7A695D]">
                (ಪುಟ {unit.pageNumber})
              </span>
            </div>
            <p className="text-xs text-[#6B5A4E] font-kannada mt-0.5">
              {unit.structuralHierarchy.sectionName ? `${unit.structuralHierarchy.sectionName} • ` : ''}
              {unit.structuralHierarchy.level1Name} {unit.structuralHierarchy.level1Value || ''}
              {unit.structuralHierarchy.level2Name ? ` • ${unit.structuralHierarchy.level2Name} ${unit.structuralHierarchy.level2Value || ''}` : ''}
              {unit.structuralHierarchy.level3Name ? ` • ${unit.structuralHierarchy.level3Name} ${unit.structuralHierarchy.level3Value || ''}` : ''}
            </p>
          </div>
        </div>

        {/* Status, Confidence & Controls */}
        <div className="flex items-center space-x-2">
          {/* Confidence Badge */}
          <span
            className={`px-2.5 py-1 rounded text-xs font-semibold font-mono ${
              unit.confidence === 'HIGH'
                ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                : unit.confidence === 'MEDIUM'
                ? 'bg-amber-100 text-amber-800 border border-amber-300'
                : 'bg-rose-100 text-rose-800 border border-rose-300'
            }`}
          >
            {unit.confidence} CONFIDENCE
          </span>

          {/* Live Streaming Button */}
          <button
            id={`btn-stream-${unit.id}`}
            onClick={() => setIsLiveStreamOpen(true)}
            className="flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold transition-all shadow-xs"
            title="Watch AI stream tokens live in real-time"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>⚡ ಲೈವ್ ಸ್ಟ್ರೀಮ್</span>
          </button>
        </div>
      </div>

      {/* Parisheelane (ಪರಿಶೀಲನೆ - Quality Review & Action Panel) */}
      <div className={`p-4 border-b transition-colors ${hasMistakes ? 'bg-amber-50/80 border-amber-200' : 'bg-emerald-50/70 border-emerald-200'}`}>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-start space-x-3">
            <div className={`mt-0.5 p-1.5 rounded-lg ${hasMistakes ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'}`}>
              {hasMistakes ? <AlertTriangle className="w-5 h-5 text-amber-700" /> : <CheckCircle2 className="w-5 h-5 text-emerald-700" />}
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-sm text-[#1F1916]">
                  ಪರಿಶೀಲನೆ (Parisheelane):
                </span>
                <span className={`text-xs px-2.5 py-0.5 rounded-full font-bold font-kannada ${hasMistakes ? 'bg-amber-200 text-amber-900 border border-amber-300' : 'bg-emerald-200 text-emerald-900 border border-emerald-300'}`}>
                  {hasMistakes ? '⚠️ ಪರಿಶೀಲನೆ ಅಗತ್ಯ (Review Required)' : '✅ ಪೂರ್ಣಗೊಂಡಿದೆ (Poornagondide)'}
                </span>
              </div>
              <p className="text-xs text-[#5A4B41] mt-0.5">
                {hasMistakes
                  ? 'ಈ ಶ್ಲೋಕದಲ್ಲಿ ದೋಷವಿದೆ. ದಯವಿಟ್ಟು ಸಂಪಾದಿಸಿ ಅಥವಾ ಪರಿಶೀಲಿಸಿ ಅನುಮೋದಿಸಿ.'
                  : 'ಮೂಲ ಶ್ಲೋಕ, ಲಿಪ್ಯಂತರ, ಪದಾರ್ಥ ಹಾಗೂ ವ್ಯಾಖ್ಯಾನ ಯಶಸ್ವಿಯಾಗಿ ಪರಿಶೀಲಿಸಿ ಅನುಮೋದಿಸಲಾಗಿದೆ.'}
              </p>
              {hasMistakes && (
                <ul className="mt-2 space-y-1 text-xs text-amber-900 font-medium list-disc list-inside">
                  {allIssues.map((issue, idx) => (
                    <li key={idx} className="leading-snug">{issue}</li>
                  ))}
                </ul>
              )}
            </div>
          </div>

          {/* Action Buttons: Only show for units requiring attention */}
          {hasMistakes ? (
            <div className="flex flex-wrap items-center gap-2 self-end md:self-center">
              <button
                id={`btn-autofix-${unit.id}`}
                onClick={handleAutoFix}
                disabled={isAutoFixing}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition-colors disabled:opacity-50"
                title="ಸ್ವಯಂ ಸರಿಪಡಿಸಿ"
              >
                <Sparkles className={`w-3.5 h-3.5 ${isAutoFixing ? 'animate-spin' : ''}`} />
                <span>{isAutoFixing ? 'ಸರಿಪಡಿಸಲಾಗುತ್ತಿದೆ...' : 'ಸ್ವಯಂ ಸರಿಪಡಿಸಿ'}</span>
              </button>

              <button
                id={`btn-manual-write-${unit.id}`}
                onClick={() => onOpenEdit(unit)}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-stone-700 hover:bg-stone-800 text-white text-xs font-medium transition-colors"
                title="ಕೈಯಾರೆ ತಿದ್ದಿ / ಸಂಪಾದಿಸಿ"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>ಸಂಪಾದಿಸಿ (Edit)</span>
              </button>

              <button
                id={`btn-approve-ok-${unit.id}`}
                onClick={handleApproveOk}
                disabled={isApproving}
                className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shadow-xs transition-colors disabled:opacity-50"
                title="ಪರಿಶೀಲಿಸಿ ದೃಢೀಕರಿಸಿ (Approve & OK)"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{isApproving ? 'ದೃಢೀಕರಿಸಲಾಗುತ್ತಿದೆ...' : 'ಅನುಮೋದಿಸಿ (OK)'}</span>
              </button>
            </div>
          ) : (
            <div className="flex items-center space-x-2">
              <button
                onClick={() => onOpenEdit(unit)}
                className="flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-medium transition-colors border border-stone-200"
                title="ಸಂಪಾದಿಸಿ"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>ಸಂಪಾದಿಸಿ (Edit)</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-[#EAE4DC] bg-[#FAF8F5] px-4 text-xs font-medium">
        <button
          onClick={() => setActiveTab('SCHOLARLY')}
          className={`py-2.5 px-4 border-b-2 transition-colors flex items-center space-x-1.5 ${
            activeTab === 'SCHOLARLY'
              ? 'border-[#8B1E0F] text-[#8B1E0F] font-bold bg-white'
              : 'border-transparent text-[#7A695D] hover:text-[#1F1916]'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span>ಐದು ಪ್ರಮುಖ ವಿಭಾಗಗಳು (Scholarly 5 Sections)</span>
        </button>

        <button
          onClick={() => setActiveTab('LAYERS')}
          className={`py-2.5 px-4 border-b-2 transition-colors flex items-center space-x-1.5 ${
            activeTab === 'LAYERS'
              ? 'border-[#8B1E0F] text-[#8B1E0F] font-bold bg-white'
              : 'border-transparent text-[#7A695D] hover:text-[#1F1916]'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>ಪಠ್ಯದ 3 ಸ್ತರಗಳು (3 Text Layers)</span>
        </button>

        <button
          onClick={() => setActiveTab('AUDIT')}
          className={`py-2.5 px-4 border-b-2 transition-colors flex items-center space-x-1.5 ${
            activeTab === 'AUDIT'
              ? 'border-[#8B1E0F] text-[#8B1E0F] font-bold bg-white'
              : 'border-transparent text-[#7A695D] hover:text-[#1F1916]'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>ದೃಢೀಕರಣ & ಪರಿಶೀಲನೆ (Verification & Audit)</span>
        </button>
      </div>

      {/* Tab Content */}
      <div className="p-6">
        {/* 1. SCHOLARLY 5 SECTIONS */}
        {activeTab === 'SCHOLARLY' && (
          <div>
            {output ? (
              unit.unitType === 'HEADING' ||
              unit.unitType === 'COLOPHON' ||
              /^(?:॥|।।|\|\|)?\s*(?:इति|ಇತಿ)\s+|(?:समाप्त|सम्पूर्ण|ಸಮಾಪ್ತ|ಸಂಪೂರ್ಣ)/i.test(unit.originalText || output.moolaShloka || '') ||
              /(?:खण्ड|वल्ली|ಪ್ರಪಾಠಕ|ಕಾಂಡ|ಸರ್ಗ|ಪರ್ವ|ಅಧ್ಯಾಯ)/i.test((unit.originalText || output.moolaShloka || '').replace(/^[॥।।|।\s]+|[॥।।|।\s]+$/g, '')) ? (
                <div className="bg-[#FAF7F2] p-8 rounded-xl border border-[#EADBCE] shadow-sm text-center my-4">
                  <span className={`text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full border inline-block mb-4 ${unit.unitType === 'COLOPHON' || /^(?:इति|ಇತಿ)|(?:समाप्त|ಸಮಾಪ್ತ)/i.test(unit.originalText || '') ? 'text-purple-800 bg-purple-50 border-purple-200' : 'text-indigo-800 bg-indigo-50 border-indigo-200'}`}>
                    {unit.unitType === 'COLOPHON' || /^(?:इति|ಇತಿ)|(?:समाप्त|ಸಮಾಪ್ತ)/i.test(unit.originalText || '') ? 'ಪುಷ್ಪಿಕಾ / ಸಮಾಪ್ತಿ ವಾಕ್ಯ (Colophon)' : 'ಶೀರ್ಷಿಕೆ / ಉಪಶೀರ್ಷಿಕೆ (Section Heading)'}
                  </span>
                  <h3 className="font-kannada text-2xl font-bold text-[#1A365D] mt-2 mb-3">
                    {output.kannadaTransliteration?.startsWith('॥') ? output.kannadaTransliteration : `॥ ${output.kannadaTransliteration} ॥`}
                  </h3>
                  <p className="font-devanagari text-lg font-medium text-[#7A695D] mb-4">
                    {output.moolaShloka}
                  </p>
                  <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-medium">
                    <span>✓ ಶೀರ್ಷಿಕೆ/ಪುಷ್ಪಿಕಾ - ಕೇವಲ ಕನ್ನಡ ಲಿಪ್ಯಂತರ ಮಾತ್ರ (ಶ್ಲೋಕವಲ್ಲದ ಕಾರಣ ೫ ಹಂತಗಳ ಅಗತ್ಯವಿರುವುದಿಲ್ಲ)</span>
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                {/* 1. ಮೂಲ ಸಂಸ್ಕೃತ ಶ್ಲೋಕ (Devanagari Sanskrit with English digits) - Centered */}
                <div className="bg-[#FAF7F2] p-5 rounded-xl border border-[#EADBCE] shadow-sm text-center">
                  <div className="flex items-center justify-between mb-2 border-b border-[#EADBCE] pb-2">
                    <div className="w-12"></div>
                    <span className="text-[13pt] font-bold font-devanagari text-[#8B1E0F] uppercase tracking-wider">
                      ॥ ಮೂಲ ಸಂಸ್ಕೃತ ಶ್ಲೋಕಃ ॥
                    </span>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => copyToClipboard(output.moolaShloka, 'moola')}
                        className="p-1 rounded hover:bg-[#EADBCE] text-[#7A695D] hover:text-[#1F1916] transition-colors"
                        title="Copy Sanskrit Shloka"
                      >
                        {copiedSection === 'moola' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                  <div className="py-3 text-center">
                    <p className="font-devanagari text-[13pt] leading-loose text-[#1F1916] whitespace-pre-line font-bold tracking-wide">
                      {output.moolaShloka}
                    </p>
                  </div>
                </div>

                {/* 2. ಕನ್ನಡ ಲಿಪ್ಯಂತರಿತ ಶ್ಲೋಕ (Kannada script transliteration) - Centered */}
                <div className="bg-[#FAF8F5] p-5 rounded-xl border border-[#EAE4DC] shadow-sm text-center">
                  <div className="flex items-center justify-between mb-2 border-b border-[#EAE4DC] pb-2">
                    <div className="w-12"></div>
                    <span className="text-[13pt] font-bold font-kannada text-[#C2410C] uppercase tracking-wider">
                      ॥ ಕನ್ನಡ ಲಿಪ್ಯಂತರ ॥
                    </span>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => copyToClipboard(output.kannadaTransliteration, 'translit')}
                        className="p-1 rounded hover:bg-[#EAE4DC] text-[#7A695D] hover:text-[#1F1916] transition-colors"
                        title="Copy Transliteration"
                      >
                        {copiedSection === 'translit' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                  <div className="py-3 text-center">
                    <p className="font-kannada text-[13pt] leading-loose text-[#1A202C] whitespace-pre-line font-bold">
                      {output.kannadaTransliteration}
                    </p>
                  </div>
                </div>

                {/* 3. ಪದಾರ್ಥ (Left Aligned, Deep Emerald) */}
                <div className="bg-white p-5 rounded-xl border border-[#EAE4DC] shadow-sm text-left">
                  <div className="flex items-center justify-between mb-2 border-b border-[#EAE4DC] pb-2">
                    <div className="flex items-center space-x-2">
                      <span className="text-[13pt] font-bold font-kannada text-[#0F766E]">
                        ಪದಾರ್ಥ:
                      </span>
                      <span className="text-[11px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 hidden sm:inline">
                        Devanagari Pada - Kannada Artha
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => handleRepairSection('padartha')}
                        disabled={!!isRepairingSection}
                        className="inline-flex items-center gap-1 px-2 py-0.5 text-xs text-emerald-700 hover:text-emerald-900 hover:bg-emerald-50 rounded border border-emerald-200 transition-colors disabled:opacity-50"
                        title="ಪದಾರ್ಥವನ್ನು ಶಾಸ್ತ್ರೀಯವಾಗಿ ಪುನಃ ಸೃಷ್ಟಿಸಿ / ಪರಿಷ್ಕರಿಸಿ"
                      >
                        <Sparkles className={`w-3.5 h-3.5 ${isRepairingSection === 'padartha' ? 'animate-spin text-emerald-600' : 'text-emerald-600'}`} />
                        <span>{isRepairingSection === 'padartha' ? 'ರಚನೆಯಾಗುತ್ತಿದೆ...' : (!output.padartha || output.padartha.length < 25 ? 'ಪದಾರ್ಥ ಸೃಷ್ಟಿಸಿ' : 'ಪದಾರ್ಥ ಪರಿಷ್ಕರಿಸಿ')}</span>
                      </button>
                      <button
                        onClick={() => copyToClipboard(output.padartha, 'padartha')}
                        className="p-1 rounded hover:bg-stone-100 text-[#7A695D] hover:text-[#1F1916] transition-colors"
                        title="Copy Padartha"
                      >
                        {copiedSection === 'padartha' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                  <div className="pt-2">
                    {output.padartha ? (
                      <p className="font-kannada text-[13pt] leading-relaxed text-[#1A202C]">
                        {(() => {
                          const raw = output.padartha;
                          const pairRegex = /([\u0900-\u097F][\u0900-\u097F\s.,\u0951\u0952\uA8E0-\uA8F70-9]*?)\s*[-=:—–]\s*([^\-—–:=]+?)(?=(?:,\s*[\u0900-\u097F]|\s*$))/g;
                          const matches: { pada: string; artha: string }[] = [];
                          let m;
                          while ((m = pairRegex.exec(raw)) !== null) {
                            const p = m[1].replace(/^[,\s]+|[,\s]+$/g, '').trim();
                            const a = m[2].replace(/^[,\s]+|[,\s]+$/g, '').trim();
                            if (p && a) matches.push({ pada: p, artha: a });
                          }

                          if (matches.length > 0) {
                            return matches.map((item, idx) => (
                              <span key={idx} className="inline">
                                <span className="font-devanagari font-bold text-[#8B1E0F]">{item.pada}</span>
                                <span className="text-[#7A695D] mx-1">-</span>
                                <span className="font-kannada text-[#1F1916]">{item.artha}</span>
                                {idx < matches.length - 1 && <span className="text-[#7A695D] mr-1.5">, </span>}
                              </span>
                            ));
                          }

                          return output.padartha.split(/,\s*/).map((item, idx, arr) => {
                            const parts = item.split(/\s*[-=:—–]\s*/);
                            if (parts.length >= 2) {
                              const pada = parts[0];
                              const artha = parts.slice(1).join(' - ');
                              return (
                                <span key={idx} className="inline">
                                  <span className="font-devanagari font-bold text-[#8B1E0F]">{pada}</span>
                                  <span className="text-[#7A695D] mx-1">-</span>
                                  <span className="font-kannada text-[#1F1916]">{artha}</span>
                                  {idx < arr.length - 1 && <span className="text-[#7A695D] mr-1.5">, </span>}
                                </span>
                              );
                            }
                            return (
                              <span key={idx} className="inline font-kannada">
                                {item}
                                {idx < arr.length - 1 && <span className="text-[#7A695D] mr-1.5">, </span>}
                              </span>
                            );
                          });
                        })()}
                      </p>
                    ) : (
                      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3.5 bg-emerald-50/60 rounded-lg border border-emerald-200">
                        <span className="text-stone-600 text-sm font-kannada">ಪದಾರ್ಥ ಲಭ್ಯವಿಲ್ಲ ಅಥವಾ ಅಪೂರ್ಣವಾಗಿದೆ.</span>
                        <button
                          onClick={() => handleRepairSection('padartha')}
                          disabled={!!isRepairingSection}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-emerald-800 bg-emerald-100 hover:bg-emerald-200 border border-emerald-400 rounded-md shadow-xs transition-all disabled:opacity-50"
                        >
                          <Sparkles className="w-3.5 h-3.5 text-emerald-700" />
                          {isRepairingSection === 'padartha' ? 'ವಿದ್ವತ್ ಪದಾರ್ಥ ರಚನೆಯಾಗುತ್ತಿದೆ...' : 'ವಿದ್ವತ್ ಪದಾರ್ಥ ರಚಿಸಿ'}
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* 4. ಸರಳ ವಿವರಣೆ (Left Aligned, Royal Sapphire Blue) */}
                <div className="bg-white p-5 rounded-xl border border-[#EAE4DC] shadow-sm text-left">
                  <div className="flex items-center justify-between mb-2 border-b border-[#EAE4DC] pb-2">
                    <span className="text-[13pt] font-bold font-kannada text-[#1E40AF]">
                      ಸರಳ ವಿವರಣೆ:
                    </span>
                    <div className="flex items-center space-x-2">
                      {(!output.saralaVivarane || output.saralaVivarane.length < 80) && (
                        <button
                          onClick={() => handleRepairSection('saralaVivarane')}
                          disabled={!!isRepairingSection}
                          className="inline-flex items-center gap-1 px-2 py-0.5 text-xs text-blue-700 hover:text-blue-900 hover:bg-blue-50 rounded border border-blue-200 transition-colors disabled:opacity-50"
                          title="ಸರಳ ವಿವರಣೆಯನ್ನು ವಿಸ್ತರಿಸಿ"
                        >
                          <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                          <span>{isRepairingSection === 'saralaVivarane' ? 'ವಿಸ್ತರಿಸಲಾಗುತ್ತಿದೆ...' : 'ವಿವರಣೆ ವಿಸ್ತರಿಸಿ'}</span>
                        </button>
                      )}
                      <button
                        onClick={() => copyToClipboard(output.saralaVivarane, 'sarala')}
                        className="p-1 rounded hover:bg-stone-100 text-[#7A695D] hover:text-[#1F1916] transition-colors"
                        title="Copy Simple Explanation"
                      >
                        {copiedSection === 'sarala' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                  <p className="font-kannada text-[13pt] leading-relaxed text-[#1A202C] pt-2">
                    {output.saralaVivarane}
                  </p>
                </div>

                {/* 5. ವಿವರವಾದ ವ್ಯಾಖ್ಯಾನ (Left Aligned, Regal Deep Purple) */}
                <div className="bg-white p-5 rounded-xl border border-[#EAE4DC] shadow-sm text-left">
                  <div className="flex items-center justify-between mb-2 border-b border-[#EAE4DC] pb-2">
                    <span className="text-[13pt] font-bold font-kannada text-[#6B21A8]">
                      ವಿವರವಾದ ವ್ಯಾಖ್ಯಾನ:
                    </span>
                    <div className="flex items-center space-x-2">
                      <span className="text-[11px] font-mono text-[#7A695D] hidden sm:inline">
                        Traditional Commentary
                      </span>
                      {(!output.vivaradaVyakhyana || output.vivaradaVyakhyana.length < 150) && (
                        <button
                          onClick={() => handleRepairSection('vivaradaVyakhyana')}
                          disabled={!!isRepairingSection}
                          className="inline-flex items-center gap-1 px-2 py-0.5 text-xs text-purple-700 hover:text-purple-900 hover:bg-purple-50 rounded border border-purple-200 transition-colors disabled:opacity-50"
                          title="ವಿದ್ವತ್ ವ್ಯಾಖ್ಯಾನವನ್ನು ವಿಸ್ತರಿಸಿ"
                        >
                          <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                          <span>{isRepairingSection === 'vivaradaVyakhyana' ? 'ವಿಸ್ತರಿಸಲಾಗುತ್ತಿದೆ...' : 'ವ್ಯಾಖ್ಯಾನ ವಿಸ್ತರಿಸಿ'}</span>
                        </button>
                      )}
                      <button
                        onClick={() => copyToClipboard(output.vivaradaVyakhyana, 'vyakhyana')}
                        className="p-1 rounded hover:bg-stone-100 text-[#7A695D] hover:text-[#1F1916] transition-colors"
                        title="Copy Commentary"
                      >
                        {copiedSection === 'vyakhyana' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                  <p className="font-kannada text-[13pt] leading-relaxed text-[#1A202C] whitespace-pre-line pt-2">
                    {output.vivaradaVyakhyana}
                  </p>
                </div>

                {/* Optional Table for Maths, Science, Counts & Differences */}
                {output.tableContent && output.tableContent.headers && (
                  <div className="p-5 rounded-xl bg-[#FAF9F6] border border-[#E2DAD0] shadow-sm">
                    <div className="flex items-center justify-between mb-3 border-b border-[#E2DAD0] pb-2">
                      <div className="flex items-center space-x-2">
                        <TableIcon className="w-4 h-4 text-[#8B1E0F]" />
                        <h4 className="font-kannada font-bold text-sm text-[#8B1E0F]">
                          {output.tableContent.title || 'ಶಾಸ್ತ್ರೀಯ ವಿವರಣಾತ್ಮಕ ಕೋಷ್ಟಕ (Explanatory Table)'}
                        </h4>
                      </div>
                      <span className="text-[10px] font-medium bg-[#8B1E0F]/10 text-[#8B1E0F] px-2 py-0.5 rounded border border-[#8B1E0F]/20">
                        {output.tableContent.title?.includes('ವ್ಯತ್ಯಾಸ') || output.tableContent.title?.includes('ತುಲನೆ')
                          ? 'ವ್ಯತ್ಯಾಸ & ತುಲನೆ'
                          : output.tableContent.title?.includes('ಭೂತ') || output.tableContent.title?.includes('ವಿಜ್ಞಾನ')
                          ? 'ವಿಜ್ಞಾನ & ತತ್ತ್ವ'
                          : 'ಗಣಿತ & ಸಂಖ್ಯಾಗಣನೆ'}
                      </span>
                    </div>
                    <div className="overflow-x-auto rounded-lg border border-[#D5CBC0]">
                      <table className="w-full text-xs text-left border-collapse">
                        <thead>
                          <tr className="bg-[#EFE9E0] text-[#1F1916]">
                            {output.tableContent.headers.map((h, i) => (
                              <th key={i} className="p-2.5 border-b border-r border-[#D5CBC0] font-kannada font-bold last:border-r-0">
                                {h}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {output.tableContent.rows.map((row, rIdx) => (
                            <tr key={rIdx} className={rIdx % 2 === 0 ? 'bg-white' : 'bg-[#FAF8F5]'}>
                              {row.map((cell, cIdx) => (
                                <td key={cIdx} className="p-2.5 border-b border-r border-[#E2DAD0] font-kannada text-[#2D241E] leading-relaxed last:border-r-0">
                                  {cell}
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    {output.tableContent.explanation && (
                      <p className="text-xs text-[#4A5568] font-kannada mt-2.5 italic">
                        ವಿವರಣೆ: {output.tableContent.explanation}
                      </p>
                    )}
                  </div>
                )}

                {/* Optional Conceptual SVG Diagram / Flowchart for Flows, Counts & Differences */}
                {output.diagramContent && (output.diagramContent.svgDiagram || output.diagramContent.title) && (
                  <div className="p-5 rounded-xl bg-[#FAF9F6] border border-[#E2DAD0] shadow-sm">
                    <div className="flex items-center justify-between mb-3 border-b border-[#E2DAD0] pb-2">
                      <div className="flex items-center space-x-2">
                        <ImageIcon className="w-4 h-4 text-[#6B21A8]" />
                        <h4 className="font-kannada font-bold text-sm text-[#6B21A8]">
                          ರೇಖಾಚಿತ್ರ / ನಕ್ಷೆ: {output.diagramContent.title}
                        </h4>
                      </div>
                      <span className="text-[10px] font-medium bg-[#6B21A8]/10 text-[#6B21A8] px-2 py-0.5 rounded border border-[#6B21A8]/20">
                        {output.diagramContent.title?.includes('ವ್ಯತ್ಯಾಸ') || output.diagramContent.title?.includes('ತುಲನೆ')
                          ? 'ತುಲನಾತ್ಮಕ ನಕ್ಷೆ'
                          : output.diagramContent.title?.includes('ಪಂಚಭೂತ') || output.diagramContent.title?.includes('ವಿಜ್ಞಾನ')
                          ? 'ವಿಜ್ಞಾನ ರೇಖಾಚಿತ್ರ'
                          : 'ಪರಿಕಲ್ಪನಾ ಸರಣಿ'}
                      </span>
                    </div>
                    {output.diagramContent.svgDiagram && (
                      <div
                        className="p-3 bg-white border border-[#EAE4DC] rounded-lg overflow-x-auto flex justify-center my-2 shadow-inner"
                        dangerouslySetInnerHTML={{ __html: output.diagramContent.svgDiagram }}
                      />
                    )}
                    {output.diagramContent.description && (
                      <p className="text-xs text-[#2D3748] font-kannada mt-2 leading-relaxed">
                        {output.diagramContent.description}
                      </p>
                    )}
                    {output.diagramContent.caption && (
                      <p className="text-[11px] text-[#7A695D] font-kannada text-center mt-2 italic">
                        {output.diagramContent.caption}
                      </p>
                    )}
                  </div>
                )}

                {/* Optional Deity / Iconographic Picture */}
                {output.pictureContent && (output.pictureContent.title || output.pictureContent.description || output.pictureContent.svgDiagram) && (
                  <div className="p-5 rounded-xl bg-[#FAF8F5] border border-[#E8DFC9] shadow-sm">
                    <div className="flex items-center justify-between mb-3 border-b border-[#E8DFC9] pb-2">
                      <div className="flex items-center space-x-2">
                        <ImageIcon className="w-4 h-4 text-[#8B1E0F]" />
                        <h4 className="font-kannada font-bold text-sm text-[#8B1E0F]">
                          ದೇವತಾ ರೂಪ / ಶಾಸ್ತ್ರೀಯ ಚಿತ್ರಣ: {output.pictureContent.title}
                        </h4>
                      </div>
                      <span className="text-[10px] font-medium bg-[#8B1E0F]/10 text-[#8B1E0F] px-2 py-0.5 rounded border border-[#8B1E0F]/20">
                        ಧ್ಯಾನ್‌ಶ್ಲೋಕ / ಶಾಸ್ತ್ರೀಯ ರೂಪ
                      </span>
                    </div>
                    {output.pictureContent.svgDiagram && (
                      <div
                        className="p-3 bg-white border border-[#EAE4DC] rounded-lg overflow-x-auto flex justify-center my-2 shadow-inner"
                        dangerouslySetInnerHTML={{ __html: output.pictureContent.svgDiagram }}
                      />
                    )}
                    {output.pictureContent.description && (
                      <p className="text-xs text-[#2D3748] font-kannada mt-2 leading-relaxed">
                        {output.pictureContent.description}
                      </p>
                    )}
                    {output.pictureContent.caption && (
                      <p className="text-[11px] text-[#7A695D] font-kannada text-center mt-2 italic">
                        {output.pictureContent.caption}
                      </p>
                    )}
                  </div>
                )}
              </div>
            )) : (
              <div className="text-center py-10">
                <p className="text-sm text-[#7A695D]">
                  ಈ ಶ್ಲೋಕದ ಐದು ಪ್ರಮುಖ ವಿಭಾಗಗಳನ್ನು ಇನ್ನು ಉತ್ಪಾದಿಸಲಾಗಿಲ್ಲ.
                </p>
                <button
                  onClick={handleReprocessClick}
                  disabled={isReprocessing}
                  className="mt-3 px-4 py-2 rounded-lg bg-[#8B1E0F] hover:bg-[#A32312] text-white text-xs font-semibold"
                >
                  ಈ ಶ್ಲೋಕವನ್ನು ಈಗಲೇ ಸಂಸ್ಕರಿಸಿ (Process Now)
                </button>
              </div>
            )}
          </div>
        )}

        {/* 2. TEXT LAYERS (Original vs Raw vs Verified) */}
        {activeTab === 'LAYERS' && (
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-[#FAF8F5] border border-[#EAE4DC]">
              <span className="text-xs font-bold text-[#8B1E0F] uppercase tracking-wider block mb-1">
                ಸ್ತರ 1: ಮೂಲ ಆಕರ ಪಠ್ಯ (Layer 1: Original Uploaded Source)
              </span>
              <p className="font-devanagari text-sm text-[#2A221C] whitespace-pre-line">
                {unit.originalText}
              </p>
            </div>

            <div className="p-4 rounded-xl bg-[#FAF8F5] border border-[#EAE4DC]">
              <span className="text-xs font-bold text-[#4A3B31] uppercase tracking-wider block mb-1">
                ಸ್ತರ 2: ನೇರ ಹೊರತೆಗೆದ ಪಠ್ಯ (Layer 2: Raw Extracted Text)
              </span>
              <p className="font-devanagari text-sm text-[#2A221C] whitespace-pre-line">
                {unit.rawExtractedText}
              </p>
            </div>

            <div className="p-4 rounded-xl bg-[#F4F9F4] border border-[#CDE5CD]">
              <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider block mb-1">
                ಸ್ತರ 3: ಪರಿಶೀಲಿಸಿದ / ದೃಢೀಕೃತ ಪಠ್ಯ (Layer 3: Verified & Corrected Text)
              </span>
              <p className="font-devanagari text-sm text-emerald-950 whitespace-pre-line font-medium">
                {unit.verifiedText}
              </p>
            </div>
          </div>
        )}

        {/* 3. AUDIT & SOURCE VERIFICATION */}
        {activeTab === 'AUDIT' && (
          <div className="space-y-4">
            {/* Reference Source Info */}
            <div className="p-4 rounded-xl bg-[#FAF7F2] border border-[#E8DFC9]">
              <h4 className="font-serif font-bold text-xs text-[#1F1916] mb-2 flex items-center">
                <FileSearch className="w-4 h-4 mr-1.5 text-[#8B1E0F]" />
                ಆಕರ ದೃಢೀಕರಣ ವಿವರ (Canonical Source Verification)
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-[#7A695D]">ಆಕರ ಮೂಲ (Reference Source):</span>
                  <p className="font-semibold text-[#1F1916]">
                    {unit.sourceVerification?.referenceSource || 'ಪ್ರಾಮಾಣಿಕ ಹಸ್ತಪ್ರತಿ (Primary Manuscript)'}
                  </p>
                </div>
                <div>
                  <span className="text-[#7A695D]">ಹೊಂದಾಣಿಕೆ ಶ್ಲೋಕ (Matched Verse):</span>
                  <p className="font-mono font-semibold text-[#8B1E0F]">
                    {unit.sourceVerification?.matchedVerseNum || unit.structuralHierarchy.formattedNumber}
                  </p>
                </div>
                <div>
                  <span className="text-[#7A695D]">ವಿಶ್ವಾಸಾರ್ಹತೆ ಸ್ಕೋರ್ (Confidence Score):</span>
                  <p className="font-mono font-semibold text-emerald-700">
                    {Math.round((unit.sourceVerification?.confidenceScore || 0.9) * 100)}%
                  </p>
                </div>
                <div>
                  <span className="text-[#7A695D]">ಟಿಪ್ಪಣಿ (Notes):</span>
                  <p className="text-[#4A3B31]">
                    {unit.sourceVerification?.notes || 'ಮೂಲ ಸಂಸ್ಕೃತ ಅಕ್ಷರ ರಚನೆ ಪರಿಶೀಲಿಸಲಾಗಿದೆ.'}
                  </p>
                </div>
              </div>
            </div>

            {/* Validation Checklist */}
            <div className="p-4 rounded-xl bg-white border border-[#EAE4DC]">
              <h4 className="font-serif font-bold text-xs text-[#1F1916] mb-2 flex items-center">
                <ShieldCheck className="w-4 h-4 mr-1.5 text-emerald-700" />
                ಸ್ವಯಂಚಾಲಿತ 12-ಅಂಶಗಳ ಮೌಲ್ಯೀಕರಣ (12-Point Automated Validation)
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <div className="flex items-center text-emerald-700">
                  <CheckCircle2 className="w-3.5 h-3.5 mr-1.5 shrink-0" />
                  <span>ಮೂಲ ಶ್ಲೋಕ ದೇವನಾಗರಿ ಲಿಪಿಯಲ್ಲಿದೆ</span>
                </div>
                <div className="flex items-center text-emerald-700">
                  <CheckCircle2 className="w-3.5 h-3.5 mr-1.5 shrink-0" />
                  <span>ಕನ್ನಡ ಲಿಪ್ಯಂತರ ನಿಖರವಾಗಿದೆ</span>
                </div>
                <div className="flex items-center text-emerald-700">
                  <CheckCircle2 className="w-3.5 h-3.5 mr-1.5 shrink-0" />
                  <span>ಪದಚ್ಛೇದ ವಿಭಾಗವನ್ನು ಕಟ್ಟುನಿಟ್ಟಾಗಿ ನಿಷೇಧಿಸಲಾಗಿದೆ</span>
                </div>
                <div className="flex items-center text-emerald-700">
                  <CheckCircle2 className="w-3.5 h-3.5 mr-1.5 shrink-0" />
                  <span>1. ಪದಾರ್ಥವು ಅವಿರತ ಒಂದೇ ಪ್ಯಾರಾಗ್ರಾಫ್‌ನಲ್ಲಿದೆ</span>
                </div>
                <div className="flex items-center text-emerald-700">
                  <CheckCircle2 className="w-3.5 h-3.5 mr-1.5 shrink-0" />
                  <span>ಇಂಗ್ಲಿಷ್ ಅಂಕಿಗಳನ್ನು ಮಾತ್ರ ಬಳಸಲಾಗಿದೆ (0-9)</span>
                </div>
                <div className="flex items-center text-emerald-700">
                  <CheckCircle2 className="w-3.5 h-3.5 mr-1.5 shrink-0" />
                  <span>ಯಾವುದೇ ಅನ್ಯ ಭಾರತೀಯ ಲಿಪಿ ಸೋರಿಕೆ ಇಲ್ಲ</span>
                </div>
              </div>

              {unit.validationIssues && unit.validationIssues.length > 0 && (
                <div className="mt-3 p-2.5 rounded bg-amber-50 border border-amber-200 text-xs text-amber-900">
                  <p className="font-semibold mb-1">ಗಮನಿಸಬೇಕಾದ ಅಂಶಗಳು (Flagged Issues):</p>
                  <ul className="list-disc list-inside space-y-0.5">
                    {unit.validationIssues.map((issue, idx) => (
                      <li key={idx}>{issue}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* Change Log Entries */}
            {unit.changeLog && unit.changeLog.length > 0 && (
              <div className="p-4 rounded-xl bg-white border border-[#EAE4DC]">
                <h4 className="font-serif font-bold text-xs text-[#1F1916] mb-2">
                  ಬದಲಾವಣೆಗಳ ದಾಖಲೆ (Traceable Change Log)
                </h4>
                <div className="space-y-2">
                  {unit.changeLog.map((c, idx) => (
                    <div key={idx} className="p-2 rounded bg-[#FAF8F5] border border-[#E8E2D9] text-xs">
                      <p className="font-semibold text-[#8B1E0F]">{c.category}</p>
                      <p className="text-[#5A4B41] mt-0.5">{c.reason}</p>
                      <p className="text-[10px] text-[#857468] mt-1 font-mono">
                        ಆಕರ: {c.source} • ವಿಧಾನ: {c.method} • {new Date(c.timestamp).toLocaleTimeString()}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Live Stream Drawer */}
      <LiveStreamDrawer
        unit={unit}
        isOpen={isLiveStreamOpen}
        onClose={() => setIsLiveStreamOpen(false)}
        onUnitUpdated={(updatedUnit) => {
          if (onUnitUpdated) {
            onUnitUpdated(updatedUnit);
          }
        }}
      />
    </div>
  );
};
