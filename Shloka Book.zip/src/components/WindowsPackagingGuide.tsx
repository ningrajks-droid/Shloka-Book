import React from 'react';
import {
  X,
  Monitor,
  CheckCircle,
  Download,
  Terminal,
  FolderCheck,
  Cpu,
  Package,
} from 'lucide-react';

interface WindowsPackagingGuideProps {
  onClose: () => void;
}

export const WindowsPackagingGuide: React.FC<WindowsPackagingGuideProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-2xl border border-[#E8E2D9] max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-5 bg-[#FAF7F2] border-b border-[#E8DFC9] flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#2E4A70] text-white flex items-center justify-center">
              <Monitor className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-serif font-bold text-base text-[#1F1916]">
                Windows PC Desktop Application Packaging
              </h3>
              <p className="text-xs text-[#7A695D]">
                Offline-capable standalone Windows desktop execution architecture
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-[#EADBCE] text-[#7A695D] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1 text-xs">
          {/* Overview */}
          <div className="p-4 rounded-xl bg-[#F0F5FA] border border-[#C5D8E8] text-[#1E3A5F]">
            <h4 className="font-bold text-sm mb-1 flex items-center">
              <Package className="w-4 h-4 mr-1.5" />
              Windows Standalone Executable & Distribution
            </h4>
            <p className="leading-relaxed">
              This engine is architected as a decoupled system: a Node/TypeScript native core engine, bundled SQLite persistence, and an optimized Vite React UI. It runs seamlessly as a 100% self-contained Windows application without requiring users to install Python, compilers, or build tools.
            </p>
          </div>

          {/* Key Advantages */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3 rounded-lg bg-[#FAF8F5] border border-[#EAE4DC]">
              <Cpu className="w-4 h-4 text-[#8B1E0F] mb-1.5" />
              <h5 className="font-bold text-[#1F1916]">Zero External Tools</h5>
              <p className="text-[11px] text-[#7A695D] mt-0.5">
                No Python, Docker, or dev packages required on the target machine.
              </p>
            </div>

            <div className="p-3 rounded-lg bg-[#FAF8F5] border border-[#EAE4DC]">
              <FolderCheck className="w-4 h-4 text-emerald-700 mb-1.5" />
              <h5 className="font-bold text-[#1F1916]">Local SQLite Store</h5>
              <p className="text-[11px] text-[#7A695D] mt-0.5">
                All uploaded Sanskrit PDFs and state are stored in <code className="font-mono text-[10px]">grantha_data/</code>.
              </p>
            </div>

            <div className="p-3 rounded-lg bg-[#FAF8F5] border border-[#EAE4DC]">
              <CheckCircle className="w-4 h-4 text-blue-700 mb-1.5" />
              <h5 className="font-bold text-[#1F1916]">Resumable Checkpoints</h5>
              <p className="text-[11px] text-[#7A695D] mt-0.5">
                Restarting the application resumes directly from the last processed shloka.
              </p>
            </div>
          </div>

          {/* Packaging Instructions */}
          <div className="p-4 rounded-xl bg-white border border-[#EAE4DC] space-y-3">
            <h4 className="font-serif font-bold text-xs text-[#1F1916] flex items-center">
              <Terminal className="w-4 h-4 mr-1.5 text-[#8B1E0F]" />
              Build & Distribution Options
            </h4>
            <p className="text-[#635347]">
              <strong>Option 1 (Node Standalone Engine):</strong>
            </p>
            <div className="p-3 rounded-lg bg-[#1C1613] text-[#EADBCE] font-mono text-[11px]">
              <code>node scripts/build_windows_dist.js</code>
            </div>
            <p className="text-[#635347] pt-2">
              <strong>Option 2 (High-Performance Python Batch Processor - 1000+ Shlokas):</strong><br/>
              Includes PyMuPDF (<code className="font-mono text-[10px]">fitz</code>) fast PDF parsing, smart 25-30 shloka batching (reducing 1000 calls to ~35), ThreadPool parallel execution, and incremental DOCX generation:
            </p>
            <div className="p-3 rounded-lg bg-[#1C1613] text-[#EADBCE] font-mono text-[11px] space-y-1">
              <div><code>pip install -r requirements.txt</code></div>
              <div><code>python desktop_grantha_processor.py input.pdf -o output.docx -k YOUR_KEY -b 25 -w 2</code></div>
            </div>
          </div>

          {/* Desktop Launcher Configuration */}
          <div className="p-4 rounded-xl bg-[#FAF8F5] border border-[#EAE4DC]">
            <h4 className="font-bold text-xs text-[#1F1916] mb-2">
              Electron / Tauri Wrapper Compatibility
            </h4>
            <p className="text-[#635347] leading-relaxed">
              The engine serves the local API on port 3000 and can be wrapped with Electron or Tauri to provide native window borders, taskbar integration, and auto-update capabilities.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#FAF7F2] border-t border-[#E8DFC9] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-lg bg-[#8B1E0F] hover:bg-[#A32312] text-white text-xs font-semibold shadow-sm transition-colors"
          >
            ಅರ್ಥವಾಯಿತು (Done)
          </button>
        </div>
      </div>
    </div>
  );
};
