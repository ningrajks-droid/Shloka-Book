import React, { useState } from 'react';
import {
  Plus,
  Trash2,
  FolderOpen,
  BookOpen,
  Calendar,
  Layers,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  X,
  FileText,
} from 'lucide-react';
import { GranthaProject } from '../types';

interface ProjectManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  projects: GranthaProject[];
  currentProjectId: string | null;
  onSelectProject: (id: string) => void;
  onCreateProject: (name: string, description: string) => Promise<void>;
  onDeleteProject: (id: string) => Promise<void>;
  initialTab?: 'NEW' | 'MANAGE';
}

export const ProjectManagerModal: React.FC<ProjectManagerModalProps> = ({
  isOpen,
  onClose,
  projects,
  currentProjectId,
  onSelectProject,
  onCreateProject,
  onDeleteProject,
  initialTab = 'NEW',
}) => {
  const [activeTab, setActiveTab] = useState<'NEW' | 'MANAGE'>(initialTab);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;

    setIsCreating(true);
    setError(null);
    try {
      await onCreateProject(newName.trim(), newDesc.trim());
      setNewName('');
      setNewDesc('');
      onClose();
    } catch (err: any) {
      setError(err.message || 'ಪ್ರಕಲ್ಪ ರಚನೆ ವಿಫಲವಾಗಿದೆ.');
    } finally {
      setIsCreating(false);
    }
  };

  const handleDelete = async (proj: GranthaProject) => {
    const confirm = window.confirm(
      `ಎಚ್ಚರಿಕೆ: ನೀವು ನಿಜವಾಗಿಯೂ "${proj.name}" ಹಳೆಯ ಪ್ರಕಲ್ಪವನ್ನು ಶಾಶ್ವತವಾಗಿ ಅಳಿಸಲು ಬಯಸುವಿರಾ?\n\nಈ ಪ್ರಕಲ್ಪದ ಎಲ್ಲಾ ಕಡತಗಳು ಮತ್ತು ಹೊರತೆಗೆಯಲಾದ ಶ್ಲೋಕಗಳು ಅಳಿಸಲ್ಪಡುತ್ತವೆ.\n\n(Are you sure you want to permanently delete this project and all its files?)`
    );
    if (!confirm) return;

    setDeletingId(proj.id);
    setError(null);
    try {
      await onDeleteProject(proj.id);
    } catch (err: any) {
      setError(err.message || 'ಪ್ರಕಲ್ಪ ಅಳಿಸುವಿಕೆ ವಿಫಲವಾಗಿದೆ.');
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl border border-[#E8E2D9] max-w-2xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-[#EAE4DC] flex items-center justify-between bg-[#FAF8F5]">
          <div>
            <h3 className="font-serif font-bold text-lg text-[#1F1916] flex items-center">
              <FolderOpen className="w-5 h-5 mr-2 text-[#8B1E0F]" />
              ಗ್ರಂಥ ಪ್ರಕಲ್ಪಗಳ ನಿರ್ವಹಣೆ (Grantha Project Manager)
            </h3>
            <p className="text-xs text-[#7A695D] mt-0.5">
              ಹೊಸ ಪ್ರಕಲ್ಪ ರಚಿಸಿ ಅಥವಾ ಹಳೆಯ ಪ್ರಕಲ್ಪಗಳನ್ನು ವೀಕ್ಷಿಸಿ/ಅಳಿಸಿ.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#8C7B70] hover:text-[#1F1916] hover:bg-[#EFE9E2] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex border-b border-[#EAE4DC] px-6 bg-[#FAF8F5]">
          <button
            onClick={() => setActiveTab('NEW')}
            className={`py-3 px-4 text-xs font-semibold border-b-2 flex items-center space-x-1.5 transition-colors ${
              activeTab === 'NEW'
                ? 'border-[#8B1E0F] text-[#8B1E0F]'
                : 'border-transparent text-[#7A695D] hover:text-[#1F1916]'
            }`}
          >
            <Plus className="w-4 h-4" />
            <span>ಹೊಸ ಪ್ರಕಲ್ಪ ರಚಿಸಿ (New Project)</span>
          </button>
          <button
            onClick={() => setActiveTab('MANAGE')}
            className={`py-3 px-4 text-xs font-semibold border-b-2 flex items-center space-x-1.5 transition-colors ${
              activeTab === 'MANAGE'
                ? 'border-[#8B1E0F] text-[#8B1E0F]'
                : 'border-transparent text-[#7A695D] hover:text-[#1F1916]'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>ಹಳೆಯ ಪ್ರಕಲ್ಪಗಳ ಪಟ್ಟಿ & ಅಳಿಸುವಿಕೆ ({projects.length})</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {error && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700 flex items-center">
              <AlertTriangle className="w-4 h-4 mr-2 shrink-0 text-red-600" />
              <span>{error}</span>
            </div>
          )}

          {activeTab === 'NEW' ? (
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#1F1916] mb-1">
                  ಪ್ರಕಲ್ಪದ ಹೆಸರು (Project Name) <span className="text-red-600">*</span>:
                </label>
                <input
                  type="text"
                  required
                  placeholder="ಉದಾ: 108 ಉಪನಿಷತ್ ಶ್ಲೋಕಗಳು - ಕನ್ನಡ ವಿದ್ವತ್ ವ್ಯಾಖ್ಯಾನ"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full p-2.5 rounded-lg border border-[#DDD5C9] text-xs focus:outline-none focus:border-[#8B1E0F] bg-[#FAF8F5]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#1F1916] mb-1">
                  ವಿವರಣೆ (Project Description):
                </label>
                <textarea
                  placeholder="ಸಂಸ್ಕೃತ ಮೂಲ PDF ಕಡತಗಳ ಪರಿಶೀಲನೆ, ಕನ್ನಡ ಲಿಪ್ಯಂತರ, ಪದಾರ್ಥ, ಸರಳ ವಿವರಣೆ ಹಾಗೂ ವಿಸ್ತೃತ ವ್ಯಾಖ್ಯಾನ ಪ್ರಕಲ್ಪ..."
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  rows={3}
                  className="w-full p-2.5 rounded-lg border border-[#DDD5C9] text-xs focus:outline-none focus:border-[#8B1E0F] bg-[#FAF8F5]"
                />
              </div>

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-lg border border-[#DDD5C9] hover:bg-[#EADBCE] text-xs font-semibold text-[#5A4B41] transition-colors"
                >
                  ರದ್ದು (Cancel)
                </button>
                <button
                  type="submit"
                  disabled={!newName.trim() || isCreating}
                  className="px-5 py-2 rounded-lg bg-[#8B1E0F] hover:bg-[#A32312] text-white text-xs font-semibold shadow-sm transition-colors disabled:opacity-50 flex items-center"
                >
                  {isCreating && <RefreshCw className="w-3.5 h-3.5 mr-1.5 animate-spin" />}
                  ಹೊಸ ಪ್ರಕಲ್ಪ ರಚಿಸಿ (Create Project)
                </button>
              </div>
            </form>
          ) : (
            <div className="space-y-3">
              <p className="text-xs text-[#7A695D]">
                ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ ಎಲ್ಲಾ ಪ್ರಕಲ್ಪಗಳ ಪಟ್ಟಿ. ಅನಗತ್ಯ ಅಥವಾ ಹಳೆಯ ಪ್ರಕಲ್ಪಗಳನ್ನು ಅಳಿಸಲು ಕೆಳಗಿನ <strong>"ಅಳಿಸಿ (Delete)"</strong> ಬಟನ್ ಬಳಸಿ.
              </p>

              {projects.length === 0 ? (
                <div className="p-8 text-center bg-[#FAF8F5] rounded-xl border border-dashed border-[#DDD5C9]">
                  <BookOpen className="w-8 h-8 text-[#A89689] mx-auto mb-2" />
                  <p className="text-xs font-semibold text-[#5A4B41]">ಯಾವುದೇ ಪ್ರಕಲ್ಪಗಳು ಲಭ್ಯವಿಲ್ಲ</p>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {projects.map((proj) => {
                    const isCurrent = proj.id === currentProjectId;
                    return (
                      <div
                        key={proj.id}
                        className={`p-4 rounded-xl border transition-all ${
                          isCurrent
                            ? 'border-[#8B1E0F] bg-[#FAF3F0] shadow-xs'
                            : 'border-[#E8E2D9] bg-white hover:border-[#DDD3C7]'
                        }`}
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          <div className="space-y-1">
                            <div className="flex items-center space-x-2">
                              <h4 className="font-serif font-bold text-sm text-[#1F1916]">
                                {proj.name}
                              </h4>
                              {isCurrent && (
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#8B1E0F] text-white">
                                  ಪ್ರಸ್ತುತ ಪ್ರಕಲ್ಪ (Active)
                                </span>
                              )}
                            </div>
                            {proj.description && (
                              <p className="text-xs text-[#7A695D] line-clamp-1">
                                {proj.description}
                              </p>
                            )}
                            <div className="flex items-center space-x-3 text-[11px] text-[#8C7B70] pt-1">
                              <span className="flex items-center">
                                <FileText className="w-3.5 h-3.5 mr-1" />
                                {proj.totalDocuments || 0} ಕಡತಗಳು • {proj.totalPages || 0} ಪುಟಗಳು
                              </span>
                              <span>•</span>
                              <span className="flex items-center">
                                <CheckCircle2 className="w-3.5 h-3.5 mr-1 text-emerald-600" />
                                {proj.completedUnits || 0} / {proj.totalUnits || 0} ಶ್ಲೋಕಗಳು
                              </span>
                              {proj.detectedWork && (
                                <>
                                  <span>•</span>
                                  <span className="text-[#8B1E0F] font-devanagari font-semibold">
                                    {proj.detectedWork}
                                  </span>
                                </>
                              )}
                            </div>
                          </div>

                          <div className="flex items-center space-x-2 shrink-0">
                            {!isCurrent && (
                              <button
                                onClick={() => {
                                  onSelectProject(proj.id);
                                  onClose();
                                }}
                                className="px-3 py-1.5 rounded-lg bg-[#FAF5EE] hover:bg-[#EADBCE] border border-[#E6DCCE] text-xs font-semibold text-[#5A4B41] transition-colors"
                              >
                                ತೆರೆಯಿರಿ (Open)
                              </button>
                            )}

                            <button
                              id={`btn-delete-project-${proj.id}`}
                              onClick={() => handleDelete(proj)}
                              disabled={deletingId === proj.id}
                              className="px-3 py-1.5 rounded-lg bg-red-50 hover:bg-red-600 hover:text-white border border-red-200 hover:border-red-600 text-red-700 text-xs font-semibold transition-all flex items-center shadow-2xs disabled:opacity-50"
                              title="ಹಳೆಯ ಪ್ರಕಲ್ಪವನ್ನು ಶಾಶ್ವತವಾಗಿ ಅಳಿಸಿ (Delete this project)"
                            >
                              {deletingId === proj.id ? (
                                <RefreshCw className="w-3.5 h-3.5 mr-1 animate-spin" />
                              ) : (
                                <Trash2 className="w-3.5 h-3.5 mr-1" />
                              )}
                              <span>ಅಳಿಸಿ (Delete)</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
