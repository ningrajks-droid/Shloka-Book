import React, { useState } from 'react';
import {
  X,
  CheckCircle,
  XCircle,
  RefreshCw,
  Save,
  AlertTriangle,
  BookOpen,
  FileSearch,
  Languages,
} from 'lucide-react';
import { SanskritUnit } from '../types';
import { devanagariToKannada } from '../utils/transliteration';

interface ReviewModalProps {
  unit: SanskritUnit | null;
  onClose: () => void;
  onSaveUnit: (updated: Partial<SanskritUnit> & { id: string; action?: 'ACCEPT' | 'REJECT' }) => Promise<void>;
  onReprocess: (unitId: string) => Promise<void>;
}

export const ReviewModal: React.FC<ReviewModalProps> = ({
  unit,
  onClose,
  onSaveUnit,
  onReprocess,
}) => {
  if (!unit) return null;

  const [verifiedText, setVerifiedText] = useState(unit.verifiedText || unit.originalText);
  const [kannadaTransliteration, setKannadaTransliteration] = useState(
    unit.output?.kannadaTransliteration || devanagariToKannada(unit.verifiedText || unit.originalText)
  );
  const [padartha, setPadartha] = useState(unit.output?.padartha || '');
  const [saralaVivarane, setSaralaVivarane] = useState(unit.output?.saralaVivarane || '');
  const [vivaradaVyakhyana, setVivaradaVyakhyana] = useState(unit.output?.vivaradaVyakhyana || '');
  const [isSaving, setIsSaving] = useState(false);
  const [isReprocessing, setIsReprocessing] = useState(false);

  const handleAutoTransliterate = () => {
    const transliterated = devanagariToKannada(verifiedText);
    setKannadaTransliteration(transliterated);
  };

  const handleAccept = async () => {
    setIsSaving(true);
    try {
      await onSaveUnit({
        id: unit.id,
        verifiedText,
        output: unit.output ? {
          ...unit.output,
          moolaShloka: verifiedText,
          kannadaTransliteration: kannadaTransliteration || devanagariToKannada(verifiedText),
          padartha,
          saralaVivarane,
          vivaradaVyakhyana,
        } : undefined,
        action: 'ACCEPT',
      });
      onClose();
    } catch (err: any) {
      alert(`ದೋಷ: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handleReject = async () => {
    if (!confirm('ಈ ಶ್ಲೋಕವನ್ನು ಅಮಾನ್ಯಗೊಳಿಸಿ ತಿರಸ್ಕರಿಸಬೇಕೆ (Reject this unit)?')) return;
    setIsSaving(true);
    try {
      await onSaveUnit({
        id: unit.id,
        action: 'REJECT',
      });
      onClose();
    } catch (err: any) {
      alert(`ದೋಷ: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handleReprocess = async () => {
    setIsReprocessing(true);
    try {
      await onReprocess(unit.id);
      onClose();
    } catch (err: any) {
      alert(`ದೋಷ: ${err.message}`);
    } finally {
      setIsReprocessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-2xl border border-[#E8E2D9] max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="p-5 bg-[#FAF7F2] border-b border-[#E8DFC9] flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#8B1E0F]/10 text-[#8B1E0F] flex items-center justify-center">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif font-bold text-base text-[#1F1916]">
                ವಿದ್ವತ್ ಪರಿಶೀಲನೆ & ಅನುಮೋದನೆ (Scholarly Review & Verification)
              </h3>
              <p className="text-xs text-[#7A695D]">
                {unit.detectedWork} • {unit.structuralHierarchy.formattedNumber} (ಪುಟ {unit.pageNumber})
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-[#EADBCE] text-[#7A695D] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1 text-xs">
          {/* Side-by-side Comparison */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Left: Original Source */}
            <div className="p-4 rounded-xl bg-[#FAF8F5] border border-[#EAE4DC]">
              <span className="font-bold text-[#8B1E0F] uppercase tracking-wider block mb-1">
                ಮೂಲ ಆಕರ ಹಸ್ತಪ್ರತಿ (Original Source)
              </span>
              <p className="font-devanagari text-sm leading-relaxed text-[#2D231E] whitespace-pre-line">
                {unit.originalText}
              </p>
            </div>

            {/* Right: Reference Source & Canonical Match */}
            <div className="p-4 rounded-xl bg-[#FAF7F2] border border-[#E8DFC9]">
              <span className="font-bold text-[#2E4A70] uppercase tracking-wider block mb-1">
                ಆಕರ ದೃಢೀಕರಣ (Canonical Reference Match)
              </span>
              <p className="text-[11px] text-[#7A695D] mb-1">
                ಆಕರ: {unit.sourceVerification?.referenceSource || 'SanskritDocuments.org'}
              </p>
              <p className="text-[11px] text-[#4A3B31]">
                {unit.sourceVerification?.notes || 'ಮೂಲ ಸಂಸ್ಕೃತ ಧ್ವನಿ ಸಂರಕ್ಷಣೆ & ಲಿಪ್ಯಂತರ ನಿಖರತೆ ಪರಿಶೀಲಿಸಲಾಗಿದೆ.'}
              </p>
            </div>
          </div>

          {/* Editable Verified Sanskrit Text */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="font-bold text-[#8B1E0F]">
                ॥ ಮೂಲ ಸಂಸ್ಕೃತ ಶ್ಲೋಕಃ ॥ (Verified Sanskrit Text - Devanagari):
              </label>
              <span className="text-[10px] text-stone-500 font-mono">
                ದೇವನಾಗರಿ ಲಿಪಿ (English Digits)
              </span>
            </div>
            <textarea
              value={verifiedText}
              onChange={(e) => setVerifiedText(e.target.value)}
              rows={3}
              className="w-full p-3 rounded-lg border border-[#DDD5C9] font-devanagari text-sm focus:outline-none focus:border-[#8B1E0F] bg-[#FAF8F5] text-center"
            />
          </div>

          {/* Editable Kannada Transliteration (ಕನ್ನಡ ಲಿಪ್ಯಂತರ) */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="font-bold text-[#C2410C] flex items-center space-x-1.5">
                <span>॥ ಕನ್ನಡ ಲಿಪ್ಯಂತರ ॥ (Kannada Script Transliteration):</span>
              </label>
              <button
                type="button"
                onClick={handleAutoTransliterate}
                className="flex items-center space-x-1 text-[11px] font-semibold text-[#8B1E0F] hover:text-[#A32312] bg-[#FAF4ED] hover:bg-[#F3E7DB] px-2.5 py-0.5 rounded border border-[#E4D5C5] transition-colors"
                title="ಸಂಸ್ಕೃತ ಮೂಲದಿಂದ ಸ್ವಯಂ ಕನ್ನಡ ಲಿಪ್ಯಂತರ ರಚಿಸಿ"
              >
                <Languages className="w-3 h-3" />
                <span>ಮೂಲದಿಂದ ಸ್ವಯಂ ಲಿಪ್ಯಂತರ (Auto-Transliterate)</span>
              </button>
            </div>
            <textarea
              value={kannadaTransliteration}
              onChange={(e) => setKannadaTransliteration(e.target.value)}
              rows={3}
              className="w-full p-3 rounded-lg border border-[#DDD5C9] font-kannada text-sm focus:outline-none focus:border-[#C2410C] bg-[#FAF8F5] text-center font-medium text-[#1A202C]"
            />
          </div>

          {/* Editable Padartha (Enforcing continuous single paragraph rule!) */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="font-bold text-[#0F766E]">
                ಪದಾರ್ಥ: (Continuous Single Paragraph - ಪದ - ಅರ್ಥ, ಪದ - ಅರ್ಥ...):
              </label>
              <span className="text-[10px] text-emerald-700 font-mono">
                ಒಂದೇ ಪ್ಯಾರಾಗ್ರಾಫ್ ನಿಯಮ (No Bullets/Newlines)
              </span>
            </div>
            <textarea
              value={padartha}
              onChange={(e) => setPadartha(e.target.value)}
              rows={3}
              className="w-full p-3 rounded-lg border border-[#DDD5C9] font-kannada text-xs focus:outline-none focus:border-[#0F766E] bg-white text-left"
            />
          </div>

          {/* Editable Simple Explanation */}
          <div>
            <label className="block font-bold text-[#1E40AF] mb-1">
              ಸರಳ ವಿವರಣೆ: (Simple Explanation in Kannada):
            </label>
            <textarea
              value={saralaVivarane}
              onChange={(e) => setSaralaVivarane(e.target.value)}
              rows={2}
              className="w-full p-3 rounded-lg border border-[#DDD5C9] font-kannada text-xs focus:outline-none focus:border-[#1E40AF] bg-white text-left"
            />
          </div>

          {/* Editable Detailed Commentary */}
          <div>
            <label className="block font-bold text-[#6B21A8] mb-1">
              ವಿವರವಾದ ವ್ಯಾಖ್ಯಾನ: (Detailed Scholarly Commentary):
            </label>
            <textarea
              value={vivaradaVyakhyana}
              onChange={(e) => setVivaradaVyakhyana(e.target.value)}
              rows={4}
              className="w-full p-3 rounded-lg border border-[#DDD5C9] font-kannada text-xs focus:outline-none focus:border-[#6B21A8] bg-white text-left"
            />
          </div>
        </div>

        {/* Modal Footer Controls */}
        <div className="p-4 bg-[#FAF7F2] border-t border-[#E8DFC9] flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center space-x-2">
            <button
              onClick={handleReject}
              disabled={isSaving}
              className="flex items-center space-x-1 px-3 py-2 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 text-xs font-semibold transition-colors"
            >
              <XCircle className="w-4 h-4 text-rose-600" />
              <span>ತಿರಸ್ಕರಿಸಿ (Reject)</span>
            </button>

            <button
              onClick={handleReprocess}
              disabled={isReprocessing}
              className="flex items-center space-x-1 px-3 py-2 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-800 border border-stone-300 text-xs font-semibold transition-colors"
            >
              <RefreshCw className={`w-4 h-4 ${isReprocessing ? 'animate-spin' : ''}`} />
              <span>AI ಮರುಸಂಸ್ಕರಣೆ (Reprocess AI)</span>
            </button>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg border border-[#DDD5C9] hover:bg-[#EADBCE] text-xs font-semibold text-[#5A4B41] transition-colors"
            >
              ಮುಚ್ಚಿ (Cancel)
            </button>

            <button
              onClick={handleAccept}
              disabled={isSaving}
              className="flex items-center space-x-1.5 px-5 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold shadow-sm transition-colors"
            >
              <CheckCircle className="w-4 h-4" />
              <span>ಅನುಮೋದಿಸಿ & ಉಳಿಸಿ (Accept & Save)</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
