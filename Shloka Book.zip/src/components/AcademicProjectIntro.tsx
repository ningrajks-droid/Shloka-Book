import React, { useState } from 'react';
import { Award, BookOpen, ChevronDown, ChevronUp, Sparkles, User, GraduationCap } from 'lucide-react';

export const AcademicProjectIntro: React.FC = () => {
  const [isExpanded, setIsExpanded] = useState(true);
  const photoUrl = '/NKS.jpg';

  return (
    <div className="bg-gradient-to-r from-[#FAF7F2] via-[#FFFDF9] to-[#F5EFE6] border border-[#D8C7B5] rounded-2xl shadow-sm overflow-hidden transition-all duration-300">
      {/* Header Bar */}
      <div className="bg-[#2B1D16] text-[#F5EFE6] px-5 py-3 flex items-center justify-between border-b border-[#4A382D]">
        <div className="flex items-center space-x-2.5">
          <GraduationCap className="w-5 h-5 text-[#E5A96A]" />
          <span className="font-serif font-bold text-sm tracking-wide">
            ಪ್ರಕಲ್ಪ-परिचयः (Academic Project Presentation)
          </span>
          <span className="hidden sm:inline-block text-[11px] px-2 py-0.5 rounded bg-[#8B1E0F] text-[#FFE8D6] font-semibold">
            संस्कृत-ग्रन्थ-ಪ್ರಕಲ್ಪಃ
          </span>
        </div>
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="text-xs text-[#D8C7B5] hover:text-white flex items-center space-x-1 px-2.5 py-1 rounded bg-[#3D2C22] hover:bg-[#4E392D] transition-colors cursor-pointer"
          title={isExpanded ? 'ಸಂಕ್ಷೇಪಿಸಿ (Collapse)' : 'ವಿಸ್ತರಿಸಿ (Expand)'}
        >
          <span>{isExpanded ? 'ಮರೆಮಾಡಿ (Hide)' : 'ವೀಕ್ಷಿಸಿ (Show)'}</span>
          {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
        </button>
      </div>

      {/* Expanded Content */}
      {isExpanded && (
        <div className="p-5 sm:p-6">
          <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
            {/* Left: Portrait Frame */}
            <div className="flex flex-col items-center flex-shrink-0">
              <div className="relative">
                {/* Traditional Decorative Frame */}
                <div className="p-1.5 rounded-xl bg-gradient-to-b from-[#8B1E0F] via-[#C2410C] to-[#78350F] shadow-md">
                  <div className="bg-white p-1 rounded-lg relative overflow-hidden">
                    <img
                      src={photoUrl}
                      alt="Ningaraju K S - Creator of the Project"
                      className="w-36 h-44 sm:w-40 sm:h-48 object-cover rounded-md shadow-inner border border-[#E5D7C7]"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        if (!target.src.includes('NKS.jpg')) {
                          target.src = '/NKS.jpg';
                        }
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Right: Academic Project Credentials & Details */}
            <div className="flex-1 text-center md:text-left space-y-3">
              <div>
                <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#8B1E0F]/10 text-[#8B1E0F] text-xs font-semibold border border-[#8B1E0F]/20 mb-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#8B1E0F]" />
                  <span>Sanskrit-Kannada Scholarly Research & Publishing</span>
                </div>
                <h2 className="font-serif text-xl sm:text-2xl font-extrabold text-[#1F1916] tracking-tight">
                  Sanskrit Grantha Prakalpa
                  <span className="block text-base sm:text-lg font-normal text-[#8B1E0F] mt-0.5 font-serif">
                    (संस्कृत-ग्रन्थ-प्रकल्पः / ಸಂಸ್ಕೃತ ಗ್ರಂಥ ಪ್ರಕಲ್ಪ)
                  </span>
                </h2>
              </div>

              {/* Creator Identification */}
              <div className="p-3 rounded-xl bg-[#FFFFFF] border border-[#E5DACD] shadow-xs">
                <div className="flex items-center justify-center md:justify-start space-x-2 text-sm">
                  <span className="font-serif font-bold text-[#8B1E0F]">
                    प्रकल्पस्य निर्माता (Creator of the Project):
                  </span>
                  <span className="font-bold text-[#1F1916] text-base">
                    Ningaraju K S
                  </span>
                </div>
                <p className="text-xs text-[#6B5A4E] mt-1 font-kannada">
                  ಸರ್ವ ಸಂಸ್ಕೃತ-ಕನ್ನಡ ವಿದ್ವತ್ ಗ್ರಂಥ ಸಂರಕ್ಷಣೆ, ಪರಿಶುದ್ಧ ಲಿಪ್ಯಂತರ, ಶ್ಲೋಕಾರ್ಥ, ಸರಳ ವಿವರಣೆ ಹಾಗೂ ವಿಸ್ತೃತ ವ್ಯಾಖ್ಯಾನ ನಿರ್ಮಾಣ ಯಂತ್ರ.
                </p>
              </div>

              {/* Badges / Highlights */}
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 pt-1 text-[11px]">
                <span className="px-2.5 py-1 rounded-lg bg-[#FAF0E6] text-[#7C2D12] font-semibold border border-[#E8D0BA]">
                  🏛️ Scholarly Presentation
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-[#F0FDF4] text-[#166534] font-semibold border border-[#BBF7D0]">
                  ✨ 100% Pure Kannada Script
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-[#EFF6FF] text-[#1E40AF] font-semibold border border-[#BFDBFE]">
                  📜 Continuous Padartha
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-[#FAF5FF] text-[#6B21A8] font-semibold border border-[#E9D5FF]">
                  🎯 A4 Docx & PDF Engine
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
