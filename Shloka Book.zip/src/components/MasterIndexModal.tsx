import React, { useState, useEffect } from 'react';
import {
  X,
  Layers,
  Edit3,
  Save,
  CheckCircle2,
  RefreshCw,
  Search,
  BookOpen,
  Hash,
  FileText,
  Sliders,
  Check,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';
import { GranthaProject, SanskritUnit, GranthaTableOfContents, TableOfContentsEntry } from '../types';
import { safeFetchJson } from '../utils/apiClient';

interface MasterIndexModalProps {
  project: GranthaProject;
  units: SanskritUnit[];
  onClose: () => void;
  onProjectUpdated: () => void;
  onSelectUnit?: (unitId: string) => void;
  onStartProcessing?: () => void;
}

export const MasterIndexModal: React.FC<MasterIndexModalProps> = ({
  project,
  units,
  onClose,
  onProjectUpdated,
  onSelectUnit,
  onStartProcessing,
}) => {
  const [tocData, setTocData] = useState<GranthaTableOfContents | null>(null);
  const [isLoadingToc, setIsLoadingToc] = useState(true);
  const [activeTab, setActiveTab] = useState<'MASTER_INDEX' | 'STRUCTURE_EDITOR' | 'BATCH_CONFIG'>('MASTER_INDEX');
  const [searchQuery, setSearchQuery] = useState('');

  // Global Structure Configuration State
  const [globalWorkTitle, setGlobalWorkTitle] = useState(project.detectedWork || project.name || '');
  const [globalGenre, setGlobalGenre] = useState(project.detectedGenre || 'ಉಪನಿಷತ್ / ವೇದಾಂತ');
  const [globalLevel1Name, setGlobalLevel1Name] = useState(units[0]?.structuralHierarchy?.level1Name || '');
  const [globalLevel2Name, setGlobalLevel2Name] = useState(units[0]?.structuralHierarchy?.level2Name || '');
  const [globalLevel3Name, setGlobalLevel3Name] = useState(units[0]?.structuralHierarchy?.level3Name || 'ಮಂತ್ರ');

  // Single unit inline editing
  const [editingUnitId, setEditingUnitId] = useState<string | null>(null);
  const [editHeadValue, setEditHeadValue] = useState('');
  const [editSubheadValue, setEditSubheadValue] = useState('');
  const [editSectionName, setEditSectionName] = useState('');
  const [editFormattedNumber, setEditFormattedNumber] = useState('');
  const [editUnitType, setEditUnitType] = useState<string>('MANTRA');

  // Saving states
  const [isSavingBatch, setIsSavingBatch] = useState(false);
  const [isSavingUnit, setIsSavingUnit] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Load Table of Contents
  const loadToc = async () => {
    setIsLoadingToc(true);
    try {
      const res = await safeFetchJson<GranthaTableOfContents>(`/api/projects/${project.id}/table-of-contents`);
      if (res.ok && res.data) {
        setTocData(res.data);
        if (res.data.level1Name && !globalLevel1Name) {
          setGlobalLevel1Name(res.data.level1Name);
        }
      }
    } catch (err) {
      console.error('Error loading TOC:', err);
    } finally {
      setIsLoadingToc(false);
    }
  };

  useEffect(() => {
    loadToc();
  }, [project.id, units.length]);

  // Handle Global Grantha Structure Update across all units
  const handleSaveGlobalStructure = async () => {
    setIsSavingBatch(true);
    setStatusMessage(null);
    try {
      const res = await fetch(`/api/projects/${project.id}/update-structure-schema`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          workTitle: globalWorkTitle.trim(),
          genre: globalGenre.trim(),
          level1Name: globalLevel1Name.trim(),
          level2Name: globalLevel2Name.trim(),
          level3Name: globalLevel3Name.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to update structure');

      setStatusMessage({
        type: 'success',
        text: `ಗ್ರಂಥದ ಶೀರ್ಷಿಕೆ ಮತ್ತು ಶ್ರೇಣಿ ವಿಭಾಗಗಳು (${data.updatedUnitsCount || units.length} ಶ್ಲೋಕಗಳಿಗೆ) ಯಶಸ್ವಿಯಾಗಿ ಅಪ್ಡೇಟ್ ಆಗಿವೆ!`,
      });
      await loadToc();
      onProjectUpdated();
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: `ದೋಷ: ${err.message}` });
    } finally {
      setIsSavingBatch(false);
    }
  };

  // Start inline edit for a unit
  const startEditUnit = (unit: SanskritUnit) => {
    setEditingUnitId(unit.id);
    setEditHeadValue(String(unit.structuralHierarchy?.level1Value || ''));
    setEditSubheadValue(String(unit.structuralHierarchy?.level2Value || ''));
    setEditSectionName(unit.structuralHierarchy?.sectionName || '');
    setEditFormattedNumber(unit.structuralHierarchy?.formattedNumber || '');
    setEditUnitType(unit.unitType || 'MANTRA');
  };

  // Save inline edit for a unit
  const handleSaveSingleUnit = async (unit: SanskritUnit) => {
    setIsSavingUnit(true);
    try {
      const updatedHierarchy = {
        ...unit.structuralHierarchy,
        level1Name: globalLevel1Name || unit.structuralHierarchy?.level1Name || '',
        level1Value: editHeadValue.trim() || undefined,
        level2Name: globalLevel2Name || unit.structuralHierarchy?.level2Name || undefined,
        level2Value: editSubheadValue.trim() || undefined,
        sectionName: editSectionName.trim() || undefined,
        formattedNumber: editFormattedNumber.trim() || (editHeadValue ? `${editHeadValue}` : `ಸಂಖ್ಯೆ ${unit.unitIndex}`),
      };

      const res = await fetch(`/api/units/${unit.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          structuralHierarchy: updatedHierarchy,
          unitType: editUnitType,
        }),
      });

      if (!res.ok) throw new Error('Failed to update verse');

      setEditingUnitId(null);
      await loadToc();
      onProjectUpdated();
      setStatusMessage({ type: 'success', text: `ಶ್ಲೋಕ ${unit.unitIndex} ನ ಶೀರ್ಷಿಕೆ/ಉಪಶೀರ್ಷಿಕೆ ಅಪ್ಡೇಟ್ ಆಗಿದೆ.` });
    } catch (err: any) {
      alert(`ದೋಷ: ${err.message}`);
    } finally {
      setIsSavingUnit(false);
    }
  };

  // Filtered entries for table view
  const filteredUnits = units.filter((u) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      (u.originalText || '').toLowerCase().includes(q) ||
      (u.structuralHierarchy?.formattedNumber || '').toLowerCase().includes(q) ||
      (u.structuralHierarchy?.sectionName || '').toLowerCase().includes(q) ||
      (u.firstMeaningfulWord || '').toLowerCase().includes(q)
    );
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-2xl border border-[#E8DFC9] max-w-6xl w-full max-h-[92vh] flex flex-col shadow-2xl overflow-hidden font-sans">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 bg-[#FAF7F2] border-b border-[#E8DFC9] flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#8B1E0F] to-[#5C140A] text-white flex items-center justify-center shadow-xs">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2 flex-wrap">
                <h3 className="font-serif font-bold text-lg text-[#1F1916]">
                  ಗ್ರಂಥ ಶೀರ್ಷಿಕಾನುಕ್ರಮಣಿಕಾ & ವಿಭಾಗ ನಿರ್ವಹಣೆ (Master Index & Hierarchy Editor)
                </h3>
                <span className="text-xs px-2.5 py-0.5 rounded-full font-bold bg-[#8B1E0F]/10 text-[#8B1E0F] border border-[#8B1E0F]/20 font-kannada">
                  {units.length} ಶ್ಲೋಕಗಳು / ಮಂತ್ರಗಳು
                </span>
              </div>
              <p className="text-xs text-[#7A695D] font-kannada mt-0.5">
                ಗ್ರಂಥದ ಪ್ರಧಾನ ಶೀರ್ಷಿಕೆ (Head), ಉಪಶೀರ್ಷಿಕೆ (Sub-head), ಮಂತ್ರ ಶ್ರೇಣಿ ಹಾಗೂ ಅನುಕ್ರಮಣಿಕೆಯನ್ನು ನಿಮ್ಮ ಇಚ್ಛೆಯಂತೆ ಪರಿಷ್ಕರಿಸಿ ನಂತರ ಮುಂದುವರಿಯಿರಿ.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl hover:bg-[#EADBCE] text-[#7A695D] transition-colors"
            title="ಮುಚ್ಚಿ (Close)"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-[#E8DFC9] bg-[#FAF8F5] px-4 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('MASTER_INDEX')}
            className={`py-3 px-4 border-b-2 transition-all flex items-center space-x-2 ${
              activeTab === 'MASTER_INDEX'
                ? 'border-[#8B1E0F] text-[#8B1E0F] bg-white font-bold'
                : 'border-transparent text-[#7A695D] hover:text-[#1F1916]'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>೧. ಮಾಸ್ಟರ್ ಇಂಡೆಕ್ಸ್ ವೀಕ್ಷಣೆ (Master Index / TOC)</span>
          </button>
          <button
            onClick={() => setActiveTab('STRUCTURE_EDITOR')}
            className={`py-3 px-4 border-b-2 transition-all flex items-center space-x-2 ${
              activeTab === 'STRUCTURE_EDITOR'
                ? 'border-[#8B1E0F] text-[#8B1E0F] bg-white font-bold'
                : 'border-transparent text-[#7A695D] hover:text-[#1F1916]'
            }`}
          >
            <Sliders className="w-4 h-4" />
            <span>೨. ಸಾರ್ವತ್ರಿಕ ಶ್ರೇಣಿ ನಿಯಮಗಳು (Global Head & Sub-head Settings)</span>
          </button>
          <button
            onClick={() => setActiveTab('BATCH_CONFIG')}
            className={`py-3 px-4 border-b-2 transition-all flex items-center space-x-2 ${
              activeTab === 'BATCH_CONFIG'
                ? 'border-[#8B1E0F] text-[#8B1E0F] bg-white font-bold'
                : 'border-transparent text-[#7A695D] hover:text-[#1F1916]'
            }`}
          >
            <Edit3 className="w-4 h-4" />
            <span>೩. ಪ್ರತಿ ಶ್ಲೋಕದ ಶೀರ್ಷಿಕೆ ಸಂಪಾದನೆ (Individual Verse Headings)</span>
          </button>
        </div>

        {/* Status Notification Banner */}
        {statusMessage && (
          <div
            className={`px-4 py-2 text-xs font-medium flex items-center justify-between ${
              statusMessage.type === 'success'
                ? 'bg-emerald-50 text-emerald-800 border-b border-emerald-200'
                : 'bg-rose-50 text-rose-800 border-b border-rose-200'
            }`}
          >
            <div className="flex items-center space-x-1.5">
              {statusMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-600" />
              )}
              <span>{statusMessage.text}</span>
            </div>
            <button onClick={() => setStatusMessage(null)} className="text-stone-400 hover:text-stone-600">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 bg-[#FCFAF7] space-y-6">
          {/* TAB 1: MASTER INDEX (TOC) */}
          {activeTab === 'MASTER_INDEX' && (
            <div className="space-y-4">
              {/* Summary Header Card */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-[#FAF2EF] to-[#F5ECE5] border border-[#E8DFC9] flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <span className="text-[11px] font-bold text-[#8B1E0F] uppercase tracking-wider">
                    ದೃಢೀಕೃತ ಗ್ರಂಥ (Detected Grantha)
                  </span>
                  <h4 className="font-serif text-xl font-bold text-[#1F1916]">
                    {globalWorkTitle || 'ಗರ್ಭೋಪನಿಷತ್'}
                  </h4>
                  <p className="text-xs text-[#7A695D] font-kannada">
                    ಪ್ರಕಾರ: <span className="font-bold text-[#4A3B31]">{globalGenre}</span> • ವಿಭಾಗ ಮಾದರಿ:{' '}
                    <span className="font-bold text-[#4A3B31]">
                      {globalLevel1Name ? `${globalLevel1Name} → ` : ''}
                      {globalLevel2Name ? `${globalLevel2Name} → ` : ''}
                      {globalLevel3Name || 'ಮಂತ್ರ'}
                    </span>
                  </p>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setActiveTab('STRUCTURE_EDITOR')}
                    className="flex items-center space-x-1.5 px-3 py-2 rounded-lg bg-white hover:bg-[#FAF8F5] border border-[#DDD5C9] text-xs font-semibold text-[#634E42] shadow-xs"
                  >
                    <Sliders className="w-3.5 h-3.5 text-[#8B1E0F]" />
                    <span>ಹೆಡ್ / ಸಬ್‌ಹೆಡ್ ಬದಲಿಸಿ</span>
                  </button>
                  {onStartProcessing && (
                    <button
                      onClick={() => {
                        onClose();
                        onStartProcessing();
                      }}
                      className="flex items-center space-x-1.5 px-4 py-2 rounded-lg bg-[#8B1E0F] hover:bg-[#A32312] text-white text-xs font-bold shadow-sm"
                    >
                      <BookOpen className="w-3.5 h-3.5" />
                      <span>ಗ್ರಂಥ ರಚನೆ ಪ್ರಾರಂಭಿಸಿ (Generate Grantha)</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Structure Summary Table */}
              <div className="bg-white border border-[#E8E2D9] rounded-xl overflow-hidden shadow-xs">
                <div className="p-3 bg-[#FAF7F2] border-b border-[#E8DFC9] flex items-center justify-between">
                  <h5 className="font-serif text-xs font-bold text-[#1F1916] flex items-center">
                    <Layers className="w-4 h-4 mr-1.5 text-[#8B1E0F]" />
                    ಗ್ರಂಥ ರಚನಾ ಪ್ರಕಾರ / ವಿವರ (Grantha Structural Summary)
                  </h5>
                </div>
                <table className="w-full text-left text-xs border-collapse font-kannada">
                  <thead>
                    <tr className="bg-[#FAF8F5] text-[#5C4D43] border-b border-[#EAE4DC] font-serif">
                      <th className="p-3 font-bold">ಗ್ರಂಥ ರಚನಾ ಪ್ರಕಾರ / ವಿವರ (Structure Type)</th>
                      <th className="p-3 font-bold text-center w-36">ದೃಢೀಕೃತ ಸಂಖ್ಯೆ (Count)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#F0EBE4] text-[#1F1916]">
                    <tr>
                      <td className="p-3 font-medium">
                        {globalLevel1Name ? `${globalLevel1Name}ಗಳು / ಪ್ರಧಾನ ವಿಭಾಗಗಳು (${globalLevel1Name}s / Divisions)` : 'ಅಧ್ಯಾಯಗಳು / ಪ್ರಧಾನ ವಿಭಾಗಗಳು (Chapters / Divisions)'}
                      </td>
                      <td className="p-3 text-center font-mono font-bold text-[#8B1E0F]">
                        {tocData?.summaryStats?.totalChaptersCount || 1}
                      </td>
                    </tr>
                    {(tocData?.summaryStats?.totalKhandasCount || 0) > 0 && (
                      <tr>
                        <td className="p-3 font-medium">
                          {globalLevel2Name ? `${globalLevel2Name}ಗಳು / ಉಪವಿಭಾಗಗಳು (${globalLevel2Name}s / Sub-heads)` : 'ಖಂಡಗಳು / ಉಪವಿಭಾಗಗಳು (Khandas / Sub-heads)'}
                        </td>
                        <td className="p-3 text-center font-mono font-bold text-[#8B1E0F]">
                          {tocData?.summaryStats?.totalKhandasCount}
                        </td>
                      </tr>
                    )}
                    {(tocData?.summaryStats?.totalSectionsCount || 0) > 0 && (
                      <tr>
                        <td className="p-3 font-medium">
                          ಪ್ರಕರಣಗಳು / ವಿಷಯ ವಿಭಾಗಗಳು (Sections / Topics)
                        </td>
                        <td className="p-3 text-center font-mono font-bold text-[#8B1E0F]">
                          {tocData?.summaryStats?.totalSectionsCount}
                        </td>
                      </tr>
                    )}
                    <tr className="bg-[#FAF8F5]">
                      <td className="p-3 font-bold text-[#8B1E0F]">
                        ಶ್ಲೋಕಗಳು / ಮಂತ್ರಗಳು (Shlokas / Mantras)
                      </td>
                      <td className="p-3 text-center font-mono font-bold text-[#8B1E0F] text-sm">
                        {units.length}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* TOC Table */}
              <div className="bg-white border border-[#E8E2D9] rounded-xl overflow-hidden shadow-xs">
                <div className="p-3.5 bg-[#FAF7F2] border-b border-[#E8DFC9] flex items-center justify-between">
                  <h5 className="font-serif text-xs font-bold text-[#1F1916] flex items-center">
                    <BookOpen className="w-4 h-4 mr-1.5 text-[#8B1E0F]" />
                    ಗ್ರಂಥ ಶೀರ್ಷಿಕಾನುಕ್ರಮಣಿಕಾ (Master Table of Contents: Heads, Sub-heads & What It Teaches)
                  </h5>
                  <span className="text-xs font-mono font-bold text-[#8B1E0F] bg-[#8B1E0F]/10 px-2 py-0.5 rounded border border-[#8B1E0F]/20">
                    ಒಟ್ಟು {tocData?.entries?.length || 1} ಪ್ರಮುಖ ವಿಭಾಗಗಳು
                  </span>
                </div>

                {isLoadingToc ? (
                  <div className="p-8 text-center text-xs text-[#7A695D]">
                    <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-[#8B1E0F]" />
                    ಅನುಕ್ರಮಣಿಕೆಯನ್ನು ಲೆಕ್ಕಿಸಲಾಗುತ್ತಿದೆ...
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-[#FAF8F5] text-[#5C4D43] border-b border-[#EAE4DC] font-serif">
                          <th className="p-3 font-bold text-center w-12">ಕ್ರ.ಸಂ.</th>
                          <th className="p-3 font-bold">
                            ಮುಖ್ಯ ವಿಭಾಗ (Head: {globalLevel1Name || 'ಅಧ್ಯಾಯ / ವಲ್ಲಿ / ಖಂಡ'})
                          </th>
                          {tocData?.hasLevel2 && (
                            <th className="p-3 font-bold">
                              ಉಪವಿಭಾಗ (Sub-heads: {tocData.level2Name || 'ಖಂಡ / ಸರ್ಗ'})
                            </th>
                          )}
                          <th className="p-3 font-bold">ವಿಷಯ ಮತ್ತು ಬೋಧಿಸುವ ತತ್ತ್ವಾರ್ಥ (Subject & What It Teaches)</th>
                          <th className="p-3 font-bold text-center">ಪುಟ</th>
                          <th className="p-3 font-bold text-center">ಕ್ರಿಯೆ</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#F0EBE4]">
                        {(tocData?.entries || []).map((entry, idx) => {
                          const firstUnitId = entry.unitIds?.[0];
                          const headTitle = entry.level1Name ? `${entry.level1Name} ${entry.level1Value || ''}` : `ಅಧ್ಯಾಯ ${idx + 1}`;
                          const subheadTitle = entry.subheadSummary || (entry.level2Name && entry.level2Value ? `${entry.level2Name} ${entry.level2Value}` : '—');
                          const teachingContent = entry.whatItTeaches || entry.topic || entry.sectionName || `${headTitle} ಉಪದೇಶ ಹಾಗೂ ತತ್ತ್ವಾರ್ಥ`;

                          return (
                            <tr
                              key={entry.slNo || idx}
                              className="hover:bg-[#FAF6F2] transition-colors"
                            >
                              <td className="p-3 text-center font-mono font-bold text-[#8B1E0F]">
                                {entry.slNo || idx + 1}
                              </td>
                              <td className="p-3 font-kannada font-bold text-[#2D231E]">
                                {headTitle}
                              </td>
                              {tocData?.hasLevel2 && (
                                <td className="p-3 font-kannada font-medium text-[#4A3B31]">
                                  {subheadTitle}
                                </td>
                              )}
                              <td className="p-3 font-kannada text-[#1F1916]">
                                <span className="font-semibold leading-relaxed">
                                  {teachingContent}
                                </span>
                              </td>
                              <td className="p-3 text-center font-mono text-[#7A695D]">
                                {entry.pageRange ? `ಪುಟ ${entry.pageRange}` : `ಪುಟ 1`}
                              </td>
                              <td className="p-3 text-center">
                                {firstUnitId && onSelectUnit && (
                                  <button
                                    onClick={() => {
                                      onSelectUnit(firstUnitId);
                                      onClose();
                                    }}
                                    className="px-2.5 py-1 rounded bg-[#FAF7F2] hover:bg-[#8B1E0F] hover:text-white border border-[#DDD5C9] text-[11px] font-bold text-[#8B1E0F] transition-all"
                                  >
                                    ವೀಕ್ಷಿಸಿ →
                                  </button>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: GLOBAL HEAD & SUB-HEAD SETTINGS */}
          {activeTab === 'STRUCTURE_EDITOR' && (
            <div className="space-y-6 max-w-3xl mx-auto">
              <div className="p-4 rounded-xl bg-[#FAF7F2] border border-[#E8DFC9]">
                <h4 className="font-serif text-sm font-bold text-[#1F1916] mb-1 flex items-center">
                  <Sliders className="w-4 h-4 mr-1.5 text-[#8B1E0F]" />
                  ಸಮಗ್ರ ಗ್ರಂಥ ಶ್ರೇಣಿ ವಿಭಾಗ ನಿಯಮಗಳು (Global Head & Sub-head Schema)
                </h4>
                <p className="text-xs text-[#7A695D] font-kannada">
                  ಇಲ್ಲಿ ನೀವು ನಮೂದಿಸುವ ಮುಖ್ಯ ಶೀರ್ಷಿಕೆ (Head) ಮತ್ತು ಉಪಶೀರ್ಷಿಕೆ (Sub-head) ನಿಯಮಗಳು ಈ ಗ್ರಂಥದ ಎಲ್ಲಾ ಶ್ಲೋಕಗಳಿಗೆ ಮತ್ತು ರಫ್ತು ಮಾಡಲಾಗುವ Word (DOCX) ಗ್ರಂಥಕ್ಕೆ ಅನ್ವಯಿಸುತ್ತವೆ.
                </p>
              </div>

              <div className="bg-white p-6 rounded-xl border border-[#E8E2D9] space-y-4 shadow-xs">
                {/* Grantha Title */}
                <div>
                  <label className="block text-xs font-bold text-[#1F1916] mb-1">
                    ೧. ಗ್ರಂಥದ ಪೂರ್ಣ ಹೆಸರು / ಶೀರ್ಷಿಕೆ (Grantha Work Title):
                  </label>
                  <input
                    type="text"
                    value={globalWorkTitle}
                    onChange={(e) => setGlobalWorkTitle(e.target.value)}
                    placeholder="ಉದಾ: ಗರ್ಭೋಪನಿಷತ್ (Garbha Upanishad) ಅಥವಾ ಶ್ರೀಮದ್ಭಗವದ್ಗೀತಾ"
                    className="w-full p-2.5 rounded-lg border border-[#DDD5C9] text-xs font-kannada focus:outline-none focus:border-[#8B1E0F] bg-[#FAF8F5]"
                  />
                  <p className="text-[11px] text-[#7A695D] mt-1">
                    ಇದು ಗ್ರಂಥದ ಮುಖಪುಟ, ಹೆಡರ್ ಮತ್ತು ಎಲ್ಲಾ ಶ್ಲೋಕಗಳ ಶೀರ್ಷಿಕೆಯಲ್ಲಿ ಕಾಣಿಸಿಕೊಳ್ಳುತ್ತದೆ.
                  </p>
                </div>

                {/* Genre */}
                <div>
                  <label className="block text-xs font-bold text-[#1F1916] mb-1">
                    ೨. ಸಾಹಿತ್ಯಿಕ ಪ್ರಕಾರ (Genre / Grantha Type):
                  </label>
                  <select
                    value={globalGenre}
                    onChange={(e) => setGlobalGenre(e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-[#DDD5C9] text-xs font-kannada focus:outline-none focus:border-[#8B1E0F] bg-[#FAF8F5]"
                  >
                    <option value="ಉಪನಿಷತ್ / ವೇದಾಂತ">ಉಪನಿಷತ್ / ವೇದಾಂತ (Upanishad / Vedanta)</option>
                    <option value="ಗೀತಾ ಶಾಸ್ತ್ರ">ಗೀತಾ ಶಾಸ್ತ್ರ (Gita Shastra)</option>
                    <option value="ಸ್ತೋತ್ರ ಸಾಹಿತ್ಯ">ಸ್ತೋತ್ರ ಸಾಹಿತ್ಯ (Stotra Literature)</option>
                    <option value="ಮಹಾಕಾವ್ಯ / ಪುರಾಣ">ಮಹಾಕಾವ್ಯ / ಪುರಾಣ (Mahakavya / Purana)</option>
                    <option value="ಸೂತ್ರ / ಭಾಷ್ಯ ಗ್ರಂಥ">ಸೂತ್ರ / ಭಾಷ್ಯ ಗ್ರಂಥ (Sutra / Bhashya)</option>
                    <option value="ಶಾಸ್ತ್ರೀಯ ಸಂಸ್ಕೃತ ಸಾಹಿತ್ಯ">ಶಾಸ್ತ್ರೀಯ ಸಂಸ್ಕೃತ ಸಾಹಿತ್ಯ (Classical Sanskrit)</option>
                  </select>
                </div>

                {/* Level 1 Division (Head) */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-[#1F1916] mb-1">
                      ೩. ಪ್ರಧಾನ ಶೀರ್ಷಿಕೆ / ವಿಭಾಗ (Head - Level 1):
                    </label>
                    <input
                      type="text"
                      value={globalLevel1Name}
                      onChange={(e) => setGlobalLevel1Name(e.target.value)}
                      placeholder="ಉದಾ: ಅಧ್ಯಾಯ, ಕಾಂಡ, ಪರ್ವ, ವಲ್ಲಿ (ಅಥವಾ ಖಾಲಿ ಬಿಡಿ)"
                      className="w-full p-2.5 rounded-lg border border-[#DDD5C9] text-xs font-kannada focus:outline-none focus:border-[#8B1E0F] bg-[#FAF8F5]"
                    />
                    <span className="text-[10px] text-[#7A695D]">
                      ಉದಾ: 'ಅಧ್ಯಾಯ', 'ವಲ್ಲಿ', 'ಕಾಂಡ' (ಯಾವುದೇ ವಿಭಾಗಗಳಿಲ್ಲದಿದ್ದರೆ ಖಾಲಿ ಬಿಡಿ).
                    </span>
                  </div>

                  {/* Level 2 Division (Sub-head) */}
                  <div>
                    <label className="block text-xs font-bold text-[#1F1916] mb-1">
                      ೪. ಉಪಶೀರ್ಷಿಕೆ / ಉಪವಿಭಾಗ (Sub-head - Level 2):
                    </label>
                    <input
                      type="text"
                      value={globalLevel2Name}
                      onChange={(e) => setGlobalLevel2Name(e.target.value)}
                      placeholder="ಉದಾ: ಸರ್ಗ, ಖಂಡ, ಅನುವಾಕ, ಸೂಕ್ತ (ಅಥವಾ ಖಾಲಿ ಬಿಡಿ)"
                      className="w-full p-2.5 rounded-lg border border-[#DDD5C9] text-xs font-kannada focus:outline-none focus:border-[#8B1E0F] bg-[#FAF8F5]"
                    />
                    <span className="text-[10px] text-[#7A695D]">
                      ಉದಾ: 'ಸರ್ಗ', 'ಖಂಡ', 'ಸೂಕ್ತ' (ಅಥವಾ ಖಾಲಿ ಬಿಡಿ).
                    </span>
                  </div>
                </div>

                {/* Level 3 Unit Name (Verse / Mantra) */}
                <div>
                  <label className="block text-xs font-bold text-[#1F1916] mb-1">
                    ೫. ಘಟಕ ನಾಮ (Unit Name - Level 3):
                  </label>
                  <div className="flex items-center space-x-3">
                    {['ಮಂತ್ರ', 'ಶ್ಲೋಕ', 'ಗದ್ಯ ಭಾಗ', 'ಸೂತ್ರ'].map((name) => (
                      <button
                        key={name}
                        type="button"
                        onClick={() => setGlobalLevel3Name(name)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                          globalLevel3Name === name
                            ? 'bg-[#8B1E0F] text-white border-[#8B1E0F]'
                            : 'bg-[#FAF8F5] text-[#5C4D43] border-[#DDD5C9] hover:bg-[#F3ECE4]'
                        }`}
                      >
                        {name}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Save Button */}
                <div className="pt-4 border-t border-[#EAE4DC] flex justify-end">
                  <button
                    onClick={handleSaveGlobalStructure}
                    disabled={isSavingBatch}
                    className="flex items-center space-x-2 px-5 py-2.5 rounded-lg bg-[#8B1E0F] hover:bg-[#A32312] text-white text-xs font-bold shadow-sm transition-all disabled:opacity-50"
                  >
                    <Save className="w-4 h-4" />
                    <span>
                      {isSavingBatch ? 'ಅಪ್ಡೇಟ್ ಮಾಡಲಾಗುತ್ತಿದೆ...' : 'ಸಮಗ್ರ ಗ್ರಂಥಕ್ಕೆ ಅನ್ವಯಿಸಿ (Apply to All Verses)'}
                    </span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: INDIVIDUAL VERSE HEADINGS */}
          {activeTab === 'BATCH_CONFIG' && (
            <div className="space-y-4">
              {/* Search Bar */}
              <div className="flex items-center justify-between gap-4 flex-wrap">
                <div className="relative max-w-md w-full">
                  <Search className="w-4 h-4 absolute left-3 top-2.5 text-[#A39286]" />
                  <input
                    type="text"
                    placeholder="ಶ್ಲೋಕ ಅಥವಾ ಸಂಖ್ಯೆ ಹುಡುಕಿ..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 rounded-lg border border-[#DDD5C9] text-xs bg-white focus:outline-none focus:border-[#8B1E0F]"
                  />
                </div>
                <span className="text-xs text-[#7A695D] font-mono">
                  {filteredUnits.length} / {units.length} ಘಟಕಗಳು
                </span>
              </div>

              {/* List of Units for Detailed Editing */}
              <div className="space-y-3">
                {filteredUnits.map((u, idx) => {
                  const isEditing = editingUnitId === u.id;
                  const h = u.structuralHierarchy || {};

                  return (
                    <div
                      key={u.id}
                      className={`p-4 rounded-xl border transition-all ${
                        isEditing
                          ? 'bg-white border-[#8B1E0F] ring-2 ring-[#8B1E0F]/20 shadow-md'
                          : 'bg-white border-[#E8E2D9] hover:border-[#DDD5C9] shadow-xs'
                      }`}
                    >
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-2 border-b border-[#F0EBE4] mb-3">
                        <div className="flex items-center space-x-2.5">
                          <span className="w-7 h-7 rounded-lg bg-[#8B1E0F] text-white flex items-center justify-center font-mono font-bold text-xs">
                            {u.unitIndex}
                          </span>
                          <div>
                            <span className="font-kannada font-bold text-xs text-[#1F1916]">
                              {h.level1Name ? `${h.level1Name} ${h.level1Value || ''} • ` : ''}
                              {h.level2Name ? `${h.level2Name} ${h.level2Value || ''} • ` : ''}
                              {h.formattedNumber || `ಸಂಖ್ಯೆ ${u.unitIndex}`}
                            </span>
                            <span className="text-[11px] text-[#7A695D] ml-2 font-mono">
                              (ಪುಟ {u.pageNumber})
                            </span>
                          </div>
                        </div>

                        {!isEditing ? (
                          <button
                            onClick={() => startEditUnit(u)}
                            className="flex items-center space-x-1 px-3 py-1 rounded-lg bg-[#FAF7F2] hover:bg-[#F3ECE4] border border-[#DDD5C9] text-xs font-semibold text-[#8B1E0F]"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>ಶೀರ್ಷಿಕೆ / ಸಂಖ್ಯೆ ಬದಲಿಸಿ</span>
                          </button>
                        ) : (
                          <div className="flex items-center space-x-2">
                            <button
                              onClick={() => setEditingUnitId(null)}
                              className="px-3 py-1 rounded-lg bg-stone-100 hover:bg-stone-200 text-xs font-medium text-stone-700"
                            >
                              ರದ್ದು (Cancel)
                            </button>
                            <button
                              onClick={() => handleSaveSingleUnit(u)}
                              disabled={isSavingUnit}
                              className="flex items-center space-x-1 px-3 py-1 rounded-lg bg-[#8B1E0F] hover:bg-[#A32312] text-white text-xs font-bold shadow-xs"
                            >
                              <Save className="w-3.5 h-3.5" />
                              <span>ಉಳಿಸಿ (Save)</span>
                            </button>
                          </div>
                        )}
                      </div>

                      {/* Sanskrit Preview */}
                      <p className="font-devanagari text-xs text-[#2A231E] leading-relaxed mb-3">
                        {u.originalText}
                      </p>

                      {/* Inline Edit Form */}
                      {isEditing && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 p-3 bg-[#FAF8F5] rounded-lg border border-[#E8DFC9] text-xs">
                          <div>
                            <label className="block text-[11px] font-bold text-[#5C4D43] mb-1">
                              ಪ್ರಧಾನ ಹೆಡ್ ಮೌಲ್ಯ (Head Value):
                            </label>
                            <input
                              type="text"
                              value={editHeadValue}
                              onChange={(e) => setEditHeadValue(e.target.value)}
                              placeholder="ಉದಾ: 1 ಅಥವಾ ಶಾಂತಿ ಪಾಠ"
                              className="w-full p-1.5 rounded border border-[#DDD5C9] bg-white font-kannada"
                            />
                          </div>

                          <div>
                            <label className="block text-[11px] font-bold text-[#5C4D43] mb-1">
                              ಉಪಶೀರ್ಷಿಕೆ ಮೌಲ್ಯ (Sub-head Value):
                            </label>
                            <input
                              type="text"
                              value={editSubheadValue}
                              onChange={(e) => setEditSubheadValue(e.target.value)}
                              placeholder="ಉದಾ: 2 ಅಥವಾ ಖಂಡ 1"
                              className="w-full p-1.5 rounded border border-[#DDD5C9] bg-white font-kannada"
                            />
                          </div>

                          <div>
                            <label className="block text-[11px] font-bold text-[#5C4D43] mb-1">
                              ಘಟಕ ವಿಧ (Unit Type):
                            </label>
                            <select
                              value={editUnitType}
                              onChange={(e) => setEditUnitType(e.target.value)}
                              className="w-full p-1.5 rounded border border-[#DDD5C9] bg-white font-kannada"
                            >
                              <option value="MANTRA">ಮಂತ್ರ (Mantra)</option>
                              <option value="SHANTI_MANTRA">ಶಾಂತಿ ಮಂತ್ರ (Shanti Mantra)</option>
                              <option value="SHLOKA">ಶ್ಲೋಕ (Shloka)</option>
                              <option value="GADYA">ಗದ್ಯ (Gadya)</option>
                              <option value="COLOPHON">ಪುಷ್ಪಿಕಾ (Colophon)</option>
                            </select>
                          </div>

                          <div>
                            <label className="block text-[11px] font-bold text-[#5C4D43] mb-1">
                              ಕಸ್ಟಮ್ ಗುರುತು (Display Number):
                            </label>
                            <input
                              type="text"
                              value={editFormattedNumber}
                              onChange={(e) => setEditFormattedNumber(e.target.value)}
                              placeholder="ಉದಾ: || 1 || ಅಥವಾ ಶಾಂತಿ ಮಂತ್ರ"
                              className="w-full p-1.5 rounded border border-[#DDD5C9] bg-white font-kannada"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-[#FAF7F2] border-t border-[#E8DFC9] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center space-x-2 text-xs text-[#7A695D]">
            <HelpCircle className="w-4 h-4 text-[#8B1E0F]" />
            <span>
              ಇಲ್ಲಿ ಶೀರ್ಷಿಕೆಗಳನ್ನು ಖಚಿತಪಡಿಸಿಕೊಂಡ ನಂತರ <strong>'ಗ್ರಂಥ ರಚನೆ'</strong> ಬಟನ್ ಒತ್ತಿ ಸಂಸ್ಕರಣೆಯನ್ನು ಆರಂಭಿಸಬಹುದು.
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-stone-200 hover:bg-stone-300 text-stone-800 text-xs font-semibold"
            >
              ಮುಚ್ಚಿ (Close)
            </button>
            {onStartProcessing && (
              <button
                onClick={() => {
                  onClose();
                  onStartProcessing();
                }}
                className="flex items-center space-x-1.5 px-5 py-2 rounded-lg bg-[#8B1E0F] hover:bg-[#A32312] text-white text-xs font-bold shadow-sm"
              >
                <BookOpen className="w-4 h-4" />
                <span>ಗ್ರಂಥ ರಚನೆ ಪ್ರಾರಂಭಿಸಿ (Start Grantha Generation)</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
