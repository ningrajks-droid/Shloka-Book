import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  X,
  Play,
  RotateCw,
  CheckCircle2,
  AlertCircle,
  Terminal,
  BookOpen,
  Layers,
  Zap,
} from 'lucide-react';
import { SanskritUnit } from '../types';

interface LiveStreamDrawerProps {
  unit: SanskritUnit | null;
  isOpen: boolean;
  onClose: () => void;
  onUnitUpdated: (updatedUnit: SanskritUnit) => void;
}

export const LiveStreamDrawer: React.FC<LiveStreamDrawerProps> = ({
  unit,
  isOpen,
  onClose,
  onUnitUpdated,
}) => {
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamStatus, setStreamStatus] = useState<string>('');
  const [liveRawText, setLiveRawText] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [completedUnit, setCompletedUnit] = useState<SanskritUnit | null>(null);
  const eventSourceRef = useRef<EventSource | null>(null);
  const preContainerRef = useRef<HTMLPreElement>(null);

  useEffect(() => {
    if (isOpen && unit) {
      setLiveRawText('');
      setError(null);
      setCompletedUnit(null);
      startStream(unit.id);
    }
    return () => {
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
      }
    };
  }, [isOpen, unit?.id]);

  useEffect(() => {
    if (preContainerRef.current) {
      preContainerRef.current.scrollTop = preContainerRef.current.scrollHeight;
    }
  }, [liveRawText]);

  const startStream = (unitId: string) => {
    if (eventSourceRef.current) {
      eventSourceRef.current.close();
    }

    setIsStreaming(true);
    setError(null);
    setLiveRawText('');
    setStreamStatus('ಸಂಪರ್ಕ ಸಾಧಿಸಲಾಗುತ್ತಿದೆ (Connecting)...');

    const es = new EventSource(`/api/units/${unitId}/stream`);
    eventSourceRef.current = es;

    es.addEventListener('status', (e: any) => {
      try {
        const data = JSON.parse(e.data);
        setStreamStatus(data.message || 'ಪ್ರಕ್ರಿಯೆ ನಡೆಯುತ್ತಿದೆ...');
      } catch {
        // Ignore
      }
    });

    es.addEventListener('chunk', (e: any) => {
      try {
        const data = JSON.parse(e.data);
        if (data.fullTextSoFar) {
          setLiveRawText(data.fullTextSoFar);
        } else if (data.chunk) {
          setLiveRawText((prev) => prev + data.chunk);
        }
      } catch {
        // Ignore
      }
    });

    es.addEventListener('complete', (e: any) => {
      try {
        const data = JSON.parse(e.data);
        if (data.unit) {
          setCompletedUnit(data.unit);
          onUnitUpdated(data.unit);
          setStreamStatus('ಸಂಸ್ಕರಣೆ ಸಂಪೂರ್ಣವಾಗಿದೆ! (Completed)');
        }
      } catch {
        // Ignore
      }
      setIsStreaming(false);
      es.close();
    });

    es.addEventListener('error', (e: any) => {
      try {
        if (e.data) {
          const data = JSON.parse(e.data);
          setError(data.error || 'ಸ್ಟ್ರೀಮಿಂಗ್ ದೋಷ ಸಂಭವಿಸಿದೆ');
        } else {
          setError('ಸರ್ವರ್ ಸಂಪರ್ಕ ಕಡಿತಗೊಂಡಿದೆ');
        }
      } catch {
        setError('ಸ್ಟ್ರೀಮಿಂಗ್ ದೋಷ ಸಂಭವಿಸಿದೆ');
      }
      setIsStreaming(false);
      es.close();
    });
  };

  if (!isOpen || !unit) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/50 backdrop-blur-xs flex justify-end animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-[#FCFAF7] h-full shadow-2xl flex flex-col border-l border-[#E8DFC9]">
        {/* Top Header */}
        <div className="p-4 bg-[#8B1E0F] text-white flex items-center justify-between shadow-md">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-lg bg-white/10 text-amber-300">
              <Zap className={`w-5 h-5 ${isStreaming ? 'animate-bounce' : ''}`} />
            </div>
            <div>
              <h2 className="font-bold text-base font-kannada flex items-center space-x-2">
                <span>AI ಲೈವ್ ಸ್ಟ್ರೀಮಿಂಗ್ ಸಂಸ್ಕರಣೆ</span>
                {isStreaming && (
                  <span className="px-2 py-0.5 text-[10px] font-mono uppercase bg-amber-400 text-black font-bold rounded-full animate-pulse">
                    LIVE
                  </span>
                )}
              </h2>
              <p className="text-xs text-white/80 font-mono">
                {unit.detectedWork} • ಶ್ಲೋಕ {unit.structuralHierarchy.formattedNumber || unit.unitIndex}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-white/10 text-white/80 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Status Bar */}
        <div className="bg-[#FAF4EB] border-b border-[#E8DFC9] px-5 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <RotateCw
              className={`w-4 h-4 text-[#8B1E0F] ${isStreaming ? 'animate-spin' : ''}`}
            />
            <span className="text-xs font-semibold text-[#8B1E0F] font-kannada">
              {streamStatus || (isStreaming ? 'AI ಡೇಟಾ ಬರೆಯುತ್ತಿದೆ...' : 'ಸಿದ್ಧವಾಗಿದೆ')}
            </span>
          </div>

          {!isStreaming && (
            <button
              onClick={() => startStream(unit.id)}
              className="flex items-center space-x-1.5 px-3 py-1 bg-[#8B1E0F] hover:bg-[#A32312] text-white text-xs font-medium rounded-md transition-colors"
            >
              <RotateCw className="w-3.5 h-3.5" />
              <span>ಮರು-ಸ್ಟ್ರೀಮ್ ಆರಂಭಿಸಿ</span>
            </button>
          )}
        </div>

        {/* Stream Content Area */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4 font-sans">
          {/* Source Shloka Card */}
          <div className="p-3.5 rounded-lg bg-white border border-[#E8DFC9] shadow-xs">
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#7A695D] block mb-1">
              ಮೂಲ ಸಂಸ್ಕೃತ ಪಠ್ಯ (Source Sanskrit Text)
            </span>
            <pre className="font-devanagari text-sm font-semibold text-[#1F1916] whitespace-pre-wrap leading-relaxed">
              {unit.originalText}
            </pre>
          </div>

          {/* Error Banner */}
          {error && (
            <div className="p-3.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start space-x-2">
              <AlertCircle className="w-4 h-4 text-rose-600 mt-0.5 shrink-0" />
              <div>
                <p className="font-bold">ಸ್ಟ್ರೀಮಿಂಗ್ ವಿಫಲವಾಗಿದೆ:</p>
                <p>{error}</p>
              </div>
            </div>
          )}

          {/* Live Streaming Terminal / Stream Card */}
          <div className="bg-[#181412] text-[#F3ECE4] rounded-xl p-4 shadow-inner border border-[#3A2E28] font-mono text-xs relative">
            <div className="flex items-center justify-between pb-2 mb-3 border-b border-[#3A2E28] text-[#9A897D] text-[11px]">
              <div className="flex items-center space-x-2">
                <Terminal className="w-3.5 h-3.5 text-amber-400" />
                <span>AI Live Generation Stream (SSE)</span>
              </div>
              <span>{liveRawText.length} characters</span>
            </div>

            {liveRawText ? (
              <pre
                ref={preContainerRef}
                className="whitespace-pre-wrap font-sans text-xs text-[#EAE2D8] leading-relaxed max-h-72 overflow-y-auto pr-2 scrollbar-thin select-text"
              >
                {liveRawText}
                {isStreaming && <span className="inline-block w-2 h-4 bg-amber-400 animate-pulse ml-1 align-middle" />}
              </pre>
            ) : isStreaming ? (
              <div className="py-8 text-center text-[#9A897D] space-y-2">
                <Sparkles className="w-6 h-6 text-amber-400 mx-auto animate-spin" />
                <p className="font-kannada">AI ವಿದ್ವತ್ ವ್ಯಾಖ್ಯಾನವನ್ನು ಲೈವ್ ಆಗಿ ರಚಿಸುತ್ತಿದೆ...</p>
              </div>
            ) : (
              <div className="py-6 text-center text-[#9A897D]">
                <span>ಸ್ಟ್ರೀಮಿಂಗ್ ಆರಂಭಿಸಲು ಮೇಲಿನ ಬಟನ್ ಒತ್ತಿ</span>
              </div>
            )}
          </div>

          {/* Rendered Live Preview of 5 Sections if Completed */}
          {completedUnit?.output && (
            <div className="space-y-4 pt-2 animate-in fade-in duration-300">
              <div className="flex items-center space-x-2 text-emerald-700 text-xs font-bold font-kannada">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>ಅಂತಿಮ ವಿದ್ವತ್ ಗ್ರಂಥ ಸ್ವರೂಪ ಸಿದ್ಧವಾಗಿದೆ:</span>
              </div>

              {/* 1. Moola */}
              <div className="p-4 bg-white rounded-lg border border-[#E8DFC9] shadow-xs">
                <span className="text-[11px] font-bold text-[#8B1E0F] uppercase block mb-1">
                  ೧. ಮೂಲ ಸಂಸ್ಕೃತ ಶ್ಲೋಕ
                </span>
                <p className="font-devanagari font-bold text-[#1F1916] whitespace-pre-wrap">
                  {completedUnit.output.moolaShloka}
                </p>
              </div>

              {/* 2. Transliteration */}
              <div className="p-4 bg-white rounded-lg border border-[#E8DFC9] shadow-xs">
                <span className="text-[11px] font-bold text-[#8B1E0F] uppercase block mb-1">
                  ೨. ಕನ್ನಡ ಲಿಪ್ಯಂತರ
                </span>
                <p className="font-kannada font-bold text-[#1F1916] whitespace-pre-wrap">
                  {completedUnit.output.kannadaTransliteration}
                </p>
              </div>

              {/* 3. Padartha */}
              <div className="p-4 bg-white rounded-lg border border-[#E8DFC9] shadow-xs">
                <span className="text-[11px] font-bold text-[#8B1E0F] uppercase block mb-1">
                  ೩. ಅವಿರತ ಪದಾರ್ಥ (Continuous Paragraph)
                </span>
                <p className="font-kannada text-xs text-[#2A211C] leading-relaxed">
                  {completedUnit.output.padartha}
                </p>
              </div>

              {/* 4. Sarala Vivarane */}
              <div className="p-4 bg-white rounded-lg border border-[#E8DFC9] shadow-xs">
                <span className="text-[11px] font-bold text-[#8B1E0F] uppercase block mb-1">
                  ೪. ಸರಳ ವಿವರಣೆ
                </span>
                <p className="font-kannada text-xs text-[#2A211C] leading-relaxed">
                  {completedUnit.output.saralaVivarane}
                </p>
              </div>

              {/* 5. Vivarada Vyakhyana */}
              <div className="p-4 bg-white rounded-lg border border-[#E8DFC9] shadow-xs">
                <span className="text-[11px] font-bold text-[#8B1E0F] uppercase block mb-1">
                  ೫. ವಿವರವಾದ ವ್ಯಾಖ್ಯಾನ
                </span>
                <p className="font-kannada text-xs text-[#2A211C] leading-relaxed">
                  {completedUnit.output.vivaradaVyakhyana}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#FAF4EB] border-t border-[#E8DFC9] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#8B1E0F] hover:bg-[#A32312] text-white text-xs font-bold rounded-lg transition-colors"
          >
            ಮುಚ್ಚಿ (Close)
          </button>
        </div>
      </div>
    </div>
  );
};
