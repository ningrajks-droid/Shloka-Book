import React from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Square,
  FileText,
  CheckCircle,
  AlertTriangle,
  Clock,
  Download,
  Flame,
  Search,
  BookOpen,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  Trash2,
  Laptop,
} from 'lucide-react';
import { GranthaProject, SanskritUnit } from '../types';

interface ProjectDashboardProps {
  project: GranthaProject;
  units: SanskritUnit[];
  isProcessing: boolean;
  onStart: () => void;
  onPause: () => void;
  onCancel: () => void;
  onOpenExport: () => void;
  onOpenReview: () => void;
  onOpenMasterIndex?: () => void;
  onFilterStatus: (status: string) => void;
  onDeleteProject?: () => void;
  currentFilter: string;
}

export const ProjectDashboard: React.FC<ProjectDashboardProps> = ({
  project,
  units,
  isProcessing,
  onStart,
  onPause,
  onCancel,
  onOpenExport,
  onOpenReview,
  onOpenMasterIndex,
  onFilterStatus,
  onDeleteProject,
  currentFilter,
}) => {
  const total = units.length;
  const completed = units.filter((u) => u.status === 'COMPLETED').length;
  const reviewReq = units.filter((u) => u.status === 'REVIEW_REQUIRED').length;
  const failed = units.filter((u) => u.status === 'FAILED').length;
  const pending = units.filter((u) => u.status === 'PENDING' || u.status === 'EXTRACTING' || u.status === 'VERIFYING' || u.status === 'GENERATING' || u.status === 'VALIDATING').length;

  const percentComplete = total > 0 ? Math.round((completed / total) * 100) : 0;

  return (
    <div className="space-y-6">
      {/* Project Header Banner */}
      <div className="bg-[#FFFFFF] border border-[#E8E2D9] rounded-xl p-6 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <div className="flex items-center space-x-3 flex-wrap gap-y-2">
              <h1 className="font-serif text-2xl font-bold text-[#1F1916]">
                {project.name}
              </h1>
              {project.detectedWork && (
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#8B1E0F]/10 text-[#8B1E0F] border border-[#8B1E0F]/20">
                  <BookOpen className="w-3.5 h-3.5 mr-1" />
                  {project.detectedWork}
                </span>
              )}
              {project.detectedGenre && (
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-[#F4EDE5] text-[#634E42] border border-[#E2D5C8]">
                  {project.detectedGenre}
                </span>
              )}
              <span
                className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                  isProcessing
                    ? 'bg-amber-100 text-amber-900 animate-pulse border border-amber-300'
                    : project.status === 'COMPLETED'
                    ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                    : 'bg-stone-100 text-stone-700 border border-stone-300'
                }`}
              >
                {isProcessing
                  ? 'ಸಂಸ್ಕರಣೆ ಚಾಲನೆಯಲ್ಲಿದೆ (Processing)'
                  : project.status === 'COMPLETED'
                  ? 'ಸಂಪೂರ್ಣ (Completed)'
                  : project.status === 'PAUSED'
                  ? 'ವಿರಾಮ (Paused)'
                  : 'ಸಿದ್ಧವಾಗಿದೆ (Ready)'}
              </span>
            </div>
            <p className="text-sm text-[#736357] mt-1.5 font-kannada">
              {project.description ||
                'ಸಂಸ್ಕೃತ ಮೂಲ ಪಠ್ಯ ಸಂರಕ್ಷಣೆ, ಕನ್ನಡ ಲಿಪ್ಯಂತರ, ಅವಿರತ ಪದಾರ್ಥ, ಸರಳ ವಿವರಣೆ ಹಾಗೂ ವಿದ್ವತ್ಪೂರ್ಣ ವ್ಯಾಖ್ಯಾನ ಉತ್ಪಾದನೆ.'}
            </p>
          </div>

          {/* Action Control Buttons */}
          <div className="flex items-center space-x-2 flex-wrap gap-y-2">
            {onOpenMasterIndex && (
              <button
                id="btn-open-master-index"
                onClick={onOpenMasterIndex}
                disabled={total === 0}
                className="flex items-center space-x-1.5 px-4 py-2.5 rounded-lg bg-[#FAF2EF] hover:bg-[#F3E5E0] text-[#8B1E0F] border border-[#E8C7BE] font-bold text-sm transition-all shadow-xs disabled:opacity-50 disabled:cursor-not-allowed"
                title="ಗ್ರಂಥದ ಹೆಡ್, ಸಬ್‌ಹೆಡ್ ಮತ್ತು ಮಾಸ್ಟರ್ ಇಂಡೆಕ್ಸ್ ವೀಕ್ಷಿಸಿ ಮತ್ತು ಬದಲಾಯಿಸಿ"
              >
                <BookOpen className="w-4 h-4 text-[#8B1E0F]" />
                <span>ಮಾಸ್ಟರ್ ಇಂಡೆಕ್ಸ್ / Head & Sub-head ({total})</span>
              </button>
            )}

            {!isProcessing ? (
              <button
                id="btn-start-processing"
                onClick={onStart}
                disabled={total === 0}
                className="flex items-center space-x-2 px-5 py-2.5 rounded-lg bg-[#8B1E0F] hover:bg-[#A32312] text-white font-medium text-sm shadow-sm transition-all disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>
                  {completed > 0 && (units.some(u => u.status === 'PENDING' || u.status === 'FAILED' || u.status === 'VERIFYING' || u.status === 'GENERATING'))
                    ? 'ಪುನರಾರಂಭಿಸಿ (Resume)'
                    : total > 0 && completed + reviewReq >= total
                    ? 'ಮರು-ಸಂಸ್ಕರಣೆ (Reprocess)'
                    : 'ಸಂಸ್ಕರಣೆ ಆರಂಭಿಸಿ (Start)'}
                </span>
              </button>
            ) : (
              <>
                <button
                  id="btn-pause-processing"
                  onClick={onPause}
                  className="flex items-center space-x-1.5 px-4 py-2.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-medium text-sm transition-colors cursor-pointer"
                >
                  <Pause className="w-4 h-4" />
                  <span>ವಿರಾಮ (Pause)</span>
                </button>
                <button
                  id="btn-cancel-processing"
                  onClick={onCancel}
                  className="flex items-center space-x-1.5 px-4 py-2.5 rounded-lg bg-stone-700 hover:bg-stone-800 text-white font-medium text-sm transition-colors cursor-pointer"
                >
                  <Square className="w-4 h-4" />
                  <span>ರದ್ದು (Cancel)</span>
                </button>
              </>
            )}

            {reviewReq > 0 && (
              <button
                id="btn-review-required"
                onClick={onOpenReview}
                className="flex items-center space-x-1.5 px-4 py-2.5 rounded-lg bg-[#FAF0E6] hover:bg-[#F3E2D0] border border-[#DEB887] text-[#8B4513] font-medium text-sm transition-colors"
              >
                <AlertTriangle className="w-4 h-4 text-amber-700" />
                <span>ಪುನರ್ಪರಿಶೀಲನೆ ({reviewReq})</span>
              </button>
            )}

            <button
              id="btn-export-dashboard"
              onClick={onOpenExport}
              disabled={completed === 0}
              className="flex items-center space-x-1.5 px-4 py-2.5 rounded-lg bg-[#2E231D] hover:bg-[#42332A] text-white font-medium text-sm transition-colors disabled:opacity-50"
            >
              <Download className="w-4 h-4 text-amber-300" />
              <span>ಗ್ರಂಥ ರಫ್ತು (Export)</span>
            </button>

            <a
              id="btn-download-desktop-app"
              href="/api/desktop/download-offline-pack"
              download="GRANTHA_ENGINE_DESKTOP_OFFLINE_BUNDLE.zip"
              className="flex items-center space-x-1.5 px-3.5 py-2.5 rounded-lg bg-[#F2EAE0] hover:bg-[#E5D8CA] text-[#4A3B32] border border-[#D5C4B4] font-medium text-sm transition-colors"
              title="ಲ್ಯಾಪ್ಟಾಪ್ ಅಥವಾ ಕಂಪ್ಯೂಟರ್‌ನಲ್ಲಿ ಆಫ್‌ಲೈನ್‌ನಲ್ಲಿ ಚಲಾಯಿಸಲು ಡೆಸ್ಕ್‌ಟಾಪ್ ಪ್ಯಾಕೇಜ್ ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ"
            >
              <Laptop className="w-4 h-4 text-[#8B1E0F]" />
              <span>ಲ್ಯಾಪ್ಟಾಪ್ ಆವೃತ್ತಿ (Desktop App)</span>
            </a>

            {onDeleteProject && (
              <button
                id="btn-delete-project-dashboard"
                onClick={onDeleteProject}
                className="flex items-center space-x-1.5 px-3 py-2.5 rounded-lg text-red-700 bg-red-50 hover:bg-red-600 hover:text-white border border-red-200 hover:border-red-600 font-medium text-sm transition-all shadow-2xs"
                title="ಪ್ರಸ್ತುತ ಪ್ರಕಲ್ಪವನ್ನು ಅಳಿಸಿ (Delete Current Project)"
              >
                <Trash2 className="w-4 h-4" />
                <span className="hidden sm:inline">ಪ್ರಕಲ್ಪ ಅಳಿಸಿ</span>
              </button>
            )}
          </div>
        </div>

        {/* Live Processing Pipeline Status (When running) */}
        {isProcessing && (
          <div className="mt-5 p-4 rounded-lg bg-[#FAF7F2] border border-[#E8DFC9] flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <RefreshCw className="w-5 h-5 text-[#8B1E0F] animate-spin" />
              <div>
                <p className="text-sm font-semibold text-[#2D231E]">
                  ಪ್ರಸ್ತುತ ಪ್ರಕ್ರಿಯೆ: {project.currentDocName || 'ದಾಖಲೆ ಸಂಸ್ಕರಣೆ'}
                </p>
                <p className="text-xs text-[#7A695D]">
                  ಪುಟ {project.currentPage || 1} • ಶ್ಲೋಕ {project.currentUnitNumber || '1'} • ಹಂತ: ಸಂಸ್ಕೃತ ಪರಿಶೀಲನೆ & ವ್ಯಾಖ್ಯಾನ ರಚನೆ
                </p>
              </div>
            </div>
            <span className="text-xs font-mono px-2 py-1 rounded bg-[#EADECE] text-[#4A382C]">
              {completed} / {total} ಶ್ಲೋಕಗಳು
            </span>
          </div>
        )}

        {/* Progress Bar */}
        <div className="mt-6">
          <div className="flex justify-between text-xs text-[#6B5A4E] mb-1.5">
            <span className="font-medium">ಒಟ್ಟು ಪ್ರಗತಿ (Overall Progress)</span>
            <span className="font-mono font-semibold">{percentComplete}% ({completed}/{total} ಶ್ಲೋಕಗಳು)</span>
          </div>
          <div className="w-full h-2.5 bg-[#EAE4DC] rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-[#8B1E0F] to-[#B32915] transition-all duration-500 rounded-full"
              style={{ width: `${percentComplete}%` }}
            />
          </div>
        </div>
      </div>

      {/* 4 Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {/* Total Units */}
        <button
          onClick={() => onFilterStatus('ALL')}
          className={`p-4 rounded-xl border text-left transition-all ${
            currentFilter === 'ALL'
              ? 'bg-[#FAF7F2] border-[#8B1E0F] shadow-sm ring-1 ring-[#8B1E0F]'
              : 'bg-white border-[#E8E2D9] hover:bg-[#FAF8F5]'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-[#7A695D]">ಒಟ್ಟು ಶ್ಲೋಕಗಳು</span>
            <FileText className="w-4 h-4 text-[#8B1E0F]" />
          </div>
          <p className="text-2xl font-bold font-mono text-[#1F1916] mt-2">{total}</p>
          <p className="text-[11px] text-[#918176] mt-0.5">Total Verse Units</p>
        </button>

        {/* Completed */}
        <button
          onClick={() => onFilterStatus('COMPLETED')}
          className={`p-4 rounded-xl border text-left transition-all ${
            currentFilter === 'COMPLETED'
              ? 'bg-emerald-50 border-emerald-600 shadow-sm ring-1 ring-emerald-600'
              : 'bg-white border-[#E8E2D9] hover:bg-emerald-50/50'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-emerald-800">ಪೂರ್ಣಗೊಂಡಿದೆ</span>
            <CheckCircle className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-2xl font-bold font-mono text-emerald-950 mt-2">{completed}</p>
          <p className="text-[11px] text-emerald-700 mt-0.5">Verified & Validated</p>
        </button>

        {/* Review Required */}
        <button
          onClick={() => onFilterStatus('REVIEW_REQUIRED')}
          className={`p-4 rounded-xl border text-left transition-all ${
            currentFilter === 'REVIEW_REQUIRED'
              ? 'bg-amber-50 border-amber-600 shadow-sm ring-1 ring-amber-600'
              : 'bg-white border-[#E8E2D9] hover:bg-amber-50/50'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-amber-900">ಪುನರ್ಪರಿಶೀಲನೆ</span>
            <AlertTriangle className="w-4 h-4 text-amber-600" />
          </div>
          <p className="text-2xl font-bold font-mono text-amber-950 mt-2">{reviewReq}</p>
          <p className="text-[11px] text-amber-700 mt-0.5">Needs Review</p>
        </button>

        {/* Pending / Queue */}
        <button
          onClick={() => onFilterStatus('PENDING')}
          className={`p-4 rounded-xl border text-left transition-all ${
            currentFilter === 'PENDING'
              ? 'bg-stone-100 border-stone-600 shadow-sm ring-1 ring-stone-600'
              : 'bg-white border-[#E8E2D9] hover:bg-stone-50'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-[#7A695D]">ಬಾಕಿ ಉಳಿದಿದೆ</span>
            <Clock className="w-4 h-4 text-[#7A695D]" />
          </div>
          <p className="text-2xl font-bold font-mono text-[#1F1916] mt-2">{pending}</p>
          <p className="text-[11px] text-[#918176] mt-0.5">In Pipeline / Queue</p>
        </button>
      </div>
    </div>
  );
};
