import React, { useState, useRef } from 'react';
import {
  Upload,
  FileText,
  FileCheck,
  FolderOpen,
  Layers,
  CheckCircle2,
  AlertCircle,
  FileUp,
  BookOpen,
  Trash2,
  RefreshCw,
  Play,
  Sparkles,
  ArrowRight,
  X,
  RotateCcw,
} from 'lucide-react';
import { GranthaDocument } from '../types';

interface FileUploadSectionProps {
  projectId: string;
  documents: GranthaDocument[];
  onFilesUploaded: () => void;
  onStartProcessing?: () => void;
}

export const FileUploadSection: React.FC<FileUploadSectionProps> = ({
  projectId,
  documents,
  onFilesUploaded,
  onStartProcessing,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [deletingDocId, setDeletingDocId] = useState<string | null>(null);
  const [isClearingAll, setIsClearingAll] = useState(false);
  const [uploadMessage, setUploadMessage] = useState<string | null>(null);
  const [lastUploadedSummary, setLastUploadedSummary] = useState<{
    filesUploaded: number;
    totalPagesAdded: number;
    totalUnitsAdded: number;
    detectedWork?: string;
  } | null>(null);
  const [uploadTab, setUploadTab] = useState<'pdf' | 'text'>('pdf');
  const [directText, setDirectText] = useState('');
  const [directTitle, setDirectTitle] = useState('');
  const [isSubmittingText, setIsSubmittingText] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDirectTextSubmit = async () => {
    if (!directText.trim()) {
      setUploadError('ದಯವಿಟ್ಟು ಸಂಸ್ಕೃತ ಶ್ಲೋಕ ಅಥವಾ ಪಠ್ಯವನ್ನು ನಮೂದಿಸಿ.');
      return;
    }

    setIsSubmittingText(true);
    setUploadError(null);
    setUploadMessage('ಸಂಸ್ಕೃತ ಪಠ್ಯವನ್ನು ವಿಶ್ಲೇಷಿಸಲಾಗುತ್ತಿದೆ...');

    try {
      const uploadUrl = projectId ? `/api/projects/${projectId}/add-text` : '/api/add-text';
      const res = await fetch(uploadUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: directText, title: directTitle.trim() || undefined }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to add Sanskrit text');

      setLastUploadedSummary({
        filesUploaded: 1,
        totalPagesAdded: 1,
        totalUnitsAdded: data.unitsCount || 1,
        detectedWork: data.detectedWork,
      });

      setUploadMessage(
        `ಯಶಸ್ವಿಯಾಗಿ ವಿಶ್ಲೇಷಿಸಲಾಗಿದೆ: ${data.unitsCount || 1} ಸಂಸ್ಕೃತ ಶ್ಲೋಕಗಳು ಸಿದ್ಧವಾಗಿವೆ. ಗ್ರಂಥ: ${data.detectedWork || 'ಸಂಸ್ಕೃತ ಗ್ರಂಥ'}`
      );
      setDirectText('');
      setDirectTitle('');
      onFilesUploaded();
    } catch (err: any) {
      console.error('Direct text upload error:', err);
      setUploadError(`ಪಠ್ಯ ಸೇರಿಸುವಲ್ಲಿ ದೋಷ: ${err.message}`);
    } finally {
      setIsSubmittingText(false);
    }
  };

  const handleFiles = async (files: FileList | File[]) => {
    if (!files || files.length === 0) return;

    setIsUploading(true);
    setUploadError(null);
    setUploadMessage('ಸಂಸ್ಕೃತ ಕಡತಗಳ ನೇರ ಪಠ್ಯ ವಿಶ್ಲೇಷಣೆ ಮಾಡಲಾಗುತ್ತಿದೆ (Analyzing native Sanskrit text from PDF)...');

    const formData = new FormData();
    for (let i = 0; i < files.length; i++) {
      formData.append('files', files[i]);
    }

    try {
      const uploadUrl = projectId ? `/api/projects/${projectId}/upload` : '/api/upload';
      const res = await fetch(uploadUrl, {
        method: 'POST',
        body: formData,
      });

      const contentType = res.headers.get('content-type') || '';
      let data: any = null;

      if (contentType.includes('application/json')) {
        data = await res.json();
      } else {
        const text = await res.text();
        if (res.status === 413) {
          throw new Error('ಕಡತದ ಗಾತ್ರ ಬಹಳ ದೊಡ್ಡದಾಗಿದೆ (File too large, max 100MB).');
        }
        throw new Error(`ಸರ್ವರ್ ಪ್ರತಿಕ್ರಿಯೆ ದೋಷ (${res.status}): ${text.replace(/<[^>]*>?/gm, '').slice(0, 120)}`);
      }

      if (!res.ok) {
        throw new Error(data?.error || `Upload failed with status ${res.status}`);
      }

      setLastUploadedSummary({
        filesUploaded: data.filesUploaded || 1,
        totalPagesAdded: data.totalPagesAdded || 1,
        totalUnitsAdded: data.totalUnitsAdded || 0,
        detectedWork: data.detectedWork,
      });

      setUploadMessage(
        `ಯಶಸ್ವಿಯಾಗಿ ವಿಶ್ಲೇಷಿಸಲಾಗಿದೆ: ${data.filesUploaded || 1} ಕಡತ(ಗಳು), ${data.totalPagesAdded || 1} ಪುಟ(ಗಳು), ${data.totalUnitsAdded || 0} ಸಂಸ್ಕೃತ ಶ್ಲೋಕಗಳು ಸಿದ್ಧವಾಗಿವೆ.`
      );
      onFilesUploaded();
    } catch (err: any) {
      console.error('File upload error:', err);
      setUploadError(`ಅಪ್ಲೋಡ್ ದೋಷ: ${err.message}`);
    } finally {
      setIsUploading(false);
    }
  };

  const handleDeleteDocument = async (doc: GranthaDocument) => {
    const confirmDelete = window.confirm(
      `ನೀವು ನಿಜವಾಗಿಯೂ "${doc.fileName}" ಕಡತವನ್ನು ಮತ್ತು ಇದರಿಂದ ರಚಿಸಲಾದ ಎಲ್ಲಾ ಶ್ಲೋಕಗಳನ್ನು ಅಳಿಸಲು ಬಯಸುವಿರಾ?\n\n(Are you sure you want to delete this file and its extracted verses?)`
    );
    if (!confirmDelete) return;

    setDeletingDocId(doc.id);
    setUploadError(null);
    setLastUploadedSummary(null);
    try {
      const res = await fetch(`/api/projects/${projectId}/documents/${doc.id}`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to delete document');

      setUploadMessage(`"${doc.fileName}" ಕಡತ ಮತ್ತು ಸಂಬಂಧಿತ ಶ್ಲೋಕಗಳನ್ನು ಯಶಸ್ವಿಯಾಗಿ ಅಳಿಸಲಾಗಿದೆ.`);
      onFilesUploaded();
      setTimeout(() => setUploadMessage(null), 4000);
    } catch (err: any) {
      console.error('Delete document error:', err);
      setUploadError(`ಕಡತ ಅಳಿಸುವಲ್ಲಿ ದೋಷ: ${err.message}`);
    } finally {
      setDeletingDocId(null);
    }
  };

  const handleClearAllDocuments = async () => {
    const confirmClear = window.confirm(
      `ಎಚ್ಚರಿಕೆ: ನೀವು ಈ ಪ್ರಕಲ್ಪದಲ್ಲಿರುವ ಎಲ್ಲಾ (${documents.length}) ಕಡತಗಳನ್ನು ಮತ್ತು ಅವುಗಳ ಎಲ್ಲಾ ಶ್ಲೋಕಗಳನ್ನು ಅಳಿಸಲು ಬಯಸುವಿರಾ?\n\n(Are you sure you want to delete all uploaded files and verses from this project?)`
    );
    if (!confirmClear) return;

    setIsClearingAll(true);
    setUploadError(null);
    setLastUploadedSummary(null);
    try {
      const res = await fetch(`/api/projects/${projectId}/documents`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to clear documents');

      setUploadMessage('ಎಲ್ಲಾ ಕಡತಗಳು ಮತ್ತು ಶ್ಲೋಕಗಳನ್ನು ಯಶಸ್ವಿಯಾಗಿ ಅಳಿಸಲಾಗಿದೆ.');
      onFilesUploaded();
      setTimeout(() => setUploadMessage(null), 4000);
    } catch (err: any) {
      console.error('Clear all documents error:', err);
      setUploadError(`ಎಲ್ಲಾ ಕಡತಗಳನ್ನು ಅಳಿಸುವಲ್ಲಿ ದೋಷ: ${err.message}`);
    } finally {
      setIsClearingAll(false);
    }
  };

  const handleResetEntireProject = async () => {
    const confirmReset = window.confirm(
      'ಎಚ್ಚರಿಕೆ: ನೀವು ಈ ಪ್ರಕಲ್ಪದ ಎಲ್ಲಾ ಕಡತಗಳು, ಶ್ಲೋಕಗಳು, ವಿಶ್ಲೇಷಣೆಗಳು ಮತ್ತು ಪ್ರಗತಿಯನ್ನು ಸಂಪೂರ್ಣವಾಗಿ ಮರುಹೊಂದಿಸಲು (Reset) ಬಯಸುವಿರಾ?\n\n(Are you sure you want to completely reset this project?)'
    );
    if (!confirmReset) return;

    setIsClearingAll(true);
    setUploadError(null);
    setLastUploadedSummary(null);
    setDirectText('');
    setDirectTitle('');
    try {
      const res = await fetch(`/api/projects/${projectId}/reset`, {
        method: 'POST',
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to reset project');

      setUploadMessage('ಪ್ರಕಲ್ಪವನ್ನು ಯಶಸ್ವಿಯಾಗಿ ಸಂಪೂರ್ಣ ಮರುಹೊಂದಿಸಲಾಗಿದೆ.');
      onFilesUploaded();
      setTimeout(() => setUploadMessage(null), 4000);
    } catch (err: any) {
      console.error('Reset project error:', err);
      setUploadError(`ಮರುಹೊಂದಿಸುವಲ್ಲಿ ದೋಷ: ${err.message}`);
    } finally {
      setIsClearingAll(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files) {
      handleFiles(e.dataTransfer.files);
    }
  };

  return (
    <div className="space-y-6">
      {/* Primary Manual File Upload Box */}
      <div className="bg-white border border-[#E8E2D9] rounded-xl p-6 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-4">
          <div>
            <h2 className="font-serif text-lg font-bold text-[#1F1916] flex items-center">
              <Upload className="w-5 h-5 mr-2 text-[#8B1E0F]" />
              ಸಂಸ್ಕೃತ ಕಡತಗಳ ನೇರ ಸೇರ್ಪಡೆ (Upload Sanskrit Source PDFs)
            </h2>
            <p className="text-xs text-[#7A695D] mt-0.5">
              ನಿಮ್ಮ ಮೂಲ ಸಂಸ್ಕೃತ PDF, Merged PDF ಅಥವಾ TXT ಕಡತಗಳನ್ನು ಇಲ್ಲಿ ಅಪ್ಲೋಡ್ ಮಾಡಿ.
            </p>
          </div>
          <span className="text-xs px-2.5 py-1 rounded bg-[#FAF5EE] border border-[#E6DCce] text-[#6E5B4F] font-mono self-start sm:self-auto">
            ಬೆಂಬಲಿತ ಮಾದರಿಗಳು: PDF, TXT
          </span>
        </div>

        {/* Mode Selector Tabs */}
        <div className="flex items-center space-x-2 mb-4 border-b border-[#EAE4DC] pb-3">
          <button
            type="button"
            id="tab-pdf-upload"
            onClick={() => setUploadTab('pdf')}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-xs font-bold transition-all ${
              uploadTab === 'pdf'
                ? 'bg-[#8B1E0F] text-white shadow-xs'
                : 'bg-[#FAF8F5] text-[#5A483E] hover:bg-[#EADBCE]'
            }`}
          >
            <Upload className="w-4 h-4" />
            <span>PDF / TXT ಕಡತ ಅಪ್ಲೋಡ್ (Upload Source Files)</span>
          </button>
          <button
            type="button"
            id="tab-direct-text-entry"
            onClick={() => setUploadTab('text')}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-xs font-bold transition-all ${
              uploadTab === 'text'
                ? 'bg-[#8B1E0F] text-white shadow-xs'
                : 'bg-[#FAF8F5] text-[#5A483E] hover:bg-[#EADBCE]'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>ನೇರ ಶ್ಲೋಕ / ಪಠ್ಯ ನಮೂದು (Direct Shloka / Text Input)</span>
          </button>
        </div>

        {uploadTab === 'pdf' ? (
          /* Drop Zone */
          <div
            id="drop-zone-sanskrit"
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-xl p-10 text-center cursor-pointer transition-all ${
              isDragging
                ? 'border-[#8B1E0F] bg-[#FAF2EF] scale-[1.005]'
                : 'border-[#DDD5C9] bg-[#FAF8F5] hover:bg-[#F5EFEB] hover:border-[#8B1E0F]/60'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept=".pdf,.txt,.html,.md"
              className="hidden"
              onChange={(e) => {
                if (e.target.files) handleFiles(e.target.files);
              }}
            />
            <div className="flex flex-col items-center justify-center space-y-3">
              <div className="w-14 h-14 rounded-full bg-[#8B1E0F]/10 flex items-center justify-center text-[#8B1E0F] shadow-sm">
                {isUploading ? (
                  <FileUp className="w-7 h-7 animate-bounce" />
                ) : (
                  <FolderOpen className="w-7 h-7" />
                )}
              </div>
              <div>
                <p className="text-base font-semibold text-[#1F1916]">
                  {isUploading
                    ? 'ಸಂಸ್ಕೃತ ಕಡತವನ್ನು ವಿಶ್ಲೇಷಿಸಲಾಗುತ್ತಿದೆ...'
                    : 'ನಿಮ್ಮ ಸಂಸ್ಕೃತ PDF ಕಡತಗಳನ್ನು ಇಲ್ಲಿಗೆ ಎಳೆಯಿರಿ ಅಥವಾ ಕ್ಲಿಕ್ ಮಾಡಿ'}
                </p>
                <p className="text-xs text-[#7A695D] mt-1.5 max-w-xl mx-auto">
                  ಸ್ಥಳೀಯ ನೇರ ದೇವನಾಗರಿ ಪಠ್ಯ ಹೊರತೆಗೆಯುವಿಕೆ (Native PDF Extraction Priority). ಏಕಕಾಲದಲ್ಲಿ ಒಂದಕ್ಕಿಂತ ಹೆಚ್ಚು PDF ಕಡತಗಳನ್ನು ಆಯ್ಕೆ ಮಾಡಬಹುದು.
                </p>
              </div>

              <button
                type="button"
                id="btn-browse-pdf-files"
                onClick={(e) => {
                  e.stopPropagation();
                  fileInputRef.current?.click();
                }}
                className="mt-2 inline-flex items-center px-4 py-2 rounded-lg bg-[#8B1E0F] hover:bg-[#A32312] text-white text-xs font-semibold shadow-sm transition-colors"
              >
                <FileUp className="w-4 h-4 mr-1.5" />
                ಕಡತಗಳನ್ನು ಆಯ್ಕೆಮಾಡಿ (Browse Sanskrit Files)
              </button>
            </div>
          </div>
        ) : (
          /* Direct Text Entry Panel */
          <div className="p-5 rounded-xl bg-[#FAF8F5] border border-[#DDD5C9] space-y-4">
            <div>
              <label className="block text-xs font-bold text-[#1F1916] mb-1.5">
                ಪ್ರಕಲ್ಪ / ಅಧ್ಯಾಯದ ಶೀರ್ಷಿಕೆ (ಐಚ್ಛಿಕ - Document / Chapter Title):
              </label>
              <input
                type="text"
                value={directTitle}
                onChange={(e) => setDirectTitle(e.target.value)}
                placeholder="ಉದಾ: ಈಶೋಪನಿಷತ್ - ಮಂತ್ರ ೪ (Ishopanishad Mantra 4)"
                className="w-full p-2.5 rounded-lg border border-[#DDD5C9] text-xs font-kannada bg-white focus:outline-none focus:border-[#8B1E0F]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1F1916] mb-1.5">
                ಮೂಲ ಸಂಸ್ಕೃತ ಶ್ಲೋಕ ಅಥವಾ ಮಂತ್ರಗಳನ್ನು ಇಲ್ಲಿ ನಮೂದಿಸಿ (Devanagari Sanskrit Shlokas / Mantras):
              </label>
              <textarea
                value={directText}
                onChange={(e) => setDirectText(e.target.value)}
                rows={6}
                placeholder={`ಅಥವಾ ನೇರವಾಗಿ ದೇವನಾಗರಿ ಶ್ಲೋಕವನ್ನು ಅಂಟಿಸಿ:\n\nअनेजदेकं मनसो जवीयो नैनद्देवा आप्नुवन्पूर्वमर्षत् ।\nतद्धावतोऽन्यानत्येति तिष्ठत्तस्मिन्नपो मातरिश्वा दधाति ॥ ४ ॥`}
                className="w-full p-3 rounded-lg border border-[#DDD5C9] font-devanagari text-sm bg-white focus:outline-none focus:border-[#8B1E0F] leading-relaxed"
              />
            </div>

            <div className="flex items-center justify-between pt-2">
              <p className="text-[11px] text-[#7A695D]">
                ಸ್ವಯಂಚಾಲಿತ ಪಾರ್ಸಿಂಗ್ ನಿಯಮ: //, \\, /, \, ಅಥವಾ II ಚಿಹ್ನೆಗಳು ತಕ್ಷಣವೇ ಒಡೆಯುವುದಿಲ್ಲ; ನಿರಂತರವಾಗಿ 10 ರಿಂದ 15 ಸಾಲುಗಳ ತಾರ್ಕಿಕ ಘಟಕವಾಗಿ ಸಂಸ್ಕರಿಸುತ್ತದೆ. ಸ್ಪಷ್ಟ ಶ್ಲೋಕ ಸಂಖ್ಯೆ (॥ ೧ ॥, // 1 //) ಅಥವಾ ಮುಕ್ತಾಯ ಚಿಹ್ನೆ ಬಂದಾಗ ತಕ್ಷಣವೇ ಸಂಸ್ಕರಿಸುತ್ತದೆ.
              </p>
              <button
                type="button"
                id="btn-submit-direct-sanskrit-text"
                onClick={handleDirectTextSubmit}
                disabled={isSubmittingText || !directText.trim()}
                className="inline-flex items-center space-x-2 px-5 py-2.5 rounded-lg bg-[#8B1E0F] hover:bg-[#A32312] text-white text-xs font-bold shadow-md transition-colors disabled:opacity-50"
              >
                {isSubmittingText ? (
                  <RefreshCw className="w-4 h-4 mr-1.5 animate-spin text-white" />
                ) : (
                  <Sparkles className="w-4 h-4 mr-1.5 text-white" />
                )}
                <span>ಶ್ಲೋಕವನ್ನು ಸೇರಿಸಿ ಮತ್ತು ವಿಶ್ಲೇಷಿಸಿ (Add & Analyze Shloka)</span>
              </button>
            </div>
          </div>
        )}

        {/* Status Alerts */}
        {lastUploadedSummary && documents.length > 0 && (
          <div className="mt-4 p-4 rounded-xl bg-[#FAF5EE] border-2 border-[#8B1E0F]/30 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3 relative">
            <div className="flex items-start space-x-3 pr-6 sm:pr-0">
              <div className="p-2 rounded-lg bg-[#8B1E0F] text-white shrink-0 mt-0.5">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-[#1F1916] font-serif flex items-center gap-2">
                  <span>ಕಡತ ಯಶಸ್ವಿಯಾಗಿ ವಿಶ್ಲೇಷಿಸಲಾಗಿದೆ!</span>
                  <span className="text-xs px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-full font-sans font-semibold">
                    {lastUploadedSummary.totalUnitsAdded} ಶ್ಲೋಕಗಳು ಪತ್ತೆಯಾಗಿವೆ
                  </span>
                </h4>
                <p className="text-xs text-[#634E42] mt-1 font-kannada">
                  {lastUploadedSummary.detectedWork && (
                    <span className="font-semibold text-[#8B1E0F]">ಗ್ರಂಥ: {lastUploadedSummary.detectedWork} • </span>
                  )}
                  ಮುಂದಿನ ಹಂತ: <strong>"ವಿದ್ವತ್ ಸಂಸ್ಕರಣೆ ಆರಂಭಿಸಿ"</strong> ಒತ್ತಿ ಕನ್ನಡ ಲಿಪ್ಯಂತರ, ಪ್ರತಿಪದಾರ್ಥ ಮತ್ತು ವಿಸ್ತೃತ ವ್ಯಾಖ್ಯಾನವನ್ನು ರಚಿಸಿ.
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {onStartProcessing && (
                <button
                  type="button"
                  id="btn-upload-start-processing-cta"
                  onClick={onStartProcessing}
                  className="flex items-center justify-center space-x-2 px-5 py-2.5 rounded-lg bg-[#8B1E0F] hover:bg-[#A32312] text-white font-bold text-xs shadow-md transition-all whitespace-nowrap"
                >
                  <Play className="w-4 h-4 fill-white" />
                  <span>ವಿದ್ವತ್ ಸಂಸ್ಕರಣೆ ಆರಂಭಿಸಿ (Start Processing)</span>
                </button>
              )}
              <button
                type="button"
                id="btn-dismiss-upload-summary"
                onClick={() => setLastUploadedSummary(null)}
                className="p-2 rounded-lg text-[#7A695D] hover:text-[#1F1916] hover:bg-[#EADBCE] transition-colors"
                title="ಮುಚ್ಚಿ (Dismiss Banner)"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {uploadMessage && !lastUploadedSummary && (
          <div className="mt-4 p-3.5 rounded-lg bg-[#FAF7E8] border border-[#E6DBAC] text-xs text-[#614D16] flex items-center">
            <CheckCircle2 className="w-4 h-4 mr-2 text-emerald-600 shrink-0" />
            <span>{uploadMessage}</span>
          </div>
        )}

        {uploadError && (
          <div className="mt-4 p-3.5 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700 flex items-center">
            <AlertCircle className="w-4 h-4 mr-2 text-red-600 shrink-0" />
            <span>{uploadError}</span>
          </div>
        )}

        {/* Feature Capabilities Banner */}
        <div className="mt-5 grid grid-cols-1 md:grid-cols-3 gap-3 pt-4 border-t border-[#EAE3D8] text-xs text-[#6E5D52]">
          <div className="flex items-start space-x-2">
            <CheckCircle2 className="w-4 h-4 text-[#8B1E0F] shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-[#241C18]">ಮೂಲ ಸಂಸ್ಕೃತ ಸಂರಕ್ಷಣೆ:</span>
              <p className="text-[11px] text-[#7A695D]">ದೇವನಾಗರಿ ಲಿಪಿಯ ಅಕ್ಷರಶಃ ಶುದ್ಧತೆ ಮತ್ತು ದಂಡ ವಿರಾಮಗಳ ಸಂರಕ್ಷಣೆ.</p>
            </div>
          </div>
          <div className="flex items-start space-x-2">
            <CheckCircle2 className="w-4 h-4 text-[#8B1E0F] shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-[#241C18]">ರಚನಾ ಶ್ರೇಣಿ ವಿಶ್ಲೇಷಣೆ:</span>
              <p className="text-[11px] text-[#7A695D]">ಕಾಂಡ/ಸರ್ಗ/ಪರ್ವ/ಅಧ್ಯಾಯ/ಸೂಕ್ತ/ಖಂಡ ಶ್ರೇಣಿಗಳ ಸ್ವಯಂಚಾಲಿತ ಗುರುತಿಸುವಿಕೆ.</p>
            </div>
          </div>
          <div className="flex items-start space-x-2">
            <CheckCircle2 className="w-4 h-4 text-[#8B1E0F] shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-[#241C18]">ವಿದ್ವತ್ ಪ್ರಕಾಶನ ಮಾನದಂಡ:</span>
              <p className="text-[11px] text-[#7A695D]">ಅವಿರತ ಪದಾರ್ಥ, ಸರಳ ವಿವರಣೆ ಹಾಗೂ ವಿಸ್ತೃತ ವ್ಯಾಖ್ಯಾನ.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Uploaded Documents Manifest Table */}
      {documents.length > 0 ? (
        <div className="bg-white border border-[#E8E2D9] rounded-xl p-5 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-3">
            <div>
              <h3 className="font-serif text-sm font-bold text-[#1F1916] flex items-center">
                <Layers className="w-4 h-4 mr-1.5 text-[#8B1E0F]" />
                ಅಪ್ಲೋಡ್ ಮಾಡಿದ ಮೂಲ ಕಡತಗಳ ವಿವರ (Source Manifest & Traceability)
              </h3>
              <p className="text-xs text-[#7A695D] mt-0.5">
                ಒಟ್ಟು {documents.length} ಕಡತ(ಗಳು) • {documents.reduce((a, b) => a + b.pageCount, 0)} ಪುಟಗಳು
              </p>
            </div>
            <div className="flex items-center space-x-2 flex-wrap gap-y-2 self-start sm:self-auto">
              <button
                type="button"
                id="btn-reset-entire-project"
                onClick={handleResetEntireProject}
                disabled={isClearingAll || documents.length === 0}
                className="inline-flex items-center px-3 py-1.5 text-xs font-semibold text-stone-700 bg-stone-100 hover:bg-stone-200 border border-stone-300 rounded-lg transition-colors disabled:opacity-50"
                title="ಪ್ರಕಲ್ಪವನ್ನು ಮರುಹೊಂದಿಸಿ (Reset Project State)"
              >
                <RotateCcw className="w-3.5 h-3.5 mr-1.5 text-stone-600" />
                ಮರುಹೊಂದಿಸಿ (Reset)
              </button>
              <button
                type="button"
                id="btn-clear-all-documents"
                onClick={handleClearAllDocuments}
                disabled={isClearingAll || documents.length === 0}
                className="inline-flex items-center px-3 py-1.5 text-xs font-semibold text-red-700 bg-red-50 hover:bg-red-100 border border-red-200 rounded-lg transition-colors disabled:opacity-50"
                title="ಎಲ್ಲಾ ಕಡತಗಳನ್ನು ಮತ್ತು ಶ್ಲೋಕಗಳನ್ನು ಅಳಿಸಿ (Delete all uploaded files)"
              >
                {isClearingAll ? (
                  <RefreshCw className="w-3.5 h-3.5 mr-1.5 animate-spin text-red-600" />
                ) : (
                  <Trash2 className="w-3.5 h-3.5 mr-1.5 text-red-600" />
                )}
                ಎಲ್ಲಾ ಕಡತಗಳನ್ನು ಅಳಿಸಿ (Clear All Files)
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-[#EAE4DC] text-[#7A695D] bg-[#FAF8F5]">
                  <th className="py-2.5 px-3 font-semibold">ಕ್ರಮ</th>
                  <th className="py-2.5 px-3 font-semibold">ಕಡತದ ಹೆಸರು (File Name)</th>
                  <th className="py-2.5 px-3 font-semibold">ಗುರುತಿಸಲಾದ ಗ್ರಂಥ (Detected Work)</th>
                  <th className="py-2.5 px-3 font-semibold">ರಚನಾ ಶ್ರೇಣಿ (Structure)</th>
                  <th className="py-2.5 px-3 font-semibold">ಪುಟಗಳು</th>
                  <th className="py-2.5 px-3 font-semibold">ರೀತಿ</th>
                  <th className="py-2.5 px-3 font-semibold">ಸ್ಥಿತಿ</th>
                  <th className="py-2.5 px-3 font-semibold text-center">ಕ್ರಿಯೆ (Action)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EFEBE4]">
                {documents.map((doc, idx) => (
                  <tr key={doc.id} className="hover:bg-[#FAF8F5] transition-colors">
                    <td className="py-2.5 px-3 font-mono text-[#8B1E0F] font-bold">
                      {String(idx + 1).padStart(2, '0')}
                    </td>
                    <td className="py-2.5 px-3 font-medium text-[#1F1916] max-w-[220px] truncate">
                      {doc.fileName}
                    </td>
                    <td className="py-2.5 px-3 font-devanagari text-[#2A231E]">
                      {doc.detectedWork || 'ಸಂಸ್ಕೃತ ಗ್ರಂಥ'}
                    </td>
                    <td className="py-2.5 px-3 font-kannada text-[#6E5C50]">
                      {doc.structuralType || 'ಅಧ್ಯಾಯ → ಶ್ಲೋಕ'}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-[#4A3F37]">
                      {doc.pageCount}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-stone-100 text-stone-700">
                        {doc.detectedType}
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="inline-flex items-center text-emerald-700 font-medium">
                        <FileCheck className="w-3.5 h-3.5 mr-1" />
                        ಹೊರತೆಗೆಯಲಾಗಿದೆ
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <button
                        id={`btn-delete-doc-${doc.id}`}
                        onClick={() => handleDeleteDocument(doc)}
                        disabled={deletingDocId === doc.id}
                        className="inline-flex items-center justify-center p-1.5 rounded-lg text-red-600 hover:text-white hover:bg-red-600 border border-red-200 hover:border-red-600 transition-all disabled:opacity-50 shadow-2xs"
                        title={`"${doc.fileName}" ಕಡತವನ್ನು ಅಳಿಸಿ (Delete File)`}
                      >
                        {deletingDocId === doc.id ? (
                          <RefreshCw className="w-3.5 h-3.5 animate-spin text-red-600" />
                        ) : (
                          <Trash2 className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="bg-[#FAF8F5] border border-dashed border-[#DDD5C9] rounded-xl p-8 text-center">
          <BookOpen className="w-8 h-8 text-[#A89689] mx-auto mb-2" />
          <p className="text-sm font-semibold text-[#4A3D35]">ಯಾವುದೇ ಕಡತಗಳನ್ನು ಅಪ್ಲೋಡ್ ಮಾಡಲಾಗಿಲ್ಲ</p>
          <p className="text-xs text-[#7A695D] mt-1">
            ಮೇಲಿನ ಅಪ್ಲೋಡ್ ಬಾಕ್ಸ್ ಮೂಲಕ ನಿಮ್ಮ ಸಂಸ್ಕೃತ PDF ಕಡತಗಳನ್ನು ಅಪ್ಲೋಡ್ ಮಾಡಿದ ತಕ್ಷಣ ಶ್ಲೋಕಗಳು ಇಲ್ಲಿ ಪ್ರದರ್ಶನಗೊಳ್ಳುತ್ತವೆ.
          </p>
        </div>
      )}
    </div>
  );
};
