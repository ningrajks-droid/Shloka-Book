import React from 'react';
import {
  BookOpen,
  Settings,
  Download,
  Plus,
  Layers,
  Sparkles,
  Monitor,
  CheckCircle2,
  AlertCircle,
  Database,
  FolderKanban,
} from 'lucide-react';
import { GranthaProject } from '../types';

interface NavbarProps {
  projects: GranthaProject[];
  currentProject: GranthaProject | null;
  onSelectProject: (id: string) => void;
  onNewProject: () => void;
  onManageProjects?: () => void;
  onOpenMasterIndex?: () => void;
  onOpenSettings: () => void;
  onOpenWindowsGuide: () => void;
  onOpenExport: () => void;
  keyStatus?: { total: number; active: number; rateLimited: number };
}

export const Navbar: React.FC<NavbarProps> = ({
  projects,
  currentProject,
  onSelectProject,
  onNewProject,
  onManageProjects,
  onOpenMasterIndex,
  onOpenSettings,
  onOpenWindowsGuide,
  onOpenExport,
  keyStatus,
}) => {
  return (
    <header className="bg-[#1C1613] text-[#F3EEEA] border-b border-[#3D2E27] sticky top-0 z-40 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo & Title */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#8B1E0F] to-[#5C140A] flex items-center justify-center border border-[#A83220] shadow-sm">
              <BookOpen className="w-5 h-5 text-[#FCEEE6]" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-serif font-bold text-lg tracking-wide text-[#FAF7F5]">
                  UNIVERSAL GRANTHA ENGINE
                </span>
                <span className="text-[11px] px-2 py-0.5 rounded bg-[#8B1E0F]/40 border border-[#8B1E0F] text-[#F9C3B7] font-mono">
                  SANSKRIT → KANNADA
                </span>
              </div>
              <p className="text-[11px] text-[#AFA39B] font-kannada leading-tight">
                ಸರ್ವ ಸಂಸ್ಕೃತ-ಕನ್ನಡ ಗ್ರಂಥ ವಿದ್ವತ್ ಪ್ರಕಾಶನ ಯಂತ್ರ
              </p>
            </div>
          </div>

          {/* Project Selector & Actions */}
          <div className="flex items-center space-x-2.5">
            {/* Project Picker */}
            <div className="flex items-center bg-[#281F1A] border border-[#4A3930] rounded-lg px-2 py-1">
              <span className="text-xs text-[#A8988F] mr-2 hidden sm:inline">ಪ್ರಕಲ್ಪ (Project):</span>
              <select
                id="project-selector-dropdown"
                value={currentProject?.id || ''}
                onChange={(e) => onSelectProject(e.target.value)}
                aria-label="Select Project"
                className="bg-transparent text-sm text-[#F3EEEA] font-medium focus:outline-none cursor-pointer max-w-[160px] sm:max-w-[220px] truncate"
              >
                {projects.map((p) => (
                  <option key={p.id} value={p.id} className="bg-[#1C1613] text-[#F3EEEA]">
                    {p.name}
                  </option>
                ))}
              </select>
            </div>

            {/* New Project / Manage Button */}
            <button
              id="btn-create-new-project-header"
              onClick={onNewProject}
              className="flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-[#8B1E0F] hover:bg-[#A32312] text-white text-xs font-semibold shadow-sm transition-colors"
              title="ಹೊಸ ಪ್ರಕಲ್ಪ ರಚಿಸಿ ಅಥವಾ ಹಳೆಯ ಪ್ರಕಲ್ಪಗಳನ್ನು ನಿರ್ವಹಿಸಿ/ಅಳಿಸಿ"
            >
              <Plus className="w-4 h-4" />
              <span>ಹೊಸ ಪ್ರಕಲ್ಪ / ನಿರ್ವಹಣೆ</span>
            </button>

            {/* SQLite & Key Status Pill */}
            <div className="hidden lg:flex items-center space-x-2 bg-[#281F1A] border border-[#3E2F27] rounded-lg px-2.5 py-1 text-xs text-[#C5B8AF]">
              <div className="flex items-center space-x-1" title="SQLite Checkpoint Engine Active">
                <Database className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-[11px] font-mono">SQLite Checkpoints</span>
              </div>
              <span className="text-[#554238]">|</span>
              <div className="flex items-center space-x-1" title="Gemini AI Key Pool">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-[11px] font-mono">
                  Keys: {keyStatus?.active || 1} Active
                </span>
              </div>
            </div>

            {/* Master Index / Head & Subhead Button */}
            {currentProject && onOpenMasterIndex && (
              <button
                id="btn-master-index-header"
                onClick={onOpenMasterIndex}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-[#38261E] hover:bg-[#4D3328] border border-[#634233] text-[#FCD8CC] text-xs font-semibold transition-colors"
                title="ಮಾಸ್ಟರ್ ಇಂಡೆಕ್ಸ್, ಹೆಡ್ ಮತ್ತು ಸಬ್‌ಹೆಡ್ ನಿರ್ವಹಣೆ (Head & Sub-head Index)"
              >
                <Layers className="w-4 h-4 text-[#F9A891]" />
                <span className="hidden sm:inline">ಮಾಸ್ಟರ್ ಇಂಡೆಕ್ಸ್</span>
              </button>
            )}

            {/* Export Button */}
            {currentProject && (
              <button
                id="btn-export-header"
                onClick={onOpenExport}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-[#2E231D] hover:bg-[#3D2F27] border border-[#523F34] text-[#E8DED6] text-xs font-medium transition-colors"
                title="Export DOCX / XLSX / ZIP"
              >
                <Download className="w-4 h-4 text-amber-300" />
                <span className="hidden sm:inline">ರಫ್ತು (Export)</span>
              </button>
            )}

            {/* Windows Desktop Guide */}
            <button
              id="btn-windows-guide"
              onClick={onOpenWindowsGuide}
              className="p-1.5 rounded-lg bg-[#281F1A] hover:bg-[#382C24] border border-[#44332A] text-[#C5B8AF] hover:text-white transition-colors"
              title="Windows Desktop Edition Packaging"
            >
              <Monitor className="w-4 h-4" />
            </button>

            {/* Settings */}
            <button
              id="btn-settings-header"
              onClick={onOpenSettings}
              className="p-1.5 rounded-lg bg-[#281F1A] hover:bg-[#382C24] border border-[#44332A] text-[#C5B8AF] hover:text-white transition-colors"
              title="Engine Settings & API Keys"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
