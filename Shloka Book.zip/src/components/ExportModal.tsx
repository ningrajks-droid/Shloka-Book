import React, { useState } from 'react';
import {
  X,
  Download,
  FileText,
  FileSpreadsheet,
  Archive,
  BookOpen,
  CheckCircle,
  Sparkles,
  Type,
  FileCheck2,
} from 'lucide-react';
import { GranthaProject, SanskritUnit } from '../types';

interface ExportModalProps {
  project: GranthaProject | null;
  units: SanskritUnit[];
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  project,
  units,
  onClose,
}) => {
  if (!project) return null;

  const [downloadingType, setDownloadingType] = useState<string | null>(null);
  const [selectedFont, setSelectedFont] = useState<'Nirmala UI' | 'Mangal' | 'Noto Sans Devanagari' | 'Arial Unicode MS'>('Nirmala UI');

  const completedCount = units.filter(u => u.status === 'COMPLETED').length;

  const handleDownload = (type: 'pure-docx' | 'pure-txt' | 'pdf' | 'docx' | 'audit-xlsx' | 'shloka-index' | 'zip') => {
    setDownloadingType(type);
    const fontParam = `?fontDevanagari=${encodeURIComponent(selectedFont)}&fontKannada=${encodeURIComponent(selectedFont === 'Mangal' ? 'Tunga' : selectedFont)}`;
    const url = `/api/projects/${project.id}/export/${type}${type.includes('docx') ? fontParam : ''}`;
    window.location.href = url;
    setTimeout(() => setDownloadingType(null), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-white rounded-2xl border border-[#E8E2D9] max-w-2xl w-full p-6 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-[#EAE4DC] mb-5">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-lg bg-[#8B1E0F] text-white flex items-center justify-center">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif font-bold text-lg text-[#1F1916]">
                ವಿದ್ವತ್ ಪ್ರಕಾಶನ ಗ್ರಂಥ ರಫ್ತು (Grantha Export Center)
              </h3>
              <p className="text-xs text-[#7A695D]">
                {project.name} • {completedCount} ಶ್ಲೋಕಗಳು ಸಿದ್ಧವಾಗಿವೆ
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-[#EADBCE] text-[#7A695D] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Font Selection Dropdown (Solves Blank Boxes / Tofu in MS Word) */}
        <div className="mb-5 p-3.5 bg-[#FAF7F2] border border-[#E8DFC9] rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center space-x-2">
            <Type className="w-4 h-4 text-[#8B1E0F]" />
            <div>
              <span className="text-xs font-bold text-[#1F1916]">Word ಅಕ್ಷರಶೈಲಿ (Word Indic Font):</span>
              <p className="text-[11px] text-[#7A695D]">ವರ್ಡ್‌ನಲ್ಲಿ ಖಾಲಿ ಚೌಕಗಳು (Blank boxes) ಬಾರದಂತೆ ಮುನ್ನೆಚ್ಚರಿಕೆ</p>
            </div>
          </div>
          <select
            value={selectedFont}
            onChange={(e) => setSelectedFont(e.target.value as any)}
            className="text-xs border border-[#D5CBC0] bg-white rounded-lg px-2.5 py-1.5 font-medium text-[#1F1916] focus:outline-none focus:ring-1 focus:ring-[#8B1E0F]"
          >
            <option value="Nirmala UI">Nirmala UI (Windows ಸಾರ್ವತ್ರಿಕ - ಶಿಫಾರಸು)</option>
            <option value="Mangal">Mangal (Devanagari) & Tunga (Kannada)</option>
            <option value="Noto Sans Devanagari">Noto Sans Devanagari & Kannada</option>
            <option value="Arial Unicode MS">Arial Unicode MS</option>
          </select>
        </div>

        {/* Deliverables Options */}
        <div className="space-y-3 mb-6 max-h-[50vh] overflow-y-auto pr-1">
          {/* 0. PURE SHLOKA & EXPLANATION ONLY (Highlighted for User) */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-[#FAF5F0] to-[#FFF9F5] border-2 border-[#8B1E0F] shadow-sm flex items-center justify-between">
            <div className="flex items-start space-x-3">
              <FileCheck2 className="w-6 h-6 text-[#8B1E0F] shrink-0 mt-0.5" />
              <div>
                <h4 className="font-serif font-bold text-sm text-[#1F1916] flex items-center">
                  <span>ಕೇವಲ ಶ್ಲೋಕ & ವಿವರಣೆ ಮಾತ್ರ (Pure Shloka & Explanation DOCX)</span>
                  <span className="ml-2 text-[10px] bg-[#8B1E0F] text-white px-2 py-0.5 rounded font-sans font-bold">
                    USER REQUESTED
                  </span>
                </h4>
                <p className="text-xs text-[#736357] mt-0.5">
                  ಕೇವಲ ಮೂಲ ಶ್ಲೋಕ, ಕನ್ನಡ ಲಿಪ್ಯಂತರ, ಪದಾರ್ಥ, ಸರಳ ವಿವರಣೆ ಮತ್ತು ವ್ಯಾಖ್ಯಾನ ಮಾತ್ರ (ಯಾವುದೇ ಹೆಚ್ಚುವರಿ ಕೋಷ್ಟಕ/ಸೂಚಿ ಇಲ್ಲದೆ)
                </p>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-1.5 shrink-0 ml-3">
              <button
                id="btn-download-pure-docx"
                onClick={() => handleDownload('pure-docx')}
                disabled={downloadingType !== null}
                className="px-3.5 py-1.5 rounded-lg bg-[#8B1E0F] hover:bg-[#A32312] text-white text-xs font-semibold shadow-sm transition-colors"
              >
                {downloadingType === 'pure-docx' ? 'ಸಿದ್ಧವಾಗುತ್ತಿದೆ...' : 'DOCX'}
              </button>
              <button
                id="btn-download-pdf"
                onClick={() => handleDownload('pdf')}
                disabled={downloadingType !== null}
                className="px-3 py-1.5 rounded-lg bg-red-800 hover:bg-red-900 text-white text-xs font-semibold shadow-sm transition-colors"
                title="Download Scholarly Pure PDF"
              >
                {downloadingType === 'pdf' ? 'ಸಿದ್ಧವಾಗುತ್ತಿದೆ...' : 'PDF'}
              </button>
              <button
                id="btn-download-pure-txt"
                onClick={() => handleDownload('pure-txt')}
                disabled={downloadingType !== null}
                className="px-2.5 py-1.5 rounded-lg bg-stone-700 hover:bg-stone-800 text-white text-xs font-medium transition-colors"
                title="Download Plain Text / Markdown"
              >
                {downloadingType === 'pure-txt' ? '...' : '.TXT'}
              </button>
            </div>
          </div>

          {/* 1. Complete Final Package ZIP */}
          <div className="p-3.5 rounded-xl bg-white border border-[#E8E2D9] hover:bg-[#FAF8F5] transition-all flex items-center justify-between">
            <div className="flex items-start space-x-3">
              <Archive className="w-5 h-5 text-[#8B1E0F] shrink-0 mt-0.5" />
              <div>
                <h4 className="font-serif font-bold text-xs text-[#1F1916] flex items-center">
                  <span>FINAL_PACKAGE.zip (ಸಮಗ್ರ ಗ್ರಂಥ ಪ್ಯಾಕೇಜ್)</span>
                </h4>
                <p className="text-[11px] text-[#736357] mt-0.5">
                  ಒಳಗೊಂಡಿದೆ: PURE SHLOKA.docx, FINAL MANUSCRIPT.docx, COMPLETE AUDIT.xlsx, SHLOKA INDEX.xlsx, REPORT.txt
                </p>
              </div>
            </div>
            <button
              id="btn-download-zip"
              onClick={() => handleDownload('zip')}
              disabled={downloadingType !== null}
              className="px-3.5 py-1.5 rounded-lg bg-[#2E231D] hover:bg-[#42332A] text-white text-xs font-medium shrink-0 transition-colors"
            >
              {downloadingType === 'zip' ? 'ರಚಿಸಲಾಗುತ್ತಿದೆ...' : 'ZIP'}
            </button>
          </div>

          {/* 2. Master DOCX Manuscript with Full Index */}
          <div className="p-3.5 rounded-xl bg-white border border-[#E8E2D9] hover:bg-[#FAF8F5] transition-all flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <FileText className="w-5 h-5 text-blue-700 shrink-0" />
              <div>
                <h4 className="font-serif font-bold text-xs text-[#1F1916]">
                  FINAL_SCHOLARLY_MANUSCRIPT.docx (ವಿಸ್ತೃತ ವಿದ್ವತ್ ಗ್ರಂಥ)
                </h4>
                <p className="text-[11px] text-[#7A695D]">
                  5 ವಿಭಾಗಗಳು, ಕೋಷ್ಟಕಗಳು, ಮತ್ತು ಶ್ಲೋಕಾನುಕ್ರಮಣಿಕಾ ಸೂಚಿ ಸಹಿತ
                </p>
              </div>
            </div>
            <button
              id="btn-download-docx"
              onClick={() => handleDownload('docx')}
              disabled={downloadingType !== null}
              className="px-3.5 py-1.5 rounded-lg bg-[#2E231D] hover:bg-[#42332A] text-white text-xs font-medium shrink-0 transition-colors"
            >
              {downloadingType === 'docx' ? 'ಸಿದ್ಧವಾಗುತ್ತಿದೆ...' : 'DOCX'}
            </button>
          </div>

          {/* 3. Complete Audit Workbook XLSX */}
          <div className="p-3.5 rounded-xl bg-white border border-[#E8E2D9] hover:bg-[#FAF8F5] transition-all flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <FileSpreadsheet className="w-5 h-5 text-emerald-700 shrink-0" />
              <div>
                <h4 className="font-serif font-bold text-xs text-[#1F1916]">
                  COMPLETE_AUDIT.xlsx (ಸಮಗ್ರ ಲೆಕ್ಕಪರಿಶೋಧನೆ)
                </h4>
                <p className="text-[11px] text-[#7A695D]">
                  ಮಾಸ್ಟರ್ ಇಂಡೆಕ್ಸ್, ಬದಲಾವಣೆಗಳ ದಾಖಲೆ, ಪುನರ್ಪರಿಶೀಲನೆ, ದೃಢೀಕರಣ
                </p>
              </div>
            </div>
            <button
              id="btn-download-audit-xlsx"
              onClick={() => handleDownload('audit-xlsx')}
              disabled={downloadingType !== null}
              className="px-3.5 py-1.5 rounded-lg bg-[#2E231D] hover:bg-[#42332A] text-white text-xs font-medium shrink-0 transition-colors"
            >
              {downloadingType === 'audit-xlsx' ? 'ಸಿದ್ಧವಾಗುತ್ತಿದೆ...' : 'Audit XLSX'}
            </button>
          </div>

          {/* 4. Shloka Index XLSX */}
          <div className="p-3.5 rounded-xl bg-white border border-[#E8E2D9] hover:bg-[#FAF8F5] transition-all flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <BookOpen className="w-5 h-5 text-amber-700 shrink-0" />
              <div>
                <h4 className="font-serif font-bold text-xs text-[#1F1916]">
                  SHLOKA_INDEX.xlsx (ಶ್ಲೋಕಾನುಕ್ರಮಣಿಕಾ ಸೂಚಿ)
                </h4>
                <p className="text-[11px] text-[#7A695D]">
                  ಪ್ರಥಮ ಪದ, ಗ್ರಂಥ, ಶ್ರೇಣಿ & ಪುಟ ಸಂಖ್ಯೆಯೊಂದಿಗೆ ವರ್ಣಮಾಲಾ ಸೂಚಿ
                </p>
              </div>
            </div>
            <button
              id="btn-download-shloka-index"
              onClick={() => handleDownload('shloka-index')}
              disabled={downloadingType !== null}
              className="px-3.5 py-1.5 rounded-lg bg-[#2E231D] hover:bg-[#42332A] text-white text-xs font-medium shrink-0 transition-colors"
            >
              {downloadingType === 'shloka-index' ? 'ಸಿದ್ಧವಾಗುತ್ತಿದೆ...' : 'Index XLSX'}
            </button>
          </div>
        </div>

        {/* Close Button */}
        <div className="flex justify-end pt-3 border-t border-[#EAE4DC]">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold transition-colors"
          >
            ಮುಚ್ಚಿ (Close)
          </button>
        </div>
      </div>
    </div>
  );
};

