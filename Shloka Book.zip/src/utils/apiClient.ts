/**
 * Safe API Client for resilient JSON communication with rate-limit resilience
 */

export interface SafeFetchResponse<T> {
  data: T | null;
  error: string | null;
  ok: boolean;
  status: number;
  isRateLimited?: boolean;
}

export async function safeFetchJson<T = any>(
  url: string,
  options?: RequestInit
): Promise<SafeFetchResponse<T>> {
  try {
    const res = await fetch(url, options);
    const contentType = res.headers.get('content-type') || '';
    const text = await res.text();

    const isRateLimited =
      res.status === 429 ||
      text.includes('Rate exceeded') ||
      text.includes('quota exceeded') ||
      text.includes('RESOURCE_EXHAUSTED');

    if (!res.ok || isRateLimited) {
      return {
        data: null,
        error: isRateLimited ? 'Rate limit reached, backing off...' : (text || `HTTP ${res.status}`),
        ok: false,
        status: res.status,
        isRateLimited,
      };
    }

    if (!contentType.includes('application/json') && !text.trim().startsWith('{') && !text.trim().startsWith('[')) {
      return {
        data: null,
        error: `Unexpected server response: ${text.slice(0, 100)}`,
        ok: false,
        status: res.status,
      };
    }

    try {
      const data = JSON.parse(text) as T;
      return {
        data,
        error: null,
        ok: true,
        status: res.status,
      };
    } catch (parseError: any) {
      return {
        data: null,
        error: `JSON Parse error: ${parseError.message}`,
        ok: false,
        status: res.status,
      };
    }
  } catch (err: any) {
    return {
      data: null,
      error: err.message || 'Network communication error',
      ok: false,
      status: 0,
    };
  }
}
