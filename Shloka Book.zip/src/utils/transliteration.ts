// Client-side pure transliterator between Devanagari Sanskrit and Kannada script
export function sanitizeUnicodeText(text: string): string {
  if (!text) return '';
  return text
    .normalize('NFC')
    .replace(/\uFFFD/g, '')
    .replace(/[\u0000-\u0008\u000B-\u001F\u007F-\u009F\uFEFF]/g, '')
    .replace(/[\u200B\u200C\u200D\u2060]/g, '')
    .replace(/[\u00A0\u1680\u2000-\u200A\u202F\u205F\u3000]/g, ' ');
}

export function toEnglishDigits(text: string): string {
  if (!text) return '';
  return sanitizeUnicodeText(text)
    .replace(/[०-९]/g, (d) => String(d.charCodeAt(0) - 0x0966))
    .replace(/[೦-೯]/g, (d) => String(d.charCodeAt(0) - 0x0CE6));
}

const DEVA_TO_KAN_MAP: Record<string, string> = {
  'अ': 'ಅ', 'आ': 'ಆ', 'इ': 'ಇ', 'ई': 'ಈ', 'उ': 'ಉ', 'ऊ': 'ಊ',
  'ऋ': 'ಋ', 'ॠ': 'ೠ', 'ऌ': 'ಌ', 'ॡ': 'ೡ',
  'ए': 'ಏ', 'ऐ': 'ಐ', 'ओ': 'ಓ', 'औ': 'ಔ',
  'क': 'ಕ', 'ख': 'ಖ', 'ग': 'ಗ', 'घ': 'ಘ', 'ङ': 'ಙ',
  'च': 'ಚ', 'छ': 'ಛ', 'ज': 'ಜ', 'झ': 'ಝ', 'ञ': 'ಞ',
  'ट': 'ಟ', 'ठ': 'ಠ', 'ಡ': 'ಡ', 'ढ': 'ಢ', 'ण': 'ಣ',
  'त': 'ತ', 'थ': 'ಥ', 'द': 'ದ', 'ಧ': 'ಧ', 'न': 'ನ',
  'प': 'ಪ', 'फ': 'ಫ', 'ब': 'ಬ', 'ಭ': 'ಭ', 'म': 'ಮ',
  'य': 'ಯ', 'र': 'ರ', 'ल': 'ಲ', 'व': 'ವ',
  'श': 'ಶ', 'ष': 'ಷ', 'ಸ': 'ಸ', 'स': 'ಸ', 'ह': 'ಹ',
  'ळ': 'ಳ',
  'ा': 'ಾ', 'ि': 'ಿ', 'ी': 'ೀ', 'ु': 'ು', 'ू': 'ೂ',
  'ृ': 'ೃ', 'ॄ': 'ೄ', 'ॢ': 'ೢ', 'ॣ': 'ೣ',
  'े': 'ೇ', 'ै': 'ೈ', 'ो': 'ೋ', 'ौ': 'ೌ',
  '्': '್',
  'ं': 'ಂ', 'ः': 'ಃ', 'ँ': 'ಁ', 'ऽ': 'ಽ', 'ॐ': 'ಓಂ', '़': '',
  '०': '0', '१': '1', '२': '2', '३': '3', '४': '4',
  '५': '5', '६': '6', '७': '7', '८': '8', '९': '9',
  '೦': '0', '೧': '1', '೨': '2', '೩': '3', '೪': '4',
  '೫': '5', '೬': '6', '೭': '7', '೮': '8', '೯': '9',
  '।': ' । ', '॥': ' ॥ ',
};

export function devanagariToKannada(devanagariText: string): string {
  if (!devanagariText) return '';
  const sanitized = sanitizeUnicodeText(devanagariText);
  let result = '';
  const length = sanitized.length;
  let i = 0;

  while (i < length) {
    if (i + 1 < length) {
      const twoChar = sanitized.substring(i, i + 2);
      if (twoChar === '||' || twoChar === '//') {
        result += ' ॥ ';
        i += 2;
        continue;
      }
    }

    const char = sanitized[i];
    if (char === '|') {
      result += ' । ';
      i++;
      continue;
    }

    if (DEVA_TO_KAN_MAP[char] !== undefined) {
      result += DEVA_TO_KAN_MAP[char];
    } else if (/[A-Za-z]/.test(char)) {
      // ignore latin
    } else {
      result += char;
    }
    i++;
  }

  return toEnglishDigits(result).trim();
}
