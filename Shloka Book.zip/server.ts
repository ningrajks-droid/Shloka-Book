import 'dotenv/config';
import express from 'express';
import path from 'path';
import fs from 'fs';
import multer from 'multer';
import { createServer as createViteServer } from 'vite';
import {
  createProject,
  getAllProjects,
  getProjectById,
  updateProject,
  deleteProject,
  clearAllProjectsAndUnits,
  addDocument,
  getDocumentsByProjectId,
  deleteDocument,
  deleteAllDocumentsInProject,
  resetProjectData,
  getUnitsByProjectId,
  getUnitById,
  saveUnit,
  deleteUnit,
  getSettings,
  saveSettings,
} from './server/db';
import { extractDocumentText } from './server/pdfExtractor';
import {
  detectDocumentStructure,
  splitTextIntoSanskritUnits,
  extractAllSanskritUnitsFromDocument,
  buildTableOfContents,
  isHeadingOrColophonUnit,
  classifyTextBlock,
} from './server/structureDetector';
import {
  startOrResumeProjectProcessing,
  pauseProjectProcessing,
  cancelProjectProcessing,
  isProjectProcessing,
  addProjectLog,
  getProjectLogs,
  clearProjectLogs,
  subscribeProjectStream,
  getProjectLiveState,
} from './server/jobRunner';
import {
  generatePureShlokaDocx,
  generatePureShlokaText,
  generatePureShlokaPdf,
  generateMasterDocx,
  generateCompleteAuditXlsx,
  generateShlokaIndexXlsx,
  generateFinalPackageZip,
  generateDesktopOfflineBundle,
} from './server/documentGenerator';
import { SAMPLE_SANSKRIT_DOCS } from './server/sampleData';
import { keyManager } from './server/keyManager';
import { verifySanskritUnit } from './server/sourceVerifier';
import { generateScholarlyUnitContent, generateScholarlyUnitContentStream, completeMissingScholarlySections } from './server/gemini';
import {
  normalizeSanskritVerse,
  devanagariToKannada,
  formatPadarthaWithDevanagariPadas,
  standardizeShlokaNumbering,
  ensurePureKannadaTransliteration,
  ensurePureKannadaScript,
  cleanRepetitiveLoops,
} from './server/transliteration';
import { validateSanskritUnitOutput } from './server/validator';
import { SanskritUnit } from './src/types';

const UPLOAD_DIR = path.join(process.cwd(), 'grantha_uploads');
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

const upload = multer({
  dest: UPLOAD_DIR,
  limits: { fileSize: 100 * 1024 * 1024 }, // 100MB limit
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // ===================== API ENDPOINTS =====================

  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      service: 'Universal Sanskrit -> Kannada Scholarly Grantha Engine',
      timestamp: new Date().toISOString(),
    });
  });

  // Settings
  app.get('/api/settings', async (req, res) => {
    try {
      const settings = await getSettings();
      res.json(settings);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/settings', async (req, res) => {
    try {
      const updated = await saveSettings(req.body);
      res.json(updated);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Upload custom Creator / Author Portrait Photo
  app.post('/api/author-photo', upload.single('photo'), async (req, res) => {
    try {
      const file = req.file;
      if (!file) {
        return res.status(400).json({ success: false, error: 'ಯಾವುದೇ ಫೋಟೋ ಆಯ್ಕೆಯಾಗಿಲ್ಲ (No photo selected)' });
      }

      // Read uploaded photo and save it to public and dist directories as NKS.jpg
      const photoBuffer = fs.readFileSync(file.path);
      const publicDir = path.join(process.cwd(), 'public');
      const distDir = path.join(process.cwd(), 'dist');

      if (!fs.existsSync(publicDir)) fs.mkdirSync(publicDir, { recursive: true });
      if (!fs.existsSync(distDir)) fs.mkdirSync(distDir, { recursive: true });

      const publicPath = path.join(publicDir, 'NKS.jpg');
      const distPath = path.join(distDir, 'NKS.jpg');

      fs.writeFileSync(publicPath, photoBuffer);
      fs.writeFileSync(distPath, photoBuffer);

      // Clean up temp file
      try {
        fs.unlinkSync(file.path);
      } catch (e) {
        // ignore
      }

      const timestamp = Date.now();
      res.json({
        success: true,
        message: 'ಫೋಟೋ ಯಶಸ್ವಿಯಾಗಿ ನವೀಕರಣಗೊಂಡಿದೆ (Photo uploaded successfully)',
        photoUrl: `/NKS.jpg?v=${timestamp}`,
      });
    } catch (err: any) {
      console.error('Error saving author photo:', err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  app.get('/api/key-status', async (req, res) => {
    try {
      const status = await keyManager.getKeyStatuses();
      res.json(status);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/test-key', async (req, res) => {
    try {
      const key = await keyManager.getNextApiKey();
      if (!key) {
        return res.status(400).json({ success: false, error: 'ಯಾವುದೇ Gemini API ಕೀ ಕಂಡುಬಂದಿಲ್ಲ (No API key found)' });
      }
      // Simple lightweight verification call
      const { GoogleGenAI } = await import('@google/genai');
      const ai = new GoogleGenAI({ apiKey: key });
      const response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite',
        contents: 'Respond with OK',
      });
      if (response.text) {
        keyManager.reportSuccess(key);
        res.json({ success: true, message: 'Gemini API Key is valid and connected!' });
      } else {
        res.status(500).json({ success: false, error: 'Empty response from Gemini' });
      }
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Samples
  app.get('/api/samples', (req, res) => {
    res.json(SAMPLE_SANSKRIT_DOCS);
  });

  // Projects
  app.get('/api/projects', async (req, res) => {
    try {
      const projects = await getAllProjects();
      res.json(projects);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/projects', async (req, res) => {
    try {
      const { name, description } = req.body;
      const project = await createProject(name || 'ನೂತನ ವಿದ್ವತ್ ಪ್ರಕಲ್ಪ (New Project)', description || '');
      res.json(project);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/projects/:id', async (req, res) => {
    try {
      const project = await getProjectById(req.params.id);
      if (!project) return res.status(404).json({ error: 'Project not found' });
      const docs = await getDocumentsByProjectId(req.params.id);
      const isRunning = isProjectProcessing(req.params.id);
      res.json({ ...project, documents: docs, isRunning });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.delete('/api/projects/:id', async (req, res) => {
    try {
      cancelProjectProcessing(req.params.id);
      await deleteProject(req.params.id);
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Clear all projects, documents, and units
  app.post('/api/reset-all', async (req, res) => {
    try {
      await clearAllProjectsAndUnits();
      res.json({ success: true, message: 'All project data, documents, and units cleared.' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Load Built-in Canonical Sample into Project
  app.post('/api/projects/:id/load-sample', async (req, res) => {
    try {
      const projectId = req.params.id;
      const { sampleId } = req.body;
      const sample = SAMPLE_SANSKRIT_DOCS.find(s => s.id === sampleId) || SAMPLE_SANSKRIT_DOCS[0];

      const docId = 'doc_' + Date.now();
      const structure = detectDocumentStructure(sample.fullText);

      await addDocument({
        id: docId,
        projectId,
        fileName: sample.fileName,
        fileSize: Buffer.byteLength(sample.fullText, 'utf-8'),
        pageCount: 1,
        detectedType: 'TEXT_FILE',
        detectedWork: structure.detectedWork,
        structuralType: `${structure.level1Name} → ${structure.level3Name || 'ಶ್ಲೋಕ'}`,
        status: 'EXTRACTED',
        uploadedAt: new Date().toISOString(),
      });

      const extractedUnits = extractAllSanskritUnitsFromDocument([{ pageNumber: 1, text: sample.fullText }], structure);

      let unitIndex = 1;
      for (const eu of extractedUnits) {
        const uId = `unit_${projectId}_${docId}_${unitIndex}`;
        const isHeadOrColophon = eu.unitType === 'HEADING' || eu.unitType === 'COLOPHON';
        const unitObj: SanskritUnit = {
          id: uId,
          projectId,
          docId,
          fileName: sample.fileName,
          pageNumber: eu.pageNumber,
          unitIndex,
          detectedWork: structure.detectedWork,
          unitType: eu.unitType,
          structuralHierarchy: eu.hierarchy,
          originalText: eu.originalText,
          rawExtractedText: eu.rawText,
          verifiedText: eu.originalText,
          firstMeaningfulWord: eu.firstMeaningfulWord,
          status: 'PENDING',
          confidence: 'HIGH',
          validationScore: 0,
          validationIssues: [],
          output: undefined,
          timestamps: {
            created: new Date().toISOString(),
            updated: new Date().toISOString(),
          },
        };
        await saveUnit(unitObj);
        unitIndex++;
      }

      await updateProject({
        id: projectId,
        totalDocuments: 1,
        totalPages: 1,
        totalUnits: extractedUnits.length,
        detectedWork: structure.detectedWork,
        detectedGenre: structure.genre,
      });

      res.json({ success: true, count: extractedUnits.length, detectedWork: structure.detectedWork });
    } catch (err: any) {
      console.error('Error loading sample:', err);
      res.status(500).json({ error: err.message });
    }
  });

  // Upload Files (Single PDF, Multiple PDFs, Merged PDF, TXT)
  const handleUploadRequest = async (req: express.Request, res: express.Response) => {
    const files = req.files as Express.Multer.File[];
    try {
      let projectId = req.params.id;
      let project = (projectId && projectId !== 'upload' && projectId !== 'undefined') 
        ? await getProjectById(projectId) 
        : null;

      if (!project) {
        const allProjs = await getAllProjects();
        if (allProjs.length > 0) {
          projectId = allProjs[0].id;
          project = allProjs[0];
        } else {
          project = await createProject('ನನ್ನ ಸಂಸ್ಕೃತ ಗ್ರಂಥ ಪ್ರಕಲ್ಪ', 'PDF ಸಂಸ್ಕೃತ ಗ್ರಂಥ ಸಂಗ್ರಹ');
          projectId = project.id;
        }
      }

      if (!files || files.length === 0) {
        return res.status(400).json({ error: 'ಯಾವುದೇ ಕಡತಗಳು ಸ್ವೀಕೃತವಾಗಿಲ್ಲ (No files uploaded)' });
      }

      let totalPagesAdded = 0;
      let totalUnitsAdded = 0;
      let lastDetectedWork = '';
      let lastDetectedGenre = '';

      for (const file of files) {
        const docId = 'doc_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4);
        
        try {
          // Native PDF extraction
          const extraction = await extractDocumentText(file.path, file.originalname);
          const structure = detectDocumentStructure(extraction.fullText || file.originalname);
          lastDetectedWork = structure.detectedWork;
          lastDetectedGenre = structure.genre;

          await addDocument({
            id: docId,
            projectId,
            fileName: file.originalname,
            fileSize: file.size,
            pageCount: extraction.totalPages,
            detectedType: extraction.detectedType,
            detectedWork: structure.detectedWork,
            structuralType: `${structure.level1Name} → ${structure.level2Name ? structure.level2Name + ' → ' : ''}${structure.level3Name || 'ಶ್ಲೋಕ'}`,
            status: 'EXTRACTED',
            uploadedAt: new Date().toISOString(),
          });

          totalPagesAdded += extraction.totalPages;

          const docUnits = extractAllSanskritUnitsFromDocument(extraction.pages, structure);
          let docUnitIndex = 1;
          for (const pu of docUnits) {
            const uId = `unit_${projectId}_${docId}_${docUnitIndex}`;
            const isHeadOrColophon = isHeadingOrColophonUnit({ originalText: pu.originalText, unitType: pu.unitType });
            const finalUnitType = isHeadOrColophon
              ? (pu.unitType === 'COLOPHON' || classifyTextBlock(pu.originalText).isColophon ? 'COLOPHON' : 'HEADING')
              : pu.unitType;
            const unitObj: SanskritUnit = {
              id: uId,
              projectId,
              docId,
              fileName: file.originalname,
              pageNumber: pu.pageNumber,
              unitIndex: docUnitIndex,
              detectedWork: structure.detectedWork,
              unitType: finalUnitType,
              structuralHierarchy: pu.hierarchy,
              originalText: pu.originalText,
              rawExtractedText: pu.rawText,
              verifiedText: pu.originalText,
              firstMeaningfulWord: pu.firstMeaningfulWord,
              status: 'PENDING',
              confidence: 'HIGH',
              validationScore: 0,
              validationIssues: [],
              output: undefined,
              timestamps: {
                created: new Date().toISOString(),
                updated: new Date().toISOString(),
              },
            };
            await saveUnit(unitObj);
            docUnitIndex++;
            totalUnitsAdded++;
          }
        } finally {
          // Clean up uploaded temp file
          try {
            if (fs.existsSync(file.path)) {
              fs.unlinkSync(file.path);
            }
          } catch {
            // Safe ignore
          }
        }
      }

      const existingUnits = await getUnitsByProjectId(projectId);
      const existingDocs = await getDocumentsByProjectId(projectId);

      await updateProject({
        id: projectId,
        totalDocuments: existingDocs.length,
        totalPages: existingDocs.reduce((acc, d) => acc + d.pageCount, 0),
        totalUnits: existingUnits.length,
        detectedWork: lastDetectedWork || project.detectedWork,
        detectedGenre: lastDetectedGenre || project.detectedGenre,
      });

      addProjectLog(projectId, {
        level: 'success',
        message: `ಕಡತ ವಿಶ್ಲೇಷಣೆ ಪೂರ್ಣಗೊಂಡಿದೆ: ${files.length} ಕಡತ(ಗಳು), ${totalPagesAdded} ಪುಟಗಳು, ${totalUnitsAdded} ಶ್ಲೋಕಗಳು ಸಿದ್ಧವಾಗಿವೆ. ಗ್ರಂಥ: ${lastDetectedWork || 'ಗುರುತಿಸಲಾಗಿದೆ'}.`,
        stage: 'UPLOAD_COMPLETE',
      });

      res.json({
        success: true,
        projectId,
        filesUploaded: files.length,
        totalPagesAdded,
        totalUnitsAdded,
        detectedWork: lastDetectedWork,
      });
    } catch (err: any) {
      console.error('Error handling upload:', err);
      // Clean up files on error
      if (files && Array.isArray(files)) {
        for (const file of files) {
          try {
            if (fs.existsSync(file.path)) fs.unlinkSync(file.path);
          } catch {}
        }
      }
      res.status(500).json({ error: err.message || 'Error parsing uploaded Sanskrit document' });
    }
  };

  app.post('/api/projects/:id/upload', upload.array('files'), handleUploadRequest);
  app.post('/api/projects/upload', upload.array('files'), handleUploadRequest);
  app.post('/api/upload', upload.array('files'), handleUploadRequest);

  // Direct text / Shloka paste endpoint
  app.post('/api/projects/:id/add-text', async (req, res) => {
    try {
      const projectId = req.params.id;
      const { text, title } = req.body;
      if (!text || !text.trim()) {
        return res.status(400).json({ error: 'ಪಠ್ಯವನ್ನು ನಮೂದಿಸಿ (Text is required)' });
      }

      const structure = detectDocumentStructure(text);
      const docId = 'doc_' + Date.now();
      const fileName = title || `${structure.detectedWork || 'ಸಂಸ್ಕೃತ_ಪಠ್ಯ'}.txt`;

      await addDocument({
        id: docId,
        projectId,
        fileName,
        fileSize: Buffer.byteLength(text, 'utf-8'),
        pageCount: 1,
        detectedType: 'TEXT_FILE',
        detectedWork: structure.detectedWork,
        structuralType: `${structure.level1Name} → ${structure.level3Name || 'ಶ್ಲೋಕ'}`,
        status: 'EXTRACTED',
        uploadedAt: new Date().toISOString(),
      });

      const extractedUnits = splitTextIntoSanskritUnits(text, 1, structure, 1);
      let unitIndex = 1;
      for (const eu of extractedUnits) {
        const uId = `unit_${projectId}_${docId}_${unitIndex}`;
        const isHeadOrColophon = isHeadingOrColophonUnit({ originalText: eu.originalText, unitType: eu.unitType });
        const finalUnitType = isHeadOrColophon
          ? (eu.unitType === 'COLOPHON' || classifyTextBlock(eu.originalText).isColophon ? 'COLOPHON' : 'HEADING')
          : (eu.unitType || 'SHLOKA');
        const unitObj: SanskritUnit = {
          id: uId,
          projectId,
          docId,
          fileName,
          pageNumber: eu.pageNumber,
          unitIndex,
          detectedWork: structure.detectedWork,
          unitType: finalUnitType,
          structuralHierarchy: eu.hierarchy,
          originalText: eu.originalText,
          rawExtractedText: eu.rawText,
          verifiedText: eu.originalText,
          firstMeaningfulWord: eu.firstMeaningfulWord,
          status: 'PENDING',
          confidence: 'HIGH',
          validationScore: 0,
          validationIssues: [],
          output: undefined,
          timestamps: {
            created: new Date().toISOString(),
            updated: new Date().toISOString(),
          },
        };
        await saveUnit(unitObj);
        unitIndex++;
      }

      const existingUnits = await getUnitsByProjectId(projectId);
      const existingDocs = await getDocumentsByProjectId(projectId);

      await updateProject({
        id: projectId,
        totalDocuments: existingDocs.length,
        totalPages: existingDocs.reduce((acc, d) => acc + d.pageCount, 0),
        totalUnits: existingUnits.length,
        detectedWork: structure.detectedWork,
        detectedGenre: structure.genre,
      });

      res.json({
        success: true,
        detectedWork: structure.detectedWork,
        unitsCount: extractedUnits.length,
      });
    } catch (err: any) {
      console.error('Error adding text:', err);
      res.status(500).json({ error: err.message });
    }
  });

  // Delete single document and its extracted units
  app.delete('/api/projects/:projectId/documents/:docId', async (req, res) => {
    try {
      const { projectId, docId } = req.params;
      await deleteDocument(projectId, docId);
      const remainingDocs = await getDocumentsByProjectId(projectId);
      const remainingUnits = await getUnitsByProjectId(projectId);
      res.json({
        success: true,
        message: 'Document and its extracted verses deleted successfully',
        remainingDocsCount: remainingDocs.length,
        remainingUnitsCount: remainingUnits.length,
      });
    } catch (err: any) {
      console.error('Error deleting document:', err);
      res.status(500).json({ error: err.message });
    }
  });

  // Clear all documents in project
  app.delete('/api/projects/:projectId/documents', async (req, res) => {
    try {
      const { projectId } = req.params;
      await deleteAllDocumentsInProject(projectId);
      res.json({ success: true, message: 'All documents cleared from project' });
    } catch (err: any) {
      console.error('Error clearing documents:', err);
      res.status(500).json({ error: err.message });
    }
  });

  // Full reset project data (documents, units, detected work, progress)
  app.post('/api/projects/:id/reset', async (req, res) => {
    try {
      const projectId = req.params.id;
      await resetProjectData(projectId);
      res.json({ success: true, message: 'Project reset successfully' });
    } catch (err: any) {
      console.error('Error resetting project:', err);
      res.status(500).json({ error: err.message });
    }
  });

  // Table of Contents / Master Index endpoint
  app.get('/api/projects/:id/table-of-contents', async (req, res) => {
    try {
      const project = await getProjectById(req.params.id);
      if (!project) return res.status(404).json({ error: 'Project not found' });
      const units = await getUnitsByProjectId(req.params.id);
      const toc = buildTableOfContents(units, project.detectedWork || project.name);
      res.json(toc);
    } catch (err: any) {
      console.error('Error generating TOC:', err);
      res.status(500).json({ error: err.message });
    }
  });

  // Batch update global structure schema (Head, Sub-head, Grantha Title, Genre)
  app.post('/api/projects/:id/update-structure-schema', async (req, res) => {
    try {
      const projectId = req.params.id;
      const { workTitle, genre, level1Name, level2Name, level3Name } = req.body;
      const project = await getProjectById(projectId);
      if (!project) return res.status(404).json({ error: 'Project not found' });

      // Update project record
      await updateProject({
        id: projectId,
        name: workTitle || project.name,
        detectedWork: workTitle || project.detectedWork,
        detectedGenre: genre || project.detectedGenre,
      });

      // Update all units with new level names
      const units = await getUnitsByProjectId(projectId);
      for (const u of units) {
        const h = {
          level1Name: level1Name !== undefined ? level1Name.trim() : (u.structuralHierarchy?.level1Name || ''),
          level1Value: u.structuralHierarchy?.level1Value,
          level2Name: level2Name !== undefined ? (level2Name.trim() || undefined) : u.structuralHierarchy?.level2Name,
          level2Value: u.structuralHierarchy?.level2Value,
          level3Name: level3Name !== undefined ? (level3Name.trim() || 'ಮಂತ್ರ') : u.structuralHierarchy?.level3Name,
          level3Value: u.structuralHierarchy?.level3Value,
          sectionName: u.structuralHierarchy?.sectionName,
          subsectionName: u.structuralHierarchy?.subsectionName,
          formattedNumber: u.structuralHierarchy?.formattedNumber || '',
          isUnnumbered: u.structuralHierarchy?.isUnnumbered,
        };

        await saveUnit({
          ...u,
          detectedWork: workTitle || u.detectedWork,
          structuralHierarchy: h,
        });
      }

      res.json({
        success: true,
        updatedUnitsCount: units.length,
        detectedWork: workTitle || project.detectedWork,
      });
    } catch (err: any) {
      console.error('Error updating structure schema:', err);
      res.status(500).json({ error: err.message });
    }
  });

  // Units
  app.get('/api/projects/:id/units', async (req, res) => {
    try {
      const units = await getUnitsByProjectId(req.params.id);
      res.json(units);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/units/:id', async (req, res) => {
    try {
      const unit = await getUnitById(req.params.id);
      if (!unit) return res.status(404).json({ error: 'Unit not found' });
      res.json(unit);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.delete('/api/units/:id', async (req, res) => {
    try {
      const unit = await getUnitById(req.params.id);
      if (!unit) return res.status(404).json({ error: 'Unit not found' });
      await deleteUnit(req.params.id);
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Manual Review / Edit Unit
  app.put('/api/units/:id', async (req, res) => {
    try {
      const existing = await getUnitById(req.params.id);
      if (!existing) return res.status(404).json({ error: 'Unit not found' });

      const updated = { ...existing, ...req.body };
      if (req.body.action === 'ACCEPT') {
        updated.status = 'COMPLETED';
        updated.confidence = 'HIGH';
      } else if (req.body.action === 'REJECT') {
        updated.status = 'FAILED';
      }

      await saveUnit(updated);
      res.json(updated);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Reprocess Single Unit
  // Optional body: { manualUnitType: 'HEADING' | 'SHLOKA' } lets the user manually
  // override the auto-detected classification from the Verse Index list (see
  // handleChangeUnitType in App.tsx). 'HEADING' forces heading-only output (no
  // padartha/saralaVivarane/vivaradaVyakhyana generation); 'SHLOKA' forces the full
  // 5-section generation pipeline even if the text would otherwise auto-classify as
  // a heading/colophon.
  app.post('/api/units/:id/reprocess', async (req, res) => {
    try {
      const unit = await getUnitById(req.params.id);
      if (!unit) return res.status(404).json({ error: 'Unit not found' });

      const manualUnitType: 'HEADING' | 'SHLOKA' | undefined =
        req.body?.manualUnitType === 'HEADING' || req.body?.manualUnitType === 'SHLOKA'
          ? req.body.manualUnitType
          : undefined;

      // HEADINGS & COLOPHONS (auto-detected, or manually forced to HEADING):
      if (manualUnitType === 'HEADING' || (!manualUnitType && isHeadingOrColophonUnit(unit))) {
        unit.unitType =
          manualUnitType === 'HEADING'
            ? 'HEADING'
            : unit.unitType === 'COLOPHON' || classifyTextBlock(unit.originalText).isColophon
            ? 'COLOPHON'
            : 'HEADING';
        const normText = normalizeSanskritVerse(unit.originalText);
        const kannadaTrans = devanagariToKannada(normText);
        unit.verifiedText = normText;
        unit.confidence = 'HIGH';
        unit.output = {
          moolaShloka: normText,
          kannadaTransliteration: kannadaTrans,
          padartha: '',
          saralaVivarane: '',
          vivaradaVyakhyana: '',
        };
        unit.status = 'COMPLETED';
        unit.validationScore = 100;
        unit.validationIssues = [];
        await saveUnit(unit);
        return res.json(unit);
      }

      // Manual override to SHLOKA: force the full 5-section generation pipeline below
      // even if this unit was previously (or would otherwise be) classified as a
      // HEADING/COLOPHON/GADYA. The unitType is set now; Step 2 fills all 5 output
      // fields (moolaShloka, kannadaTransliteration, padartha, saralaVivarane,
      // vivaradaVyakhyana) so the "5 parameters" requirement is met.
      if (manualUnitType === 'SHLOKA') {
        unit.unitType = 'SHLOKA';
      }

      // Step 1: verify
      const ver = await verifySanskritUnit(unit.originalText, unit.detectedWork, unit.structuralHierarchy.formattedNumber);
      unit.verifiedText = ver.verifiedText;
      unit.confidence = ver.confidence;
      unit.sourceVerification = {
        referenceSource: ver.referenceSource,
        matchedWork: ver.matchedWork,
        matchedVerseNum: ver.matchedVerseNum,
        confidenceScore: ver.confidenceScore,
        notes: ver.notes,
        diffFound: ver.diffFound,
      };

      // Step 2: generate
      const gen = await generateScholarlyUnitContent(unit, 0.1);
      
      const cleanMoola = standardizeShlokaNumbering(gen.moolaShloka || unit.verifiedText || unit.originalText);
      const pureKannadaTranslit = ensurePureKannadaTransliteration(
        gen.kannadaTransliteration,
        cleanMoola || unit.verifiedText || unit.originalText
      );

      unit.output = {
        moolaShloka: cleanMoola,
        kannadaTransliteration: standardizeShlokaNumbering(pureKannadaTranslit),
        padartha: formatPadarthaWithDevanagariPadas(gen.padartha),
        saralaVivarane: ensurePureKannadaScript(cleanRepetitiveLoops(gen.saralaVivarane)),
        vivaradaVyakhyana: ensurePureKannadaScript(cleanRepetitiveLoops(gen.vivaradaVyakhyana)),
        visualAnalysis: gen.visualAnalysis,
        tableContent: gen.tableContent,
        diagramContent: gen.diagramContent,
        pictureContent: gen.pictureContent,
      };

      // Step 3: validate
      const val = validateSanskritUnitOutput(unit);
      unit.validationScore = val.score;
      unit.validationIssues = val.issues;
      unit.status = val.isValid ? 'COMPLETED' : 'REVIEW_REQUIRED';

      await saveUnit(unit);
      res.json(unit);
    } catch (err: any) {
      console.error(`Error reprocessing unit ${req.params.id}:`, err);
      res.status(500).json({ error: err.message });
    }
  });

  // Targeted Scholarly Repair for Unit Section (Padartha, Sarala, Vyakhyana, or All)
  app.post('/api/units/:id/repair-section', async (req, res) => {
    try {
      const unit = await getUnitById(req.params.id);
      if (!unit) return res.status(404).json({ error: 'Unit not found' });

      const section = req.body?.section || 'all';
      const moola = unit.output?.moolaShloka || unit.verifiedText || unit.originalText;
      let padartha = unit.output?.padartha || '';
      let sarala = unit.output?.saralaVivarane || '';
      let vyakhyana = unit.output?.vivaradaVyakhyana || '';

      if (section === 'padartha' || section === 'all') {
        padartha = ''; // Force regeneration of complete word-by-word padartha
      }
      if (section === 'saralaVivarane' || section === 'all') {
        sarala = ''; // Force regeneration of complete sarala vivarane
      }
      if (section === 'vivaradaVyakhyana' || section === 'all') {
        vyakhyana = ''; // Force regeneration of complete doctrinal commentary
      }

      const completed = await completeMissingScholarlySections(
        moola,
        padartha,
        sarala,
        vyakhyana,
        unit.detectedWork
      );

      if (!unit.output) {
        unit.output = {
          moolaShloka: moola,
          kannadaTransliteration: ensurePureKannadaTransliteration('', moola),
          padartha: formatPadarthaWithDevanagariPadas(completed.padartha),
          saralaVivarane: ensurePureKannadaScript(cleanRepetitiveLoops(completed.saralaVivarane)),
          vivaradaVyakhyana: ensurePureKannadaScript(cleanRepetitiveLoops(completed.vivaradaVyakhyana)),
        };
      } else {
        if (completed.padartha) {
          unit.output.padartha = formatPadarthaWithDevanagariPadas(completed.padartha);
        }
        if (completed.saralaVivarane) {
          unit.output.saralaVivarane = ensurePureKannadaScript(cleanRepetitiveLoops(completed.saralaVivarane));
        }
        if (completed.vivaradaVyakhyana) {
          unit.output.vivaradaVyakhyana = ensurePureKannadaScript(cleanRepetitiveLoops(completed.vivaradaVyakhyana));
        }
      }

      // Re-validate unit against standard Sanskrit-Kannada criteria
      const val = validateSanskritUnitOutput(unit);
      unit.validationScore = val.score;
      unit.validationIssues = val.issues;
      unit.status = val.isValid ? 'COMPLETED' : 'REVIEW_REQUIRED';

      await saveUnit(unit);
      res.json({ success: true, unit });
    } catch (err: any) {
      console.error(`Error repairing section for unit ${req.params.id}:`, err);
      res.status(500).json({ error: err.message });
    }
  });

  // Real-time SSE Live Streaming Endpoint for Shloka Generation
  app.get('/api/units/:id/stream', async (req, res) => {
    try {
      const unit = await getUnitById(req.params.id);
      if (!unit) {
        return res.status(404).json({ error: 'Unit not found' });
      }

      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');
      res.flushHeaders?.();

      const sendEvent = (event: string, data: any) => {
        res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
      };

      // HEADINGS & COLOPHONS:
      if (isHeadingOrColophonUnit(unit)) {
        unit.unitType = unit.unitType === 'COLOPHON' || classifyTextBlock(unit.originalText).isColophon ? 'COLOPHON' : 'HEADING';
        const normText = normalizeSanskritVerse(unit.originalText);
        const kannadaTrans = devanagariToKannada(normText);
        const headingDisplay = `॥ ${kannadaTrans} ॥`;
        sendEvent('status', { message: 'ಶೀರ್ಷಿಕೆ/ಪುಷ್ಪಿಕಾ - ನೇರ ಕನ್ನಡ ಲಿಪ್ಯಂತರ...' });
        sendEvent('chunk', { chunk: headingDisplay, fullTextSoFar: headingDisplay });
        unit.verifiedText = normText;
        unit.confidence = 'HIGH';
        unit.output = {
          moolaShloka: normText,
          kannadaTransliteration: kannadaTrans,
          padartha: '',
          saralaVivarane: '',
          vivaradaVyakhyana: '',
        };
        unit.status = 'COMPLETED';
        unit.validationScore = 100;
        unit.validationIssues = [];
        await saveUnit(unit);
        sendEvent('complete', { unit });
        return res.end();
      }

      // Step 1: verify
      const ver = await verifySanskritUnit(unit.originalText, unit.detectedWork, unit.structuralHierarchy.formattedNumber);
      unit.verifiedText = ver.verifiedText;
      unit.confidence = ver.confidence;
      unit.sourceVerification = {
        referenceSource: ver.referenceSource,
        matchedWork: ver.matchedWork,
        matchedVerseNum: ver.matchedVerseNum,
        confidenceScore: ver.confidenceScore,
        notes: ver.notes,
        diffFound: ver.diffFound,
      };

      sendEvent('status', { message: 'Gemini AI ಲೈವ್ ಸಂಸ್ಕರಣೆ ಮತ್ತು ವ್ಯಾಖ್ಯಾನ ರಚನೆ...' });

      // Step 2: Stream generate
      const gen = await generateScholarlyUnitContentStream(
        unit,
        (chunk) => {
          sendEvent('chunk', { chunk: chunk.text, fullTextSoFar: chunk.fullTextSoFar });
        },
        0.1
      );

      unit.output = {
        moolaShloka: gen.moolaShloka,
        kannadaTransliteration: gen.kannadaTransliteration,
        padartha: gen.padartha,
        saralaVivarane: gen.saralaVivarane,
        vivaradaVyakhyana: gen.vivaradaVyakhyana,
        visualAnalysis: gen.visualAnalysis,
        tableContent: gen.tableContent,
        diagramContent: gen.diagramContent,
        pictureContent: gen.pictureContent,
      };

      // Step 3: validate
      const val = validateSanskritUnitOutput(unit);
      unit.validationScore = val.score;
      unit.validationIssues = val.issues;
      unit.status = val.isValid ? 'COMPLETED' : 'REVIEW_REQUIRED';

      await saveUnit(unit);

      sendEvent('complete', { unit });
      res.end();
    } catch (err: any) {
      console.error('Streaming error:', err);
      res.write(`event: error\ndata: ${JSON.stringify({ error: err.message || String(err) })}\n\n`);
      res.end();
    }
  });

  // Project Processing Control
  app.post('/api/projects/:id/start', async (req, res) => {
    try {
      const projectId = req.params.id;
      const force = req.body?.force === true || req.query?.force === 'true';
      const project = await getProjectById(projectId);
      if (!project) {
        return res.status(404).json({ success: false, error: 'ಪ್ರಕಲ್ಪ ಕಂಡುಬಂದಿಲ್ಲ (Project not found).' });
      }
      const units = await getUnitsByProjectId(projectId);
      if (units.length === 0) {
        return res.status(400).json({
          success: false,
          error: 'ಯಾವುದೇ ಶ್ಲೋಕಗಳು ಕಂಡುಬಂದಿಲ್ಲ. ಮೊದಲು PDF ಅಥವಾ ಪಠ್ಯ ದಾಖಲೆಯನ್ನು ಅಪ್ಲೋಡ್ ಮಾಡಿ (No shlokas found in project).',
        });
      }

      // Trigger background runner asynchronously
      startOrResumeProjectProcessing(projectId, undefined, force).catch(err => {
        console.error('Background processing error:', err);
      });
      res.json({ success: true, message: 'Processing started', totalUnits: units.length });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Reprocess all units in project
  app.post('/api/projects/:id/reprocess-all', async (req, res) => {
    try {
      const projectId = req.params.id;
      const project = await getProjectById(projectId);
      if (!project) {
        return res.status(404).json({ success: false, error: 'ಪ್ರಕಲ್ಪ ಕಂಡುಬಂದಿಲ್ಲ (Project not found).' });
      }
      const units = await getUnitsByProjectId(projectId);
      if (units.length === 0) {
        return res.status(400).json({ success: false, error: 'No units found in project.' });
      }

      startOrResumeProjectProcessing(projectId, undefined, true).catch(err => {
        console.error('Background reprocessing error:', err);
      });
      res.json({ success: true, message: 'Reprocessing started for all units', totalUnits: units.length });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  app.post('/api/projects/:id/pause', (req, res) => {
    try {
      pauseProjectProcessing(req.params.id);
      res.json({ success: true, message: 'Processing paused' });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  app.post('/api/projects/:id/cancel', (req, res) => {
    try {
      cancelProjectProcessing(req.params.id);
      res.json({ success: true, message: 'Processing cancelled' });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Project Activity Logs
  app.get('/api/projects/:id/logs', (req, res) => {
    try {
      const logs = getProjectLogs(req.params.id);
      res.json(logs);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.delete('/api/projects/:id/logs', (req, res) => {
    try {
      clearProjectLogs(req.params.id);
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Real-time SSE Live Streaming Endpoint for Project (Live letters/words being generated during batch runs)
  app.get('/api/projects/:id/live-stream', (req, res) => {
    const projectId = req.params.id;
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders?.();

    // Send initial live state if any
    const currentState = getProjectLiveState(projectId);
    if (currentState) {
      res.write(`event: state\ndata: ${JSON.stringify(currentState)}\n\n`);
    }

    const unsubscribe = subscribeProjectStream(projectId, (event) => {
      res.write(`event: ${event.type}\ndata: ${JSON.stringify(event.data)}\n\n`);
    });

    req.on('close', () => {
      unsubscribe();
    });
  });

  // Project Live State GET endpoint
  app.get('/api/projects/:id/live-state', (req, res) => {
    try {
      const state = getProjectLiveState(req.params.id);
      res.json(state || { accumulatedText: '', latestChunk: '', charCount: 0 });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ===================== EXPORTS =====================

  // 0. Pure Shloka & Explanation DOCX (Focused Edition)
  app.get('/api/projects/:id/export/pure-docx', async (req, res) => {
    try {
      const project = await getProjectById(req.params.id);
      if (!project) return res.status(404).json({ error: 'Project not found' });
      const units = await getUnitsByProjectId(req.params.id);
      const settings = await getSettings();

      const fontDeva = (req.query.fontDevanagari as string) || settings.outputFontDevanagari || 'Nirmala UI';
      const fontKan = (req.query.fontKannada as string) || settings.outputFontKannada || 'Nirmala UI';

      const buffer = await generatePureShlokaDocx(
        project,
        units,
        fontDeva,
        fontKan,
        settings.fontSizePt
      );

      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
      res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(project.name)}_PURE_SHLOKA_EXPLANATION.docx"`);
      res.send(buffer);
    } catch (err: any) {
      console.error('Export Pure DOCX error:', err);
      res.status(500).json({ error: err.message });
    }
  });

  // 0b. Pure Shloka Plain Text / Markdown
  app.get('/api/projects/:id/export/pure-txt', async (req, res) => {
    try {
      const project = await getProjectById(req.params.id);
      if (!project) return res.status(404).json({ error: 'Project not found' });
      const units = await getUnitsByProjectId(req.params.id);

      const text = generatePureShlokaText(project, units);
      res.setHeader('Content-Type', 'text/plain; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(project.name)}_PURE_SHLOKA.txt"`);
      res.send(text);
    } catch (err: any) {
      console.error('Export Pure TXT error:', err);
      res.status(500).json({ error: err.message });
    }
  });

  // 0c. Pure Shloka Reading Edition PDF
  app.get('/api/projects/:id/export/pdf', async (req, res) => {
    try {
      const project = await getProjectById(req.params.id);
      if (!project) return res.status(404).json({ error: 'Project not found' });
      const units = await getUnitsByProjectId(req.params.id);

      const buffer = await generatePureShlokaPdf(project, units);
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(project.name)}_PURE_SCHOLARLY.pdf"`);
      res.send(buffer);
    } catch (err: any) {
      console.error('Export PDF error:', err);
      res.status(500).json({ error: err.message });
    }
  });

  // 1. Master DOCX
  app.get('/api/projects/:id/export/docx', async (req, res) => {
    try {
      const project = await getProjectById(req.params.id);
      if (!project) return res.status(404).json({ error: 'Project not found' });
      const units = await getUnitsByProjectId(req.params.id);
      const settings = await getSettings();

      const fontDeva = (req.query.fontDevanagari as string) || settings.outputFontDevanagari || 'Nirmala UI';
      const fontKan = (req.query.fontKannada as string) || settings.outputFontKannada || 'Nirmala UI';

      const buffer = await generateMasterDocx(
        project,
        units,
        fontDeva,
        fontKan,
        settings.fontSizePt
      );

      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
      res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(project.name)}_FINAL_SCHOLARLY_MANUSCRIPT.docx"`);
      res.send(buffer);
    } catch (err: any) {
      console.error('Export DOCX error:', err);
      res.status(500).json({ error: err.message });
    }
  });

  // 2. Complete Audit XLSX
  app.get('/api/projects/:id/export/audit-xlsx', async (req, res) => {
    try {
      const project = await getProjectById(req.params.id);
      if (!project) return res.status(404).json({ error: 'Project not found' });
      const docs = await getDocumentsByProjectId(req.params.id);
      const units = await getUnitsByProjectId(req.params.id);

      const buffer = await generateCompleteAuditXlsx(project, docs, units);
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(project.name)}_COMPLETE_AUDIT.xlsx"`);
      res.send(buffer);
    } catch (err: any) {
      console.error('Export XLSX error:', err);
      res.status(500).json({ error: err.message });
    }
  });

  // 3. Shloka Index XLSX
  app.get('/api/projects/:id/export/shloka-index', async (req, res) => {
    try {
      const units = await getUnitsByProjectId(req.params.id);
      const buffer = await generateShlokaIndexXlsx(units);
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename="SHLOKA_INDEX.xlsx"`);
      res.send(buffer);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 4. Final Package ZIP
  app.get('/api/projects/:id/export/zip', async (req, res) => {
    try {
      const project = await getProjectById(req.params.id);
      if (!project) return res.status(404).json({ error: 'Project not found' });
      const docs = await getDocumentsByProjectId(req.params.id);
      const units = await getUnitsByProjectId(req.params.id);

      const buffer = await generateFinalPackageZip(project, docs, units);
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(project.name)}_FINAL_PACKAGE.zip"`);
      res.send(buffer);
    } catch (err: any) {
      console.error('Export ZIP error:', err);
      res.status(500).json({ error: err.message });
    }
  });

  // 5. Standalone Desktop / Laptop Offline Bundle ZIP
  app.get('/api/desktop/download-offline-pack', async (req, res) => {
    try {
      const buffer = await generateDesktopOfflineBundle();
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="GRANTHA_ENGINE_DESKTOP_OFFLINE_BUNDLE.zip"');
      res.send(buffer);
    } catch (err: any) {
      console.error('Download Desktop Bundle error:', err);
      res.status(500).json({ error: err.message });
    }
  });

  // Error handling middleware for API routes / Multer
  app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (req.path.startsWith('/api/')) {
      console.error('API Error:', err);
      const statusCode = err.status || (err.code === 'LIMIT_FILE_SIZE' ? 413 : 500);
      return res.status(statusCode).json({
        error: err.code === 'LIMIT_FILE_SIZE' 
          ? 'ಕಡತದ ಗಾತ್ರ 100MB ಮಿತಿಗಿಂತ ಹೆಚ್ಚಾಗಿದೆ (File exceeds 100MB limit)' 
          : err.message || 'Internal Server Error',
      });
    }
    next(err);
  });

  // Catch-all for undefined /api routes so they NEVER fall through to Vite HTML
  app.all('/api/*', (req, res) => {
    res.status(404).json({ error: `API route not found: ${req.method} ${req.originalUrl}` });
  });

  // ===================== VITE & STATIC SERVING =====================

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Universal Sanskrit -> Kannada Grantha Engine running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Server start error:', err);
});
